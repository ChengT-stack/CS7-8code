# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/lr_asymmetry/lr_asym.py (2026-10-03; artifact a79bc571, session 0b0712b4)
# sha256 of original: 7fc41269d32d4144543fb4a3360d8358c83888606e259aba09f5bd5709e2b21a
# Methods paragraphs: Supplementary Figure 5C-E legends
# Produces: cs8_lr_asymmetry_tests.csv / _all_genes.csv / cs8_lr_asymmetry.{png,pdf} (STAGE=CS8; STAGE=CS7 needs
#     export_cs7_disc.R); also the statistics engine exec-ed by lr_asym_lpm.py and
#     compute_lpm_map_profiles_data.py
# Edits/notes: h5ad path -> HGC_DATA; seeds unchanged (default_rng(7)).
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

"""Left-right asymmetry test for DLL1 / NOTCH1 (and the canonical LR genes) in one stage.
STAGE=CS8 reads cs8_kept_counts.h5ad (all kept CS8 cells); STAGE=CS7 reads handoff/cs7_disc_*.
Steps: (1) midline = LOWESS of LR on AP through the axial-chain cells, LR' = LR - midline(AP);
(2) per-population LR' profiles of detection with bootstrap CI (15-um bins = physical sections);
(3) genome-wide null: asymmetry index for every gene with >=2% detection in that population, on a
    MIRRORED window |LR'| in [20, Wmax] (Wmax = the smaller side's extent, so edge truncation cannot bias it);
(4) depth: nCount compared between sides; Fisher on detection and a permutation test with side labels
    shuffled within AP x DV bins for the target genes."""
import os, sys, json, textwrap
for k,v in [("KMP_AFFINITY","disabled"),("OMP_NUM_THREADS","8"),("KMP_INIT_AT_FORK","FALSE")]: os.environ.setdefault(k,v)
import numpy as np, pandas as pd, scipy.sparse as ssp
from scipy.stats import fisher_exact, mannwhitneyu
from statsmodels.nonparametric.smoothers_lowess import lowess
import matplotlib as mpl; mpl.use("Agg"); import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
sys.path.insert(0,os.getcwd()); from figure_style import apply_figure_style, panel_letter
META="#8A8A8A"; STAGE=os.environ.get("STAGE","CS8"); rng=np.random.default_rng(7)
if STAGE=="CS8":
    import anndata as ad
    A=ad.read_h5ad(str(DATA / "cs8_kept_counts.h5ad"))
    obs=A.obs; lab=obs.label.astype(str).to_numpy(); disc=obs.disc.to_numpy(bool)
    C=np.c_[obs.y,obs.z,obs.x].astype(float); X=ssp.csc_matrix(A.X); genes=np.array(A.var_names); nC=obs.nCount.to_numpy(float)
    AXIAL=["Node","Notochord","Prechordal plate","Primitive streak (PS)"]
    POPS={"Node":["Node"],"Notochord":["Notochord"],"PS":["Primitive streak (PS)"],"Para.Meso":["Paraxial mesoderm (Para.Meso)"],
          "Nas.Meso":["Nascent mesoderm (Nas.Meso)"],"LP.Meso":["Lateral plate mesoderm (LP.Meso)"],"Rostral.Meso":["Rostral mesoderm (Rostral.Meso)"],
          "EPI":["Epiblast (EPI)"],"DE":["Definitive endoderm (DE)"],"Heart meso":["Heart mesoderm"]}
    # AP sign check: PS posterior to prechordal plate (as in cs8_genes.py)
    ok=np.isfinite(C).all(1); C-=np.median(C[disc&ok],0)
    assert np.median(C[(lab=="Primitive streak (PS)")&ok,0])>np.median(C[(lab=="Prechordal plate")&ok,0])
else:
    from scipy.io import mmread
    X=ssp.csc_matrix(mmread("handoff/cs7_disc_counts.mtx").T); genes=pd.read_csv("handoff/cs7_disc_genes.csv").gene.to_numpy()
    cells=pd.read_csv("handoff/cs7_disc_cells.csv"); lab=cells.label.to_numpy(); nC=cells.nCount.to_numpy(float)
    # CS7 frame (project convention, verified earlier): AP = -x, LR = z, view/DV = y
    C=np.c_[-cells.x,cells.z,cells.y].astype(float); ok=np.isfinite(C).all(1); disc=np.ones(len(lab),bool); C-=np.median(C[ok],0)
    assert np.median(C[(lab=="Primitive streak (PS)")&ok,0])>np.median(C[(lab=="Anterior visceral endoderm (AVE)")&ok,0])
    AXIAL=["Node","Anterior primitive streak (APS)","Primitive streak (PS)"]
    POPS={"Node":["Node"],"APS":["Anterior primitive streak (APS)"],"PS":["Primitive streak (PS)"],"EPI":["Epiblast (EPI)"],"ECT":["Ectoderm (ECT)"],
          "DE":["Definitive endoderm (DE)"],"AVE":["Anterior visceral endoderm (AVE)"],"VE1":["Visceral endoderm 1 (VE1)"],"VE2":["Visceral endoderm 2 (VE2)"],
          "Exe.Meso prog":["Extraembryonic mesoderm progenitor (Exe.Meso progenitor)"]}
gi={g:i for i,g in enumerate(genes)}
# ---------- (1) midline ----------
ax_=np.isin(lab,AXIAL)&ok
lo_=lowess(C[ax_,1],C[ax_,0],frac=0.4,it=2,return_sorted=True)
apmin,apmax=C[ax_,0].min(),C[ax_,0].max()
def midline(ap): return np.interp(np.clip(ap,apmin,apmax),lo_[:,0],lo_[:,1])
LRp=C[:,1]-midline(C[:,0]); LRp[~ok]=np.nan
res_sd=np.std(LRp[ax_]); 
print(f"[{STAGE}] midline: LOWESS through {int(ax_.sum()):,} axial cells ({', '.join(AXIAL)}); LR at AP -400/-200/0/+200: "
      f"{[round(float(midline(a))) for a in [-400,-200,0,200]]} um; axial residual SD {res_sd:.0f} um",flush=True)
for pn in AXIAL:
    m=(lab==pn)&ok; print(f"    {pn:32s} median LR' {np.median(LRp[m]):+5.0f}  (n {int(m.sum())})")
# ---------- side definition, mirrored window ----------
TARGET=["DLL1","NOTCH1"]; LRGENES=["NODAL","LEFTY1","LEFTY2","PITX2","DAND5","CER1","GDF1","SHH"]
GSHOW=TARGET+[g for g in LRGENES if g in gi]
MID=20.0
def pop_mask(pn): return np.isin(lab,POPS[pn])&ok&np.isfinite(LRp)
rows=[]; NULL={}; PROF={}
for pn in POPS:
    m=pop_mask(pn)
    if m.sum()<40: continue
    wmax=min(np.percentile(-LRp[m&(LRp<0)],98) if (m&(LRp<0)).sum()>5 else 0, np.percentile(LRp[m&(LRp>0)],98) if (m&(LRp>0)).sum()>5 else 0)
    win=m&(np.abs(LRp)>=MID)&(np.abs(LRp)<=wmax)
    L=win&(LRp<0); R=win&(LRp>0)
    if L.sum()<15 or R.sum()<15: continue
    depth_p=mannwhitneyu(nC[L],nC[R]).pvalue
    # genome-wide null on detection-filtered genes
    sub=X[np.where(win)[0],:]; det=np.asarray((sub>0).mean(0)).ravel(); keep=det>=0.02
    XL=X[np.where(L)[0],:][:,keep]; XR=X[np.where(R)[0],:][:,keep]
    cpL=np.asarray(XL.multiply(1e4/nC[L][:,None]).mean(0)).ravel(); cpR=np.asarray(XR.multiply(1e4/nC[R][:,None]).mean(0)).ravel()
    AI=(cpL-cpR)/(cpL+cpR+1e-9); gk=genes[keep]
    NULL[pn]=dict(AI=AI,genes=gk,nL=int(L.sum()),nR=int(R.sum()),wmax=float(wmax),depth_p=depth_p,
                  med=float(np.median(AI)),mad=float(1.4826*np.median(np.abs(AI-np.median(AI)))))
    # AP x DV bins for the permutation test
    bins=np.zeros(len(lab),int); q=np.where(win)[0]
    ba=np.digitize(C[q,0],np.percentile(C[q,0],[25,50,75])); bd=np.digitize(C[q,2],np.percentile(C[q,2],[33,67])); bins[q]=ba*3+bd
    for g in GSHOW:
        j=gi[g]; v=np.asarray(X[:,j].todense()).ravel()
        dL,dR=(v[L]>0).mean(),(v[R]>0).mean(); cL,cR=(v[L]/nC[L]*1e4).mean(),(v[R]/nC[R]*1e4).mean()
        ai=(cL-cR)/(cL+cR+1e-9); z=(ai-NULL[pn]["med"])/NULL[pn]["mad"] if NULL[pn]["mad"]>0 else np.nan
        pct=float((np.abs(AI-NULL[pn]["med"])>=abs(ai-NULL[pn]["med"])).mean())
        pf=fisher_exact([[int((v[L]>0).sum()),int(L.sum()-(v[L]>0).sum())],[int((v[R]>0).sum()),int(R.sum()-(v[R]>0).sum())]])[1]
        # permutation: shuffle side within AP x DV bins
        side=np.zeros(len(lab),int); side[L]=-1; side[R]=1; obs_d=cL-cR; null_d=[]
        cpv=v/nC*1e4
        for _ in range(500):
            s2=side.copy()
            for b in np.unique(bins[q]):
                ii=q[bins[q]==b]; s2[ii]=rng.permutation(side[ii])
            null_d.append(cpv[s2==-1].mean()-cpv[s2==1].mean())
        pperm=float((np.abs(null_d)>=abs(obs_d)).mean())
        rows.append(dict(stage=STAGE,pop=pn,gene=g,nL=int(L.sum()),nR=int(R.sum()),window_um=round(wmax),detL_pct=round(100*dL,2),detR_pct=round(100*dR,2),
                         meanL=round(cL,4),meanR=round(cR,4),asym_index=round(ai,3),z_vs_genome=round(z,2),genome_pct_more_extreme=round(pct,3),
                         fisher_p=pf,perm_p=pperm,depth_p=depth_p))
    # LR' profiles (15-um bins) for the shown genes, detection with bootstrap CI
    edges=np.arange(-wmax-7.5,wmax+7.6,15.0); ctr=(edges[:-1]+edges[1:])/2
    for g in GSHOW:
        v=np.asarray(X[:,gi[g]].todense()).ravel()>0
        d=[]; lo=[]; hi=[]
        for a,b in zip(edges[:-1],edges[1:]):
            s=m&(LRp>=a)&(LRp<b); n=int(s.sum())
            if n<8: d.append(np.nan); lo.append(np.nan); hi.append(np.nan); continue
            vv=v[s].astype(float); d.append(vv.mean()); bs=rng.choice(vv,(300,n)).mean(1); lo.append(np.percentile(bs,2.5)); hi.append(np.percentile(bs,97.5))
        PROF[(pn,g)]=(ctr,np.array(d),np.array(lo),np.array(hi))
T=pd.DataFrame(rows); T.to_csv(f"{STAGE.lower()}_lr_asymmetry_tests.csv",index=False)
NG=pd.concat([pd.DataFrame(dict(stage=STAGE,pop=pn,gene=d["genes"],asym_index=np.round(d["AI"],4))) for pn,d in NULL.items()])
NG.to_csv(f"{STAGE.lower()}_lr_asymmetry_all_genes.csv",index=False)
print(f"\n[{STAGE}] sides (mirrored window, |LR'| in [20, Wmax]) and depth balance:")
for pn,d in NULL.items(): print(f"    {pn:14s} L {d['nL']:5d} R {d['nR']:5d}  Wmax {d['wmax']:4.0f} um  nCount L vs R p={d['depth_p']:.3g}  genome AI median {d['med']:+.3f} MAD {d['mad']:.3f}")
print(f"\n[{STAGE}] DLL1 / NOTCH1:")
print(T[T.gene.isin(TARGET)][["pop","gene","nL","nR","detL_pct","detR_pct","asym_index","z_vs_genome","genome_pct_more_extreme","fisher_p","perm_p"]].to_string(index=False))
print(f"\n[{STAGE}] canonical LR genes with |z| >= 2 or perm_p < 0.01:")
S=T[~T.gene.isin(TARGET)&((T.z_vs_genome.abs()>=2)|(T.perm_p<0.01))]
print(S[["pop","gene","nL","nR","detL_pct","detR_pct","asym_index","z_vs_genome","fisher_p","perm_p"]].to_string(index=False) if len(S) else "    none")
# ---------- figure ----------
plt.close("all"); apply_figure_style()
SHOWP=[p for p in POPS if p in NULL]
fig=plt.figure(figsize=(16.2,13.6))
# (a) dorsal view with midline, DLL1 / NOTCH1 detection
dm=disc&ok if STAGE=="CS8" else ok
for i,g in enumerate(TARGET):
    ax=fig.add_axes([0.045+i*0.33,0.70,0.30,0.215]); v=np.asarray(X[:,gi[g]].todense()).ravel()>0
    ax.scatter(C[dm,0],C[dm,1],s=.6,color="#E8E8E8",lw=0)
    q=np.where(dm&v)[0]; ax.scatter(C[q,0],C[q,1],s=2.2,color="#C2401A",lw=0,alpha=.7)
    apg=np.linspace(apmin,apmax,200); ax.plot(apg,midline(apg),color="#111111",lw=1.2); ax.plot(apg,midline(apg)+MID,color="#111111",lw=.5,ls=":"); ax.plot(apg,midline(apg)-MID,color="#111111",lw=.5,ls=":")
    ax.set_aspect("equal"); ax.set_xlabel("anterior \u2192 posterior (\u00b5m)",fontsize=7); ax.set_ylabel("LR (\u00b5m), raw",fontsize=7); ax.tick_params(labelsize=6)
    ax.set_title(f"{'ab'[i]}   {g}: cells with \u2265 1 count ({len(q):,}); black = fitted midline, dotted = \u00b120 \u00b5m",loc="left",fontsize=7.8)
ax=fig.add_axes([0.72,0.70,0.26,0.215]); 
for pn,c in zip(AXIAL,["#2E6B4F","#00A383","#D97706","#7B4FA3"]):
    m=(lab==pn)&ok; ax.scatter(C[m,0],C[m,1],s=1.4,color=c,lw=0,label=f"{pn.split(' (')[0]} ({int(m.sum())})")
apg=np.linspace(apmin,apmax,200); ax.plot(apg,midline(apg),color="#111111",lw=1.2)
ax.set_aspect("equal"); ax.legend(fontsize=5.8,frameon=False,markerscale=4,loc="lower left"); ax.tick_params(labelsize=6)
ax.set_title("c   axial chain used for the midline (LOWESS, frac 0.4)",loc="left",fontsize=7.8); ax.set_xlabel("AP (\u00b5m)",fontsize=7)
# (d) profiles: rows = genes (DLL1, NOTCH1, NODAL, LEFTY2, PITX2, DAND5), cols = populations
PG=[g for g in ["DLL1","NOTCH1","NODAL","LEFTY2","PITX2","DAND5","CER1"] if g in gi][:6]
PP=[p for p in SHOWP][:8]
gw=(0.985-0.045-0.012*(len(PP)-1))/len(PP); gh=(0.655-0.30-0.010*(len(PG)-1))/len(PG)
for r,g in enumerate(PG):
    for c_,pn in enumerate(PP):
        ax=fig.add_axes([0.045+c_*(gw+0.012),0.655-(r+1)*gh-r*0.010,gw,gh])
        ctr,d,lo,hi=PROF[(pn,g)]; col="#C2401A" if g in TARGET else "#1F6FB2"
        ax.fill_between(ctr,lo,hi,color=col,alpha=.18,lw=0); ax.plot(ctr,d,color=col,lw=1.2)
        ax.axvline(0,color="#111111",lw=.6); ax.axvspan(-MID,MID,color="#DDDDDD",alpha=.5,lw=0)
        ax.set_xlim(-NULL[pn]["wmax"]-10,NULL[pn]["wmax"]+10); ax.set_ylim(0,max(np.nanmax(hi) if np.isfinite(hi).any() else 0.05,0.02)*1.1)
        ax.tick_params(labelsize=5.2); ax.spines[["top","right"]].set_visible(False)
        rr=T[(T["pop"]==pn)&(T.gene==g)].iloc[0]
        ax.text(.03,.95,f"AI {rr.asym_index:+.2f}  z {rr.z_vs_genome:+.1f}  p {rr.perm_p:.2f}",transform=ax.transAxes,fontsize=5.0,va="top",
                color="#C2401A" if (abs(rr.z_vs_genome)>=2 and rr.perm_p<0.01) else "#777777")
        if r==0: ax.set_title(f"{pn}  (L {NULL[pn]['nL']} / R {NULL[pn]['nR']})",fontsize=6.4,loc="left")
        if c_==0: ax.set_ylabel(f"{g}\ndetection",fontsize=6.2)
        if r<len(PG)-1: ax.tick_params(labelbottom=False)
        else: ax.set_xlabel("LR\u2032 (\u00b5m)",fontsize=6)
panel_letter(fig.axes[3],"d")
# (e) genome-wide null histograms with DLL1 / NOTCH1 marked
NP_=[p for p in PP][:8]; hw=(0.985-0.045-0.012*(len(NP_)-1))/len(NP_)
for c_,pn in enumerate(NP_):
    ax=fig.add_axes([0.045+c_*(hw+0.012),0.045,hw,0.17]); AI=NULL[pn]["AI"]
    ax.hist(AI,bins=np.linspace(-1,1,61),color="#BBBBBB",lw=0)
    for g,col in [("DLL1","#C2401A"),("NOTCH1","#7B4FA3")]:
        rr=T[(T["pop"]==pn)&(T.gene==g)].iloc[0]; ax.axvline(rr.asym_index,color=col,lw=1.3)
        ax.text(rr.asym_index,ax.get_ylim()[1]*(0.92 if g=="DLL1" else 0.80),f"{g} {rr.asym_index:+.2f}",color=col,fontsize=5.4,ha="left" if rr.asym_index<0 else "right",
                path_effects=[pe.withStroke(linewidth=1.5,foreground="white")])
    ax.set_xlim(-1,1); ax.tick_params(labelsize=5.4); ax.spines[["top","right"]].set_visible(False)
    ax.set_title(f"{pn}: {len(AI):,} genes",fontsize=6.4,loc="left"); ax.set_xlabel("asymmetry index (L\u2212R)/(L+R)",fontsize=6)
    if c_==0: ax.set_ylabel("genes",fontsize=6.4)
panel_letter(fig.axes[3+len(PG)*len(PP)],"e")
fig.text(.006,.985,f"Is DLL1 or NOTCH1 left\u2013right asymmetric at {STAGE}? Midline fit, per-population LR\u2032 profiles, and a genome-wide control",fontsize=10.6)
fig.text(.006,.962,"\n".join(textwrap.fill(
 f"{STAGE} ({'obj7' if STAGE=='CS8' else 'obj6'}), 39Type, curation-kept. The midline is a LOWESS fit of LR on AP through the axial-chain cells ({', '.join(a.split(' (')[0] for a in AXIAL)}); LR\u2032 = LR \u2212 midline(AP), residual SD of the axial cells {res_sd:.0f} \u00b5m. "
 f"'Left' = LR\u2032 < 0 is the sample's \u2212LR side; WHICH SIDE IS ANATOMICAL LEFT IS NOT KNOWN, so the canonical left-side genes (NODAL, LEFTY2, PITX2; DAND5 right-biased in mouse) are shown as the reference. "
 f"Sides are compared on a MIRRORED window |LR\u2032| in [20, Wmax] where Wmax is the smaller side's 98th-percentile extent, so edge truncation of one side cannot bias the comparison. "
 f"AI = (meanL \u2212 meanR)/(meanL + meanR) on CP10K; z = AI relative to the median and MAD of the SAME index over every gene detected in \u2265 2% of that population's cells (panel e), which absorbs section-batch and depth effects shared by all genes; "
 f"p = permutation test (500 shuffles of the side label within AP \u00d7 DV bins). Red annotation = |z| \u2265 2 AND p < 0.01. Profiles (d): detection per 15-\u00b5m bin (one physical section), band = bootstrap 95% CI; grey strip = the excluded midline.",232).split("\n")),
 fontsize=6.0,color=META,linespacing=1.5,va="top")
for e in ["png","pdf"]: fig.savefig(f"{STAGE.lower()}_lr_asymmetry.{e}",**({"dpi":175} if e=="png" else {}),bbox_inches="tight")
fig.canvas.draw(); r_=fig.canvas.get_renderer()
tx=[(t,t.get_window_extent(r_)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
tk={t for a_ in fig.axes for t in a_.get_xticklabels()+a_.get_yticklabels()}
print("\noverlaps:",[(a.get_text()[:14],b.get_text()[:14]) for i_,(a,ba) in enumerate(tx) for b,bb in tx[i_+1:] if ba.overlaps(bb) and not (a in tk or b in tk)][:6])
