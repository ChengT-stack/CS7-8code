# Build representations (scVI-integrated, UCE-PCA, concat) + endpoint pairings for mouse/monkey/human intervals.
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import numpy as np, pandas as pd, anndata as ad, ot, glob, os, warnings; warnings.filterwarnings('ignore')
from sklearn.decomposition import PCA
rng=np.random.default_rng(0); B=DATA + '/cs7_cs8_matching/'
H=ad.read_h5ad('ai/integrated_scvi.h5ad'); o=H.obs.copy(); uid=o.index.values; n=len(o)
REP={'scvi30':H.obsm['X_scVI'].astype(np.float32)}
U=np.full((n,1280),np.nan,np.float32); pos={u:i for i,u in enumerate(uid)}
for f in sorted(glob.glob(DATA + '/UCE/out/*_uce_adata.h5ad')):
    a=ad.read_h5ad(f); ix=[pos[x] for x in a.obs_names]; U[ix]=a.obsm['X_uce']; print(os.path.basename(f),a.n_obs,flush=True)
okU=~np.isnan(U).any(1); print('UCE coverage',okU.sum(),'/',n)
# PCA on a dataset-balanced subsample (<=3000 per dataset) so no platform dominates the axes
sub=np.concatenate([rng.choice(ix,min(3000,len(ix)),replace=False) for ix in o[okU].groupby('dataset').indices.values()])
sub=np.where(okU)[0][sub] if False else np.concatenate([rng.choice(np.where(okU&(o.dataset.values==d))[0],min(3000,int((okU&(o.dataset.values==d)).sum())),replace=False) for d in o.dataset.unique()])
P=PCA(128,random_state=0).fit(U[sub]); Up=np.full((n,128),np.nan,np.float32); Up[okU]=P.transform(U[okU]); print('UCE PCA var 32/64/128',P.explained_variance_ratio_[:32].sum().round(3),P.explained_variance_ratio_[:64].sum().round(3),P.explained_variance_ratio_.sum().round(3))
for k in [32,64,128]: REP[f'uce_pca{k}']=Up[:,:k]
def zs(X): m=np.nanmean(X[sub],0); s=np.nanstd(X[sub],0)+1e-6; return ((X-m)/s).astype(np.float32)
REP={k:zs(v) for k,v in REP.items()}
import harmonypy
bat=o['batch'].astype(str).values
ho=harmonypy.run_harmony(Up[:,:64],pd.DataFrame({'b':bat}),'b',random_state=0,max_iter_harmony=20)
Hm=np.asarray(ho.Z_corr); Hm=Hm.T if Hm.shape[0]==64 else Hm
REP['uce_harm64']=zs(Hm.astype(np.float32))
REP['concat']=np.hstack([REP['scvi30'],REP['uce_pca64']*np.sqrt(30/64)]).astype(np.float32)
REP['concat_harm']=np.hstack([REP['scvi30'],REP['uce_harm64']*np.sqrt(30/64)]).astype(np.float32)
for k in ['uce_pca32','uce_pca128']: REP.pop(k)
valid=okU.copy()   # use the same cells for every representation
ds=o.dataset.values; grp=o.group.values.astype(str); mt=o.mouse_time.values.astype(float)
STG=[6.5,6.75,7.0,7.25,7.5,7.75,8.0,8.25,8.5]
def cells(mask): return np.where(mask&valid)[0]
def stage(s): return cells(mt==s)
def pair(ia,ib,Z,cap=3000):
    ia=rng.choice(ia,min(cap,len(ia)),replace=False) if len(ia)>cap else ia
    M=ot.dist(Z[ia],Z[ib]); M/=M.max(); G=ot.emd(np.ones(len(ia))/len(ia),np.ones(len(ib))/len(ib),M,numItermax=2000000)
    W=G/G.sum(1,keepdims=True); cen=W@Z[ib]; top=ib[G.argmax(1)]
    gb=np.array(sorted(set(grp))); Wg=np.stack([W[:,grp[ib]==g].sum(1) for g in gb],1); dom=gb[Wg.argmax(1)]
    return ia,cen.astype(np.float32),top,dom
out={}
for rk,Z in REP.items():
    D={'Z':Z,'valid':valid}
    for i,a in enumerate(STG):            # mouse pairs with spacing 0.25 (flow), 0.5 and 1.0 (triplet endpoints)
        for b in STG[i+1:]:
            if round(b-a,2) not in (0.25,0.5,1.0): continue
            ia,cen,top,dom=pair(stage(a),stage(b),Z); key=f'm_{a}_{b}'
            D[key+'_a']=ia; D[key+'_cen']=cen; D[key+'_top']=top; D[key+'_dom']=dom
    mk8=cells(np.isin(ds,['Monkey_CS8-e1','Monkey_CS8-e2'])); mk11=cells(ds=='Monkey_CS11-e1')
    ia,cen,top,dom=pair(mk8,mk11,Z,cap=4000); D['k_a']=ia; D['k_cen']=cen; D['k_dom']=dom; D['k_top']=top
    D['k_mid']=cells(np.isin(ds,['Monkey_CS9-e1','Monkey_CS9-e2']))
    out[rk]=D; print(rk,Z.shape,flush=True)
# human GG-OT pairs (CS7 export index -> integrated uid)
c7=pd.read_csv(B+'dataprep/export/CS7_cells.csv'); c8=pd.read_csv(B+'dataprep/export/CS8_cells.csv')
m7=o[ds=='HuE1_CS7']; m8=o[ds=='HuE2_CS8']
u7=pd.Series(np.where(ds=='HuE1_CS7')[0],index=m7.cell.astype(str).values).reindex(c7.cell.astype(str).values).values
u8=pd.Series(np.where(ds=='HuE2_CS8')[0],index=m8.cell.astype(str).values).reindex(c8.cell.astype(str).values).values
anc=pd.read_csv(B+'figure/final_ggot/ggot_table_cs8_ancestor.csv'); anc=anc[anc.cls!='unmatched']
t05=pd.read_csv(B+'figure/final_ggot/ggot_table_t05_pseudocells.csv'); t05=t05[t05.cs7_idx.isin(anc.ancestor_idx)].reset_index(drop=True)
desc=anc.groupby('ancestor_idx').cs8_idx.apply(np.array).reindex(t05.cs7_idx.values)
print('human t05 pairs',len(t05),' all CS7 mapped',np.isfinite(u7).all(),' CS8 mapped',np.isfinite(u8).all(), 'valid', valid[u7.astype(int)].mean(), valid[u8.astype(int)].mean())
for rk,D in out.items():
    Z=D['Z']; D['h_a']=u7.astype(int)[t05.cs7_idx.values]
    D['h_cen']=np.stack([Z[u8.astype(int)[d]].mean(0) for d in desc.values]).astype(np.float32)
    rr=np.random.default_rng(1); D['h_top']=np.array([u8.astype(int)[rr.choice(d)] for d in desc.values])
    np.savez(f'ai/step5_cache_{rk}.npz',**D)
o[['dataset','group','mouse_time']].assign(valid=valid).to_csv('ai/step5_cells.csv')
t05.to_csv('ai/step5_human_t05_index.csv',index=False)
np.save('ai/step5_u7.npy',u7.astype(int)); np.save('ai/step5_u8.npy',u8.astype(int))
print('done')
