"""Timing of gene changes along the generated trajectories of CS7 streak cells (Figure 7I; Methods 'Timing of gene
changes along generated trajectories'). The 12 generated states (t = 0..1, five seeds; human_traj_12fr_v153.npz from
generative/human/gen_fractions_v153.py) are mapped from the 94-d generator latent to the 30-d scVI latent by an affine
least-squares map fitted on the stored generated cells, decoded with the scVI decoder (CosMx batch), averaged per
destination lineage, and the half-change time of each gene is interpolated on the seed-averaged and per-seed curves
(genes changing by < 0.25 log2 units are not timed). Mouse-equivalent stage = 7.25 + 0.375 t days.
Reconstructed verbatim from session 5113e657 messages [4575], [4579], [4603], [4605], [4678], [4684], [4688], [4690],
[4710], [4720], [4730], [4732], [4734], [4738], [4740], [4742], [4752], [4754] (subsets as marked; the earlier HOX
analysis on the pre-v153 trajectory that shared these cells was removed). Outputs (cwd): Fig_AI_trajectory_gene_timing.png/.pdf
(draft heatmap panel), gene_timing_*.csv; statistics are printed.
"""
import os
import numpy as np, pandas as pd, anndata as ad
import scvi, torch
from scipy.stats import mannwhitneyu, spearmanr
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)

# ---- [glue] inputs shared with streak_fate_t05.py ([4311], [4319], [4323], [4433], [4435] subsets)
z=np.load(DATA+'/bridge_bundle/latent.npz',allow_pickle=True)
Z=z['Z']; i7z=z['i7']
base=DATA+'/cs7_cs8_matching/dataprep/'
C7=pd.read_csv(base+'export/CS7_cells.csv'); F7=pd.read_csv(base+'frames/CS7_frames.csv')
Z7=Z[i7z]
bz=np.load(DATA+'/bridge_bundle/bridge.npz',allow_pickle=True)
pm=bz['ps_mask'].astype(bool); ci7=bz['cs7_idx']

# ---- [4575] (subset)
A5=ad.read_h5ad(DATA+'/step12_t05_PS_dataset/t05_PS_generated_cells.h5ad')   # generated t = 0.5 streak cells (session read the uploaded copy)

# ---- [4579] (subset)
ai5=A5[A5.obs.generator=='AI_V1a']

# ---- [4603] (subset)
Aint=ad.read_h5ad(DATA+'/ai_t05/ai/integrated_scvi.h5ad')
mdl=scvi.model.SCVI.load(DATA+'/ai_t05/ai/scvi_model',adata=Aint)

# ---- [4605] (subset)
dev='cuda' if torch.cuda.is_available() else 'cpu'; mdl.module.to(dev); mdl.module.eval()

# ---- [4678] (subset)
ps_rows=np.where(pm)[0]; ci_ps=ci7[ps_rows]

# ---- [4684] (subset)
a=ai5.obsm['X_latent94'][:,:30]; b=ai5.obsm['X_scVI30']

# ---- [4688] (subset)
from numpy.linalg import lstsq
X1=np.c_[ai5.obsm['X_latent94'],np.ones(len(a))]; W,_,_,_=lstsq(X1,b,rcond=None); pred=X1@W
print('94->30 linear max err',np.abs(pred-b).max(), 'R2',1-((pred-b)**2).sum()/((b-b.mean(0))**2).sum())

# ---- [4690]
def to30(L94): return np.c_[L94,np.ones(len(L94))]@W
# verify on real HuE#1 cells: scVI latent from model vs mapped latent.npz rows
hue1=np.where(Aint.obs.dataset.values=='HuE1_CS7')[0][:500]
zq=mdl.get_latent_representation(adata=Aint[hue1],give_mean=True)
cellsA=Aint.obs.cell.values[hue1]; rows=pd.Index(C7.cell).get_indexer(cellsA)
print(np.abs(to30(Z7[rows])-zq).max(), np.corrcoef(to30(Z7[rows]).ravel(),zq.ravel())[0,1])

# ---- [4710] (subset)
Tv=np.load(DATA+'/ai_t05/out_trajectory/human_traj_12fr_v153.npz'); Gv=Tv['gen']; frg=Tv['fr']

# ---- [4720] (subset)
tEq=7.25+frg*0.375

# ---- [4730]
genes=np.array(A5.var_names)
destps=bz['dest'][ps_rows].astype(str)  # bridge dest for PS rows
apps=F7.AP_arc_frac.values[ci_ps]
lin_map={'Para.Meso':'paraxial','LP.Meso':'lateral plate','Nas.Meso':'nascent','Rostral.Meso':'rostral','PrP':'axial','Notochord':'axial','Node':'axial','Heart.Meso':'heart','PS':'stays PS'}
linv=np.array([lin_map.get(d,'other') for d in destps]); print(pd.Series(linv).value_counts().to_dict())
lins=['rostral','nascent','paraxial','lateral plate','axial','stays PS']
@torch.no_grad()
def dec_scale_t(z):
    out=[]
    for k in range(0,len(z),4096):
        zz=torch.tensor(z[k:k+4096],device=dev,dtype=torch.float32)
        o=mdl.module.generative(z=zz,library=torch.zeros(len(zz),1,device=dev),batch_index=torch.full((len(zz),1),3,device=dev,dtype=torch.long))
        out.append(o['px'].scale)
    return torch.cat(out)
LM=np.zeros((5,len(frg),len(lins),3000),np.float32); ALL=np.zeros((5,len(frg),3000),np.float32)
masks=[torch.tensor(linv==l,device=dev) for l in lins]
for s in range(5):
    for k in range(len(frg)):
        Sx=dec_scale_t(to30(Gv[s,k,ps_rows]))*1e4
        ALL[s,k]=Sx.mean(0).cpu().numpy()
        for li,m in enumerate(masks): LM[s,k,li]=Sx[m].mean(0).cpu().numpy()
print(LM.shape, np.isnan(LM).sum())

# ---- [4732]
def curves(lin_idx):
    x=LM[:,:,lin_idx,:].mean(0); return x  # fr x genes
recs=[]
for li,l in enumerate(lins):
    x=curves(li); c=np.log2(x+0.5); d=c[-1]-c[0]
    for gj in range(3000):
        if abs(d[gj])<0.5 or x[:,gj].max()<3: continue
        y=(c[:,gj]-c[0,gj])/d[gj]
        k=np.argmax(y>=0.5); th=frg[k-1]+(0.5-y[k-1])/(y[k]-y[k-1])*(frg[k]-frg[k-1]) if k>0 else np.nan
        peak=(c[1:-1,gj]-max(c[0,gj],c[-1,gj])).max(); dip=(min(c[0,gj],c[-1,gj])-c[1:-1,gj]).max()
        # seed range of t_half
        ths=[]
        for s in range(5):
            cs=np.log2(LM[s,:,li,gj]+0.5); ds=cs[-1]-cs[0]
            if ds*d[gj]<=0: ths.append(np.nan); continue
            ys=(cs-cs[0])/ds; kk=np.argmax(ys>=0.5); ths.append(frg[kk-1]+(0.5-ys[kk-1])/(ys[kk]-ys[kk-1])*(frg[kk]-frg[kk-1]) if kk>0 else np.nan)
        recs.append(dict(lineage=l,gene=genes[gj],dir='up' if d[gj]>0 else 'down',dl2=d[gj],start=x[0,gj],end=x[-1,gj],t_half=th,th_sd=np.nanstd(ths),peak=peak,dip=dip))
R=pd.DataFrame(recs)
print(R.groupby(['lineage','dir']).t_half.agg(['count','median']).round(3))
for l in lins:
    u=R[(R.lineage==l)&(R.dir=='up')].t_half; dn=R[(R.lineage==l)&(R.dir=='down')].t_half
    if len(u)>3 and len(dn)>3: print(l,'down earlier than up?', mannwhitneyu(dn,u,alternative='less').pvalue)
print('transient peaks', (R.peak>=0.3).sum(), ' dips',(R.dip>=0.3).sum())

# ---- [4734]
Ab_ps=bz['A'][ps_rows]; Bb_ps=bz['B'][ps_rows]
LL=np.zeros((len(frg),len(lins),3000),np.float32)
for k,f_ in enumerate(frg):
    Sx=dec_scale_t(to30((1-f_)*Ab_ps+f_*Bb_ps))*1e4
    for li,m in enumerate(masks): LL[k,li]=Sx[m].mean(0).cpu().numpy()
recL=[]
for li,l in enumerate(lins):
    x=LL[:,li]; c=np.log2(x+0.5); d=c[-1]-c[0]
    for gj in range(3000):
        if abs(d[gj])<0.5 or x[:,gj].max()<3: continue
        y=(c[:,gj]-c[0,gj])/d[gj]; k=np.argmax(y>=0.5)
        recL.append(dict(lineage=l,gene=genes[gj],dir='up' if d[gj]>0 else 'down',t_half=frg[k-1]+(0.5-y[k-1])/(y[k]-y[k-1])*(frg[k]-frg[k-1]) if k>0 else np.nan))
RL=pd.DataFrame(recL); print(RL.groupby(['lineage','dir']).t_half.median().unstack().round(3))
# gene-level AI-specific timing shift
mrg=R.merge(RL,on=['lineage','gene','dir'],suffixes=('','_lin'))
mrg['shift']=mrg.t_half-mrg.t_half_lin
print(mrg.groupby(['lineage','dir'])['shift'].median().unstack().round(3))

# ---- [4738]
prog_sets={'streak/epiblast exit':['TBXT','MIXL1','NODAL','FGF8','FGF17','WNT3','POU5F1','NANOG','SOX2','OTX2','EOMES','GSC','LHX1','CER1','LEFTY2','LEFTY1','FST','CDH1','EPCAM','DNMT3B','L1TD1','TDGF1'],
 'paraxial early (PSM)':['TBX6','MSGN1','HES7','DLL1','DLL3','RSPO3','CYP26A1','LFNG','MESP2','RIPPLY2'],
 'paraxial late (somitic)':['MEOX1','TCF15','FOXC1','FOXC2','PAX3','ALDH1A2','UNCX','TBX18','MEOX2','PARAXIS'],
 'lateral plate / ExM':['HAND1','FOXF1','BMP4','PRRX1','TWIST1','GATA2','KDR','TAL1','ISL1','PITX1','MSX1','MSX2','TBX3','VIM'],
 'cardiac / cranial':['MESP1','GATA4','GATA6','NKX2-5','TBX20','HAND2','TBX1','PDGFRA','MYL7','TNNT2','SFRP5','KDR'],
 'EMT':['SNAI1','SNAI2','CDH2','VIM','ZEB2','FN1','TWIST1','MMP2','PDGFRA']}
gset=set(genes)
for k,v in prog_sets.items(): print(k,[g for g in v if g in gset])

# ---- [4740]
def th_curve(x):
    c=np.log2(x+0.5); d=c[-1]-c[0]
    if abs(d)<0.25: return np.nan,d
    y=(c-c[0])/d; k=np.argmax(y>=0.5)
    return (frg[k-1]+(0.5-y[k-1])/(y[k]-y[k-1])*(frg[k]-frg[k-1]) if k>0 else np.nan), d
gpos={g:i for i,g in enumerate(genes)}
def prog_table(lin, gl):
    li=lins.index(lin); out=[]
    for g in gl:
        if g not in gpos: continue
        j=gpos[g]; x=LM[:,:,li,j].mean(0); th,d=th_curve(x); thl,_=th_curve(LL[:,li,j])
        ths=[th_curve(LM[s,:,li,j])[0] for s in range(5)]
        out.append(dict(lineage=lin,gene=g,dl2=d,start=x[0],end=x[-1],t_half=th,seed_lo=np.nanmin(ths) if np.isfinite(ths).any() else np.nan,seed_hi=np.nanmax(ths) if np.isfinite(ths).any() else np.nan,t_half_geom=thl))
    return pd.DataFrame(out)
pd.set_option('display.width',200)
for lin,keys in [('paraxial',['paraxial early (PSM)','paraxial late (somitic)']),('lateral plate',['lateral plate / ExM']),('rostral',['cardiac / cranial']),('nascent',['streak/epiblast exit','EMT'])]:
    for k in keys:
        t=prog_table(lin,prog_sets[k]); print('##',lin,k); print(t.round(2).to_string(index=False))

# ---- [4742]
panels=[('nascent','Streak exit (nascent-destined)',['OTX2','SOX2','FN1','FGF8','TBXT','CER1','EPCAM','PDGFRA','NODAL','LHX1','FGF17','WNT3','GSC','CDH1','MIXL1','EOMES','VIM']),
        ('paraxial','Paraxial mesoderm',['HES7','TBX6','RSPO3','MSGN1','CYP26A1','FOXC2','DLL1','ALDH1A2','MEOX1','FOXC1','RIPPLY2']),
        ('lateral plate','Lateral plate mesoderm',['FOXF1','TWIST1','TBX3','VIM','PITX1','BMP4','HAND1','MSX1','KDR','PRRX1','ISL1'])]
tabs={}
for lin,ttl,gl in panels:
    t=prog_table(lin,gl).dropna(subset=['t_half']).sort_values('t_half'); tabs[lin]=t
def build_timing():
    fig=plt.figure(figsize=(7.2,3.3))
    xs=tEq
    for p,(lin,ttl,gl) in enumerate(panels):
        t=tabs[lin]; li=lins.index(lin)
        ax=fig.add_axes([0.075+p*0.325,0.14,0.20,0.70])
        M_=[]
        for g in t.gene:
            c=np.log2(LM[:,:,li,gpos[g]].mean(0)+0.5); M_.append((c-c[0])/(c[-1]-c[0]))
        M_=np.array(M_)
        im=ax.imshow(M_,aspect='auto',cmap='magma',vmin=0,vmax=1,extent=[xs[0],xs[-1],len(t)-0.5,-0.5])
        for i,(g,r) in enumerate(zip(t.gene,t.itertuples())):
            tt=7.25+r.t_half*0.375; ax.plot([tt],[i],marker='|',ms=5,mew=1.2,c='#00E5FF' if r.dl2>0 else '#7CFC00')
        ax.set_yticks(range(len(t))); ax.set_yticklabels([f'{g} {"↑" if d>0 else "↓"}' for g,d in zip(t.gene,t.dl2)],fontsize=5.5)
        ax.set_xticks([7.25,7.4375,7.625]); ax.set_xticklabels(['E7.25','E7.44','E7.63'])
        ax.set_title(ttl,loc='left',fontsize=6)
        if p==1: ax.set_xlabel('AI trajectory, mouse-equivalent stage')
        fig.text(0.015+p*0.325,0.90,'ABC'[p],fontsize=9,fontweight='bold')
    cax=fig.add_axes([0.975,0.30,0.008,0.4]); cb=fig.colorbar(im,cax=cax); cb.set_label('fraction of own change',fontsize=5.5); cb.ax.tick_params(labelsize=5)
    fig.text(0.075,0.955,'Order of gene changes along AI trajectories (genes sorted by half-change time; tick = half-change; ↑ up, ↓ down)',fontsize=6.5)
    return fig
f=build_timing(); f.savefig('Fig_AI_trajectory_gene_timing.png',dpi=300); f.savefig('Fig_AI_trajectory_gene_timing.pdf'); plt.close('all')

# ---- [4752]
def seed_th(lin,g):
    li=lins.index(lin); return np.array([th_curve(LM[s,:,li,gpos[g]])[0] for s in range(5)])
grpsA={'epiblast':['OTX2','SOX2','FGF8','FN1'],'NODAL/anterior streak':['CER1','NODAL','LHX1','FGF17'],'streak TF / epithelial':['GSC','MIXL1','EOMES','CDH1'],'mesenchymal':['VIM']}
grpsB={'PSM':['HES7','TBX6','MSGN1','RSPO3'],'maturing':['DLL1','ALDH1A2','FOXC2'],'somitic':['MEOX1','RIPPLY2']}
for lin,gr in [('nascent',grpsA),('paraxial',grpsB)]:
    print('##',lin)
    for k,v in gr.items():
        M_=np.array([seed_th(lin,g) for g in v]); print(k, 'mean t_half per seed', np.round(M_.mean(0),3), ' stage', round(7.25+0.375*M_.mean(),3))
    ks=list(gr)
    a=np.concatenate([seed_th(lin,g) for g in gr[ks[0]]]); b=np.concatenate([seed_th(lin,g) for g in gr[ks[-1] if lin=='paraxial' else ks[2]]])
    print('first vs late group MW (gene×seed)', mannwhitneyu(a,b,alternative='less').pvalue)
    # per-seed: is order of group means monotone?
    order_ok=[all(np.diff([np.mean([seed_th(lin,g)[s] for g in gr[k]]) for k in ks])>0) for s in range(5)]; print('monotone in seeds', order_ok)
# gene-level ordinal test: Spearman of t_half vs assigned stage rank
for lin,gr in [('nascent',grpsA),('paraxial',grpsB)]:
    xs_=[];ys_=[]
    for r_,(k,v) in enumerate(gr.items()):
        for g in v: xs_.append(r_); ys_.append(th_curve(LM[:,:,lins.index(lin),gpos[g]].mean(0))[0])
    print(lin,'Spearman expected rank vs t_half',spearmanr(xs_,ys_))

# ---- [4754]
for lin,gr,first,last in [('nascent',grpsA,'epiblast','streak TF / epithelial'),('paraxial',grpsB,'PSM','somitic')]:
    for k,v in gr.items():
        M_=np.array([seed_th(lin,g) for g in v]); print(lin,k, np.round(np.nanmean(M_,0),3), 'stage %.2f'%(7.25+0.375*np.nanmean(M_)))
    a=np.concatenate([seed_th(lin,g) for g in gr[first]]); b=np.concatenate([seed_th(lin,g) for g in gr[last]])
    print(' MW',mannwhitneyu(a[np.isfinite(a)],b[np.isfinite(b)],alternative='less').pvalue)

# ---- output tables
# [glue] save the gene-timing tables used for the heatmap
for lin,t in tabs.items(): t.to_csv(f'gene_timing_{lin.replace(" ","_")}.csv', index=False)
