# staging/03_ps_dynamics/build_fig6.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/figure6/build_fig6.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Figure 4 assembly: A+B (milestone axis / windows) + C (PS trajectories) + D (3'/5' HOX)
# + E (cross-dataset concordance) + F (key-gene log2FC across datasets). 180 mm wide.
import sys, os, numpy as np, pandas as pd, matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import m4ab
MM = 1 / 25.4
SRC = sys.argv[1]
GENES = sys.argv[2]
X = pd.ExcelFile(SRC); S = {s: X.parse(s) for s in X.sheet_names}
WT, HT = 180.0, 190.0
TOPH = 116.0
fig = plt.figure(figsize=(WT * MM, HT * MM))
G = dict(m4ab.COMPACT); G.update(tw=24.0, mx0=63.5, btx0=38.5, btw=56.0, blx0=97.5, blw=22.0, a_xlab=True)
G.update(fig=fig, ox=0.0, oy=HT - TOPH, WT=WT, HT=HT)
_, (axA, axM, axW, axL) = m4ab.draw(G, 'fig4')
for tl in axW.get_yticklabels(): tl.set_fontsize(5)
mpl.rcParams.update({'svg.fonttype': 'none', 'mathtext.fontset': 'dejavusans'})
F0, F1, F2, FL = 6, 5.5, 5, 8
C7, C8 = m4ab.COL["HuE#1 CS7 (CosMx)"], m4ab.COL["HuE#2 CS8 (CosMx)"]
def axmm(x0, y0, w, h): return fig.add_axes([x0 / WT, y0 / HT, w / WT, h / HT])
def letter(x, y, s): fig.text(x / WT, y / HT, s, fontsize=FL, fontweight='bold', va='top', ha='left')
def it(g): return '$\\mathit{' + g.replace('-', '}$-$\\mathit{') + '}$'

# ---------------- C: PS trajectories ----------------
T = S['4C_trajectories']
genes = [['TBXT', 'HOXA1', 'HOXB1'], ['EOMES', 'MIXL1', 'MESP1']]
cx0, cw, ch, cgap = 14.0, 30.0, 20.5, 3.5
rows_y = [40.0, 10.5]
for r, (gl, y0) in enumerate(zip(genes, rows_y)):
    for j, g in enumerate(gl):
        a = axmm(cx0 + j * (cw + cgap), y0, cw, ch)
        m = T[(T.gene == g) & (T.series == 'mouse PS')].sort_values('x')
        mx = m.det.max()
        a.fill_between(m.x, 100 * m.sample_min / mx, 100 * np.minimum(m.sample_max / mx, 1.15), color='0.85', lw=0, zorder=1)
        a.plot(m.x, 100 * m.det / mx, '-o', c='0.15', ms=2.2, lw=0.9, zorder=3)
        for ser, col in [('CosMx CS7 PS', C7), ('CosMx CS8 PS', C8)]:
            h = T[(T.gene == g) & (T.series == ser)].iloc[0]
            lo, hi = [float(v) for v in h.window.split('-')]
            ab = bool(h.above_bkg)
            yv = 100 * h.plotted_frac_of_max
            a.plot([lo, hi], [yv, yv], c=col, lw=1.4, zorder=4, solid_capstyle='butt')
            a.plot((lo + hi) / 2, yv, 'o', ms=3.4, mfc=col if ab else 'white', mec=col, mew=0.9, zorder=5)
        a.set_xlim(6.42, 7.83); a.set_ylim(-8, 118); a.set_yticks([0, 50, 100])
        a.set_xticks([6.5, 7.0, 7.5]); a.spines[['top', 'right']].set_visible(False)
        a.tick_params(length=1.5, pad=1, width=0.5, labelsize=F2)
        if j > 0: a.set_yticklabels([])
        if r == 0: a.set_xticklabels([])
        else: a.set_xticklabels(['E6.5', 'E7.0', 'E7.5'])
        a.text(0.03, 1.0, it(g), transform=a.transAxes, fontsize=F0, va='bottom', ha='left')
    fig.text((cx0 - 0.5) / WT, (y0 + ch + 5.2) / HT, ['Up in mouse PS, E7.0→E7.75', 'Down in mouse PS, E7.0→E7.75'][r],
             fontsize=F1, color='0.25', va='bottom', ha='left')
fig.text(3.5 / WT, (rows_y[1] + (rows_y[0] + ch - rows_y[1]) / 2) / HT, 'PS detection\n(% of within-species max)',
         rotation=90, ha='center', va='center', fontsize=F1)
fig.text((cx0 + 1.5 * cw + cgap) / WT, 3.2 / HT, 'Mouse stage (human embryos placed on their milestone windows)', ha='center', va='bottom', fontsize=F1)
# legend for C (top strip)
from matplotlib.lines import Line2D
H = [Line2D([], [], c='0.15', marker='o', ms=2.2, lw=0.9, label='mouse PS (band: sample range)'),
     Line2D([], [], c=C7, marker='o', ms=3.4, lw=1.4, label='HuE#1 CS7 PS'),
     Line2D([], [], c=C8, marker='o', ms=3.4, lw=1.4, label='HuE#2 CS8 PS'),
     Line2D([], [], ls='', marker='o', ms=3.4, mfc='white', mec='0.3', mew=0.9, label='at CosMx background')]
LEGE = fig.legend(handles=H, loc='upper left', bbox_to_anchor=((cx0 - 2.0) / WT, 72.0 / HT), ncol=4, frameon=False, fontsize=F2,
           handlelength=1.4, columnspacing=1.0, handletextpad=0.4, borderaxespad=0)
letter(0.5, 73.0, 'E')

# ---------------- D: 3'/5' HOX heatmap ----------------
Hx = S['4C_HOX_heatmap']
mcols = ['mouse_det_pct_E7.0', 'mouse_det_pct_E7.25', 'mouse_det_pct_E7.5', 'mouse_det_pct_E7.75']
hcols = ['CosMx_CS7_minus_bkg_pp', 'CosMx_CS8_minus_bkg_pp']
M = np.hstack([Hx[mcols].values, np.full((len(Hx), 1), np.nan), np.clip(Hx[hcols].values, 0, None)])
n3 = int((Hx.block == '3′').sum())
dx0, dy0, dw, dh = 138.0, 134.0, 39.0, 45.0
a = axmm(dx0, dy0, dw, dh)
cm = mpl.colormaps['YlGnBu'].copy(); cm.set_bad('white')
yy = np.arange(len(Hx)) + (np.arange(len(Hx)) >= n3) * 0.6
for i, yv in enumerate(yy):
    for jj in range(M.shape[1]):
        v = M[i, jj]
        if np.isnan(v): continue
        a.add_patch(plt.Rectangle((jj - 0.5, yv - 0.5), 1, 1, color=cm(min(v, 22) / 22), lw=0))
        a.text(jj, yv, f'{v:.0f}', ha='center', va='center', fontsize=F2 - 0.5, color='white' if v > 13 else '0.1')
a.set_xlim(-0.5, M.shape[1] - 0.5); a.set_ylim(yy.max() + 0.6, -0.6)
a.set_yticks(yy); a.set_yticklabels([it(g) for g in Hx.gene], fontsize=F2)
a.set_xticks(range(M.shape[1])); a.set_xticklabels(['E7.0', 'E7.25', 'E7.5', 'E7.75', '', 'CS7', 'CS8'], rotation=90, fontsize=F2)
for tl, c in zip(a.get_xticklabels()[5:], [C7, C8]): tl.set_color(c)
a.tick_params(length=0, pad=1.2); [s.set_visible(False) for s in a.spines.values()]
a.text(1.5, -0.9, 'mouse', ha='center', va='bottom', fontsize=F2, color='0.35')
a.text(5.5, -0.9, 'CosMx', ha='center', va='bottom', fontsize=F2, color='0.35')
for (lo, hi), lab in [((0, n3 - 1), '3′ HOX'), ((n3, len(Hx) - 1), '5′ HOX')]:
    a.plot([-3.5, -3.5], [yy[lo] - 0.4, yy[hi] + 0.4], c='0.3', lw=0.6, clip_on=False)
    a.text(-3.9, (yy[lo] + yy[hi]) / 2, lab, rotation=90, ha='right', va='center', fontsize=F1, clip_on=False)
fig.text((dx0 - 13) / WT, (dy0 + dh + 3.6) / HT, '% PS cells (human: minus VE background, pp)', fontsize=F2, color='0.35', ha='left', va='bottom')
letter(117.0, 189.0, 'C')

# ---------------- E: CosMx CS7->CS8 vs mouse E7.0->E7.75 PS change (88 orthologues) ----------------
GN = pd.read_csv(GENES); GN = GN[GN.CosMx_lfc.notna()].copy()
ex0, ey0, ew, eh = 131.0, 86.5, 44.0, 28.0
a = axmm(ex0, ey0, ew, eh)
lim = 4.2
a.fill_between([0, lim], 0, lim, color='#eef3ea', zorder=0, lw=0); a.fill_between([-lim, 0], -lim, 0, color='#eef3ea', zorder=0, lw=0)
a.axhline(0, c='0.6', lw=0.4); a.axvline(0, c='0.6', lw=0.4)
pp = GN.CosMx_pass_primary.astype(bool)
mx_, hy_ = GN['mouse_log2FC_E7.0_E7.75'], GN.CosMx_lfc.clip(-lim, lim)
a.scatter(mx_[~pp], hy_[~pp], s=4, facecolor='white', edgecolor='0.5', lw=0.4, zorder=2)
a.scatter(mx_[pp], hy_[pp], s=7, facecolor='0.15', edgecolor='white', lw=0.25, zorder=3)
labE = {'TBXT': (5, -5), 'HOXA1': (-22, 0), 'HOXB1': (3, 6), 'MIXL1': (4, 1), 'EOMES': (4, 2), 'MESP1': (4, -5), 'GAL': (4, 2)}
for _, r in GN[GN.human.isin(labE)].iterrows():
    dx, dy = labE[r.human]
    a.annotate(r.human, (r['mouse_log2FC_E7.0_E7.75'], np.clip(r.CosMx_lfc, -lim, lim)), xytext=(dx, dy), textcoords='offset points',
               fontsize=F2, style='italic', color='#b2182b' if r.human == 'GAL' else '0.15',
               arrowprops=dict(arrowstyle='-', lw=0.3, color='0.5', shrinkA=0, shrinkB=1.2))
a.set_xlim(-lim, lim); a.set_ylim(-lim, lim); a.set_xticks([-4, -2, 0, 2, 4]); a.set_yticks([-4, -2, 0, 2, 4])
a.set_xlabel('Mouse PS log2FC, E7.0→E7.75', fontsize=F2, labelpad=1)
a.set_ylabel('Human PS log2FC,\nCS7→CS8', fontsize=F2, labelpad=1, linespacing=0.95)
a.tick_params(labelsize=F2, length=1.5, pad=1, width=0.5); a.spines[['top', 'right']].set_visible(False)
fig.text(122.0 / WT, (ey0 + eh + 2.0) / HT, 'above background (filled, n = 22): 16 same sign, ρ = 0.69\nall 88 orthologues: 60 same sign, ρ = 0.43',
         fontsize=F2, color='0.3', ha='left', va='bottom', linespacing=1.0)
letter(117.0, ey0 + eh + 9.5, 'D')

# ---------------- F: key-gene log2FC across datasets ----------------
K = S['4D_key_gene_log2FC'].set_index('pair'); R0 = S['4D_mouse_reference_row'].set_index('gene')
kg = ['EOMES', 'MIXL1', 'MESP1', 'GSC', 'NODAL', 'TBXT', 'CDX2', 'HOXA1', 'HOXB1']
short = ['CosMx CS7→CS8', 'Stereo-seq CS7→CS8', 'Stereo-seq CS8→CS9*', '10x CS7→CS8',
         'Monkey CS8e1→CS9e1*', 'Monkey CS8e1→CS9e2*', 'Monkey CS8e2→CS9e1*', 'Monkey CS8e2→CS9e2*']
rows = ['Mouse E7.0→E7.75'] + short
V = np.vstack([R0.loc[kg, R0.columns[0]].values] + [K.loc[p, [f'{g}_log2FC' for g in kg]].values.astype(float) for p in K.index])
AB = np.vstack([np.ones(len(kg), bool)] + [K.loc[p, [f'{g}_above_bkg' for g in kg]].values.astype(bool) for p in K.index])
fx0, fy0, fw, fh = 142.0, 13.0, 36.0, 48.0
a = axmm(fx0, fy0, fw, fh)
cmap = mpl.colormaps['RdBu_r']; nrm = mpl.colors.Normalize(-3, 3)
yv = np.arange(len(rows)) + (np.arange(len(rows)) > 0) * 0.35
for i in range(V.shape[0]):
    for j in range(V.shape[1]):
        v = V[i, j]
        col = cmap(nrm(np.clip(v, -3, 3))) if AB[i, j] else '0.93'
        a.add_patch(plt.Rectangle((j - 0.5, yv[i] - 0.5), 1, 1, color=col, lw=0.3, ec='white'))
        a.text(j, yv[i], f'{v:.1f}', ha='center', va='center', fontsize=F2 - 1.0,
               color=('white' if (AB[i, j] and abs(v) > 2) else ('0.1' if AB[i, j] else '0.55')))
a.set_xlim(-0.5, len(kg) - 0.5); a.set_ylim(yv.max() + 0.55, -0.55)
a.set_xticks(range(len(kg))); a.set_xticklabels([it(g) for g in kg], rotation=90, fontsize=F2)
a.xaxis.tick_top(); a.tick_params(length=0, pad=1)
a.set_yticks(yv); a.set_yticklabels(rows, fontsize=F2)
[s.set_visible(False) for s in a.spines.values()]
cax = axmm(fx0 + 3, fy0 - 5.2, 26.0, 1.3)
cb = fig.colorbar(mpl.cm.ScalarMappable(norm=nrm, cmap=cmap), cax=cax, orientation='horizontal')
cb.set_ticks([-3, 0, 3]); cb.set_ticklabels(['≤−3', '0', '≥3']); cb.ax.tick_params(labelsize=F2 - 0.5, length=1, pad=0.5)
cb.outline.set_linewidth(0.4)
fig.text((fx0 + 3 + 13) / WT, (fy0 - 9.6) / HT, 'PS log2FC (grey: at background)', fontsize=F2 - 0.5, ha='center', va='bottom', color='0.3')
letter(114.0, 73.0, 'F')

# ---------------- shift everything up to make room for G ----------------
DY = 40.0; HN = HT + DY
fig.set_size_inches(WT * MM, HN * MM)
for ax_ in fig.axes:
    p = ax_.get_position(); ax_.set_position([p.x0, (p.y0 * HT + DY) / HN, p.width, p.height * HT / HN])
for t_ in fig.texts:
    x_, y_ = t_.get_position(); t_.set_position((x_, (y_ * HT + DY) / HN))
LEGE.set_bbox_to_anchor(((cx0 - 2.0) / WT, (72.0 + DY) / HN), transform=fig.transFigure)
HT = HN
# ---------------- G: draft genes that are not usable as conserved streak markers ----------------
cg = ['RSPO2', 'RSPO3', 'TBX3', 'GSC', 'CDX2', 'NODAL']
note = {'RSPO2': 'absent in mouse PS', 'RSPO3': 'human at background', 'TBX3': 'mouse PS ≤3%',
        'GSC': 'human at background', 'CDX2': 'human at background', 'NODAL': 'human at background'}
gw, gh, gg = 24.0, 22.0, 4.0
for j, gname in enumerate(cg):
    a = axmm(14 + j * (gw + gg), 10.5, gw, gh)
    m = T[(T.gene == gname) & (T.series == 'mouse PS')].sort_values('x'); mx = m.det.max()
    a.fill_between(m.x, 100 * m.sample_min, 100 * m.sample_max, color='0.85', lw=0, zorder=1)
    a.plot(m.x, 100 * m.det, '-o', c='0.15', ms=2.0, lw=0.8, zorder=3)
    for ser, col in [('CosMx CS7 PS', C7), ('CosMx CS8 PS', C8)]:
        h = T[(T.gene == gname) & (T.series == ser)].iloc[0]
        lo, hi = [float(v) for v in h.window.split('-')]; ab = bool(h.above_bkg); yv = 100 * max(h.det_minus_bkg, 0)
        a.plot([lo, hi], [yv, yv], c=col, lw=1.3, zorder=4, solid_capstyle='butt')
        a.plot((lo + hi) / 2, yv, 'o', ms=3.2, mfc=col if ab else 'white', mec=col, mew=0.8, zorder=5)
    a.set_xlim(6.42, 7.83); a.set_ylim(-5, 100); a.set_yticks([0, 50, 100]); a.set_xticks([6.5, 7.0, 7.5])
    a.set_xticklabels(['E6.5', 'E7.0', 'E7.5']); a.tick_params(labelsize=F2, length=1.5, pad=1, width=0.5)
    if j: a.set_yticklabels([])
    a.spines[['top', 'right']].set_visible(False)
    a.text(0.03, 1.02, it(gname), transform=a.transAxes, fontsize=F0, va='bottom', ha='left')
    a.text(0.03, 0.95, note[gname] + f"\nmouse max {100 * mx:.0f}%", transform=a.transAxes, fontsize=F2 - 0.5, ha='left', va='top', color='0.35', linespacing=1.0)
fig.text(3.5 / WT, (10.5 + gh / 2) / HT, 'PS detection (%)', rotation=90, ha='center', va='center', fontsize=F1)
fig.text((14 + 3 * gw + 2.5 * gg) / WT, 2.2 / HT, 'Mouse stage (human = detection minus VE background; open = at background)', ha='center', va='bottom', fontsize=F1)
letter(0.5, 39.0, 'G')

# ---------------- header strip ----------------
TOPH = 9.0; HN2 = HT + TOPH
fig.set_size_inches(WT * MM, HN2 * MM)
for ax_ in fig.axes:
    p = ax_.get_position(); ax_.set_position([p.x0, p.y0 * HT / HN2, p.width, p.height * HT / HN2])
for t_ in fig.texts:
    x_, y_ = t_.get_position(); t_.set_position((x_, y_ * HT / HN2))
LEGE.set_bbox_to_anchor(((cx0 - 2.0) / WT, (72.0 + DY) / HN2), transform=fig.transFigure)
HT = HN2
fig.text(0.5 / WT, (HT - 1.5) / HT, 'Figure 6', fontsize=10, fontweight='bold', ha='left', va='top')

def check(fig):
    fig.canvas.draw(); r = fig.canvas.get_renderer()
    tx = [t for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
    bb = [(t, t.get_window_extent(r)) for t in tx]
    ov = [(a.get_text()[:20], b.get_text()[:20]) for i, (a, ba) in enumerate(bb) for b, bb2 in bb[i + 1:] if ba.overlaps(bb2)]
    out = [t.get_text()[:20] for t, b in bb if not (fig.bbox.x0 - 1 <= b.x0 and b.x1 <= fig.bbox.x1 + 1 and fig.bbox.y0 - 1 <= b.y0 and b.y1 <= fig.bbox.y1 + 1)]
    return ov, out, sorted({round(t.get_fontsize(), 2) for t in tx})
ov, out, fs = check(fig)
print('overlaps', ov); print('outside', out); print('fonts', fs)
for ext in ('png', 'svg', 'pdf'):
    fig.savefig(f'Figure6.{ext}', dpi=600 if ext == 'png' else None)
