"""Shared code for the starmatch-vs-moscot benchmark: data loading, synthetic generator,
baseline methods, evaluation metrics, held-out-gene protocol."""
import os, sys, json, time, resource
import numpy as np, pandas as pd, scipy.sparse as ssp
from scipy.spatial import cKDTree
from scipy.stats import spearmanr, pearsonr

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "lib"))   # starmatch.py lives in aiggot/lib
import starmatch

PEN_REF = {"direct": 0.0, "allowed": 0.5, "indirect": 1.0, "penalised": 3.0}
PEN_ZERO = {"direct": 0.0, "allowed": 0.0, "indirect": 0.0, "penalised": 0.0}
KC_REF = {"direct": 40, "allowed": 40, "indirect": 20, "penalised": 10}
KC_UNIF = {"direct": 40, "allowed": 40, "indirect": 40, "penalised": 40}
REF = dict(lam=1.0, eps=0.1, tau=3.0, K=5, c_unmatched=4.0, delta=0.25)


def load_inputs():
    z = np.load(os.path.join(HERE, "data", "bench_inputs.npz"), allow_pickle=False)
    D = {k: z[k] for k in z.files}
    T = json.load(open(os.path.join(HERE, "data", "transition_table.json")))
    M_ = T["matrix"]
    trans = {(g, h): (M_[g][h] if isinstance(M_, dict) else M_[T["cs7_groups"].index(g)][T["cs8_groups"].index(h)])
             for g in T["cs7_groups"] for h in T["cs8_groups"]}
    for h in ["Nas.Meso", "Para.Meso", "Rostral.Meso", "LP.Meso", "Heart.Meso"]:
        trans[("EPI", h)] = "indirect"
    trans[("APS", "Rostral.Meso")] = "allowed"
    D["trans"] = trans
    return D


# ----------------------------------------------------------------------------- synthetic data
TRANS_PROB = {"direct": 0.60, "allowed": 0.30, "indirect": 0.10, "penalised": 0.0}


def make_synthetic(D, noise="medium", seed=0, n_parents=3000, p_unmatched7=0.10, p_unmatched8=0.10,
                   n_child_probs=(0.45, 0.35, 0.20), drift_w=0.5):
    """Synthetic CS7->CS8 pair with known ancestors, mirroring the real data.
    Parents: random real CS7 cells (smoothed Harmony E, frame coordinates S, group g).
    Descendants: each matched parent has N in {1,2,3} children; child group drawn from the
    transition table (class probabilities TRANS_PROB renormalised per source group, 'penalised' = 0);
    child expression = (1-w) parent + w * (real CS8 target-group centroid) + noise;
    child position = global allometric map of the parent position (AP x1.15, LR x1.10, DV x1.0,
    AP shift -0.03) + target-group-specific shift (N(0, 0.08^2) per group, fixed per replicate) + noise.
    10% of parents have no child (unmatched CS7); 10% of CS8 cells are de novo (no parent):
    positions of random true descendants (+ noise) but expression = target-group centroid + noise
    (no parental trace).
    noise level: sigma_expr = f * expression kNN-scale, sigma_space = f * space kNN-scale,
    f = 0.5 / 1.0 / 2.0 for low / medium / high."""
    rng = np.random.default_rng(seed)
    f = {"low": 0.5, "medium": 1.0, "high": 2.0}[noise]
    E7all, S7all, g7all = D["Hs7"].astype(float), D["S7"], D["g7"].astype(str)
    E8all, g8all = D["Hs8"].astype(float), D["g8"].astype(str)
    trans = D["trans"]; cs8_groups = list(D["cs8_groups"].astype(str))
    se = starmatch.knn_scale(np.vstack([D["Hs7"], D["Hs8"]])); ss = starmatch.knn_scale(np.vstack([D["S7"], D["S8"]]))
    mu8 = {h: E8all[g8all == h].mean(0) for h in cs8_groups}
    idx = rng.choice(len(g7all), n_parents, replace=False)
    E7, S7, g7 = E7all[idx], S7all[idx], g7all[idx]
    tp = {}
    for g in np.unique(g7):
        p = np.array([TRANS_PROB[trans.get((g, h), "penalised")] for h in cs8_groups]); tp[g] = p / p.sum()
    gshift = {h: rng.normal(0, 0.08, 3) for h in cs8_groups}
    A = np.array([1.15, 1.10, 1.0]); c = np.array([-0.03, 0.0, 0.0])
    matched7 = rng.random(n_parents) >= p_unmatched7
    nchild = np.where(matched7, rng.choice([1, 2, 3], n_parents, p=n_child_probs), 0)
    parent = np.repeat(np.arange(n_parents), nchild)
    g8 = np.array([cs8_groups[rng.choice(len(cs8_groups), p=tp[g7[i]])] for i in parent])
    E8 = (1 - drift_w) * E7[parent] + drift_w * np.array([mu8[h] for h in g8]) + rng.normal(0, f * se / np.sqrt(30), (len(parent), 30))
    S8 = S7[parent] * A + c + np.array([gshift[h] for h in g8]) + rng.normal(0, f * ss / np.sqrt(3), (len(parent), 3))
    n_dn = int(round(p_unmatched8 / (1 - p_unmatched8) * len(parent)))
    src = rng.choice(len(parent), n_dn)
    # de novo cells carry no parental expression trace: target-group centroid + noise (drift_w = 1)
    E8 = np.vstack([E8, np.array([mu8[h] for h in g8[src]]) + rng.normal(0, f * se / np.sqrt(30), (n_dn, 30))])
    S8 = np.vstack([S8, S8[src] + rng.normal(0, f * ss / np.sqrt(3), (n_dn, 3))])
    g8 = np.concatenate([g8, g8[src]]); parent = np.concatenate([parent, -np.ones(n_dn, int)])
    perm = rng.permutation(len(g8))
    return dict(E7=E7, S7=S7, g7=g7, E8=E8[perm], S8=S8[perm], g8=g8[perm], parent=parent[perm],
                a=np.ones(n_parents), b=np.ones(len(g8)), trans=trans, noise=noise, seed=seed,
                n_unmatched7=int((~matched7).sum()), n_denovo8=n_dn)


# ----------------------------------------------------------------------------- methods
def run_starmatch(E7, E8, S7, S8, g7, g8, a, b, trans, pen=PEN_REF, kc=KC_REF, **kw):
    p = dict(REF); p.update(kw)
    C, sc_ = starmatch.build_candidates(E7, E8, S7, S8, g7, g8, trans, lam=p["lam"], k_cand=kc, class_penalty=pen)
    R = starmatch.run_matching(None, None, None, None, g7, g8, a, b, trans, eps=p["eps"], tau=p["tau"], K=p["K"],
                               class_penalty=pen, c_unmatched=p["c_unmatched"], delta=p["delta"], C=C, scales=sc_)
    M = R["M"].tocsr(); m = M.shape[1]
    par = -np.ones(m, int); coo = M.tocoo(); par[coo.col] = coo.row      # each CS8 cell has <=1 parent
    return dict(parent=par, M=M, pi=R["pi"], info=R["sinkhorn"], summary=R["summary"], scales=sc_)


def run_knn_expr(E7, E8, **kw):
    _, j = cKDTree(E7).query(E8, k=1); return dict(parent=np.asarray(j).ravel())


def run_nn_space(S7, S8, **kw):
    _, j = cKDTree(S7).query(S8, k=1); return dict(parent=np.asarray(j).ravel())


# ----------------------------------------------------------------------------- metrics
def flow_from_parent(par, g7, g8, rows=None, cols=None):
    ok = par >= 0
    ft = pd.crosstab(pd.Series(g7[par[ok]], name="CS7"), pd.Series(g8[ok], name="CS8"))
    rows = rows if rows is not None else sorted(set(g7)); cols = cols if cols is not None else sorted(set(g8))
    return ft.reindex(index=rows, columns=cols, fill_value=0).astype(float)


def flow_from_soft(P_colnorm, g7, g8, rows, cols):
    """P: (n7 x n8) column-normalised coupling (each CS8 cell distributes 1 unit over parents)."""
    G7 = pd.get_dummies(pd.Categorical(g7, categories=rows)).to_numpy(float)
    G8 = pd.get_dummies(pd.Categorical(g8, categories=cols)).to_numpy(float)
    F = G7.T @ (P_colnorm @ G8) if not ssp.issparse(P_colnorm) else G7.T @ (P_colnorm @ G8)
    return pd.DataFrame(np.asarray(F), index=rows, columns=cols)


def flow_tv(F, Ftrue):
    """total variation between flow tables normalised to probability mass."""
    F = F.reindex(index=Ftrue.index, columns=Ftrue.columns, fill_value=0).to_numpy(float)
    T = Ftrue.to_numpy(float)
    return 0.5 * np.abs(F / F.sum() - T / T.sum()).sum()


def class_fraction(F, trans, cls):
    tot = F.to_numpy().sum(); s = 0.0
    for g in F.index:
        for h in F.columns:
            if trans.get((g, h), "penalised") in cls:
                s += F.loc[g, h]
    return float(s / tot) if tot > 0 else np.nan


def top_target_concentration(F):
    """per source group: share of its flow going to its single largest CS8 target."""
    r = F.div(F.sum(1).replace(0, np.nan), axis=0)
    return r.max(1)


def flow_corr(F, Fref):
    x = F.reindex(index=Fref.index, columns=Fref.columns, fill_value=0).to_numpy().ravel(); y = Fref.to_numpy().ravel()
    return float(pearsonr(x, y)[0]), float(spearmanr(x, y)[0])


def synth_metrics(par, syn, F=None):
    """ancestor-recovery accuracy etc. for a hard assignment par (CS8 -> CS7 index or -1)."""
    true = syn["parent"]; g7, g8 = syn["g7"], syn["g8"]
    has = true >= 0; pred = par >= 0
    acc = float((par[has] == true[has]).mean())                             # over CS8 cells with a true parent (unmatched prediction counts as wrong)
    acc_on_matched = float((par[has & pred] == true[has & pred]).mean()) if (has & pred).any() else np.nan
    gacc = float((g7[np.where(par[has & pred] >= 0, par[has & pred], 0)] == g7[true[has & pred]]).mean()) if (has & pred).any() else np.nan
    Ftrue = flow_from_parent(true, g7, g8)
    if F is None:
        F = flow_from_parent(par, g7, g8, Ftrue.index, Ftrue.columns)
    return dict(ancestor_acc=acc, ancestor_acc_given_matched=acc_on_matched, parent_group_acc=gacc,
                flow_tv=flow_tv(F, Ftrue), viol_penalised=class_fraction(F, syn["trans"], {"penalised"}),
                frac_cs8_unmatched_pred=float((~pred).mean()),
                unmatched_recall=float((~pred[~has]).mean()), unmatched_precision=float((~has[~pred]).mean()) if (~pred).any() else np.nan,
                unmatched7_recall=float(np.mean([i not in set(par[pred]) for i in np.setdiff1d(np.arange(len(g7)), np.unique(true[has]))])),
                frac_cs7_unmatched_pred=float(1 - len(np.unique(par[pred])) / len(g7)),
                n_true_unmatched8=int((~has).sum()))


# ----------------------------------------------------------------------------- held-out gene protocol
def heldout_rho(E7s, E8s, par, g7, g8, soft_pred=None, seed_base=0):
    """EXACT protocol of heldout_gene_validation.csv for a hard assignment (edges = matched CS8 cells),
    plus optional soft (coupling-weighted) prediction for the same cells."""
    ok = np.where(par >= 0)[0]; rows_i = par[ok]; cols_j = ok
    key = pd.Series(list(zip(g7[rows_i], g8[cols_j])))
    groups_idx = [np.array(v) for v in key.groupby(key).groups.values()]
    out = []
    for k in range(E7s.shape[1]):
        r_pred = spearmanr(E7s[rows_i, k], E8s[cols_j, k]).correlation
        gm = pd.Series(E7s[:, k]).groupby(g7).mean()
        r_group = spearmanr(np.array([gm[g] for g in g7[rows_i]]), E8s[cols_j, k]).correlation
        rng = np.random.default_rng(k + seed_base); perm = np.arange(len(rows_i))
        for idx_ in groups_idx:
            perm[idx_] = rng.permutation(idx_)
        r_shuf = spearmanr(E7s[rows_i[perm], k], E8s[cols_j, k]).correlation
        d = dict(gene=k, r_matched=r_pred, r_groupmean=r_group, r_shuffled_within_pair=r_shuf)
        if soft_pred is not None:
            d["r_soft"] = spearmanr(soft_pred[cols_j, k], E8s[cols_j, k]).correlation
        out.append(d)
    return pd.DataFrame(out)


def peak_rss_gb():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1e6
