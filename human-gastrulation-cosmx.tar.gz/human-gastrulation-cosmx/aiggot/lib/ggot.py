"""GG-OT: gated-geodesic optimal transport between two embryo snapshots.

Spatial cost = shortest path on a three-layer tissue graph (E = epiblast/ectoderm,
M = streak-derived middle layer: mesoderm + axial, N = endoderm: DE + VE) in a common
normalised disc frame (AP_arc_frac x AP_SPAN, LR_frac x LR_SPAN, in um).
Within-layer edges follow occupied tissue; between-layer edges exist at every grid site but
cost h_ab - tau * log g(u), where g is a gate field learned from the streak / EMT programme.
Development direction is enforced softly: reverse layer changes (M->E, N->M, N->E) cost
an extra `reverse` term.
"""
import numpy as np, pandas as pd, scipy.sparse as ssp
from scipy.sparse.csgraph import dijkstra
from scipy.ndimage import gaussian_filter, binary_dilation
from scipy.spatial import cKDTree

LAYERS = ("E", "M", "X", "N")          # X = axial midline (node, notochord, prechordal plate)
LAYER_OF = {"EPI": "E", "ECT": "E", "aECT": "E", "pECT": "E", "CLE": "E", "NNE": "E", "PS": "E",
            "APS": "M", "Node": "X", "Notochord": "X", "PrP": "X", "Nas.Meso": "M", "Para.Meso": "M",
            "Rostral.Meso": "M", "LP.Meso": "M", "Heart.Meso": "M",
            "DE": "N", "AVE": "N", "VE1": "N", "VE2": "N",
            # Stereo-seq (Yu lab) vocabulary
            "Adv.Meso": "M", "Other.Meso": "M", "Caudal.Meso": "M", "Gut": "N", "VE": "N"}
AP_SPAN, LR_SPAN = 1138.28, 497.49           # geometric-mean disc spans (um) of CS7 and CS8


class Grid:
    def __init__(self, ap_lim=(-0.15, 1.2), lr_lim=(-0.65, 0.65), step_um=20.0):
        self.x = np.arange(ap_lim[0] * AP_SPAN, ap_lim[1] * AP_SPAN + 1e-9, step_um)
        self.y = np.arange(lr_lim[0] * LR_SPAN, lr_lim[1] * LR_SPAN + 1e-9, step_um)
        self.nx, self.ny, self.step = len(self.x), len(self.y), step_um

    def to_um(self, ap_frac, lr_frac):
        return np.c_[np.asarray(ap_frac) * AP_SPAN, np.asarray(lr_frac) * LR_SPAN]

    def bin(self, P):
        ix = np.clip(np.round((P[:, 0] - self.x[0]) / self.step).astype(int), 0, self.nx - 1)
        iy = np.clip(np.round((P[:, 1] - self.y[0]) / self.step).astype(int), 0, self.ny - 1)
        return ix, iy

    def smooth_mean(self, P, v, sigma_um=40.0, mask_min=0.5):
        ix, iy = self.bin(P)
        S = np.zeros((self.nx, self.ny)); N = np.zeros((self.nx, self.ny))
        np.add.at(S, (ix, iy), v); np.add.at(N, (ix, iy), 1.0)
        s = sigma_um / self.step
        Sg, Ng = gaussian_filter(S, s), gaussian_filter(N, s)
        return np.where(Ng > 1e-6, Sg / np.maximum(Ng, 1e-12), np.nan), Ng


def occupancy(grid, P_by_layer, dilate=2, sigma_um=30.0, thr=0.02):
    """occupied tissue mask per layer (union of both embryos), lightly dilated"""
    occ = {}
    for L, P in P_by_layer.items():
        ix, iy = grid.bin(P); N = np.zeros((grid.nx, grid.ny)); np.add.at(N, (ix, iy), 1.0)
        Ng = gaussian_filter(N, sigma_um / grid.step)
        m = Ng > thr * Ng.max()
        occ[L] = binary_dilation(m, iterations=dilate)
    return occ


H_DEFAULT = {("E", "M"): 50.0, ("E", "X"): 50.0, ("M", "X"): 30.0, ("X", "M"): 30.0,
             ("M", "N"): 50.0, ("X", "N"): 50.0, ("E", "N"): 100.0}


def build_graph(grid, occ, gate, h=None, tau=100.0, eps_gate=1e-3, reverse=1000.0, layer_cost=None):
    """directed sparse graph over (layer, ix, iy) nodes; returns csr matrix and node index map.
    gate: dict (a,b) -> array nx x ny in (0,1]; missing pairs use eps_gate everywhere."""
    h = h or H_DEFAULT
    nid = -np.ones((len(LAYERS), grid.nx, grid.ny), int); k = 0
    for li, L in enumerate(LAYERS):
        ii, jj = np.where(occ[L]); nid[li, ii, jj] = np.arange(k, k + len(ii)); k += len(ii)
    rows, cols, w = [], [], []
    nbr = [(1, 0), (0, 1), (1, 1), (1, -1)]
    for li, L in enumerate(LAYERS):
        for dx, dy in nbr:
            x0, x1 = max(0, -dx), grid.nx - max(0, dx); y0, y1 = max(0, -dy), grid.ny - max(0, dy)
            a = nid[li, x0:x1, y0:y1]; b = nid[li, x0 + dx:x1 + dx, y0 + dy:y1 + dy]
            ok = (a >= 0) & (b >= 0); d = grid.step * np.hypot(dx, dy) * ((layer_cost or {}).get(L, 1.0))
            rows += [a[ok], b[ok]]; cols += [b[ok], a[ok]]; w += [np.full(ok.sum(), d)] * 2
    for (A, Bl), hab in h.items():
        la, lb = LAYERS.index(A), LAYERS.index(Bl)
        a, b = nid[la], nid[lb]; ok = (a >= 0) & (b >= 0)
        g = gate.get((A, Bl), np.full((grid.nx, grid.ny), eps_gate))
        cost = hab - tau * np.log(np.clip(g, eps_gate, 1.0))
        rows.append(a[ok]); cols.append(b[ok]); w.append(cost[ok])                 # forward
        rows.append(b[ok]); cols.append(a[ok]); w.append(cost[ok] + reverse)       # reverse (soft-forbidden)
    r, c, v = np.concatenate(rows), np.concatenate(cols), np.concatenate(w)
    df = pd.DataFrame(dict(r=r, c=c, v=v)).groupby(["r", "c"], as_index=False).v.min()   # min over duplicate arcs
    G = ssp.csr_matrix((df.v.to_numpy(), (df.r.to_numpy(), df.c.to_numpy())), shape=(k, k))
    return G, nid


def node_of(grid, nid, P, layer):
    """nearest occupied node in the cell's layer"""
    out = np.empty(len(P), int)
    for li, L in enumerate(LAYERS):
        m = np.asarray(layer) == L
        if not m.any():
            continue
        ii, jj = np.where(nid[li] >= 0)
        tree = cKDTree(np.c_[grid.x[ii], grid.y[jj]])
        _, q = tree.query(P[m]); out[m] = nid[li, ii[q], jj[q]]
    return out


def all_pairs(G, sources=None):
    D, pred = dijkstra(G, directed=True, indices=sources, return_predecessors=True)
    return D.astype(np.float32), pred.astype(np.int32)


def path_point(pred_row, src, dst, frac, node_xy, node_layer):
    """point at arc-length fraction `frac` along the shortest path src->dst (returns xy, layer, path)"""
    path = [dst]
    while path[-1] != src and path[-1] >= 0:
        path.append(pred_row[path[-1]])
    path = path[::-1]
    if len(path) == 1:
        return node_xy[src], node_layer[src], path
    # inter-layer steps have zero planar length: give them their own unit length so that layer
    # changes occupy a share of the path proportional to the DV separation (50 um)
    dl = np.diff(node_layer[path]) != 0
    steplen = np.hypot(*np.diff(node_xy[path], axis=0).T); steplen[dl] = 50.0
    seg = np.r_[0, np.cumsum(steplen)]; t = frac * seg[-1]
    k = int(np.clip(np.searchsorted(seg, t, side="right") - 1, 0, len(path) - 2))
    w = (t - seg[k]) / max(seg[k + 1] - seg[k], 1e-12)
    xy = (1 - w) * node_xy[path[k]] + w * node_xy[path[k + 1]]
    lay = node_layer[path[k]] if w < 0.5 else node_layer[path[k + 1]]
    return xy, lay, path
