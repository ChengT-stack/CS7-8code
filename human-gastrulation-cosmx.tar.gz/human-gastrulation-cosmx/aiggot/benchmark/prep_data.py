"""Prepare benchmark inputs (run in env 'stvcr' which has harmonypy).
Reproduces the data preparation of the reference run and of the held-out-gene protocol EXACTLY
(same code as the lineage of heldout_gene_validation.csv) and writes one npz bundle."""
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import os
for k, v in [("KMP_AFFINITY", "disabled"), ("OMP_NUM_THREADS", "8"), ("KMP_INIT_AT_FORK", "FALSE")]:
    os.environ[k] = v
import numpy as np, pandas as pd, anndata as ad, scanpy as sc, harmonypy as hm, json, time
from scipy.spatial import cKDTree

ART = os.path.join(DATA, "artifacts") + "/"
A = ad.read_h5ad(f"{ART}/cs7_cs8_germlayers_harmony.h5ad")
print(A.shape, list(A.obs.columns)[:60], list(A.obsm.keys()), list(A.layers.keys()))
obs = A.obs.copy(); obs["g"] = obs.label_short.astype(str)
SPC = ["AP_arc_frac", "LR_frac", "DV_gap_units"]
H = A.obsm["X_harmony"]; G = obs.g.to_numpy(); ZW = obs.z_weight.to_numpy(float)
SP = obs[SPC].to_numpy(float); EMB = obs.embryo.to_numpy(); XYZ = obs[["x_um", "y_um", "z_um"]].to_numpy(float)
T = json.load(open(f"{ART}/transition_table.json"))
i7 = np.where((EMB == "CS7") & np.isin(G, T["cs7_groups"]))[0]
i8 = np.where((EMB == "CS8") & np.isin(G, T["cs8_groups"]))[0]
print("n7 n8", len(i7), len(i8))

Hs_ref = np.load(f"{ART}/harmony_smoothed.npy")
print("smoothed shape", Hs_ref.shape)

def smooth_embedding(H, XYZ, G, EMB, k=15):
    Hs = np.zeros_like(H)
    for e in np.unique(EMB):
        for g in np.unique(G[EMB == e]):
            idx = np.where((EMB == e) & (G == g))[0]
            kk = min(k, len(idx))
            _, nn = cKDTree(XYZ[idx]).query(XYZ[idx], k=kk)
            nn = np.atleast_2d(nn).reshape(len(idx), kk)
            Hs[idx] = H[idx][nn].mean(1)
    return Hs

Hs_chk = smooth_embedding(H, XYZ, G, EMB, 15)
print("row-order check max|diff| smoothed vs recomputed:", float(np.abs(Hs_chk - Hs_ref).max()))

HELD = ["TBXT", "MIXL1", "EOMES", "CER1", "NOTO", "CHRD", "FOXJ1", "SHH", "GSC", "LHX1",
        "OTX2", "SIX3", "SOX17", "FOXA2", "CDX2", "NKX1-2", "TBX6", "MESP1", "HAND1", "FOXF1",
        "TBX3", "MSX2", "SOX2", "POU5F1", "NANOG", "LIN28A", "CDH1", "CDH2", "SNAI1", "SNAI2",
        "HOXA1", "HOXB1", "PAX6", "OLIG2", "DKK1", "SFRP1", "NOG", "LEFTY1", "LEFTY2", "NODAL"]
HELD = [g for g in HELD if g in A.var_names]; print("held", len(HELD))
t0 = time.time()
Ah = A.copy(); Ah.X = Ah.layers["counts"].copy()
sc.pp.normalize_total(Ah, target_sum=1e4); sc.pp.log1p(Ah)
sc.pp.highly_variable_genes(Ah, n_top_genes=2000, flavor="seurat_v3", layer="counts", batch_key="embryo")
keep = [g for g in Ah.var_names[Ah.var.highly_variable.to_numpy()] if g not in HELD]; print("keep", len(keep))
Ah = A[:, keep].copy(); Ah.X = Ah.layers["counts"].copy()
sc.pp.normalize_total(Ah, target_sum=1e4); sc.pp.log1p(Ah); sc.pp.scale(Ah, max_value=10); sc.tl.pca(Ah, n_comps=30)
ho = hm.run_harmony(Ah.obsm["X_pca"], Ah.obs, "harmony_batch", max_iter_harmony=20, verbose=False)
Hh = np.asarray(ho.Z_corr); Hh = Hh.T if Hh.shape[0] == 30 else Hh
Hhs = smooth_embedding(Hh, XYZ, G, EMB, k=15); print("heldout harmony done", Hh.shape, round(time.time() - t0))

Xc = A.layers["counts"].tocsr(); gi_ = A.var_names.get_indexer(HELD); nC = A.obs.nCount.to_numpy(float)
def cp10k(idx): return Xc[idx][:, gi_].toarray() / nC[idx, None] * 1e4
E7h = cp10k(i7); E8h = cp10k(i8)
def smooth_expr(E, idx):
    out = np.zeros_like(E)
    for g in np.unique(G[idx]):
        m = np.where(G[idx] == g)[0]; kk = min(15, len(m))
        _, nn = cKDTree(XYZ[idx][m]).query(XYZ[idx][m], k=kk); nn = np.atleast_2d(nn).reshape(len(m), kk)
        out[m] = E[m][nn].mean(1)
    return out
E7s = smooth_expr(E7h, i7); E8s = smooth_expr(E8h, i8)

os.makedirs("bench/data", exist_ok=True)
np.savez_compressed("bench/data/bench_inputs.npz",
    Hs7=Hs_ref[i7].astype(np.float32), Hs8=Hs_ref[i8].astype(np.float32),
    Hhs7=Hhs[i7].astype(np.float32), Hhs8=Hhs[i8].astype(np.float32),
    S7=SP[i7], S8=SP[i8], g7=G[i7], g8=G[i8], a=ZW[i7], b=ZW[i8],
    XYZ7=XYZ[i7], XYZ8=XYZ[i8], E7s=E7s, E8s=E8s, E8h=E8h, held=np.array(HELD),
    cells7=A.obs_names[i7].to_numpy().astype(str), cells8=A.obs_names[i8].to_numpy().astype(str),
    cs7_groups=np.array(T["cs7_groups"]), cs8_groups=np.array(T["cs8_groups"]))
json.dump(T, open("bench/data/transition_table.json", "w"))
print("saved", os.path.getsize("bench/data/bench_inputs.npz") / 1e6, "MB")
