# Export of the published Stereo-seq CS7 (Cui et al., HRA006197) and CS8 (Xiao et al., HRA005567) Seurat objects
# ({CS7,CS8}-RNA-MapQ.rds) to MatrixMarket counts + gene list + spot metadata, consumed by stereoseq_frames_pipeline.py.
# Verbatim from Stereo-seq replication session 048691a1 message [26]; only the input path was replaced by HGC_DATA.
# Run from the Stereo-seq working directory (writes export/).
DATA <- Sys.getenv("HGC_DATA", "data")   # input data root (see README)
suppressPackageStartupMessages({library(Seurat); library(Matrix)})
dir.create("export", showWarnings=FALSE)
for (st in c("CS7","CS8")) {
  obj <- readRDS(file.path(DATA, sprintf("%s-RNA-MapQ.rds", st)))
  md <- obj@meta.data
  seccol <- if (st=="CS7") "Section_final" else "Section"
  cat(st, dim(obj), "\n"); print(head(colnames(md), 40))
  cnt <- GetAssayData(obj, assay="RNA", layer="counts")
  stopifnot(all(cnt@x == round(cnt@x)))
  writeMM(cnt, sprintf("export/%s_counts.mtx", st))
  write.csv(data.frame(gene=rownames(cnt)), sprintf("export/%s_genes.csv", st), row.names=FALSE)
  sp <- data.frame(spot=colnames(obj), stage=st, section=md[[seccol]], x=md$newx, y=md$newy,
                   nCount=md$nCount_RNA, Types=md$Types, Type2=md$Type2, Type3=md$Type3, stringsAsFactors=FALSE)
  write.csv(sp, sprintf("export/%s_spots.csv", st), row.names=FALSE)
  cat(st, "sections:", length(unique(sp$section)), " x range", range(sp$x), " y range", range(sp$y), "\n")
  print(table(is.na(sp$x)))
  rm(obj, cnt); gc()
}
