# 100-cycle closed-loop optimisation of the t0.5 generator on Mittnenzweig validation embryos.
# Each cycle: 2 Bayesian (TPE) proposals + 2 diagnostic-guided mutations of the incumbent; locked-test embryos are never used here.
import sys, json, time, os, numpy as np, pandas as pd, optuna, torch
sys.path.insert(0,'ai/step7'); from lib7 import *
optuna.logging.set_verbosity(optuna.logging.WARNING)
NC=int(sys.argv[1]) if len(sys.argv)>1 else 30; LOG='ai/step7/cycles2.jsonl'
E=pd.read_csv('ai/mz_bench/embryo_split.csv',index_col=0); TV=set(E.index[E.split.isin(['T','V'])])
mzc=np.where((R['ds']=='MZ')&valid)[0]
def ref_idx(t): return mzc[np.isin(emb[mzc],list(TV-{t['ea'],t['em'],t['eb']}))]
REF={s:[torch.as_tensor(ref_idx(t),device=dev) for t in TR[s]] for s in ['val','locked']}
ET=torch.tensor(np.nan_to_num(etime),device=dev,dtype=torch.float32)
@torch.no_grad()
def knn_time(X,ri,k=30):
    d=torch.cdist(X,Zt[ri]); nn_=d.topk(k,largest=False).indices; return float(ET[ri][nn_].mean(1).median())
@torch.no_grad()
def disp(X,Y,cap=400):
    X=X[:cap]; Y=Y[torch.randperm(len(Y),device=dev)[:cap]]; return float(torch.pdist(X).mean()/torch.pdist(Y).mean())
@torch.no_grad()
def evaluate(M,cfg,split='val',seed=0):
    rows=[]; g=torch.Generator(device=dev)
    for i,t in enumerate(TR[split]):
        X=generate(M,cfg,t,seed=seed); Y=Zt[torch.as_tensor(t['im'],device=dev)]; g.manual_seed(123)
        rows.append(dict(em=t['em'],ta=t['ta'],ED=float(L.energy(X,Y,gen=g)),terr=24*(knn_time(X,REF[split][i])-t['tm']),disp=disp(X,Y)))
    return pd.DataFrame(rows)
def score(df,base):
    m=df.groupby('em').agg(ED=('ED','mean'),terr=('terr','mean'),disp=('disp','mean')); b=base.groupby('em').agg(ED=('ED','mean'),terr=('terr','mean'))
    ed=np.log(m.ED/b.ED); tp=0.1*(m.terr.abs()-b.terr.abs())
    return float((ed+tp).mean()), dict(ED_part=float(ed.mean()),time_part=float(tp.mean()),bias_h=float(m.terr.median()),abs_terr_h=float(m.terr.abs().median()),disp=float(m.disp.median()))
# ---------- baselines (sigma tuned on TRAIN triplets only)
def tune_sigma():
    best=None
    for s in [0.1,0.2,0.3,0.4,0.5,0.6,0.8]:
        cfg=dict(pair='emd_cen',sigma0=s); v=[]
        for t in TR['train'][::3]:
            X=generate(('linear_noise',None),cfg,t); Y=Zt[torch.as_tensor(t['im'],device=dev)]; v.append(float(L.energy(X,Y)))
        if best is None or np.mean(v)<best[0]: best=(np.mean(v),s)
    return best[1]
if os.path.exists('ai/step7/baseline.json'): BJ=json.load(open('ai/step7/baseline.json')); SIG=BJ['sigma0']
else:
    SIG=tune_sigma(); json.dump(dict(sigma0=SIG),open('ai/step7/baseline.json','w'))
BCFG=dict(pair='emd_cen',sigma0=SIG); BASE=evaluate(('linear_noise',None),BCFG); LINV=evaluate(('linear',None),dict(pair='emd_cen'))
print('baseline sigma',SIG,' linear vs base:',round(score(LINV,BASE)[0],4),flush=True)
# ---------- search space
RANGES=dict(ds=(0.0,3.0),ns=(0.0,3.0),shrink=(0.0,200.0),vfloor=(0.0,0.2),lr=(1e-4,3e-3),wd=(1e-6,1e-2),lam=(1e-4,1.0),sig_init=(-3.0,0.0),drop=(0.0,0.3),sigma=(0.0,0.3),steps=(500,4000),L=(2,4))
def suggest(tr):
    c=dict(family=tr.suggest_categorical('family',['net']),inv=tr.suggest_categorical('inv',[0,1,2]),pair=tr.suggest_categorical('pair',PAIRS),ds=tr.suggest_float('ds',*RANGES['ds']),ns=tr.suggest_float('ns',*RANGES['ns']))
    if c['family']=='calib':
        c.update(group_specific=tr.suggest_categorical('group_specific',[0,1]),shrink=tr.suggest_float('shrink',*RANGES['shrink']),dscale=tr.suggest_categorical('dscale',[0,1]),
                 iso=tr.suggest_categorical('iso',[0,1]),use_pijuan=tr.suggest_categorical('use_pijuan',[0,1]),vfloor=tr.suggest_float('vfloor',*RANGES['vfloor']))
    elif c['family']=='net':
        c.update(h=tr.suggest_categorical('net_h',[128,256,512]),L=tr.suggest_int('L',*RANGES['L']),drop=tr.suggest_float('drop',*RANGES['drop']),lr=tr.suggest_float('lr',*RANGES['lr'],log=True),
                 wd=tr.suggest_float('wd',*RANGES['wd'],log=True),steps=tr.suggest_int('steps',*RANGES['steps'],step=250),bs=tr.suggest_categorical('bs',[128,256,512]),
                 lam=tr.suggest_float('lam',*RANGES['lam'],log=True),use_pijuan=tr.suggest_categorical('use_pijuan',[0,1]),sig_init=tr.suggest_float('sig_init',*RANGES['sig_init']))
    else:
        c.update(h=tr.suggest_categorical('flow_h',[256,512,1024]),L=tr.suggest_int('L',*RANGES['L']),lr=tr.suggest_float('lr',*RANGES['lr'],log=True),wd=tr.suggest_float('wd',*RANGES['wd'],log=True),
                 steps=tr.suggest_int('steps',*RANGES['steps'],step=250),sigma=tr.suggest_float('sigma',*RANGES['sigma']),K=tr.suggest_categorical('K',[10,20,40]))
    return c
def clip(p):
    for k,(lo,hi) in RANGES.items():
        if k in p: p[k]=type(lo)(min(max(p[k],lo),hi)) if not isinstance(lo,int) else int(min(max(round(p[k]),lo),hi))
    if 'steps' in p: p['steps']=int(round(p['steps']/250)*250)
    return p
def mutations(inc,diag,rng):
    out=[]; a=dict(inc)
    # A: timing
    if diag['bias_h']<-0.4: a['ds']=a['ds']*1.25+0.05; why=f"time bias {diag['bias_h']:.1f} h (lags real embryo) -> drift scale x1.25"
    elif diag['bias_h']>0.4: a['ds']=a['ds']*0.8; why=f"time bias {diag['bias_h']:+.1f} h (overshoots) -> drift scale x0.8"
    else: a['pair']=rng.choice([p for p in PAIRS if p!=a['pair']]); why=f"timing on target ({diag['bias_h']:+.1f} h) -> try pairing {a['pair']}"
    out.append((clip(a),why))
    b=dict(inc)
    if diag['disp']<0.97: b['ns']=b['ns']*1.15+0.02; why=f"generated spread {diag['disp']:.2f}x real -> noise x1.15"
    elif diag['disp']>1.03: b['ns']=b['ns']*0.87; why=f"generated spread {diag['disp']:.2f}x real -> noise x0.87"
    else:
        keys=[k for k in ['shrink','vfloor','lr','wd','lam','sig_init','drop','sigma','steps'] if k in b]
        if keys: k=rng.choice(keys); b[k]=b[k]*rng.uniform(0.6,1.6) if k!='sig_init' else b[k]+rng.normal(0,0.3); why=f"spread on target ({diag['disp']:.2f}) -> perturb {k}"
        else: b['ds']=b['ds']*rng.uniform(0.9,1.1); why='spread on target -> small drift perturbation'
    out.append((clip(b),why))
    return out
u7=np.load('ai/step5_u7.npy'); u8=np.load('ai/step5_u8.npy'); HREF=Zt[torch.as_tensor(np.r_[u7,u8],device=dev)]
HD=dict(HUM); HD['ta']=7.25; HD['tb']=7.625
@torch.no_grad()
def knnd(X,k=10): return float(torch.cat([torch.cdist(X[i:i+2048],HREF).topk(k,largest=False).values.mean(1) for i in range(0,len(X),2048)]).mean())
HLIN=None
def run(cfg,seed=0):
    global HLIN
    M=fit(cfg,seed); df=evaluate(M,cfg,'val',seed); s,d=score(df,BASE)
    if HLIN is None: HLIN=knnd(generate(('linear',None),dict(pair='emd_top'),HD))
    hp=knnd(generate(M,cfg,HD,seed=seed))/HLIN; d['human_plaus']=hp; s=s+0.5*max(0.0,hp-1.15); return s,d
st=optuna.create_study(study_name='s7b',storage='sqlite:///ai/step7/opt2.db',direction='minimize',load_if_exists=True,
                       sampler=optuna.samplers.TPESampler(seed=7,multivariate=True,group=True,n_startup_trials=12,constant_liar=True))
done=0
if os.path.exists(LOG): done=max([json.loads(l)['cycle'] for l in open(LOG)]+[-1])+1
if done==0:  # cycle 0: best of loop 1 with each invariance option
    b=dict(family='net',pair='emd_top',ds=0.9848,ns=0.9688,net_h=256,L=2,drop=0.1046,lr=0.0019,wd=0.0004,steps=3500,bs=256,lam=0.0119,use_pijuan=0,sig_init=-0.7521)
    for inv in [0,1,2]: st.enqueue_trial(dict(b,inv=inv))
    st.enqueue_trial(dict(b,inv=2,use_pijuan=1))
rng=np.random.default_rng(100+done)
for cyc in range(done,NC):
    t0=time.time(); slots=[]
    if cyc>0:
        inc=st.best_trial; d=inc.user_attrs
        for p,why in mutations(inc.params,d,rng): st.enqueue_trial(p,skip_if_exists=True); slots.append(why)
    nslot=4; trials=[st.ask() for _ in range(nslot)]; whys=slots+['TPE proposal']*(nslot-len(slots)) if cyc>0 else ['seed config']*nslot
    for tr,why in zip(trials,whys):
        try:
            cfg=suggest(tr); s,d=run(cfg)
            for k,v in d.items(): tr.set_user_attr(k,v)
            tr.set_user_attr('why',why); st.tell(tr,s)
        except Exception as e:
            st.tell(tr,state=optuna.trial.TrialState.FAIL); s=None; d={}; print('fail',repr(e)[:200],flush=True)
        prev=min([t.value for t in st.trials if t.value is not None and t.number<tr.number],default=np.inf)
        rec=dict(cycle=cyc,trial=tr.number,why=why,family=tr.params.get('family'),pair=tr.params.get('pair'),score=s,**d,new_best=bool(s is not None and s<prev),best_so_far=st.best_value)
        open(LOG,'a').write(json.dumps(rec)+'\n')
    b=st.best_trial
    print(f"cycle {cyc:3d}  {time.time()-t0:5.0f}s  best={b.value:+.4f} (trial {b.number}, inv {b.params['inv']}, human {b.user_attrs['human_plaus']:.2f}, ED {b.user_attrs['ED_part']:+.3f}, time {b.user_attrs['time_part']:+.3f}, bias {b.user_attrs['bias_h']:+.1f}h, spread {b.user_attrs['disp']:.2f})",flush=True)
