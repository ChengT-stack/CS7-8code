# gastruloid/02_milestone_scoring/stage_v2.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/stage_v2.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Milestone assessability for all gastruloid / embryo-model samples (extends gall/stage_all.py):
#  - 45 previously staged groups: per-group calls re-used from gall/out/evidence.csv
#  - Hee_42 re-staged from the correctly oriented matrix (gall/groups_fix); Liu, Pedroza, Weatherbee staged for the first time (gall/groups_new)
#  - new: marker genes missing from a matrix make the milestone 'not assessable' instead of 'not reached'
import json, glob, sys, os, numpy as np, pandas as pd, anndata as ad, scanpy as sc, warnings; warnings.filterwarnings('ignore')
sys.path.insert(0, str(Path(__file__).resolve().parent)); import stage_lib as L
R, N, P, A = L.R, L.N, L.P, L.A; MM = 14848.0; OUT = 'gall/out_v2/'; os.makedirs(OUT, exist_ok=True)
B = (str(HGC_DATA) + '/')
rows = [json.load(open(f)) for f in sorted(glob.glob('gall/groups/*.json')) if not f.endswith('Hee_42.json')]
NEW = {'Hee_42': ('gall/groups_fix/', 'Hee', 1), 'Liu_PG_d11': ('gall/groups_new/', 'Liu', 1), 'Ped_hEE_D4': ('gall/groups_new/', 'Ped', 1), 'Ped_hEE_D6': ('gall/groups_new/', 'Ped', 2),
       'Wea_d4': ('gall/groups_new/', 'Wea', 1), 'Wea_d6': ('gall/groups_new/', 'Wea', 2), 'Wea_d8': ('gall/groups_new/', 'Wea', 3)}
AD = {}
for gid, (d, se, o) in NEW.items():
    j = json.load(open(d + gid + '.json')); a = ad.read_h5ad(d + gid + '.h5ad'); print(gid, a.shape, list(a.obs.columns)[:8], flush=True)
    if 'sub' not in a.obs or 'n_umi' not in a.obs:
        a, qi = L.qc(a, 'human'); a.obs['sub'], a.obsm['X_umap'] = L.subcl(a); j.update(qi)
    j.update(group=gid, series=se, order=o, genes_in_matrix=int(a.n_vars), cells_kept=int(a.n_obs), median_umi=float(a.obs.n_umi.median()), median_genes=float(a.obs.n_genes.median()), n_sub15=int((a.obs['sub'].value_counts() >= 15).sum()))
    j.setdefault('label', gid); rows.append(j); AD[gid] = a
INFO = pd.DataFrame(rows).set_index('group'); INFO['dataset'] = INFO.dataset.replace({'Miao 2023': 'Budjan 2022'})
INFO['keep_prob'] = (INFO.median_umi.clip(upper=MM) / MM).round(4); INFO['downsampled_to_mouse_depth'] = INFO.median_umi > MM
# mouse curves for the new groups
CV = pd.read_csv('gall/mouse_curves_depth_matched.csv'); CV = CV[~CV['sample'].isin(NEW)]
mm = ad.read_h5ad(B + 'external/mouse_pijuan_sala/mouse_atlas_mapped_rawcounts.h5ad')
GM = ['T', 'Eomes', 'Hoxa1', 'Hoxb1', 'Hoxb8', 'Hoxb9']; sts = ['E6.5', 'E6.75', 'E7.0', 'E7.25', 'E7.5', 'E7.75', 'E8.0', 'E8.25', 'E8.5']
Xm = np.asarray(mm[:, GM].X.todense()).astype(np.int64); stg = mm.obs.stage.astype(str).values; ct = mm.obs.celltype.astype(str)
okm = ~ct.isin(['Visceral endoderm', 'Mesenchyme']).values; ce = (ct == 'Caudal epiblast').values; del mm
def curves(p, seed=0):
    Y = np.random.default_rng(seed).binomial(Xm, p) if p < 1 else Xm
    D_ = pd.DataFrame(Y > 0, columns=GM); D_['st'] = stg
    tpl = D_[D_['T'].values & okm]; a_ = tpl.groupby('st')[['Eomes', 'Hoxa1', 'Hoxb1']].mean().mul(100).loc[sts]; a_['n'] = tpl.groupby('st').size().loc[sts]
    cc = D_[ce]; b_ = cc.groupby('st')[['Hoxb8', 'Hoxb9']].mean().mul(100); b_['n'] = cc.groupby('st').size(); b_ = b_.loc[[s for s in sts if s in b_.index and b_.loc[s, 'n'] >= 50]]
    return a_, b_
add = []
for g in NEW:
    p = float(INFO.loc[g, 'keep_prob']); a_, b_ = curves(p)
    for ref, tab in [('T+ pool', a_), ('caudal epiblast', b_)]:
        for s_, r_ in tab.iterrows():
            for g_ in [c for c in tab.columns if c != 'n']: add.append(dict(sample=g, median_umi=float(INFO.loc[g, 'median_umi']), keep_prob=round(p, 4), reference=ref, stage=s_, E=float(s_[1:]), gene=g_, detection_pct=r_[g_], n_cells=int(r_['n'])))
CV = pd.concat([CV, pd.DataFrame(add)], ignore_index=True); CV.to_csv(OUT + 'mouse_curves_depth_matched.csv', index=False)
# calls
E0 = pd.read_csv('gall/out/evidence.csv'); E0 = E0[E0['sample'] != 'Hee_42']
CALLS = {g: d.set_index('milestone_id').call_observed.to_dict() for g, d in E0.groupby('sample')}; CALLS_D = {g: d.set_index('milestone_id').call_observed_depth_matched.to_dict() for g, d in E0.groupby('sample')}
EV = [E0[['sample', 'milestone_id', 'call_observed', 'call_observed_depth_matched', 'metric', 'evidence', 'pool_n']]]
for gid, a in AD.items():
    if INFO.loc[gid, 'downsampled_to_mouse_depth']: sc.pp.downsample_counts(a, counts_per_cell=int(MM), random_state=0)
    ev, c, cd, ck = L.stage_group(a, 'human', gid, CV); CALLS[gid] = c; CALLS_D[gid] = cd; EV.append(pd.DataFrame(ev)); print('staged', gid, flush=True)
EV = pd.concat(EV, ignore_index=True)
SERIES = {g: list(INFO[(INFO.series == r.series) & (INFO.order < r.order)].sort_values('order').index) for g, r in INFO.iterrows()}
ORDER = list(INFO.sort_values(['species', 'dataset', 'series', 'order']).index); MS = sorted(L.ONSET)
KW = dict(naive_first=['Ham_0h'], hours=INFO.hours.to_dict(), naive_series=['Ham'], series_id=INFO.series.to_dict())
def table(fin): return pd.DataFrame({g: [fin[g][m] for m in MS] for g in ORDER}, index=MS)
C = table(L.onset_logic(ORDER, CALLS, SERIES, mode='timeaware', **KW)); CS = table(L.onset_logic(ORDER, CALLS, SERIES, mode='strict', **KW))
old = pd.read_csv('gall/out/calls.csv', index_col=0); same = [g for g in old.columns[3:] if g != 'Hee_42']
assert (C[same].values == old.loc[MS, same].values).all(), 'previous calls not reproduced'
print('Hee_42 changes', {m: (old.loc[m, 'Hee_42'], C.loc[m, 'Hee_42']) for m in MS if old.loc[m, 'Hee_42'] != C.loc[m, 'Hee_42']})
# marker genes measured? (absent from the matrix, or zero counts in every cell of a library)
GEN = {'m01': ['MESP1', 'TBX6'], 'm02': ['GSC', 'FOXA2'], 'm03': ['FOXJ1', 'CHRD'], 'm04': ['FOXA2', 'SOX17'], 'm05': ['FOXA2', 'SOX17', 'GSC', 'CER1'], 'm06': ['FOXA2', 'SOX17', 'GSC'], 'm07': ['NOTO'], 'm08': ['TBXT', 'HOXA1|HOXB1'],
       'm09': ['NKX1-2', 'CDX2'], 'm10': ['HESX1', 'SIX3'], 'm11': ['MEOX1', 'TCF15'], 'm12': ['TBXT', 'EOMES'], 'm13': ['NKX1-2', 'CDX2', 'HOXB8'], 'm14': ['NKX2-5', 'TNNT2'], 'm15': ['NANOS3', 'TFAP2C'], 'm16': ['KDR', 'ETV2'], 'm17': ['HAND1'],
       'm18': ['TBX4', 'HOXA10'], 'm19': ['HBE1', 'GATA1']}
GEN_M = dict(GEN); GEN_M['m15'] = ['NANOS3', 'DPPA3']; GEN_M['m19'] = ['HBA-X', 'GATA1']
allg = sorted({x for v in list(GEN.values()) + list(GEN_M.values()) for g in v for x in g.split('|')}); gm = []
for gid, r in INFO.iterrows():
    a = AD[gid] if gid in AD else ad.read_h5ad(f'gall/groups/{gid}.h5ad'); sp_ = r.species; libs = a.obs['replicate'].astype(str).values if 'replicate' in a.obs else np.array(['all'] * a.n_obs)
    for g in allg:
        n_ = L.sym(g, sp_)
        if n_ not in a.var_names and g == 'TBXT' and 'T' in a.var_names: n_ = 'T'
        inm = n_ in a.var_names; x = np.asarray(a[:, n_].X.todense()).ravel() if inm else np.zeros(a.n_obs)
        for lb in np.unique(libs):
            i = libs == lb; gm.append(dict(group=gid, library=lb, n_cells=int(i.sum()), gene=g, in_matrix=inm, counts=float(x[i].sum()), cells_detected=int((x[i] > 0).sum())))
    print('genes', gid, flush=True)
GMt = pd.DataFrame(gm); GMt.to_csv(OUT + 'marker_gene_measured_by_library.csv', index=False)
meas = GMt.assign(ok=GMt.in_matrix & (GMt.counts > 0)).groupby(['group', 'gene']).ok.any()   # measured in at least one library of the group
def missing(gid, m):
    G_ = GEN if INFO.loc[gid, 'species'] == 'human' else GEN_M; out = []
    for g in G_[m]:
        if not any(meas.get((gid, x), False) for x in g.split('|')): out.append(g.replace('|', '/'))
    return out
long = []
for gid in ORDER:
    for m in MS:
        call = C.loc[m, gid]; e = EV[(EV['sample'] == gid) & (EV.milestone_id == m)].iloc[0]; obs = e.call_observed; mis = missing(gid, m); reason = ''
        if call == A:
            if 'no DE-like population' in str(e.evidence) and m == 'm06': reason = 'no DE-like population'
            elif 'pool n=' in str(e.evidence) and '(<15)' in str(e.evidence): reason = 'reference pool < 15 cells'
            else: reason = 'transient population absent in a late sample'
        if mis and not call.startswith(R):
            reason = 'marker not detected in any cell (' + ', '.join(mis) + ')'; call = A
        long.append(dict(group=gid, dataset=INFO.loc[gid, 'dataset'], species=INFO.loc[gid, 'species'], label=INFO.loc[gid, 'label'], hours=INFO.loc[gid, 'hours'], milestone_id=m, milestone=L.MNAME[m], domain=L.DOM[m], mouse_onset=L.ONSET[m],
                         call=call, call_strict=CS.loc[m, gid], call_observed=obs, testable=call != A, reason_not_testable=reason, metric=e.metric, pool_n=e.pool_n, evidence=e.evidence))
LG = pd.DataFrame(long); LG.to_csv(OUT + 'milestone_assessability_long.csv', index=False); INFO.to_csv(OUT + 'groups.csv')
LG.pivot(index='milestone_id', columns='group', values='call').loc[MS, ORDER].to_csv(OUT + 'calls_all_samples.csv')
print(LG.call.value_counts().to_dict()); print(LG[~LG.testable].reason_not_testable.str.slice(0, 40).value_counts().to_dict())
print(LG.groupby('dataset').apply(lambda d: pd.Series(dict(samples=d.group.nunique(), testable_any=int(d.groupby('milestone_id').testable.any().sum()), reached_any=int(d.groupby('milestone_id').call.apply(lambda s: s.str.startswith(R).any()).sum())))).to_string())
