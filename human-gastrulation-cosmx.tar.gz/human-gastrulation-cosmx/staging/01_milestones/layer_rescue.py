# staging/01_milestones/layer_rescue.py
# Source: drive G: data/milestone_evidence/mz/rescue/rescue.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

import pandas as pd, numpy as np, scipy.io, h5py
from scipy.stats import binomtest
B=(str(HGC_DATA) + '/'); OD=B+'staging/layer_rescue/'
GN=["NOTO","SHH","CHRD","FOXJ1","FOXA2","TBXT","HOXB1","EOMES","NKX1-2","CDX2","HOXB8","HESX1","SIX3","MEOX1","TCF15","NKX2-5","TNNT2","GSC","CER1","SOX17","NANOS3","TFAP2C","PRDM1","TBX4","HOXA10"]
def cosmx(s):
    genes=pd.read_csv(B+'dataprep/export/genes.csv').gene.values; gi=[int(np.where(genes==g)[0][0]) for g in GN]
    m=scipy.io.mmread(B+f'dataprep/export/{s}_counts.mtx').tocsr()
    X=pd.DataFrame((np.asarray(m[gi].todense()).T>0).astype(int),columns=GN)
    c=pd.read_csv(B+f'dataprep/export/{s}_cells.csv'); X['label']=c.label_short.values
    lay={'EPI':'E','ECT':'E','aECT':'E','pECT':'E','NNE':'E','CLE':'E','PS':'E','APS':'M','Nas.Meso':'M','Para.Meso':'M','Rostral.Meso':'M','LP.Meso':'M','Heart.Meso':'M',
         'Node':'X','Notochord':'X','PrP':'X','DE':'N','AVE':'N','ADE':'N','VE1':'VE','VE2':'VE'}
    X['layer']=X.label.map(lay); return X
def stereo(s):
    h=h5py.File(f'{HGC_DATA}/CS7_CS8_feature_plots/data/{s}.h5ad','r')
    var=[v.decode() for v in h['var']['_index'][:]]; idx=[var.index(g) for g in GN]
    G=h['X']; import scipy.sparse as sp
    M=sp.csr_matrix((G['data'][:],G['indices'][:],G['indptr'][:]),shape=(len(h['obs']['_index']),len(var)))[:,idx]
    X=pd.DataFrame((M.toarray()>0).astype(int),columns=GN)
    cells=[v.decode().split('_',1)[1] for v in h['obs']['_index'][:]]
    L=pd.read_csv(B+'external/human_stereoseq/stereoseq_cell_labels.csv').set_index('cell').loc[cells]
    X['label']=L.our_group_fine.fillna('exclude').values; t2=L.Type2.astype(str).values
    lay={'EPI':'E','NNE':'E','CLE':'E','aECT':'E','pECT':'E','PS':'E','APS':'M','Nas.Meso':'M','Para.Meso':'M','Rostral.Meso':'M','LP.Meso':'M','Heart mesoderm':'M','Adv.Meso':'M','Other.Meso':'M',
         'Node':'X','DE':'N','Gut':'N','VE':'VE'}
    X['layer']=X.label.map(lay)
    mx=np.isin(t2,['29 EXM','30 Allantois','31 YS.Meso']) & X.layer.isna().values; X.loc[mx,'layer']='Mx'
    X.loc[X.layer.isna(),'layer']='other'; return X
def tenx():
    X=pd.read_csv(OD+'inhouse10x_CS7.csv'); n=X.label.str.split().str[0].astype(int)
    m={**{k:'E' for k in [1,2,3,4,5,8,12,15]},**{k:'M' for k in range(16,29)},**{k:'Mx' for k in [29,30,31]},9:'X',10:'X',35:'N',36:'N',37:'N',38:'VE'}
    X['layer']=n.map(m).fillna('other'); X.loc[X.label.isin(['39 Trophoblast','13 AME']),'layer']='bg'; return X
def tyser():
    X=pd.read_csv(OD+'tyser_CS7.csv')
    m={'Epiblast':'E','Primitive Streak':'E','NNE':'E','Nascent Mesoderm':'M','Emergent Mesoderm':'M','Advanced Mesoderm':'M','YS Mesoderm':'Mx','Axial Mesoderm':'X',
       'DE(P)':'N','DE(NP)':'N','Hypoblast':'VE','YS Endoderm':'VE','Amnion':'bg'}
    X['layer']=X.label.map(m).fillna('other'); return X
DS={'Tyser CS7 (Smart-seq2)':tyser,'HuE#1 CS7 (CosMx)':lambda:cosmx('CS7'),'Xiao CS8 (Stereo-seq)':lambda:stereo('CS8'),
    'Cui CS7 (Stereo-seq)':lambda:stereo('CS7'),'HuE#2 CS8 (CosMx)':lambda:cosmx('CS8'),'In-house CS7 (10x)':tenx}
EMB=['E','M','X','N']
T=[ # milestone key, kind, pool function, rule
("ADE appears (Gsc+Cer1+ DE)","co",lambda X:(X.layer=='N')&((X.SOX17==1)|(X.FOXA2==1)),("GSC","CER1"),'endo'),
("ADE programme regresses (Gsc in DE)","loss",lambda X:(X.layer=='N')&((X.SOX17==1)|(X.FOXA2==1)),("GSC",),'endo'),
("Notochord forms","co",lambda X:X.layer.isin(['X','M','N']),("NOTO","FOXA2"),'other'),
("HOX on in streak (Hoxb1)","onset",lambda X:X.layer.isin(['E','M'])&(X.TBXT==1),("HOXB1",),'other'),
("Caudal epiblast forms","co",lambda X:X.layer=='E',("NKX1-2","CDX2"),'other'),
("Neural plate (rostral neurectoderm)","co",lambda X:X.layer=='E',("HESX1","SIX3"),'other'),
("Paraxial mesoderm forms","co",lambda X:X.layer=='M',("MEOX1","TCF15"),'other'),
("EOMES switched off in streak","loss",lambda X:X.layer.isin(['E','M'])&(X.TBXT==1),("EOMES",),'other'),
("5′ HOX on in caudal epiblast (Hoxb8)","onset",lambda X:X.layer.isin(['E','M'])&(X['NKX1-2']==1)&(X.CDX2==1),("HOXB8",),'other'),
("Cardiomyocytes appear","co",lambda X:X.layer.isin(['M','Mx']),("NKX2-5","TNNT2"),'other'),
("PGCs appear","co",lambda X:X.layer!='bg',("NANOS3","TFAP2C"),'other'),
("Allantois forms","co",lambda X:X.layer.isin(['M','Mx']),("TBX4","HOXA10"),'other')]
calls=pd.read_csv('mz/allstage/calls.csv').set_index('milestone')
def bgmask(X,kind):
    if (X.layer=='bg').any(): return X.layer=='bg'
    return (X.layer=='E')&(X.label.isin(['ECT','EPI'])) if kind=='endo' else (X.layer=='VE')
rows=[]
for dn,f in DS.items():
    X=f(); print(dn, X.shape, X.layer.value_counts().to_dict())
    for key,kind,pool,genes,bk in T:
        P=pool(X); n=int(P.sum()); bg=bgmask(X,bk)
        r=dict(dataset=dn,milestone=key,original_call=calls.loc[key,dn],kind=kind,pool_n=n,rule='+'.join(genes))
        if kind=='co':
            a,b=genes; d=int(((X[a]==1)&(X[b]==1)&P).sum()); pa=X.loc[P,a].mean() if n else np.nan; pb=X.loc[P,b].mean() if n else np.nan
            exp=pa*pb; pbg=((X[a]==1)&(X[b]==1)&bg).mean()/max(bg.mean(),1e-9) if bg.sum() else np.nan
            p=binomtest(d,n,exp,alternative='greater').pvalue if n and exp>0 else np.nan
            pct=100*d/n if n else np.nan; oe=(d/n)/exp if n and exp>0 else np.nan
            r.update(n_pos=d,pct_pos=round(pct,2),expected_pct=round(100*exp,2),obs_over_exp=round(oe,2) if oe==oe else np.nan,P=p,bg_pct=round(100*pbg,2),bg_n=int(bg.sum()))
            res= (d>=10) and pct>=0.5 and oe>=2 and p<1e-3 and pct>=3*max(100*pbg,0.1)
            r['layer_test']='marker population present' if res else 'no marker population'
        else:
            g=genes[0]; d=int(((X[g]==1)&P).sum()); pct=100*d/n if n else np.nan; pbg=100*X.loc[bg,g].mean() if bg.sum() else np.nan
            r.update(n_pos=d,pct_pos=round(pct,2),bg_pct=round(pbg,2),bg_n=int(bg.sum()))
            if kind=='onset': r['layer_test']='on (above background)' if n>=10 and pct-pbg>=5 and pct>=2*pbg else 'off (≈ background)'
            else: r['layer_test']='lost (≈ background)' if n>=10 and pct-pbg<=3 else 'still on'
        rows.append(r)
R=pd.DataFrame(rows)
def verdict(r):
    oc=r.original_call; t=r.layer_test
    pos = t in ('marker population present','on (above background)','lost (≈ background)')
    if r.pool_n<10: return 'too few cells to test'
    if oc=='reached': return 'consistent (positive control)' if pos else 'not supported by markers'
    return 'annotation issue: marker-defined cells present' if pos else 'confirmed: no marker-defined cells'
R['verdict']=R.apply(verdict,axis=1)
R.to_csv('mz/rescue/layer_rescue_results.csv',index=False)
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',40)
print(R[R.original_call!='reached'][['dataset','milestone','original_call','pool_n','rule','n_pos','pct_pos','expected_pct','obs_over_exp','bg_pct','verdict']].to_string(index=False))
print(R[R.original_call=='reached'].verdict.value_counts())
print(R[(R.original_call=='reached')&(R.verdict!='consistent (positive control)')][['dataset','milestone','pool_n','n_pos','pct_pos','expected_pct','obs_over_exp','bg_pct','verdict']].to_string(index=False))
