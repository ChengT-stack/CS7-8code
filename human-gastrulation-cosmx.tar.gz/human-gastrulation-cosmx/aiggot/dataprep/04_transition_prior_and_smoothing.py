"""Transition prior (9 CS7 groups x 17 CS8 groups) and the spatially smoothed Harmony embedding used as z in the AIGG-OT cost.
Reconstructed verbatim from transcripts:
  frame 0f4081de [76]  - transition table (direct / allowed / indirect / penalised), written to transition/;
  session 824ef1ce [677] (data loading, subset), [683] (two amendments -> trans2, subset), [687] (smooth_embedding, subset)
  and [691] (only the lines writing matching/harmony_smoothed.npy and matching/transition_table_used.json; the starmatch
  reference matching written in the same cell was superseded by AIGG-OT and is not reproduced here).
Working directory: $HGC_DATA/cs7_cs8_matching/dataprep for the table; outputs of the second part go to
$HGC_DATA/cs7_cs8_matching/matching/ (harmony_smoothed.npy, transition_table_used.json).
"""
import os, json
import numpy as np, pandas as pd, anndata as ad
from scipy.spatial import cKDTree
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
os.chdir(os.path.join(DATA, "cs7_cs8_matching", "dataprep"))   # [glue]
adata = ad.read_h5ad("embedding/cs7_cs8_germlayers_harmony.h5ad", backed="r")   # [glue] kernel variable of [76]
cs7 = (adata.obs.embryo=="CS7").values; cs8 = ~cs7                                # [glue] defined in [64] of 0f4081de

# ---- [76] (0f4081de) transition table
os.makedirs("transition", exist_ok=True)
cs7_groups=["EPI","ECT","PS","APS","Node","DE","AVE","VE1","VE2"]
cs8_groups=["EPI","aECT","pECT","CLE","NNE","PS","Node","Notochord","PrP","Nas.Meso","Para.Meso","Rostral.Meso","LP.Meso","Heart.Meso","DE","VE1","VE2"]
direct={g:[g] for g in ["EPI","PS","Node","DE","VE1","VE2"]}
allowed={"ECT":["aECT","pECT","NNE","CLE"],"EPI":["PS","CLE"],"PS":["Nas.Meso","CLE"],"APS":["Node","Notochord","PrP","DE"],"Node":["Notochord"],"AVE":["VE1"]}
indirect={"PS":["Para.Meso","LP.Meso","Rostral.Meso","Heart.Meso"]}
T=pd.DataFrame("penalised", index=cs7_groups, columns=cs8_groups)
for src,ds in indirect.items():
    for t in ds: T.loc[src,t]="indirect"
for src,ds in allowed.items():
    for t in ds: T.loc[src,t]="allowed"
for src,ds in direct.items():
    for t in ds: T.loc[src,t]="direct"
T.index.name="CS7_group"; T.to_csv("transition/transition_table.csv")
assert set(cs8_groups)==set(adata.obs.label_short[cs8]) and set(cs7_groups)==set(adata.obs.label_short[cs7])
full_names = dict(zip(pd.read_csv("export/cell_counts_per_type.csv").label_short, pd.read_csv("export/cell_counts_per_type.csv").label))
js={"description":"CS7 (obj6) -> CS8 (obj7) group-transition classes for star-constrained cell matching. Classes: direct = same-name group; allowed = confirmed lineage transition; indirect = PS-derived mesoderm with no CS7 precursor population (reached via PS/Nas.Meso); penalised = cross-group penalty (not forbidden).",
    "cs7_groups":cs7_groups,"cs8_groups":cs8_groups,"full_names":full_names,
    "direct":direct,"allowed":allowed,"indirect":indirect,
    "penalised_rule":"every (CS7 group, CS8 group) pair not listed above",
    "notes":["APS is restricted to axial/DE targets (Node, Notochord, PrP, DE); APS->Para.Meso deliberately NOT included.",
             "AVE exists only in CS7; AVE->VE1 is the only allowed AVE transition.",
             "EPI->APS is not encoded because APS does not exist in CS8 (APS-derived fates are reached through APS->Node/Notochord/PrP/DE).",
             "Class per pair is stored as a matrix in transition_table.csv (rows CS7 groups, columns CS8 groups)."],
    "matrix":{r:T.loc[r].to_dict() for r in cs7_groups}}
json.dump(js, open("transition/transition_table.json","w"), indent=1)
print(T.to_string()); print(T.stack().value_counts().to_dict())

os.chdir(os.path.join(DATA, "cs7_cs8_matching"))   # [glue] session 824ef1ce wrote matching/ relative to this folder

# ---- [677] (824ef1ce) load embedding and transition classes (subset)
import anndata as ad
A=ad.read_h5ad(DATA + "/cs7_cs8_matching/dataprep/embedding/cs7_cs8_germlayers_harmony.h5ad")
T=json.load(open(DATA + "/cs7_cs8_matching/dataprep/transition/transition_table.json")); M_=T["matrix"]
trans={(g,h):(M_[g][h] if isinstance(M_,dict) else M_[T["cs7_groups"].index(g)][T["cs8_groups"].index(h)]) for g in T["cs7_groups"] for h in T["cs8_groups"]}
obs=A.obs.copy(); obs["g"]=obs.label_short.astype(str); SPC=["AP_arc_frac","LR_frac","DV_gap_units"]
H=A.obsm["X_harmony"]; G=obs.g.to_numpy(); ZW=obs.z_weight.to_numpy(float); SP=obs[SPC].to_numpy(float); EMB=obs.embryo.to_numpy()

# ---- [683] (824ef1ce) amendments to the transition table (subset)
trans2=dict(trans)
for h in ["Nas.Meso","Para.Meso","Rostral.Meso","LP.Meso","Heart.Meso"]: trans2[("EPI",h)]="indirect"
trans2[("APS","Rostral.Meso")]="allowed"

# ---- [687] (824ef1ce) spatial smoothing over 15 same-group neighbours in 3D (subset)
XYZ=obs[["x_um","y_um","z_um"]].to_numpy(float)
def smooth_embedding(H, XYZ, G, EMB, k=15):
    Hs=np.zeros_like(H)
    for e in np.unique(EMB):
        for g in np.unique(G[EMB==e]):
            idx=np.where((EMB==e)&(G==g))[0]; kk=min(k,len(idx))
            _,nn=cKDTree(XYZ[idx]).query(XYZ[idx],k=kk); nn=np.atleast_2d(nn).reshape(len(idx),kk)
            Hs[idx]=H[idx][nn].mean(1)
    return Hs
Hs=smooth_embedding(H,XYZ,G,EMB,k=15)

# ---- [691] (824ef1ce) save smoothed embedding and the amended table (subset)
os.makedirs("matching",exist_ok=True)
np.save("matching/harmony_smoothed.npy",Hs.astype(np.float32))
json.dump({f"{k[0]}->{k[1]}":v for k,v in trans2.items()},open("matching/transition_table_used.json","w"),indent=1)
