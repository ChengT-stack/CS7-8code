# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/endoderm_nohist_gnrh2.R (2026-09-16, session 0b0712b4)
# sha256 of original: 4fca854b4f7fa98be795cdb24390503ba44181db4f39162f4ec45d02f0cf8f12
# Methods paragraphs: P346 (manual curation of HuE#1 AVE/VE1/VE2/Al.Endo)
# Produces: obj6 endoderm re-clustering (SCTransform, histone/ribosomal genes removed from HVGs) on which the
#     AVE/Al.Endo relabel of Type39_curated was based; GNRH2 background null tables
# Edits/notes: obj6/obj7 .rds paths -> HGC_DATA; output .rds written to HGC_OUT. Part B (GNRH2 null) is not used
#     by a figure panel.
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

## Part A: re-cluster obj6's Al.Endo + VE1 + VE2 + AVE with histone and ribosomal genes
##   removed from the variable-feature set. In the previous pass, 20% of VE1's markers and
##   38% of Al.Endo's were histone/ribosomal/repeat-region even after SCTransform modelled
##   depth and the S/G2M scores were regressed - so those gene families were still shaping
##   the embedding. Removing them from the features (not from the counts, so depth and the
##   SCT residuals are unchanged) tests what the clustering looks like without them.
##
## Part B: is GNRH2 detected above background in the endoderm? Exports GNRH2 plus a set of
##   genes matched on TOTAL detection count across the object, which is the null this project
##   uses for detection-rate questions - it absorbs the sequencing-depth confound that makes
##   raw detection rates incomparable between populations. Both objects, for cross-stage check.
suppressPackageStartupMessages({library(Seurat); library(Matrix)})
set.seed(1)

HIST_RIB <- function(g) grepl("^(H1-|H2A|H2B|H3-|H3C|H4C|H1C|HIST[0-9]|RPL|RPS|MRPL|MRPS|RPLP|FAU)", g)

## ---------------- Part A ----------------
KEEP <- c("Allantois endoderm (Al.Endo)", "Visceral endoderm 1 (VE1)",
          "Visceral endoderm 2 (VE2)", "Anterior visceral endoderm (AVE)")
o6 <- readRDS(file.path(DATA, "obj6.rds"))
sel <- as.character(o6$Type39_revised) %in% KEEP
s <- subset(o6, cells = colnames(o6)[sel])
s$orig_label <- as.character(s$Type39_revised)
s <- NormalizeData(s, verbose = FALSE)
s <- CellCycleScoring(s, s.features = cc.genes$s.genes, g2m.features = cc.genes$g2m.genes, set.ident = FALSE)
s <- SCTransform(s, vars.to.regress = c("S.Score", "G2M.Score"),
                 variable.features.n = 2500, verbose = FALSE)
vf <- VariableFeatures(s)
drop <- vf[HIST_RIB(vf)]
vf2 <- setdiff(vf, drop)[1:2000]
cat("variable features: ", length(vf), " -> dropped ", length(drop),
    " histone/ribosomal -> using ", length(vf2), "\n", sep = "")
cat("dropped examples:", paste(head(drop, 12), collapse = ", "), "\n")
VariableFeatures(s) <- vf2
s <- RunPCA(s, features = vf2, npcs = 30, verbose = FALSE)
s <- RunUMAP(s, dims = 1:20, verbose = FALSE)
s <- FindNeighbors(s, dims = 1:20, verbose = FALSE)
RES <- c(0.2, 0.4, 0.6, 0.8, 1.2)
for (r in RES) {
  s <- FindClusters(s, resolution = r, verbose = FALSE)
  s[[paste0("nh_res", sub("\\.", "_", as.character(r)))]] <- s$seurat_clusters
  cat(sprintf("res %.1f -> %d clusters\n", r, length(unique(s$seurat_clusters)))); flush.console()
}
emb <- Embeddings(s, "umap"); md <- s@meta.data
out <- data.frame(cell = colnames(s), orig_label = md$orig_label,
                  UMAP1 = emb[, 1], UMAP2 = emb[, 2],
                  nCount = md$nCount_RNA, nFeature = md$nFeature_RNA,
                  S = md$S.Score, G2M = md$G2M.Score, stringsAsFactors = FALSE)
for (r in RES) out[[paste0("nh_res", sub("\\.", "_", as.character(r)))]] <-
  as.character(md[[paste0("nh_res", sub("\\.", "_", as.character(r)))]])
write.csv(out, "handoff/obj6_endoderm_nohist.csv", row.names = FALSE)
Idents(s) <- s$orig_label
mk <- FindAllMarkers(s, only.pos = TRUE, min.pct = 0.10, logfc.threshold = 0.25, verbose = FALSE)
write.csv(mk, "handoff/obj6_endoderm_nohist_origlabel_markers.csv", row.names = FALSE)
Idents(s) <- s$nh_res0_6
mk3 <- FindAllMarkers(s, only.pos = TRUE, min.pct = 0.10, logfc.threshold = 0.25, verbose = FALSE)
write.csv(mk3, "handoff/obj6_endoderm_nohist_cluster_markers.csv", row.names = FALSE)
saveRDS(s, "obj6_endoderm_nohist.rds")
rm(s); invisible(gc())

## ---------------- Part B ----------------
o7 <- readRDS(file.path(DATA, "obj7.rds"))
for (nm in c("obj6", "obj7")) {
  o <- if (nm == "obj6") o6 else o7
  cn <- LayerData(o[["RNA"]], "counts")
  if (!"GNRH2" %in% rownames(cn)) { cat(nm, ": GNRH2 NOT in the panel\n"); next }
  det <- Matrix::rowSums(cn > 0)
  tgt <- det[["GNRH2"]]
  pool <- names(det)[det > tgt * 0.8 & det < tgt * 1.2 & names(det) != "GNRH2"]
  pool <- pool[!HIST_RIB(pool)]
  pick <- sample(pool, min(300, length(pool)))
  g <- c("GNRH2", "GNRHR", pick)
  g <- g[g %in% rownames(cn)]
  D <- as.matrix(cn[g, , drop = FALSE] > 0) * 1L
  lab <- if (nm == "obj6") as.character(o$Type39_revised) else as.character(o$Type39_curated)
  out2 <- data.frame(cell = colnames(o), label = lab, nCount = o$nCount_RNA, stringsAsFactors = FALSE)
  out2 <- cbind(out2, setNames(as.data.frame(t(D)), paste0("d_", g)))
  write.csv(out2, sprintf("handoff/%s_gnrh2_null.csv", nm), row.names = FALSE)
  cat(nm, ": GNRH2 detected in", det[["GNRH2"]], "of", ncol(cn), "cells |",
      length(pick), "detection-matched null genes (pool", length(pool), ")\n")
  rm(cn, D); invisible(gc())
}
cat("DONE\n")
