# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: execution log, session 824ef1ce R kernel (scrna) cells 995-996 (producing cell of
#     mean_cp10k_type_stage.csv 5c35cf9b, frac_type_stage.csv 18b33c23, n_type_stage.csv 2b06a1b8,
#     mean_cp10k_type_pooled.csv 321e8eb3; copies in [F:]/CS6-CS7/cs7_cs8_matching/figure1_L_heatmap_by_stage/)
# sha256 of original: e36d83dbc992196eed675810170954c248331993e8d50fc91127012ac215653e
# Methods paragraphs: P343 (CP10K), P349
# Produces: hm/mean_cp10k_type_stage.csv, hm/frac_type_stage.csv, hm/n_type_stage.csv,
#     hm/mean_cp10k_type_pooled.csv (76 marker genes; curated_kept cells; 39Type x stage)
# Edits/notes: reconstructed verbatim from kernel log; object path -> HGC_DATA.
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

# --- kernel cell 995 ---
suppressPackageStartupMessages(library(Seurat))
obj <- readRDS(file.path(DATA, "obj6_obj7_merged_curated_final.rds"))
print(dim(obj)); print(colnames(obj@meta.data)); print(Assays(obj)); print(names(obj@misc))
print(table(obj$stage, useNA="ifany"))
print("ETV2" %in% rownames(obj))

# --- kernel cell 996 ---
print(table(obj$curated_kept)); print(head(obj@misc$Type39_scheme, 40))
G <- c('LIN28A','SOX2','TBXT','MIXL1','EOMES','MESP1','MESP2','CHRD','NOTO','WNT3A','NODAL','WNT3','FOXA2','NOG','CDH2','OTX2','POU5F1','NKX1-2','NANOG','WNT1','TBX1','CDH1','PAX6','TBX6','HOXB1','WNT8A','HOXA3','HOXA2','HOXD3','HOXB3','WNT5A','CDX2','VIM','BMP4','NKX2-5','UNCX','HAND1','HOXB2','HAND2','OSR1','EN1','TBX4','HESX1','ALDH1A2','MSGN1','HOXA1','FOXC1','TCF15','EPCAM','BMP2','PITX2','AFP','TTR','APOE','SHH','HOXA10','ISL1','SOX1','HOXA11','PAX2','TBX18','HOXD1','GATA6','SOX17','GATA4','SNAI1','POU3F1','CYP26A1','FOXG1','RUNX1','OLIG2','KDR','PECAM1','TAL1','GCM1','ETV2')
print(setdiff(G, rownames(obj)))
k <- obj$curated_kept %in% TRUE
cnt <- LayerData(obj, assay="RNA", layer="counts")[G, k]
nc <- obj$nCount_RNA[k]
cp <- t(t(as.matrix(cnt)) / nc * 1e4)
ty <- as.character(obj$`39Type`[k]); st <- as.character(obj$stage[k])
key <- paste(ty, st, sep="|")
agg <- function(M, f) sapply(split(seq_along(key), key), function(ii) f(M[, ii, drop=FALSE]))
mean_ts <- agg(cp, rowMeans); frac_ts <- agg(cnt>0, rowMeans)
n_ts <- table(key)
mean_p <- sapply(split(seq_along(ty), ty), function(ii) rowMeans(cp[, ii, drop=FALSE]))
dir.create("hm", showWarnings=FALSE)
write.csv(mean_ts, "hm/mean_cp10k_type_stage.csv"); write.csv(frac_ts, "hm/frac_type_stage.csv")
write.csv(as.data.frame(n_ts), "hm/n_type_stage.csv", row.names=FALSE); write.csv(mean_p, "hm/mean_cp10k_type_pooled.csv")
print(dim(mean_ts)); print(n_ts)
