# staging/04_lefty_fgf/tyser_signalling_detection.R
# Source: reconstructed from transcript 723f1529 (messages 202, 205)
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
HGC_DATA <- Sys.getenv('HGC_DATA', 'data')
HGC_OUT <- Sys.getenv('HGC_OUT', 'results')

# Smart-seq2 CS7 (Tyser et al.) detection of signalling genes per author cluster. Reconstructed verbatim from transcript 723f1529 (messages 202, 205).


# ---- cell [frame 723f1529, message 202] Inspecting Tyser raw reads and UMAP objects
rr <- readRDS(paste0(HGC_DATA, '/tyser_raw_reads.rds')); um <- readRDS(paste0(HGC_DATA, '/tyser_umap.rds'))
cat(class(rr), dim(rr), '\n'); print(rr[1:3,1:3]); cat(class(um),'\n'); print(head(um)); print(table(um[[ncol(um)]]))


# ---- cell [frame 723f1529, message 205] Computing Tyser detection per cluster for signalling genes
g <- c('FGF17','FGF8','TDGF1','LEFTY1','LEFTY2','NOG','SHH','CFC1')
cat(all(g %in% colnames(rr)), nrow(rr)==nrow(um), '\n')
cl <- um$cluster_id
res <- sapply(g, function(x) tapply(rr[[x]]>0, cl, mean)*100)
res <- cbind(n=as.vector(table(cl)[rownames(res)]), round(res,1))
print(res)
write.csv(res,'out/Tyser_CS7_signalling_detection_by_cluster.csv')
