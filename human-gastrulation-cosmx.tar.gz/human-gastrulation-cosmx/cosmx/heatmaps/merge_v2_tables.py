# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: execution log, session 824ef1ce python kernel cells 2100 (load lines) and 2101 (first block: producing
#     cell of mean_cp10k_type_stage_v2.csv 2d995037, frac_type_stage_v2.csv d641eeed, S2A_*_v2.csv c0f860bc)
# sha256 of original: cd96d047c01d904ca3e9a6abc31ad4dfceebd4f86ef098714a918794ac607fd9
# Methods paragraphs: P349
# Produces: hm/mean_cp10k_type_stage_v2.csv, hm/frac_type_stage_v2.csv, hm/S2A_mean_cp10k_type_stage_v2.csv,
#     hm/S2A_frac_type_stage_v2.csv
# Edits/notes: reconstructed from kernel log. The rest of cell 2101 generated build_SuppFig2_heatmaps_v2.py /
#     build_SuppFig3_heatmap_v2.py by string replacement; the generated files (on the F: drive) are included
#     directly instead.
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

import os, numpy as np, pandas as pd
# --- loads (kernel cell 2100; the shutil.copy of earlier tables from the F: drive is replaced by the export scripts of this folder) ---
aM = pd.read_csv('hm/add_mean_cp10k_type_stage.csv', index_col=0); aF = pd.read_csv('hm/add_frac_type_stage.csv', index_col=0); aP = pd.read_csv('hm/add_mean_cp10k_type_pooled.csv', index_col=0)
ME = pd.read_csv('hm/mean_cp10k_type_stage.csv', index_col=0); FR = pd.read_csv('hm/frac_type_stage.csv', index_col=0); MP = pd.read_csv('hm/mean_cp10k_type_pooled.csv', index_col=0)
CM = pd.read_csv('hm/S2A_mean_cp10k_type_stage.csv', index_col=0); CF = pd.read_csv('hm/S2A_frac_type_stage.csv', index_col=0)
a2 = aM.copy(); a2.columns = [c.replace('|','||') for c in a2.columns]
# --- kernel cell 2101 (first block) ---
os.makedirs('hm/out', exist_ok=True)
# ---- augmented input tables
pd.concat([ME, aM.loc[['SFRP1']]]).to_csv('hm/mean_cp10k_type_stage_v2.csv'); pd.concat([FR, aF.loc[['SFRP1']]]).to_csv('hm/frac_type_stage_v2.csv')
pd.concat([CM, a2.loc[['HESX1','SFRP1'], CM.columns]]).to_csv('hm/S2A_mean_cp10k_type_stage_v2.csv')
a2F = aF.copy(); a2F.columns = [c.replace('|','||') for c in a2F.columns]
pd.concat([CF, a2F.loc[['HESX1','SFRP1'], CF.columns]]).to_csv('hm/S2A_frac_type_stage_v2.csv')
