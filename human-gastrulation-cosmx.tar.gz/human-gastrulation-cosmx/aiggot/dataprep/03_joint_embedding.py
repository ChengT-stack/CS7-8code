"""Joint Harmony embedding of the CS7 and CS8 disc cells (2,000 seurat_v3 HVGs, 30 PCs, Harmony on 3 batches, seed 0).
Reconstructed verbatim from transcript frame 0f4081de (data-prep sub-agent of session 824ef1ce), messages [60] and [62].
Working directory: $HGC_DATA/cs7_cs8_matching/dataprep (reads export/, frames/; writes embedding/).
Output used downstream: embedding/cs7_cs8_germlayers_harmony.h5ad (obsm X_harmony; obs incl. frame columns and z_weight).
"""
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
os.chdir(os.path.join(DATA, "cs7_cs8_matching", "dataprep"))   # [glue] original cwd = sub-agent workspace

# ---- [60] load exports, HVG, PCA
import os; os.environ["KMP_AFFINITY"]="disabled"; os.environ["OMP_PROC_BIND"]="false"
import numpy as np, pandas as pd, scanpy as sc, anndata as ad, scipy.io, scipy.sparse as sp, json, harmonypy
print(sc.__version__, harmonypy.__version__ if hasattr(harmonypy,"__version__") else "harmonypy")
genes = pd.read_csv("export/genes.csv").gene.values
ads=[]
for e in ["CS7","CS8"]:
    X = scipy.io.mmread(f"export/{e}_counts.mtx").T.tocsr()
    obs = pd.read_csv(f"export/{e}_cells.csv").set_index("cell")
    fr = pd.read_csv(f"frames/{e}_frames.csv").set_index("cell")
    obs = obs.join(fr[["AP_frac","AP_arc_frac","LR_frac","DV_gap_units","DV_um_to_surface","z_weight"]])
    a = ad.AnnData(X=X.astype(np.float32), obs=obs, var=pd.DataFrame(index=genes)); a.obs["embryo"]=e; ads.append(a)
adata = ad.concat(ads, join="inner"); adata.obs_names_make_unique()
adata.obs["harmony_batch"]=adata.obs.batch.astype(str)
adata.layers["counts"]=adata.X.copy()
print(adata.shape, adata.obs.harmony_batch.value_counts().to_dict())
sc.pp.highly_variable_genes(adata, flavor="seurat_v3", n_top_genes=2000, layer="counts", batch_key="embryo")
sc.pp.normalize_total(adata, target_sum=1e4); sc.pp.log1p(adata)
adata.raw = adata
sub = adata[:, adata.var.highly_variable].copy()
sc.pp.scale(sub, max_value=10)
sc.tl.pca(sub, n_comps=30, svd_solver="arpack", random_state=0)
adata.obsm["X_pca"]=sub.obsm["X_pca"]; adata.uns["pca"]=sub.uns["pca"]
print("HVG:", adata.var.highly_variable.sum(), "var ratio first 5:", np.round(sub.uns["pca"]["variance_ratio"][:5],3))

# ---- [62] Harmony, UMAP, write embedding
import time; t=time.time()
ho = harmonypy.run_harmony(adata.obsm["X_pca"], adata.obs, "harmony_batch", max_iter_harmony=20, random_state=0, verbose=False)
Z = np.asarray(ho.Z_corr); Z = Z.T if Z.shape[0]==30 else Z
adata.obsm["X_harmony"]=Z; print("harmony", Z.shape, round(time.time()-t,1),"s")
sc.pp.neighbors(adata, use_rep="X_harmony", n_neighbors=15, random_state=0)
sc.tl.umap(adata, random_state=0); print("umap done", round(time.time()-t,1),"s")
os.makedirs("embedding", exist_ok=True)
pd.DataFrame(Z, index=adata.obs_names, columns=[f"H{i+1}" for i in range(30)]).to_csv("embedding/harmony_embedding.csv")
np.save("embedding/harmony_embedding.npy", Z.astype(np.float32))
pd.DataFrame(adata.obsm["X_pca"], index=adata.obs_names, columns=[f"PC{i+1}" for i in range(30)]).to_csv("embedding/pca_embedding.csv")
um = pd.DataFrame(adata.obsm["X_umap"], index=adata.obs_names, columns=["UMAP1","UMAP2"]); um["embryo"]=adata.obs.embryo.values; um["label_short"]=adata.obs.label_short.values; um["batch"]=adata.obs.batch.values
um.to_csv("embedding/umap_coords.csv")
adata.var[["highly_variable","highly_variable_rank","means","variances_norm"]].to_csv("embedding/hvg_table.csv")
adata.write_h5ad("embedding/cs7_cs8_germlayers_harmony.h5ad")
print("saved")
