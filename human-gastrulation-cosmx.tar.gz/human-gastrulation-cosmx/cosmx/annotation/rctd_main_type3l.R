# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/claude/rctd_main_type3l.R (2026-06-22)
# sha256 of original: d6dbc7a1a068382f31feedc504a00dc5deb70f83017b0d2749122e00888d6669
# Methods paragraphs: P346 (RCTD, doublet_mode = "full")
# Produces: RCTD weights/labels (RCTD_Type3L) for the HuE#2 object; used during manual curation
# Edits/notes: HuE#2 (true CS8) object, old name CS7_final_3d.RDS; reference = in-house 10x CS7ref.rds (Type3L).
#     Windows paths F:/claude/... -> HGC_DATA/HGC_OUT. No RCTD script for HuE#1 was found (see GAPS).
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

library(Seurat)
library(spacexr)

dir.create("results_RCTD_main_Type3L", showWarnings = FALSE)
out <- "results_RCTD_main_Type3L"

cat("── Load reference (CS7ref, Type3L) ──\n")
ref <- readRDS(file.path(DATA, "CS7ref.rds"))

type_tab <- table(as.character(ref$Type3L))
keep_types <- names(type_tab)[type_tab >= 25 & !grepl("doublet", names(type_tab), ignore.case = TRUE)]
keep_cells <- colnames(ref)[as.character(ref$Type3L) %in% keep_types]
cat("Kept Type3L categories:", length(keep_types), "| cells:", length(keep_cells), "of", ncol(ref), "\n")

cat("── Load query (CS7_final_3d) ──\n")
obj <- readRDS(file.path(DATA, "CS7_final_3d.RDS"))
cat("Query cells:", ncol(obj), "\n")

common_genes <- intersect(rownames(ref), rownames(obj))
cat("Common genes:", length(common_genes), "\n")

ref_counts   <- GetAssayData(ref, assay = "RNA", layer = "counts")[common_genes, keep_cells]
ref_types_chr     <- gsub("/", "-", as.character(ref$Type3L[keep_cells]))
ref_types         <- factor(ref_types_chr)
names(ref_types)  <- keep_cells
ref_nUMI     <- colSums(ref_counts)
cat("Building Reference object...\n")
reference    <- Reference(ref_counts, ref_types, ref_nUMI)
rm(ref); gc()

query_counts <- GetAssayData(obj, assay = "RNA", layer = "counts")[common_genes, ]
query_nUMI   <- colSums(query_counts)
coords       <- data.frame(x = obj$x_3d, y = obj$y_3d, row.names = colnames(obj))
cat("Building SpatialRNA object...\n")
spatialRNA   <- SpatialRNA(coords, query_counts, query_nUMI)

cat("── Run RCTD (full mode, max_cores=14) ──\n")
t0 <- Sys.time()
myRCTD <- create.RCTD(spatialRNA, reference, max_cores = 14)
myRCTD <- run.RCTD(myRCTD, doublet_mode = "full")
cat("RCTD runtime:", round(difftime(Sys.time(), t0, units = "mins"), 1), "min\n")

saveRDS(myRCTD, file.path(out, "myRCTD_main_type3l.rds"))

cat("── Extract predicted labels ──\n")
w <- as.matrix(myRCTD@results$weights)
pred_type <- colnames(w)[apply(w, 1, which.max)]
names(pred_type) <- rownames(w)

obj$RCTD_Type3L <- unname(pred_type[colnames(obj)])
cat("NA predictions:", sum(is.na(obj$RCTD_Type3L)), "of", ncol(obj), "\n")

tab <- table(Type4 = obj$Type4, RCTD_Type3L = obj$RCTD_Type3L)
write.csv(as.data.frame.matrix(tab), file.path(out, "type4_vs_RCTD_Type3L.csv"))

cat("\n── Predicted counts for target subtypes ──\n")
target_pat <- "Anterior epiblast|Posterior epiblast|Anterior primitive streak|Primitive streak|Caudal epiblast|Neuromesoderm progenitor"
target_hit <- grep(target_pat, names(table(obj$RCTD_Type3L)), value = TRUE)
print(table(obj$RCTD_Type3L)[target_hit])

saveRDS(obj, file.path(out, "CS7_final_3d_RCTD_Type3L.rds"))
cat("\nDone. Results in", out, "\n")
