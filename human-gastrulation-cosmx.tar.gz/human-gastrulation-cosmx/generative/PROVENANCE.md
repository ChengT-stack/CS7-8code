# PROVENANCE — generative/

## Edits applied to every file

These are the only changes made. Algorithms, parameters, seeds and output names are unchanged.
- Absolute paths were replaced by `HGC_DATA`, `HGC_OUT` or `HGC_GEN_ROOT`, following the path mapping in the README.
- Platform-only calls were removed: artifact look-ups, uploads, and copies into shared folders.
- Interactive `print` diagnostics were kept. Dead exploratory branches were removed only where they were marked as unused; each removal is listed below.
- Comments are in English. The original comments use the names that were current at the time; the README gives the name mapping.

Reconstructed files were assembled verbatim from the code cells of the analysis sessions, with the message indices given below. Lines added to join the cells together are marked `# [glue]`.

Path mapping applied:

| original | replaced by |
|---|---|
| `[F:]/CS6-CS7/cs7_cs8_matching/` | `$HGC_DATA/cs7_cs8_matching/` |
| `[G:]/data/bridge_bundle/` | `$HGC_DATA/bridge_bundle/` |
| `[G:]/data/ai_t05_v153/` | `$HGC_GEN_ROOT` |
| `[G:]/data/ai_t05/` | `$HGC_DATA/ai_t05/` |
| `[G:]/data/UCE/` | `$HGC_DATA/UCE/` |
| `[F:]/CS6-CS7/figure7/supplementary/` | `$HGC_DATA/figure7_supplementary/` |
| project artifacts | `$HGC_DATA/artifacts/<file name>` |

## Why these versions

- **Generator.** The 153-embryo rebuild (`ai_t05_v153`, `out_gencv/`) is the version reported in the paper: 77 locked mid embryos, −19.5 % [15.3–22.0], 76/77. The scripts are the files on disk that produced `nested_cv_results_v153.csv` and `human_traj_12fr_v153.npz`.
- **Fine-tuning selection.** The V1a fine-tune (`lam_h = 3`) was chosen by the pre-declared rule in `out_domain/SELECTION_RULE.txt`. That file is copied verbatim; its sha256 is in the table.
- **Bootstrap seeds.** In `analysis/streak_fate_t05.py`, the generator `rng = np.random.default_rng(0)` had already been used by earlier cells before the bootstraps were drawn. The bootstrap CIs therefore cannot be reproduced bit for bit, although the point estimates and P values can.
- **94→30 latent map.** In `analysis/half_change_timing.py`, the 94→30 latent map is an affine least-squares fit on the stored generated cells (session message [4688]). The Methods call this step "reverse standardisation"; the code is kept as it was run.
- **Removed parts.**
  - `node_dv_fate.py`: a consistency check of the bridge-bundle destinations.
  - `streak_fate_t05.py`: the latent positional-register analysis (not in the paper).
  - `half_change_timing.py`: the HOX analysis on the trajectory before v153.
  - `train_scvi_cosmx_full.py`: the superseded t = 0.5 decoding of `ai/step4_decode_t05.py`.

## Files

| repo path | status | source | sha256 of original | Methods | figure / table |
|---|---|---|---|---|---|
| `ai/mz_bench/prep.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/ai/mz_bench/prep.py | `0a0e61cc5e9277efb1fb25b3629ad264945d0eed8de6edd41f16be5f9f44a481` | P409 | Table S4 |
| `ai/mz_bench/query.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/ai/mz_bench/query.py | `e5b93ba60a5f6d268b22241bea192ff61f168227e9898ea40f99dbf89cd0fb58` | P409 | Table S4 |
| `ai/rot/build_rot.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/ai/rot/build_rot.py | `802979b2a7162671c88ddd4fb9fd1e4cdb0952c7a9743cfe258a1fe43a83c60e` | P411 | Table S4 |
| `ai/step5_decoder.py` | verbatim (paths/headers only) | [G:]/data/ai_t05/ai/step5_decoder.py | `6e82b0b59a4c2ded93c86e8747564d500e865f6b2e7077226db2faecfbbe9feb` | P412 / P419 | Fig 7D (decoded t=0.5) |
| `ai/step5_lib.py` | verbatim (paths/headers only) | [G:]/data/ai_t05/ai/step5_lib.py | `203f91b87c94cad6bf19a75c57bc71c70084a8a8bca40b778827d198768deeb9` | P412 / P419 | Fig 7D (decoded t=0.5) |
| `ai/step5_milestones.py` | verbatim (paths/headers only) | [G:]/data/ai_t05/ai/step5_milestones.py | `ef3764ea86fa33da48aa99fbfa8d9c74e9570c39e5fbfb57146ea968b208b4d0` | P412 / P419 | Fig 7D (decoded t=0.5) |
| `ai/step7/final.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/ai/step7/final.py | `6c77c67b7b82c1c7d11e084d6800873c72150efc3759b41e1ab91da201782b96` | P409–P411 | Table S4 |
| `ai/step7/final2.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/ai/step7/final2.py | `d1362ba2e7ab549202797455e052bc82cd097dad29368228c74d100bd8cb9865` | P409–P411 | Table S4 |
| `ai/step7/lib7.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/ai/step7/lib7.py | `620e4ae59a83d965b450b0479bbaf4f5339e2442782dc02ae8ac33cf48391fa5` | P409–P411 | Table S4 |
| `ai/step7/loop.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/ai/step7/loop.py | `1e6747f210ddde576abcb4fc62928aa1b773c97993af8f96415e9b76b9c4d186` | P409–P411 | Table S4 |
| `ai/step7/loop2.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/ai/step7/loop2.py | `b459b96d987486b86bd1f0e7015b6de87e23cf7a6b983866e8052bb8b267fcc6` | P409–P411 | Table S4 |
| `ai/step7/rep.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/ai/step7/rep.py | `312c84c1b1e0df48ae5088c87b790c0367964cf878a908626b965cc8d5f120e7` | P409–P411 | Table S4 |
| `animations/build_supp_material_3_4.py` | verbatim (paths/headers only) | project artifact build_supp_material_3_4.py (version 40474bb2) | `3e743762b41063535c4726e9bc8cfa46f09ccb7e74fc47fb65a8190570775dcc` | P580–P584 | Supplementary Materials 3–4 |
| `human/fill_generate.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/out_gencv/human_fill_1559/scripts/fill_generate.py | `e73deb04936c7f20dedab120f9e305065e43b3fb343b19c4cce8c1184e0e7e96` | P412 | Fig 7D, SF10A (t=0.5 cells) |
| `human/fill_merge_checks.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/out_gencv/human_fill_1559/scripts/fill_merge_checks.py | `21f0565ed4ff0556f2126ff9ca6867794fc51944dfbeae857590b4cccf507f12` | P412 | Fig 7D, SF10A (t=0.5 cells) |
| `human/gen_fractions_v153.py` | verbatim (paths/headers only) | [G:]/data/ai_t05/out_trajectory/gen_fractions_v153.py | `11ba35c0ad294f8839f88fbf91d4a9d6f1e137ae94a4fa26471d606c28381eae` | P412 | Fig 7D, SF10A (t=0.5 cells) |
| `human/make_seurat_t05_merged.R` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/out_gencv/human_fill_1559/scripts/make_seurat_t05_merged.R | `248a389231f350b2a071672ba416bb466c189716b1feb9f669a0608f9b5970bb` | P412 | Fig 7D, SF10A (t=0.5 cells) |
| `latent/assemble.py` | verbatim (paths/headers only) | [G:]/file/20261030-AI_bridge/assemble.py | `f98b9a15639c10ce8ac29c4a11b1b3979b227b9d14fde0d6dae32288225daede` | P409 | Table S4 |
| `latent/run_uce.sh` | verbatim (paths/headers only) | [G:]/data/UCE/run_uce.sh | `be0877e548dcbed726229de002ec522d260a33fd7bddf7130406e9249e48191d` | P409 | Table S4 |
| `latent/step5_cache.py` | verbatim (paths/headers only) | [G:]/file/20261030-AI_bridge/step5_t05_generator/scripts/step5_cache.py | `d0dc8d650ab0f1cc6f1deffd8c0aee8b56dd2c6de76bf9f6497ac46a4888e336` | P409 | Table S4 |
| `latent/train_scvi.py` | verbatim (paths/headers only) | [G:]/file/20261030-AI_bridge/train_scvi.py | `689c14ef31c31f84a719b1664faa83ad213a1663ac2d09600a038252bc5e6840` | P409 | Table S4 |
| `latent/uce_prepare.py` | verbatim (paths/headers only) | [G:]/file/20261030-AI_bridge/step5_t05_generator/scripts/uce_prepare.py | `a69dd0b00942f939bb738a29c2466b77031f2fa5bdfec987d2cd6725a3dbd720` | P409 | Table S4 |
| `out_domain/SELECTION_RULE.txt` | verbatim (paths/headers only) | [G:]/data/ai_t05/out_domain/SELECTION_RULE.txt | `d76e0b3687a7bdd16a5693bf6b93bd2aeba725affac08ce65d81dd990553d976` | P412 | Table S4 |
| `out_domain/dom.py` | verbatim (paths/headers only) | [G:]/data/ai_t05/out_domain/dom.py | `c39d3a699aec99a7d2aee0acb12c1d00a9845017c867d9631ddc6c795e299efe` | P412 | Table S4 |
| `out_domain/s0_lib.py` | verbatim (paths/headers only) | [G:]/data/ai_t05/out_domain/s0_lib.py | `81206d68e0990d82317fb7e82e77ed244a9842124fd26f734af313647c53296c` | P412 | Table S4 |
| `out_domain/s2_grid.py` | verbatim (paths/headers only) | [G:]/data/ai_t05/out_domain/s2_grid.py | `5060ccd77181d8552e8d48c07aae695be42d824d431e023f480a91f705a30fea` | P412 | Table S4 |
| `out_domain/s5_combo_export.py` | verbatim (paths/headers only) | [G:]/data/ai_t05/out_domain/s5_combo_export.py | `83b9087418fc556c4b77ce941f38dda6e7dda84c26f2207b862162e8cd8d7c61` | P412 | Table S4 |
| `out_gencv/analyse_v153.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/out_gencv/analyse_v153.py | `90c732f8c56b687d718e249aaf7174fdeeb47aed7c03daddd23adae1f87d83db` | P411–P412 | Table S4 |
| `out_gencv/gencv_lib.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/out_gencv/gencv_lib.py | `8e3220d9a8368e811c3ba58d6754f9947ca23fda2404421a8ac6f07da88eb2b5` | P411–P412 | Table S4 |
| `out_gencv/human_v153.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/out_gencv/human_v153.py | `6d40fd6b51032e29e3255b0be635fcabe04cbbe22a9456cb63d7f4dccdbabd89` | P411–P412 | Table S4 |
| `out_gencv/lib7dev/lib7.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/out_gencv/lib7dev/lib7.py | `f6ca289b58209fab19351423789e82d47600a7b2ebbf372eee4684bbb50c2559` | P411–P412 | Table S4 |
| `out_gencv/retrain_decoder.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/out_gencv/retrain_decoder.py | `103cfc7760b066b036adbdacaa51ccc42f5e5916331f0f56188fcf759f057f2e` | P411–P412 | Table S4 |
| `out_gencv/run_gencv.py` | verbatim (paths/headers only) | [G:]/data/ai_t05_v153/out_gencv/run_gencv.py | `cda70c19efe4c7f325a0f4bd48394a7524d970764049b3505deb792593d89327` | P411–P412 | Table S4 |
| `analysis/figure_SF10B_node_couplings.py` | reconstructed | reconstructed from transcript: session 5113e657 [5270] (definitions), [5273] | `n/a` | P415 | SF10B |
| `analysis/half_change_timing.py` | reconstructed | reconstructed from transcript: session 5113e657 [4575], [4579], [4603], [4605], [4678], [4684], [4688], [4690], [4710], [4720], [4730], [4732], [4734], [4738], [4740], [4742], [4752], [4754] (subsets) | `n/a` | P419 | Fig 7I |
| `analysis/node_dv_fate.py` | reconstructed | reconstructed from transcript: session 5113e657 [4836], [4057] (one line), [4874], [4880], [4882], [4884], [4886], [4892], [4894]/[4905] (colours), [4898] (subset), [4931] | `n/a` | P415 | Fig 7E–F, SF10B |
| `analysis/node_layers.py` | reconstructed | reconstructed from transcript: session 5113e657 [2821] (heredoc ai/node_layers/node_layers.py) | `n/a` | P415 | Fig 7E–F, SF10B |
| `analysis/node_layers_v2.py` | reconstructed | reconstructed from transcript: session 5113e657 [2848] | `n/a` | P415 | Fig 7E–F, SF10B |
| `analysis/streak_fate_t05.py` | reconstructed | reconstructed from transcript: session 5113e657 [4311], [4319], [4323], [4339], [4345], [4363], [4413], [4433], [4435], [4441], [4443], [4459], [4475], [4506] (subsets) | `n/a` | P417 | Fig 7G–H |
| `analysis/train_scvi_cosmx_full.py` | reconstructed | reconstructed from transcript: session 5113e657 [2450] (subset: training of ai/scvi_cosmx_full) | `n/a` | P415 (control) | — |
| `latent/make_rotation_splits.py` | reconstructed | reconstructed from transcript: session 5113e657 [3360] | `n/a` | P411 | Table S4 |
