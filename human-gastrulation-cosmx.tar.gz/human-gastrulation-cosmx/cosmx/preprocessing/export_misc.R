# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: artifact 90da7ca4 export_misc.R (session 32c2b2b0, 2026-11-22)
# sha256 of original: 918c60afa8e1d8414a801ce68f966e8809bdfaad5f91019ca3bef08a9f6a893f
# Methods paragraphs: P346 (curation notes), all downstream
# Produces: type39_scheme.csv (palette), cell_slice_mapping.csv.gz (cell -> section), prints curation notes
# Edits/notes: absolute .rds path -> HGC_DATA.
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

o <- readRDS(file.path(DATA, "obj6_obj7_merged_curated_final.rds"))
write.csv(o@misc$Type39_scheme, 'type39_scheme.csv', row.names=FALSE)
data.table::fwrite(o@misc$cell_slice_mapping, 'cell_slice_mapping.csv.gz')
cat(o@misc$obj6_spatial_trim_note, '\n\n', o@misc$obj7_curation_note, '\n')
