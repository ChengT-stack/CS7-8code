# staging/00_inputs/mittnenzweig_cells_markers.py
# Source: script prep.py from transcript 5113e657 (messages 3275, 3277)
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Per-cell marker UMI counts, author cell type and transcriptional time of the Mittnenzweig et al. 2021 atlas (input to build_sfig7.py).
# Script ai/mz_milestones/prep.py written in transcript 5113e657 message 3275, with the output line changed by the sed command of message 3277.
import os; os.makedirs('ai/mz_milestones', exist_ok=True)
import numpy as np, pandas as pd, tarfile, gzip, io, scipy.sparse as sp, re
MZ=(str(HGC_DATA) + '/external/mouse_mittnenzweig2021/')
ANN=(str(HGC_DATA) + '/mittnenzweig_metacell_annotation.csv')
md=pd.concat([pd.read_csv(MZ+f,sep='\t').assign(strain=s) for f,s in [('GSE169210_wt_bl6_single_cell_metadata.txt.gz','BL6'),('GSE169210_wt_icr_single_cell_metadata.txt.gz','ICR')]])
md=md.dropna(subset=['metacell_id']).merge(pd.read_csv(ANN)[['metacell_id','author_cell_type']],on='metacell_id',how='left')
md['well']=md.cell_id.str.split('.').str[1]
G=['Mesp1','Gsc','Foxa2','Foxj1','Chrd','Sox17','Cer1','Noto','Shh','Hoxa1','Hoxb1','Nkx1-2','Cdx2','Hesx1','Six3','Meox1','Tcf15','Eomes','Hoxb8','Nkx2-5','Tnnt2','Dppa3','Nanos3','Etv2','Kdr','Hand1','Tbx4','Hoxa10','Hba-x','Gata1','T','Pou5f1']
need=set(md.plate); tf=tarfile.open(MZ+'GSE169210_RAW.tar'); out=[]; rows=None
for m in tf.getmembers():
    pl=m.name.split('_',1)[1].replace('.txt.gz','')
    if pl not in need: continue
    df=pd.read_csv(io.BytesIO(gzip.decompress(tf.extractfile(m).read())),sep='\t',index_col=0)
    df=df[~df.index.str.startswith('ERCC')]
    if rows is None:
        rows=df.index; toks=[r.split(';') for r in rows]
        gi={g:[i for i,t in enumerate(toks) if g in t] for g in G}
    keep=[c for c in df.columns if c in set(md.well[md.plate==pl])]
    sub=df[keep]; tot=sub.sum(0).values
    rec=pd.DataFrame({g:(sub.iloc[gi[g]].sum(0).values if gi[g] else np.nan) for g in G},index=keep); rec['umi']=tot; rec['plate']=pl; rec['well']=keep
    out.append(rec)
X=pd.concat(out,ignore_index=True)
print({g:len(v) for g,v in gi.items() if len(v)!=1})
D=md.merge(X,on=['plate','well'],how='inner')
t1=pd.read_excel(MZ+'mmc1.xlsx'); D=D.merge(t1.rename(columns={'embryo code':'embryo_id'})[['embryo_id','stage','dpc','transcriptional_time','morphology_rank']],on='embryo_id',how='left')
D.to_csv('ai/mz_milestones/mz_cells_markers.csv.gz',index=False); print(D.shape, D.embryo_id.nunique(), D.author_cell_type.isna().sum(), D.transcriptional_time.isna().sum())
