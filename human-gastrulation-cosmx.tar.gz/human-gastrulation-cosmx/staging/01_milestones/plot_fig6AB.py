# staging/01_milestones/plot_fig6AB.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/figure6_cs9/m4ab_cs9.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Figure 4A (milestone axis + per-dataset calls) and 4B (mouse-stage windows).
# Uses audited_calls.csv / windows_audited.csv from audit.py. Colours from mz/allstage/plot.py.
import sys, re, numpy as np, pandas as pd, matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.markers import MarkerStyle
from matplotlib.transforms import Bbox
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'common'))
from figure_style import apply_figure_style
import os
OUT = str(HGC_OUT) + '/figure6_cs9/'   # originally the script's own folder (figure6_cs9/)
MM = 1 / 25.4

COL = {"Tyser CS7 (Smart-seq2)": "#7fa7d6", "HuE#1 CS7 (CosMx)": "#2c5fa8", "Xiao CS8 (Stereo-seq)": "#e08a6b", "Cui CS7 (Stereo-seq)": "#4a9bb0", "CS9 (Stereo-seq)": "#b8468c",
       "HuE#2 CS8 (CosMx)": "#c0333d", "In-house CS7 (10x)": "#7b4fa0", "In-house CS8 (10x)": "#3d1a63",
       "Monkey CS8-e1": "#9fd08a", "Monkey CS8-e2": "#9fd08a", "Monkey CS9-e1": "#4fa64a", "Monkey CS9-e2": "#4fa64a",
       "Monkey CS11-e1": "#1f6b33", "Monkey CS11-e2": "#1f6b33"}
DISC, EXTRA = '#4d4d4d', '#b5853f'
ORDER = [("HuE#1 CS7 (CosMx)", "HuE#1 CS7", 0), ("HuE#2 CS8 (CosMx)", "HuE#2 CS8", 0),
         ("Tyser CS7 (Smart-seq2)", "Tyser CS7", 1), ("In-house CS7 (10x)", "10x CS7", 1), ("In-house CS8 (10x)", "10x CS8", 1),
         ("Cui CS7 (Stereo-seq)", "CS7", 2), ("Xiao CS8 (Stereo-seq)", "CS8", 2), ("CS9 (Stereo-seq)", "CS9", 2),
         ("Monkey CS8-e1", "CS8-e1", 3), ("Monkey CS8-e2", "CS8-e2", 3), ("Monkey CS9-e1", "CS9-e1", 3),
         ("Monkey CS9-e2", "CS9-e2", 3), ("Monkey CS11-e1", "CS11-e1", 3), ("Monkey CS11-e2", "CS11-e2", 3)]
BLAB = {"HuE#1 CS7 (CosMx)": "HuE#1 CS7 (CosMx)", "HuE#2 CS8 (CosMx)": "HuE#2 CS8 (CosMx)", "Tyser CS7 (Smart-seq2)": "Tyser CS7 (Smart-seq2)",
        "In-house CS7 (10x)": "In-house CS7 (10x)", "In-house CS8 (10x)": "In-house CS8 (10x)", "Cui CS7 (Stereo-seq)": "Stereo-seq CS7",
        "Xiao CS8 (Stereo-seq)": "Stereo-seq CS8", "CS9 (Stereo-seq)": "Stereo-seq CS9", **{f"Monkey {k}": f"Monkey {k} (10x)" for k in ["CS8-e1", "CS8-e2", "CS9-e1", "CS9-e2", "CS11-e1", "CS11-e2"]}}
GROUPS = [(0, "CosMx"), (1, "scRNA-seq"), (2, "Stereo-seq"), (3, "10x")]
LAB = {"m01": "Nas.Meso ({Mesp1}⁺)", "m02": "APS ({Gsc}⁺{Foxa2}⁺)", "m03": "Node-like cells ({Foxj1}⁺{Chrd}⁺)",
       "m04": "DE ({Foxa2}⁺{Sox17}⁺)", "m05": "AVE ({Gsc}⁺{Cer1}⁺)", "m06": "AVE programme regresses ({Gsc}⁻)",
       "m07": "Notochord ({Noto}⁺ axial cells)", "m08": "3′ HOX in streak ({Hoxa1}⁺ or {Hoxb1}⁺)", "m09": "CLE ({Nkx1-2}⁺{Cdx2}⁺)",
       "m10": "Neural plate ({Hesx1}⁺{Six3}⁺)", "m11": "Presomite mesoderm ({Meox1}⁺{Tcf15}⁺)", "m12": "{Eomes} lost from streak",
       "m13": "5′ HOX in CLE ({Hoxb8}⁺)", "m14": "Cardiomyocytes ({Nkx2-5}⁺{Tnnt2}⁺)", "m15": "PGCs ({Dppa3}⁺{Nanos3}⁺)",
       "m16": "Hema ({Etv2}⁺{Kdr}⁺)", "m17": "ExE.Meso ({Hand1}⁺)", "m18": "Allantois ({Tbx4}⁺{Hoxa10}⁺)",
       "m19": "Primitive erythroid ({Hba-x}⁺{Gata1}⁺)"}

def it(s):
    out = re.sub(r'\{([^}]*)\}', lambda m: '$\\mathit{' + m.group(1).replace('-', '}$-$\\mathit{') + '}$', s)
    return out.replace('}$⁺', '}^{+}$').replace('}$⁻', '}^{-}$')

def draw(G, tag):
    """G: geometry (mm) and font sizes."""
    apply_figure_style(sizes=(G['f0'], G['f1'], G['f2']))
    mpl.rcParams.update({'font.family': ['Arial', 'DejaVu Sans'], 'font.sans-serif': ['Arial', 'DejaVu Sans'], 'svg.fonttype': 'none', 'savefig.bbox': None, 'mathtext.fontset': 'dejavusans'})
    T = pd.read_csv(OUT + 'audited_calls.csv'); W = pd.read_csv(OUT + 'windows_audited.csv').set_index('dataset')
    Wd, Hd = G['W'], G['H']
    fig = G['fig']; OX, OY, WT, HT = G['ox'], G['oy'], G['WT'], G['HT']
    def axmm(x0, y0, w, h):
        return fig.add_axes([(OX + x0) / WT, (OY + y0) / HT, w / WT, h / HT])
    n = len(T); isx = (T.domain == 'extra').values
    # y coordinates in mm (top row first)
    ymm = G['rowtop'] - np.arange(n) * G['rowh'] - isx * G['sep']
    a_lo, a_hi = ymm.min() - G['rowh'] * 0.6, G['rowtop'] + G['rowh'] * 0.6
    ax = axmm(G['tx0'], a_lo, G['tw'], a_hi - a_lo)
    axc = axmm(G['mx0'], a_lo, G['mw'], a_hi - a_lo)
    for a in (ax, axc): a.set_ylim(a_lo, a_hi)
    x0, x1 = 6.5, 8.0
    ax.set_xlim(x0 - 0.04, x1)
    for xi in np.arange(6.5, 8.01, 0.25): ax.axvline(xi, c='0.92', lw=0.4, zorder=0)
    # CosMx windows as translucent spans
    for k, yt in [("HuE#1 CS7 (CosMx)", 0), ("HuE#2 CS8 (CosMx)", 1)]:
        lo, hi = W.loc[k, 'window_lo'], min(W.loc[k, 'window_hi'], x1)
        ax.axvspan(lo, hi, color=COL[k], alpha=0.10, lw=0, zorder=0)
    for yi, (_, r) in zip(ymm, T.iterrows()):
        c = DISC if r.domain == 'disc' else EXTRA
        ax.plot([x0, r.mouse_onset], [yi, yi], c='0.82', lw=0.6, solid_capstyle='butt', zorder=1)
        ax.plot([r.mouse_onset, x1], [yi, yi], c=c, lw=G['thick'], solid_capstyle='butt', zorder=2)
        ax.plot(r.mouse_onset, yi, marker='D', ms=G['ms'] * 0.85, mfc=c, mec='white', mew=0.4, zorder=3)
    ax.set_yticks(ymm); ax.set_yticklabels([it(LAB[m]) for m in T.milestone_id], fontsize=G['f1'])
    for tl, dom in zip(ax.get_yticklabels(), T.domain): tl.set_color(EXTRA if dom == 'extra' else '0.1')
    ysep = (ymm[~isx].min() + ymm[isx].max()) / 2
    ax.axhline(ysep, c='0.6', lw=0.5, ls=(0, (3, 2))); axc.axhline(ysep, c='0.6', lw=0.5, ls=(0, (3, 2)))
    ax.spines[['top', 'right']].set_visible(False)
    ax.tick_params(axis='x', labelbottom=False, length=0); ax.tick_params(axis='y', length=1.5, pad=1.5, width=0.5)
    ax.set_xticks(np.arange(6.5, 8.01, 0.25))
    if G.get('a_xlab'):
        ax.set_xticks([6.5, 7.0, 7.5, 8.0]); ax.tick_params(axis='x', labelbottom=True, length=1.5, pad=0.8, width=0.5, labelsize=G['f2'])
        ax.set_xticklabels(['E6.5', 'E7.0', 'E7.5', 'E8.0'])
    ax.text(-0.015, 1.0 + 0.3 / (a_hi - a_lo), 'Mouse milestone (onset ◆)', transform=ax.transAxes, ha='right', va='bottom', fontsize=G['f0'])
    # CosMx window labels in the track, at the top
    for k, lab in [("HuE#1 CS7 (CosMx)", 'HuE#1'), ("HuE#2 CS8 (CosMx)", 'HuE#2')]:
        lo, hi = W.loc[k, 'window_lo'], min(W.loc[k, 'window_hi'], x1)
        ax.text(hi + 0.03 if yt == 0 else lo - 0.03, a_hi + 0.3, lab, ha='right' if yt == 0 else 'left', va='bottom', fontsize=G['f2'], color=COL[k], fontweight='bold', zorder=5, clip_on=False)
    # dot matrix
    xs, gx = [], 0.0
    for i, (k, s, g) in enumerate(ORDER):
        if i > 0 and g != ORDER[i - 1][2]: gx += G['gap']
        xs.append(gx); gx += 1
    xs = np.array(xs); axc.set_xlim(-0.6, xs.max() + 0.6); axc.axis('off')
    axc.axvspan(xs[0] - 0.5, xs[1] + 0.5, color='0.93', lw=0, zorder=0)
    for j, (k, s, g) in zip(xs, ORDER):
        for yi, v in zip(ymm, T[k]):
            kw = dict(ms=G['ms'], zorder=3)
            if v == 'reached': axc.plot(j, yi, 'o', mfc=COL[k], mec='0.15', mew=0.4, **kw)
            elif v == 'not reached': axc.plot(j, yi, 'o', mfc='white', mec='0.15', mew=0.5, **kw)
            elif v == 'partial': axc.plot(j, yi, marker=MarkerStyle('o', fillstyle='left'), mfc=COL[k], mfcalt='white', mec='0.15', mew=0.4, **kw)
            else: axc.plot(j, yi, marker='_', ms=G['ms'] * 1.05, mec='0.55', mew=0.8, zorder=3)
        axc.text(j, a_hi + G['clab_pad'], s, rotation=90, ha='center', va='bottom', fontsize=G['f1'], color=COL[k],
                 fontweight='bold' if g == 0 else 'normal')
    # group headers: placed above the measured top of the rotated column labels
    fig.canvas.draw(); rr = fig.canvas.get_renderer(); inv = axc.transData.inverted()
    ctop = max(inv.transform((0, t.get_window_extent(rr).y1))[1] for t in axc.texts)
    yg = ctop + 0.8
    gtexts = []
    for g, name in GROUPS:
        jj = xs[[o[2] == g for o in ORDER]]
        axc.plot([jj.min() - 0.35, jj.max() + 0.35], [yg, yg], c='0.4', lw=0.5, clip_on=False)
        gtexts.append(axc.text(jj.mean(), yg + 0.5, name, ha='center', va='bottom', fontsize=G['f2'], color='0.25', linespacing=0.9))
    fig.canvas.draw()
    gtop = max(inv.transform((0, t.get_window_extent(rr).y1))[1] for t in gtexts)
    hum = xs[[o[2] < 3 for o in ORDER]]; mon = xs[[o[2] == 3 for o in ORDER]]
    yh = gtop + 0.8
    axc.plot([hum.min() - 0.35, hum.max() + 0.35], [yh, yh], c='0.15', lw=0.6, clip_on=False)
    axc.plot([mon.min() - 0.35, mon.max() + 0.35], [yh, yh], c='#1f6b33', lw=0.6, clip_on=False)
    axc.text(hum.mean(), yh + 0.5, 'Human', ha='center', va='bottom', fontsize=G['f0'], fontweight='bold', color='0.15')
    axc.text(mon.mean(), yh + 0.5, 'Monkey', ha='center', va='bottom', fontsize=G['f0'], fontweight='bold', color='#1f6b33')
    # B: windows
    nb = len(ORDER)
    axw = axmm(G.get('btx0', G['tx0']), G['by0'], G.get('btw', G['tw']), G['bh'])
    yb = np.arange(nb)[::-1].astype(float)
    axw.set_xlim(ax.get_xlim()); axw.set_ylim(-0.6, nb - 0.4)
    for xi in np.arange(6.5, 8.01, 0.25): axw.axvline(xi, c='0.92', lw=0.4, zorder=0)
    for yi, (k, s, g) in zip(yb, ORDER):
        r = W.loc[k]; hi = min(r.window_hi, x1)
        axw.barh(yi, hi - r.window_lo, left=r.window_lo, height=0.62, color=COL[k], edgecolor='none', zorder=2)
        if np.isinf(r.window_hi):
            axw.annotate('', xy=(x1 + 0.07, yi), xytext=(x1 - 0.01, yi), arrowprops=dict(arrowstyle='-|>', color=COL[k], lw=0.9, mutation_scale=4), annotation_clip=False)
        axw.text(r.window_lo - 0.02, yi, r.label, ha='right', va='center', fontsize=G['f2'], color='0.2', fontweight='bold' if g == 0 else 'normal')
    axw.axhspan(yb[1] - 0.5, yb[0] + 0.5, color='0.93', lw=0, zorder=0)
    for yy in [yb[1] - 0.5, yb[4] - 0.5, yb[7] - 0.5]: axw.axhline(yy, c='0.8', lw=0.4)
    axw.set_yticks(yb); axw.set_yticklabels([BLAB[k] for k, s, g in ORDER], fontsize=G['f1'])
    for tl, (k, s, g) in zip(axw.get_yticklabels(), ORDER):
        tl.set_color(COL[k]); tl.set_fontweight('bold' if g == 0 else 'normal')
    axw.spines[['top', 'right']].set_visible(False)
    ticks = np.arange(6.5, 8.01, 0.25); axw.set_xticks(ticks); axw.set_xticklabels([f"{t:.2f}".rstrip("0").rstrip(".") if t % 0.5 else f"{t:.1f}" for t in ticks], fontsize=G['f2'])
    axw.set_xlabel('Mouse embryonic day (E); window bounded by milestones', fontsize=G['f0'], labelpad=1.5)
    axw.tick_params(axis='x', length=2, pad=1, width=0.5); axw.tick_params(axis='y', length=1.5, pad=1.5, width=0.5)
    # legend in whitespace right of B
    axl = axmm(G['lgx0'], G['lgy0'], G['lgw'], G['lgh']); axl.axis('off')
    H = [Line2D([], [], c=DISC, lw=G['thick'], label='disc milestone'), Line2D([], [], c=EXTRA, lw=G['thick'], label='extra-embryonic'),
         Line2D([], [], ls='', marker='D', ms=G['ms'] * 0.85, mfc='0.4', mec='white', mew=0.4, label='mouse onset'),
         Line2D([], [], ls='', marker='o', ms=G['ms'], mfc='0.45', mec='0.15', mew=0.4, label='reached'),
         Line2D([], [], ls='', marker=MarkerStyle('o', fillstyle='left'), ms=G['ms'], mfc='0.45', mfcalt='white', mec='0.15', mew=0.4, label='partial'),
         Line2D([], [], ls='', marker='o', ms=G['ms'], mfc='white', mec='0.15', mew=0.5, label='not reached'),
         Line2D([], [], ls='', marker='_', ms=G['ms'] * 1.05, mec='0.55', mew=0.8, label='not assessable')]
    axl.legend(handles=H, loc='upper left', bbox_to_anchor=(0.0, 1.0), frameon=False, fontsize=G['f1'], handlelength=1.6, labelspacing=0.4,
               borderaxespad=0, ncol=2, columnspacing=1.6, title=None)
    # panel letters
    fig.text((OX + G['lx']) / WT, (OY + Hd - 1.0) / HT, 'A', fontsize=G['fl'], fontweight='bold', va='top', ha='left')
    fig.text((OX + G['lx']) / WT, (OY + G['by0'] + G['bh'] + G['bletter']) / HT, 'B', fontsize=G['fl'], fontweight='bold', va='top', ha='left')
    return fig, (ax, axc, axw, axl)

def check(fig):
    fig.canvas.draw(); r = fig.canvas.get_renderer()
    tx = [t for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
    bb = [(t, t.get_window_extent(r)) for t in tx]
    ov = [(a.get_text(), b.get_text()) for i, (a, ba) in enumerate(bb) for b, bb2 in bb[i + 1:] if ba.overlaps(bb2)]
    out = [t.get_text() for t, b in bb if not (fig.bbox.x0 - 1 <= b.x0 and b.x1 <= fig.bbox.x1 + 1 and fig.bbox.y0 - 1 <= b.y0 and b.y1 <= fig.bbox.y1 + 1)]
    small = sorted({round(t.get_fontsize(), 2) for t in tx})
    return ov, out, small

def save(fig, stem, crops=None):
    for ext in ('png', 'svg', 'pdf'): fig.savefig(OUT + f'{stem}.{ext}', dpi=600 if ext == 'png' else None)
    for name, (y0, y1) in (crops or {}).items():
        bx = Bbox.from_bounds(0, y0 * MM, fig.get_figwidth(), (y1 - y0) * MM)
        for ext in ('png', 'svg', 'pdf'): fig.savefig(OUT + f'{name}.{ext}', dpi=600 if ext == 'png' else None, bbox_inches=bx)

COMPACT = dict(W=120, H=116, f0=6, f1=5.5, f2=5, fl=8, lx=0.5, tx0=38.5, tw=30.5, mx0=70.0, mw=49.5, gap=0.45,
               rowtop=91.0, rowh=2.6, sep=1.2, thick=2.0, ms=3.0, titlepad=1.2, clab_pad=0.5, clab_h=10.5, grp_h=4.6,
               by0=9.5, bh=27.0, bletter=4.2)
FULL = dict(W=180, H=132, f0=7, f1=6.5, f2=6, fl=9, lx=0.5, tx0=56.0, tw=50.0, mx0=108.5, mw=71.0, gap=0.45,
            rowtop=103.0, rowh=2.9, sep=1.5, thick=2.6, ms=3.8, titlepad=1.4, clab_pad=0.6, clab_h=12.5, grp_h=5.4,
            by0=10.5, bh=33.0, bletter=4.5)

if __name__ == '__main__':
    WT, HT = 122.0, 118.0
    fig = plt.figure(figsize=(WT * MM, HT * MM))
    G = dict(COMPACT); G.update(tw=24.0, mx0=63.5, mw=53.5, btx0=38.5, btw=56.0, a_xlab=True, lgx0=7.0, lgy0=101.5, lgw=40.0, lgh=11.5)
    G.update(fig=fig, ox=1.0, oy=1.0, WT=WT, HT=HT)
    fig, axs = draw(G, 'fig6ab')
    for tl in axs[2].get_yticklabels(): tl.set_fontsize(5)
    ov, out, small = check(fig)
    print('overlaps:', ov, 'outside:', out, 'font sizes:', small)
    stem = 'Fig6AB_with_StereoSeq_CS9'
    for ext in ('png', 'svg', 'pdf'): fig.savefig(OUT + f'{stem}.{ext}', dpi=600 if ext == 'png' else None)
