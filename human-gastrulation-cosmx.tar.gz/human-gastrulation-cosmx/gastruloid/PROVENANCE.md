# Provenance — gastruloid/

All scripts are the final versions used for the manuscript figures and tables. Edits relative to the originals: absolute paths replaced by `$HGC_DATA` / `$HGC_OUT` roots (relative sub-paths kept), a provenance header added, analysis-platform calls and artifact markers removed, imports of sibling scripts pointed at their repository folder, and Table S2 read from the xlsx. No algorithm, parameter, threshold, random seed or output definition was changed. Original paths below refer to the authors' project drives F: and G:.

Reconstructed scripts: code that existed only as cells of persistent kernel sessions was copied verbatim from the session transcripts (frame id and message numbers in the header of every cell); inspection-only and figure-polishing cells were left out, and cells that stopped with an error are truncated at the failing line and marked. sha256 values of reconstructed scripts refer to the extracted transcript text.

| Repository file | Original source | sha256 of original | Notes |
|---|---|---|---|
| `01_preprocess/export_hamazaki.R` | reconstructed from transcript 824ef1ce (messages 4859-6166) | `759322e130de1c74…` | reconstructed |
| `01_preprocess/loaders.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/code/loaders.py | `53274f45092c1182…` | registry also lists models not in the final 22 samples |
| `01_preprocess/prep_group.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/code/prep_group.py | `bfc645c05841fe61…` | usage: python prep_group.py <group ids> |
| `01_preprocess/new_models.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/benchmark/v3_rounds61-120/code/new_data.py | `c6dd3369f97a95fe…` | usage: python new_models.py models |
| `01_preprocess/fix_heemskerk_group.py` | reconstructed from transcript 824ef1ce (messages 7092-7104) | `f6a60c7a296397f6…` | reconstructed |
| `02_milestone_scoring/stage_lib.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/code/stage_lib.py | `6952bc80220245bb…` | Table S2 read from xlsx (path change) |
| `02_milestone_scoring/stage_all.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/code/stage_all.py | `325b037ccfbfc30a…` | includes depth matching to 14,848 UMI/cell |
| `02_milestone_scoring/stage_v2.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/stage_v2.py | `50dcd08819453801…` | adds Hee_42 (fixed), Liu, Pedroza, Weatherbee |
| `02_milestone_scoring/assess_v2.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/assess_v2.py | `55237fe699f9aed4…` |  |
| `03_staging_vs_cosmx/stage_cs78.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/stage_cs78.py | `238c74fb4d10d1a2…` | Table S2 read from xlsx; tb/out/sample_window.csv only fills an informational column |
| `04_denovo_annotation/pipeline.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/reannotation_denovo/code/pipeline.py | `6af5affa4608060d…` | usage: python pipeline.py <unit> |
| `04_denovo_annotation/markers.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/reannotation_denovo/code/markers.py | `2046918e70d4f8ed…` |  |
| `04_denovo_annotation/annotations.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/reannotation_denovo/code/annotations.py | `2de6a1e7c442d5da…` | manual curation encoded as constants |
| `04_denovo_annotation/apply.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/reannotation_denovo/code/apply.py | `2616f17757cb2e15…` |  |
| `04_denovo_annotation/finalize_tables.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/reannotation_denovo/code/finalize_tables.py | `007d4fc8f0ecf1a7…` | run with cwd = reanno/ |
| `05_celltype_comparison/celltypes_cs78.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/celltypes_cs78.py | `14a282e14c3824ea…` |  |
| `05_celltype_comparison/celltypes_full.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/celltypes_full.py | `ba7dcb537a308b08…` |  |
| `05_celltype_comparison/celltypes_mini.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/celltypes_mini.py | `29b8f1339ed907f8…` |  |
| `05_celltype_comparison/cm_common.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/cm_common.py | `250e1f4ad1c3cec2…` |  |
| `05_celltype_comparison/plot_assess.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/plot_assess.py | `f45009849609b42a…` | kept because of the exec import |
| `05_celltype_comparison/plot_stage_cs78_mini.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/plot_stage_cs78_mini.py | `bb34d1f0aac1fd38…` |  |
| `05_celltype_comparison/plot_combined_abbr.py` | [F:]/CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/plot_combined_abbr.py | `159755032807705e…` |  |
| `05_celltype_comparison/build_sfig8A.py` | artifact build_sf8A_human_only.py (version b6231863; session 824ef1ce, 2026-11-17) | `17a601c564f51fbb…` | usage: python build_sfig8A.py <stage_long.csv> <stage.csv> <groups.csv> <celltypes_full_missing_by_sample.csv> <plot_assess.py> <outdir> |
| `05_celltype_comparison/build_sfig8B.py` | artifact build_sf8B_human_only.py (version da78e3e2; session 824ef1ce, 2026-11-17) | `f74fda5f07c8fdc1…` | usage: python build_sfig8B.py <celltypes_full_long.csv> <celltypes_full_missing_by_sample.csv> <stage.csv> <groups.csv> <plot_assess.py> <outdir> |

## Version choices

- The final benchmark uses 22 human samples of 6 studies. `build_sf8A_human_only.py` / `build_sf8B_human_only.py` (session 824ef1ce, 2026-11-17) drop the mouse models from the 31-sample full versions (`plot_stage_cs78_full_abbr.py`, `cm_matrix_full_abbr.py`, 2026-11-13). Earlier staging/benchmark rounds (`benchmark/code`, `v2_rounds21-60`, `v3_rounds61-120` except `new_data.py`, `transition_benchmark/`, `scRNA_GSE208369/` 6-sample version, `stage_gastruloid.py`) are superseded.
- Figure 6H: `plot_combined_abbr.py` (2026-11-13, 7 samples: Hamazaki 0-96 h, Heemskerk/Jo 42 h, Liu day 11).
- Milestone scoring: `scRNA_all_datasets/milestone_staging/code/stage_lib.py` + `stage_all.py` (2026-11-12), extended by `assessability_all_models/stage_v2.py` and `assess_v2.py` (2026-11-13).
- De novo annotation: `reannotation_denovo/code/` on drive F (2026-11-13; dataset key Budjan, renamed from Miao); report/workbook builders (`build_report.py`, `build_workbook.py`, `patch_rep.py`, `summ.py`, `finalize_evidence.py`, `plot_*.py`) are not needed for the manuscript outputs and are not included.
- `loaders.py` is the 2026-11-12 version used to prepare the groups; Heemskerk rep1 orientation was corrected afterwards by `fix_heemskerk_group.py`.
