# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/lr_asymmetry/export_cs7_disc.R (2026-10-03; artifact 85b674dd)
# sha256 of original: 71b701729e86fb582d27e03229cf3907936f647dd69790935197e5cd744adbaa
# Methods paragraphs: Supplementary Figure 5 (HuE#1 counterpart, not shown in a panel)
# Produces: handoff/cs7_disc_counts.mtx, cs7_disc_genes.csv, cs7_disc_cells.csv (input of lr_asym.py STAGE=CS7)
# Edits/notes: object path -> HGC_DATA.
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

suppressPackageStartupMessages({library(Seurat); library(Matrix)})
o <- readRDS(file.path(DATA, "obj6_obj7_merged_curated_final.rds")); md <- o@meta.data
i6 <- which(md$source_object=="obj6" & as.logical(md$curated_kept) & as.logical(md$disc_main_body))
cat("CS7 disc kept cells:", length(i6), "\n")
cn <- LayerData(o[["RNA"]], "counts")[, i6]
dir.create("handoff", showWarnings=FALSE)
writeMM(cn, "handoff/cs7_disc_counts.mtx")
write.csv(data.frame(gene=rownames(cn)), "handoff/cs7_disc_genes.csv", row.names=FALSE)
write.csv(data.frame(cell=rownames(md)[i6], label=as.character(md$`39Type`[i6]), x=md$x_um[i6], y=md$y_um[i6], z=md$z_um[i6], nCount=md$nCount[i6]),
          "handoff/cs7_disc_cells.csv", row.names=FALSE)
cat("DONE\n")
