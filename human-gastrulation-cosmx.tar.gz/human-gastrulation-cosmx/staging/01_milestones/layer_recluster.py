# staging/01_milestones/layer_recluster.py
# Source: drive G: data/milestone_evidence/mz/rescue/recluster.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

import scanpy as sc, anndata as ad, numpy as np, pandas as pd, scipy.io, scipy.sparse as sp, warnings; warnings.filterwarnings('ignore')
B=(str(HGC_DATA) + '/'); OD=B+'staging/layer_rescue/'
GS=pd.read_csv(OD+'mouse_milestone_genesets.csv')
DEF={'Notochord':('NOTO','SHH'),'Caudal epiblast':('NKX1-2','CDX2'),'Rostral neurectoderm':('HESX1','SIX3'),'Paraxial mesoderm':('MEOX1','TCF15'),
     'Cardiomyocytes':('NKX2-5','TNNT2'),'PGC':('NANOS3','DPPA3'),'Allantois':('TBX4','HOXA10')}
KEY={'Notochord':'Notochord forms','Caudal epiblast':'Caudal epiblast forms','Rostral neurectoderm':'Neural plate (rostral neurectoderm)','Paraxial mesoderm':'Paraxial mesoderm forms',
     'Cardiomyocytes':'Cardiomyocytes appear','PGC':'PGCs appear','Allantois':'Allantois forms'}
POOL={'Notochord':['X','M','N'],'Caudal epiblast':['E'],'Rostral neurectoderm':['E'],'Paraxial mesoderm':['M'],'Cardiomyocytes':['M','Mx'],'PGC':['E','M','Mx','X','N','VE','other'],'Allantois':['M','Mx']}
def cosmx(s):
    g=pd.read_csv(B+'dataprep/export/genes.csv').gene.values; M=scipy.io.mmread(B+f'dataprep/export/{s}_counts.mtx').tocsr().T.tocsr()
    c=pd.read_csv(B+f'dataprep/export/{s}_cells.csv')
    lay={'EPI':'E','ECT':'E','aECT':'E','pECT':'E','NNE':'E','CLE':'E','PS':'E','APS':'M','Nas.Meso':'M','Para.Meso':'M','Rostral.Meso':'M','LP.Meso':'M','Heart.Meso':'M','Node':'X','Notochord':'X','PrP':'X','DE':'N','AVE':'N','ADE':'N','VE1':'VE','VE2':'VE'}
    return ad.AnnData(M,obs=pd.DataFrame({'label':c.label_short.values,'layer':c.label_short.map(lay).values}),var=pd.DataFrame(index=g))
def stereo(s):
    a=ad.read_h5ad(f'{HGC_DATA}/CS7_CS8_feature_plots/data/{s}.h5ad'); a.X=a.layers['counts']; a=ad.AnnData(a.X,obs=a.obs[[]].copy(),var=a.var[[]].copy())
    cells=[v.split('_',1)[1] for v in a.obs_names]; L=pd.read_csv(B+'external/human_stereoseq/stereoseq_cell_labels.csv').set_index('cell').loc[cells]
    lab=L.our_group_fine.fillna('exclude').values; t2=L.Type2.astype(str).values
    lay={'EPI':'E','NNE':'E','CLE':'E','aECT':'E','pECT':'E','PS':'E','APS':'M','Nas.Meso':'M','Para.Meso':'M','Rostral.Meso':'M','LP.Meso':'M','Heart mesoderm':'M','Adv.Meso':'M','Other.Meso':'M','Node':'X','DE':'N','Gut':'N','VE':'VE'}
    ly=pd.Series(lab).map(lay).values.astype(object); mx=np.isin(t2,['29 EXM','30 Allantois','31 YS.Meso'])&pd.isna(ly); ly[mx]='Mx'; ly[pd.isna(ly)]='other'
    a.obs['label']=np.where(lab=='exclude',t2,lab); a.obs['layer']=ly; return a
def tenx():
    M=scipy.io.mmread(OD+'inhouse10x_CS7_counts.mtx').tocsr().T.tocsr(); g=open(OD+'inhouse10x_CS7_genes.txt').read().split('\n')[:M.shape[1]]
    c=pd.read_csv(OD+'inhouse10x_CS7_cells.csv'); n=c.label.str.split().str[0].astype(int)
    m={**{k:'E' for k in [1,2,3,4,5,8,12,15]},**{k:'M' for k in range(16,29)},**{k:'Mx' for k in [29,30,31]},9:'X',10:'X',35:'N',36:'N',37:'N',38:'VE'}
    ly=n.map(m).fillna('other'); ly[c.label.isin(['39 Trophoblast','13 AME'])]='bg'
    return ad.AnnData(M,obs=pd.DataFrame({'label':c.label.values,'layer':ly.values}),var=pd.DataFrame(index=g))
def tyser():
    M=scipy.io.mmread(OD+'tyser_CS7_counts.mtx').tocsr().T.tocsr(); g=open(OD+'tyser_CS7_genes.txt').read().split('\n')[:M.shape[1]]
    c=pd.read_csv(OD+'tyser_CS7_cells.csv')
    m={'Epiblast':'E','Primitive Streak':'E','NNE':'E','Nascent Mesoderm':'M','Emergent Mesoderm':'M','Advanced Mesoderm':'M','YS Mesoderm':'Mx','Axial Mesoderm':'X','DE(P)':'N','DE(NP)':'N','Hypoblast':'VE','YS Endoderm':'VE','Amnion':'bg'}
    return ad.AnnData(M,obs=pd.DataFrame({'label':c.label.values,'layer':c.label.map(m).fillna('other').values}),var=pd.DataFrame(index=g))
DS={'Tyser CS7 (Smart-seq2)':tyser,'HuE#1 CS7 (CosMx)':lambda:cosmx('CS7'),'Xiao CS8 (Stereo-seq)':lambda:stereo('CS8'),'Cui CS7 (Stereo-seq)':lambda:stereo('CS7'),'HuE#2 CS8 (CosMx)':lambda:cosmx('CS8'),'In-house CS7 (10x)':tenx}
calls=pd.read_csv('mz/allstage/calls.csv').set_index('milestone')
rows=[]; best=[]; ALL=[]
for dn,f in DS.items():
    A=f(); A.var_names_make_unique(); A.X=sp.csr_matrix(A.X).astype(np.float32)
    for t,lays in POOL.items():
        if dn.endswith('(CosMx)') and t in ('PGC','Allantois'): continue   # CosMx export holds disc + VE only
        P=A[A.obs.layer.isin(lays).values].copy()
        if P.n_obs<50: continue
        genes=[g for g in GS[GS.celltype==t].human if g in P.var_names]
        D=(P.X>0)
        P.obs['set_score']=np.asarray(D[:,[P.var_names.get_loc(g) for g in genes]].mean(1)).ravel()
        for g in DEF[t]: P.obs[g]=np.asarray(D[:,P.var_names.get_loc(g)].todense()).ravel() if g in P.var_names else np.nan
        P.obs['depth']=np.asarray(P.X.sum(1)).ravel()
        Q=P.copy(); sc.pp.normalize_total(Q,1e4); sc.pp.log1p(Q)
        sc.tl.score_genes(Q,genes,ctrl_size=50,n_bins=25,score_name='mod',random_state=0); P.obs['mod']=Q.obs['mod'].values
        sc.pp.highly_variable_genes(Q,n_top_genes=min(2000,Q.n_vars-1)); Q=Q[:,Q.var.highly_variable].copy()
        sc.pp.scale(Q,max_value=10); sc.tl.pca(Q,n_comps=min(30,Q.n_obs-2)); sc.pp.neighbors(Q,n_neighbors=15); sc.tl.leiden(Q,resolution=2.0,flavor='igraph',n_iterations=2,key_added='sub')
        P.obs['sub']=Q.obs['sub'].values
        g=P.obs.groupby('sub'); s=g.agg(n=('set_score','size'),set_score=('set_score','mean'),mod=('mod','mean'),depth=('depth','median'),m1=(DEF[t][0],'mean'),m2=(DEF[t][1],'mean'))
        s['enrich']=s.set_score/P.obs.set_score.mean(); s['mod_z']=(s['mod']-P.obs['mod'].mean())/P.obs['mod'].std()
        p1,p2=P.obs[DEF[t][0]].mean(),P.obs[DEF[t][1]].mean()
        s['fe1']=s.m1/max(p1,1e-3); s['fe2']=s.m2/max(p2,1e-3); s['marker_fe']=np.sqrt(s.fe1*s.fe2)
        s['top_labels']=g.label.agg(lambda x: '; '.join(f'{k} {v}' for k,v in x.value_counts().head(3).items()))
        s=s[s.n>=15].sort_values('marker_fe',ascending=False)
        s2=s.copy(); s2['dataset']=dn; s2['celltype']=t; s2['pool_depth_median']=P.obs.depth.median(); s2['m1_pool']=p1; s2['m2_pool']=p2; ALL.append(s2.reset_index())
        b=s.iloc[0]
        best.append(dict(dataset=dn,celltype=t,milestone=KEY[t],original_call=calls.loc[KEY[t],dn],pool_layers='+'.join(lays),pool_n=P.n_obs,n_genes_in_set=len(genes),n_subclusters=len(s),
             best_sub_n=int(b.n),marker_fe=round(b.marker_fe,2),mod_z=round(b.mod_z,2),depth_ratio=round(b.depth/P.obs.depth.median(),2),best_enrich=round(b.enrich,2),best_set_score=round(100*b.set_score,1),pool_set_score=round(100*P.obs.set_score.mean(),1),
             marker1=DEF[t][0],m1_best=round(100*b.m1,1),m1_pool=round(100*P.obs[DEF[t][0]].mean(),1),marker2=DEF[t][1],m2_best=round(100*b.m2,1),m2_pool=round(100*P.obs[DEF[t][1]].mean(),1),
             second_marker_fe=round(s.iloc[1].marker_fe,2) if len(s)>1 else np.nan,best_top_labels=b.top_labels))
        print(dn,t,P.n_obs,len(s),'best',int(b.n),round(b.marker_fe,2),round(b.mod_z,2),flush=True)
pd.DataFrame(best).to_csv('mz/rescue/recluster_best_subclusters.csv',index=False); pd.concat(ALL).to_csv('mz/rescue/recluster_all_subclusters.csv',index=False)
