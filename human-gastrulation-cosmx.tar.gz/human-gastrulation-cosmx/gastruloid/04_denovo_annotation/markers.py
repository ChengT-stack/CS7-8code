# gastruloid/04_denovo_annotation/markers.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/reannotation_denovo/code/markers.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

"""Knowledge-based marker sets used for the de novo annotation (human symbols).
Sources: general developmental-biology knowledge of gastrulation-to-organogenesis cell states
(mouse and primate embryo literature); no dataset-specific author annotation is used."""
SIG = {
 'Pluripotent/epiblast':      ['POU5F1','NANOG','SOX2','DPPA4','TDGF1','L1TD1','LIN28A','DNMT3B','PRDM14','SFRP2','USP44','ZSCAN10'],
 'Naive-like pluripotent':    ['KLF17','DPPA3','DPPA5','SUSD2','ZFP42','TFCP2L1','KLF4','KLF5'],
 'Anterior epiblast/early neuroectoderm': ['OTX2','SOX2','HESX1','SIX3','LHX2','SOX3','ZIC2','PAX6','SOX1','FEZF1','SOX21'],
 'Primitive streak':          ['TBXT','MIXL1','EOMES','FGF8','WNT3','SP5','NODAL','CDX1','FST','MESP1','FGF17','NKX1-2'],
 'Anterior PS/mesendoderm':   ['GSC','EOMES','MIXL1','LHX1','CER1','FOXA2','CHRD','LEFTY1','LEFTY2','HHEX'],
 'Definitive endoderm':       ['SOX17','FOXA2','CXCR4','GATA6','PRDM1','CER1','HHEX','KIT','FOXA1','GPC4','EPCAM','CLDN6'],
 'Gut endoderm':              ['FOXA1','FOXA2','CDX2','EPCAM','CLDN6','SHH','HNF1B','HNF4A','NKX2-1','SOX2','PAX9','ONECUT1','CDH1','KRT19'],
 'Hypoblast/yolk-sac endoderm': ['APOA1','APOA2','APOA4','APOB','TTR','AFP','HNF4A','GATA4','GATA6','SOX17','PDGFRA','HNF1B','NOSTRIN','LINC01356','FN1','COL4A1'],
 'Node/notochord':            ['NOTO','TBXT','FOXA2','CHRD','NOG','SHH','FOXJ1','CA3','SHISA2','ARL13B','LEFTY1','FOXA1'],
 'Nascent mesoderm':          ['MESP1','MESP2','MIXL1','TBXT','SNAI1','LHX1','PDGFRA','APLNR','HAS2','CDH11','MSGN1'],
 'Posterior PSM':             ['TBX6','MSGN1','HES7','DLL3','DLL1','RSPO3','FGF17','WNT3A','CDX2','LFNG','FGF8'],
 'Anterior PSM':              ['MESP2','RIPPLY1','RIPPLY2','TCF15','MEOX1','LFNG','FOXC2','MESP1'],
 'Somite':                    ['MEOX1','TCF15','UNCX','TBX18','PAX3','FOXC2','MEOX2','ALDH1A2','FOXC1','SIX1','FST'],
 'Sclerotome':                ['PAX1','PAX9','NKX3-2','SOX9','TWIST1','FOXC2','NKX3-1','SOX5','COL2A1'],
 'Dermomyotome/myogenic':     ['PAX7','PAX3','MYF5','MYOD1','MYOG','DMRT2','LBX1','SIX1','DES','MYF6','TNNT1','MYL1'],
 'NMP/caudal progenitor':     ['SOX2','TBXT','NKX1-2','CDX2','WNT3A','FGF8','SP5','CDX1','CDX4','FGF17','HOXA10','CYP26A1','HES3'],
 'Neural progenitor (spinal/hindbrain)': ['SOX2','SOX1','PAX6','HES5','NKX6-1','OLIG2','IRX3','SOX3','MSX1','PAX3','DBX1','NKX2-2','CRABP1','ZIC1','SOX21'],
 'Floor plate':               ['FOXA2','SHH','ARX','NKX2-2','FOXA1','FERD3L','NTN1','CORIN'],
 'Roof plate/dorsal NT':      ['LMX1A','MSX1','MSX2','WNT1','WNT3A','GDF7','PAX3','PAX7','ZIC1','OLIG3','ATOH1'],
 'Brain (fore/mid/hind)':     ['OTX2','SIX3','LHX2','FOXG1','EMX2','EN1','EN2','PAX2','GBX2','HESX1','RAX','OTX1','FEZF1','PAX5','EGR2'],
 'Neuron':                    ['STMN2','ELAVL3','ELAVL4','TUBB3','DCX','ONECUT2','NEUROG2','NEUROD1','ISL1','MNX1','NHLH1','POU4F1','INA','GAP43','NEUROD4'],
 'Neural crest':              ['SOX10','FOXD3','TFAP2A','TFAP2B','PAX3','SNAI2','ETS1','PLP1','NGFR','TWIST1','SOX9','MPZ','CRABP1'],
 'Surface ectoderm/placode':  ['TFAP2A','KRT8','KRT18','KRT19','GATA3','TP63','DLX5','MSX2','GRHL2','SIX1','EYA1','DLX3','KRT5','PAX8'],
 'Amnion-like':               ['ISL1','GABRP','VTCN1','IGFBP3','GATA3','TFAP2A','TFAP2C','HAND1','WNT6','BAMBI','KRT7','TBX3','CDX2','MSX2','IGFBP5','ABCG2'],
 'Trophoblast-like':          ['GATA3','GATA2','KRT7','TFAP2C','TP63','ELF5','CGA','CGB3','HLA-G','SDC1','ERVW-1','VGLL1','TACSTD2','PGF','XAGE2','XAGE3','ENPEP','KRT18'],
 'PGC-like':                  ['NANOS3','SOX17','PRDM1','TFAP2C','DND1','DAZL','KIT','DPPA3','POU5F1','NANOG','SOX15','PRDM14','CD38'],
 'Lateral plate mesoderm':    ['HAND1','HAND2','FOXF1','GATA4','GATA5','GATA6','ISL1','BMP4','TBX20','PITX1','PITX2','IRX3','OSR1','TBX3','PRRX1'],
 'Cardiac':                   ['NKX2-5','TNNT2','MYL7','MYL4','ACTC1','MYH6','ISL1','MEF2C','TBX5','HCN4','TNNI1','MYH7','NPPA'],
 'Intermediate mesoderm':     ['OSR1','PAX2','PAX8','LHX1','WT1','GATA3','EMX2','HOXB7','RET'],
 'ExE mesoderm/mesenchyme':   ['HAND1','FOXF1','POSTN','COL3A1','COL1A1','COL1A2','ANXA1','VIM','BMP4','HAPLN1','PITX1','TWIST1','PRRX1','PDGFRB','DCN','LUM','TAGLN','ACTA2'],
 'Cranial/pharyngeal mesoderm': ['TBX1','PITX2','FOXC2','TCF21','MSC','ISL1','SIX2','FOXC1','MYF5','TLX1'],
 'Endothelium':               ['PECAM1','CDH5','KDR','TEK','ESAM','ERG','SOX7','TAL1','ETV2','FLT1','TIE1','SOX18','CLDN5'],
 'Blood':                     ['GATA1','HBE1','HBZ','HBG1','HBG2','TAL1','RUNX1','SPI1','PTPRC','GYPA','KLF1','HBA1','GFI1B'],
 'Stress/apoptosis':          ['DDIT3','ATF3','FOS','JUN','HSPA1A','HSPA1B','PPP1R15A','TRIB3','CDKN1A','GADD45B','BBC3','FAS','MDM2'],
}
HOX_GROUPS = {
 'HOX1-3':  ['HOXA1','HOXB1','HOXA2','HOXB2','HOXA3','HOXB3','HOXD3'],
 'HOX4-5':  ['HOXA4','HOXB4','HOXC4','HOXD4','HOXA5','HOXB5','HOXC5'],
 'HOX6-9':  ['HOXA7','HOXB6','HOXB7','HOXB8','HOXC6','HOXC8','HOXA9','HOXB9','HOXC9','HOXD8','HOXD9'],
 'HOX10-13': ['HOXA10','HOXC10','HOXD10','HOXA11','HOXC11','HOXD11','HOXC12','HOXA13','HOXB13','HOXC13','HOXD13'],
}
_extra = ['VIM','CDH1','CDH2','EPCAM','MKI67','TOP2A','MALAT1','NEAT1','XIST','MEG3','LEFTY1','LEFTY2','NODAL','WNT5A','WNT5B','FGF4','BMP2','BMP7','ID1','ID2','ID3',
          'CYP26A1','ALDH1A2','RARB','CRABP2','STRA6','DUSP6','SPRY4','AXIN2','NOTUM','LEF1','TCF7L1','UTF1','DPPA2','TERF1','FOXH1','ZIC3','ZIC5','GBX2','NKX1-2','SALL4','SALL1',
          'KRT8','KRT18','KRT19','FOXD3','SOX11','NES','FABP7','HES1','HES5','DLK1','IGF2','H19','CDKN1C','PEG10','TTR','AFP','APOE','SPARC','LUM','S100A10','S100A11','ANXA2',
          'TPM1','TAGLN','ACTA2','MYL9','CNN1','COL4A1','COL4A2','LAMA1','LAMB1','NID2','FN1','TBX3','TBX2','TBX1','EVX1','MSX1','MSX2','CDX1','CDX2','CDX4',
          'FOXC1','FOXC2','FOXB1','FOXD1','FOXD2','IRX1','IRX2','IRX3','IRX5','PRDM1','NANOS3','SOX17','TFAP2C','TFAP2A','GATA2','GATA3','ISL1','HAND1','HAND2',
          'OTX2','SOX1','SOX3','SOX9','SOX10','PAX2','PAX3','PAX6','PAX7','PAX8','PAX1','PAX9','EGR2','MAFB','HOXA1','HOXB1','HOXB4','HOXB9','HOXA10','HOXC10','HOXA13','HOXD13',
          'DDIT3','ATF3','HSPA1A','BNIP3','VEGFA','MT1X','MT2A','TP53','CDKN1A']
PANEL = []
for _g in [g for v in SIG.values() for g in v] + _extra + [g for v in HOX_GROUPS.values() for g in v]:
    if _g not in PANEL: PANEL.append(_g)
S_GENES = ['MCM5','PCNA','TYMS','FEN1','MCM2','MCM4','RRM1','UNG','GINS2','MCM6','CDCA7','DTL','PRIM1','UHRF1','CENPU','HELLS','RFC2','RPA2','NASP','RAD51AP1','GMNN','WDR76','SLBP','CCNE2','UBR7','POLD3','MSH2','ATAD2','RAD51','RRM2','CDC45','CDC6','EXO1','TIPIN','DSCC1','BLM','CASP8AP2','USP1','CLSPN','POLA1','CHAF1B','BRIP1','E2F8']
G2M_GENES = ['HMGB2','CDK1','NUSAP1','UBE2C','BIRC5','TPX2','TOP2A','NDC80','CKS2','NUF2','CKS1B','MKI67','TMPO','CENPF','TACC3','PIMREG','SMC4','CCNB2','CKAP2L','CKAP2','AURKB','BUB1','KIF11','ANP32E','TUBB4B','GTSE1','KIF20B','HJURP','CDCA3','JPT1','CDC20','TTK','CDC25C','KIF2C','RANGAP1','NCAPD2','DLGAP5','CDCA2','CDCA8','ECT2','KIF23','HMMR','AURKA','PSRC1','ANLN','LBR','CKAP5','CENPE','CTCF','NEK2','G2E3','GAS2L3','CBX5','CENPA']

KEY = ['POU5F1','NANOG','SOX2','DPPA4','TDGF1','L1TD1','DNMT3B','KLF17','DPPA3','OTX2','HESX1','SIX3','LHX2','SOX1','SOX3','PAX6','ZIC2','TBXT','MIXL1','EOMES','GSC','MESP1','MESP2','LHX1','CER1',
 'FOXA2','FOXA1','SOX17','CXCR4','GATA6','GATA4','HNF1B','HNF4A','APOA1','TTR','AFP','NOTO','CHRD','NOG','SHH','TBX6','MSGN1','HES7','DLL3','RIPPLY1','RIPPLY2','MEOX1','TCF15','UNCX','TBX18',
 'PAX3','PAX7','PAX1','PAX9','NKX3-2','SOX9','MYF5','MYOD1','MYOG','NKX1-2','CDX1','CDX2','CDX4','WNT3A','FGF8','FGF17','SP5','HES5','NKX6-1','OLIG2','NKX2-2','IRX3','MSX1','LMX1A','FOXG1','EMX2',
 'EN1','GBX2','EGR2','STMN2','ELAVL4','NEUROG2','ISL1','MNX1','SOX10','FOXD3','TFAP2A','TFAP2B','TFAP2C','GATA3','GATA2','TP63','KRT7','GABRP','VTCN1','CGA','NANOS3','PRDM1','HAND1','HAND2',
 'FOXF1','TBX20','NKX2-5','TNNT2','MYL7','OSR1','PAX2','PAX8','WT1','TBX1','TWIST1','PRRX1','COL3A1','POSTN','PECAM1','CDH5','KDR','ETV2','TAL1','RUNX1','GATA1','HBE1','HBZ','ALDH1A2','CYP26A1',
 'NODAL','LEFTY1','LEFTY2','BMP4','WNT3','WNT5A','WNT5B','FGF4','DDIT3','XIST']
for _g in KEY:
    if _g not in PANEL: PANEL.append(_g)
