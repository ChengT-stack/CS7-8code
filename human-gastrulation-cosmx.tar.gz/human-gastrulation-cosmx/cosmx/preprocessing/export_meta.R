# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: artifact 55d1e960 export_meta.R (session 32c2b2b0, 2026-11-22)
# sha256 of original: e3f38f605daa5bd4a6f130d371b549976a578a6209bcc8cc5855e12f27b26923
# Methods paragraphs: P343 (QC counts), all downstream
# Produces: final_meta.csv.gz (merged metadata export used by Supplementary Materials 1-2 and section pages)
# Edits/notes: absolute .rds path -> HGC_DATA.
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

suppressMessages(library(Seurat))
t0 <- Sys.time()
o <- readRDS(file.path(DATA, "obj6_obj7_merged_curated_final.rds"))
cat('loaded', format(Sys.time()-t0), '\n')
md <- o@meta.data
cat('ncells', nrow(md), '\n'); cat(paste(colnames(md), collapse=' | '), '\n')
md$cell <- rownames(md)
data.table::fwrite(md, 'final_meta.csv.gz')
cat('reductions:', paste(names(o@reductions), collapse=','), '\n')
cat('misc:', paste(names(o@misc), collapse=','), '\n')
for (nm in names(o@misc)) { cat('--', nm, '\n'); print(str(o@misc[[nm]], max.level=1, list.len=10)) }
