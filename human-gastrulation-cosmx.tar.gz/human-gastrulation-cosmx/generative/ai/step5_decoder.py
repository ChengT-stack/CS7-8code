# NB-MLP decoder: representation -> CosMx WTX counts (18,934 genes); hyper-parameter search; decode generated t0.5 states.
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import sys, json, numpy as np, pandas as pd, scipy.io, scipy.sparse as sp, torch, torch.nn as nn, optuna, anndata as ad, os
sys.path.insert(0,'ai'); from step5_lib import mlp, dev
torch.set_float32_matmul_precision('high')
B=DATA + '/cs7_cs8_matching/'; OUT=os.environ.get('S5OUT','ai/step5_final')
cfgG=json.load(open(f'{OUT}/generator_config.json')); rep=cfgG['config']['rep']
C=dict(np.load(f'ai/step5_cache_{rep}.npz',allow_pickle=True)); Zall=C['Z']; u7=np.load('ai/step5_u7.npy'); u8=np.load('ai/step5_u8.npy')
g=pd.read_csv(B+'dataprep/export/genes.csv').gene.values
X=sp.vstack([scipy.io.mmread(B+f'dataprep/export/{s}_counts.mtx').tocsr().T.tocsr() for s in ['CS7','CS8']]).tocsr().astype(np.float32)
Zc=np.vstack([Zall[u7],Zall[u8]]).astype(np.float32); n7=len(u7); lib=np.asarray(X.sum(1)).ravel()
rng=np.random.default_rng(0); val=rng.random(X.shape[0])<0.1
Xg=torch.tensor(X.toarray(),dtype=torch.float16,device=dev); Zg=torch.tensor(Zc,device=dev); Lg=torch.tensor(np.log(lib),device=dev)
tri=torch.tensor(np.where(~val)[0],device=dev); vai=torch.tensor(np.where(val)[0],device=dev)
class Dec(nn.Module):
    def __init__(s,d,G,h,L,drop):
        super().__init__(); s.net=mlp(d,G,h,L,drop); s.logth=nn.Parameter(torch.zeros(G))
    def forward(s,z,loglib): return torch.softmax(s.net(z),1)*torch.exp(loglib)[:,None], torch.exp(s.logth)
def nb_nll(x,mu,th):
    return -(torch.lgamma(x+th)-torch.lgamma(th)-torch.lgamma(x+1)+th*torch.log(th/(th+mu)+1e-8)+x*torch.log(mu/(th+mu)+1e-8)).sum(1).mean()
def fit(p,max_epochs=int(os.environ.get('MAXEP',200)),patience=15,seed=0,report=None):
    torch.manual_seed(seed); m=Dec(Zg.shape[1],Xg.shape[1],p['h'],p['L'],p['drop']).to(dev)
    opt=torch.optim.AdamW(m.parameters(),lr=p['lr'],weight_decay=p['wd']); sch=torch.optim.lr_scheduler.ReduceLROnPlateau(opt,factor=0.5,patience=5)
    best=1e18; bad=0; state=None; bs=p['bs']
    for ep in range(max_epochs):
        m.train(); perm=tri[torch.randperm(len(tri),device=dev)]
        for k in range(0,len(perm),bs):
            i=perm[k:k+bs]; z=Zg[i]+p['zin']*torch.randn_like(Zg[i]); mu,th=m(z,Lg[i]); loss=nb_nll(Xg[i].float(),mu,th)
            opt.zero_grad(); loss.backward(); opt.step()
        m.eval()
        with torch.no_grad(): v=float(np.mean([nb_nll(Xg[vai[k:k+2048]].float(),*m(Zg[vai[k:k+2048]],Lg[vai[k:k+2048]])).item() for k in range(0,len(vai),2048)]))
        sch.step(v)
        if v<best-1e-3: best=v; bad=0; state={k:t.detach().clone() for k,t in m.state_dict().items()}
        else: bad+=1
        if report: report(v,ep)
        if bad>=patience: break
    m.load_state_dict(state); return m,best,ep+1
def objective(tr):
    p=dict(h=tr.suggest_categorical('h',[512,1024,2048]),L=tr.suggest_int('L',1,3),drop=tr.suggest_float('drop',0.0,0.3),
           lr=tr.suggest_float('lr',2e-4,3e-3,log=True),wd=tr.suggest_float('wd',1e-6,1e-3,log=True),bs=tr.suggest_categorical('bs',[256,512,1024]),
           zin=tr.suggest_float('zin',0.0,0.3))
    m,b,ne=fit(p); tr.set_user_attr('epochs',ne); return b
if __name__=='__main__':
    NT=int(sys.argv[1]) if len(sys.argv)>1 else 16
    st=optuna.create_study(study_name=f'dec_{rep}_'+os.path.basename(OUT),storage='sqlite:///ai/step5_decoder.db',direction='minimize',load_if_exists=True,sampler=optuna.samplers.TPESampler(seed=0))
    st.optimize(objective,n_trials=max(0,NT-len(st.trials)))
    p=st.best_params; print('best decoder',p,round(st.best_value,3),flush=True)
    m,b,ne=fit(p,seed=0); torch.save(dict(state=m.state_dict(),params=p,rep=rep,genes=list(g)),f'{OUT}/decoder.pt'); print('final decoder val NLL',round(b,3),'epochs',ne)
    H=np.load(f'{OUT}/human_t05_latent.npz'); t05=pd.read_csv('ai/step5_human_t05_index.csv')
    anc=pd.read_csv(B+'figure/final_ggot/ggot_table_cs8_ancestor.csv'); anc=anc[anc.cls!='unmatched']; desc=anc.groupby('ancestor_idx').cs8_idx.apply(np.array).reindex(t05.cs7_idx.values)
    lib7=lib[:n7]; lib8=lib[n7:]; lib05=np.array([np.sqrt(lib7[i]*lib8[d].mean()) for i,d in zip(t05.cs7_idx.values,desc.values)])
    @torch.no_grad()
    def dec(z,ll,seed):
        torch.manual_seed(seed); out=[]
        for k in range(0,len(z),2048):
            mu,th=m(torch.tensor(z[k:k+2048],device=dev,dtype=torch.float32),torch.tensor(np.log(ll[k:k+2048]),device=dev,dtype=torch.float32))
            r=torch.distributions.Gamma(th.expand_as(mu),th.expand_as(mu)/mu.clamp_min(1e-8)).sample(); out.append(sp.csr_matrix(torch.poisson(r).cpu().numpy()))
        return sp.vstack(out).tocsr()
    D7=dec(Zc[:n7],lib7,1); D8=dec(Zc[n7:],lib8,2)
    D5=[dec(H['gen'][s],lib05,10+s) for s in range(H['gen'].shape[0])]; DL=dec(H['linear'],lib05,99)
    sp.save_npz(f'{OUT}/C7_decoded.npz',D7); sp.save_npz(f'{OUT}/C8_decoded.npz',D8); sp.save_npz(f'{OUT}/t05_linear_decoded.npz',DL)
    for s,Dm in enumerate(D5): sp.save_npz(f'{OUT}/t05_gen_seed{s}_decoded.npz',Dm)
    o=t05.copy(); o['library']=lib05
    T=ad.AnnData(D5[0].astype(np.float32),obs=o,var=pd.DataFrame(index=g)); T.obsm['X_rep']=H['gen'][0]
    T.uns['description']=f'AI-generated CS7-CS8 t=0.5 pseudo-cells: generator (Optuna-selected, trained on mouse E6.5-E8.5 intermediate stages) applied to GG-OT CS7 cells and their CS8 partners in the {rep} representation; decoded to CosMx WTX counts by an NB-MLP decoder trained on HuE#1+HuE#2.'
    T.write_h5ad(f'{OUT}/t05_AI_generated_counts.h5ad'); print('wrote',T.shape)
