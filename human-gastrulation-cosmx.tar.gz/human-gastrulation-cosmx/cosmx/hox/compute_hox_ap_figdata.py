# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: execution log, session 824ef1ce python kernel cells 910, 911, 912, 913, 916, 917, 919, 920 (920 =
#     producing cell of hox_ap_figdata.pkl, artifact 1cf40c87)
# sha256 of original: da9f969166cc6c281f5eff6c4611a18bf6f036e151e1663aac4d6da351ec1b2b
# Methods paragraphs: Figure 3L/3M legends (HOX group score; no separate Methods paragraph in v8), P343, P352
# Produces: hox/hox_ap_figdata.pkl, hox/HOX_AP_peaks_boundaries.csv, hox/HOX_AP_profiles.csv,
#     hox/HOX_gene_background_screen.csv
# Edits/notes: reconstructed from kernel log. Cells 914, 915, 918 (print-only diagnostics) omitted; cells 913
#     and 916 are kept although their outputs are superseded, because they draw from the same seeded generator
#     (default_rng(0)) and so fix the null draws of cell 917. Dataprep path -> HGC_DATA.
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

import numpy as np, pandas as pd
# --- kernel cell 910 ---
import scipy.io, numpy as np, pandas as pd, re
E=(str(DATA) + "/dataprep/")
genes=pd.read_csv(E+"export/genes.csv").gene.astype(str).values
hox=[g for g in genes if re.fullmatch(r"HOX[ABCD]\d+",g)]
print(len(hox), hox)
D={}
for st in ["CS7","CS8"]:
    cells=pd.read_csv(E+f"export/{st}_cells.csv"); fr=pd.read_csv(E+f"frames/{st}_frames.csv")
    X=scipy.io.mmread(E+f"export/{st}_counts.mtx").tocsr()  # genes x cells
    gi=[np.where(genes==g)[0][0] for g in hox]
    H=pd.DataFrame(X[gi].T.toarray(),columns=hox)
    H["nCount"]=cells.nCount.values
    assert (fr.cell.values==cells.cell.values).all()
    D[st]=pd.concat([fr.reset_index(drop=True),H],axis=1)
    print(st, D[st].shape, D[st].label_short.value_counts().to_dict())
print([c for c in D["CS8"].columns[:30]])

# --- kernel cell 911 ---
rows=[]
for st,d in D.items():
    bkgmask=d.label_short.isin(["VE1","VE2"])
    for g in hox:
        det=(d[g]>0).groupby(d.label_short).mean()
        bk=det[["VE1","VE2"]].max()
        emb=det.drop([x for x in ["VE1","VE2","AVE"] if x in det.index])
        top=emb.idxmax()
        rows.append(dict(stage=st,gene=g,bkg=bk,top_type=top,top_det=emb.max(),pp=emb.max()-bk,fold=emb.max()/max(bk,1e-3)))
R=pd.DataFrame(rows)
R["above"]=(R.pp>=0.02)&(R.fold>=2)
P=R.pivot(index="gene",columns="stage",values=["top_det","bkg","top_type","above"])
print(P[(P[("above","CS8")])|(P[("above","CS7")])].to_string())
print(R[(R.stage=="CS8")].sort_values("pp",ascending=False).head(20)[["gene","top_type","top_det","bkg","pp","fold"]].round(3).to_string())

# --- kernel cell 912 ---
above8=set(R[(R.stage=="CS8")&R.above].gene)
def para(g): return int(re.findall(r"\d+",g)[0])
GROUPS={"HOX1–2":[g for g in above8 if para(g)<=2],"HOX3–5":[g for g in above8 if 3<=para(g)<=5],
        "HOX6–8":[g for g in above8 if 6<=para(g)<=8],"HOX9–13":[g for g in above8 if para(g)>=9]}
for k,v in GROUPS.items(): GROUPS[k]=sorted(v,key=lambda g:(para(g),g)); print(k,GROUPS[k])
VE=["VE1","VE2","AVE"]
for st,d in D.items():
    for k,gl in GROUPS.items():
        sc=np.log1p(d[gl].sum(1)/d.nCount*1e4)
        d[k+"_raw"]=sc; d[k]=sc-sc[d.label_short.isin(["VE1","VE2"])].mean()
    for g in above8:
        d[g+"_s"]=np.log1p(d[g]/d.nCount*1e4)-np.log1p(d[g]/d.nCount*1e4)[d.label_short.isin(["VE1","VE2"])].mean()
def profile(d,col,grid=np.linspace(0,1,101),bw=0.04,w=None):
    x=d.AP_arc_frac.values; y=d[col].values
    K=np.exp(-0.5*((grid[:,None]-x[None,:])/bw)**2)
    return (K@y)/K.sum(1), K.sum(1)
grid=np.linspace(0,1,101)
emb={st:d[~d.label_short.isin(VE)&d.AP_arc_frac.between(-0.05,1.05)].copy() for st,d in D.items()}
for st,e in emb.items():
    print(st,len(e), "node AP", e[e.label_short=="Node"].AP_arc_frac.median().round(3))
    for k in GROUPS:
        p,_=profile(e,k); print("  ",k, "peak AP", grid[np.argmax(p)], "max", p.max().round(4))

# --- kernel cell 913 ---
rng=np.random.default_rng(0)
XS={}
for st in ["CS7","CS8"]:
    XS[st]=scipy.io.mmread(E+f"export/{st}_counts.mtx").tocsr().T.tocsr()  # cells x genes
hoxset=set(hox)
NULL={}
for st,d in D.items():
    X=XS[st]; ve=d.label_short.isin(["VE1","VE2"]).values
    detve=np.asarray((X[ve]>0).mean(0)).ravel()
    emask=(~d.label_short.isin(VE)&d.AP_arc_frac.between(-0.05,1.05)).values
    xe=d.AP_arc_frac.values[emask]; K=np.exp(-0.5*((grid[:,None]-xe[None,:])/0.04)**2); Ks=K.sum(1)
    nc=d.nCount.values
    gidx={g:i for i,g in enumerate(genes)}
    for k,gl in GROUPS.items():
        profs=[]
        for it in range(200):
            pick=[]
            for g in gl:
                t=detve[gidx[g]]
                cand=np.where((np.abs(detve-t)<=max(0.2*t,0.002))&~np.isin(genes,list(hoxset)))[0]
                pick.append(rng.choice(cand))
            s=np.log1p(np.asarray(X[:,pick].sum(1)).ravel()/nc*1e4); s=s-s[ve].mean()
            profs.append((K@s[emask])/Ks)
        NULL[(st,k)]=np.array(profs)
for st,e in emb.items():
    for k in GROUPS:
        p,_=profile(e,k); nl=NULL[(st,k)]
        hi=np.percentile(nl,97.5,axis=0); med=np.median(nl,0)
        exc=p-med; sig=p>hi
        print(st,k,"max excess",exc.max().round(3),"at",grid[np.argmax(exc)],"frac grid above null95",sig.mean().round(2))

# --- kernel cell 916 ---
for st,e in emb.items():
    nd=e[e.label_short=="Node"]
    e["x_um"]=e.AP_arc_um-nd.AP_arc_um.median()
    ax_=e[e.label_short.isin(["Node","PS","APS","Notochord","PrP"])]
    e["y_um"]=e.LR_um-ax_.LR_um.median()
    print(st, e.x_um.quantile([0.01,0.99]).round(0).tolist(), e.y_um.quantile([0.01,0.99]).round(0).tolist())
xg=np.arange(-1000,701,10.0)
def prof_um(x,y,bw=40.0):
    K=np.exp(-0.5*((xg[:,None]-x[None,:])/bw)**2); w=K.sum(1); return (K@y)/np.maximum(w,1e-9), w
# null in um
NULLU={}
for st,d in D.items():
    X=XS[st]; ve=d.label_short.isin(["VE1","VE2"]).values
    detve=np.asarray((X[ve]>0).mean(0)).ravel(); nc=d.nCount.values
    e=emb[st]; idx=e.index.values; xe=e.x_um.values
    K=np.exp(-0.5*((xg[:,None]-xe[None,:])/40.0)**2); Ks=np.maximum(K.sum(1),1e-9)
    gidx={g:i for i,g in enumerate(genes)}
    for k,gl in GROUPS.items():
        prs=[]
        for it in range(200):
            pick=[rng.choice(np.where((np.abs(detve-detve[gidx[g]])<=max(0.2*detve[gidx[g]],0.002))&~np.isin(genes,hox))[0]) for g in gl]
            s=np.log1p(np.asarray(X[:,pick].sum(1)).ravel()/nc*1e4); s=s-s[ve].mean()
            prs.append((K@s[idx])/Ks)
        NULLU[(st,k)]=np.array(prs)
print("done")

# --- kernel cell 917 ---
xg=np.arange(-800,801,10.0); BW=40.0; MINW=30.0
gidx={g:i for i,g in enumerate(genes)}
RES={}
for st,d in D.items():
    X=XS[st]; ve=d.label_short.isin(["VE1","VE2"]).values
    detve=np.asarray((X[ve]>0).mean(0)).ravel(); nc=d.nCount.values
    e=emb[st]; idx=e.index.values; xe=e.x_um.values
    K=np.exp(-0.5*((xg[:,None]-xe[None,:])/BW)**2); Ks=K.sum(1); valid=Ks>=MINW
    pools={g:np.where((np.abs(detve-detve[gidx[g]])<=max(0.2*detve[gidx[g]],0.002))&~np.isin(genes,hox))[0] for g in above8}
    def sc_of(cols):
        s=np.log1p(np.asarray(X[:,cols].sum(1)).ravel()/nc*1e4); return s-s[ve].mean()
    units=dict(GROUPS); units.update({g:[g] for g in above8})
    for k,gl in units.items():
        s=sc_of([gidx[g] for g in gl]); p=(K@s[idx])/np.maximum(Ks,1e-9)
        nl=np.array([(K@sc_of([rng.choice(pools[g]) for g in gl])[idx])/np.maximum(Ks,1e-9) for _ in range(200 if k in GROUPS else 100)])
        RES[(st,k)]=dict(p=p,med=np.median(nl,0),lo=np.percentile(nl,2.5,0),hi=np.percentile(nl,97.5,0),valid=valid,w=Ks)
def peak_boundary(r):
    ex=r["p"]-r["med"]; ex[~r["valid"]]=np.nan
    i=np.nanargmax(ex); pk=ex[i]
    sig=(r["p"]>r["hi"])&r["valid"]
    # anterior boundary: walk anteriorly from peak while ex >= 0.5*pk
    j=i
    while j-1>=0 and np.isfinite(ex[j-1]) and ex[j-1]>=0.5*pk: j-=1
    return dict(peak_um=xg[i], peak_excess=pk, ant_boundary_um=xg[j], peak_sig=bool(sig[i]), frac_sig=sig[r["valid"]].mean())
rows=[]
for (st,k),r in RES.items():
    rows.append(dict(stage=st,unit=k,kind="group" if k in GROUPS else "gene",**peak_boundary(r)))
PK=pd.DataFrame(rows)
print(PK[PK.kind=="group"].round(3).to_string())
g8=PK[(PK.kind=="gene")&(PK.stage=="CS8")].copy(); g8["paralog"]=g8.unit.map(para)
print(g8.sort_values(["paralog","unit"]).round(3).to_string())
from scipy.stats import spearmanr
s8=g8[g8.peak_sig]
print("CS8 sig genes",len(s8),"rho paralog vs ant boundary",spearmanr(s8.paralog,s8.ant_boundary_um), "vs peak",spearmanr(s8.paralog,s8.peak_um))

# --- kernel cell 919 ---
from scipy.ndimage import gaussian_filter
XE=np.arange(-760,801,10.0); YE=np.arange(-340,281,10.0)
MAPS={}
for st,e in emb.items():
    H0,_,_=np.histogram2d(e.x_um,e.y_um,bins=[XE,YE])
    Dn=gaussian_filter(H0,4.0)
    mask=Dn>=0.08*Dn.max()
    MAPS[(st,"density")]=Dn; MAPS[(st,"mask")]=mask
    for k in GROUPS:
        Hs,_,_=np.histogram2d(e.x_um,e.y_um,bins=[XE,YE],weights=e[k])
        M=gaussian_filter(Hs,4.0)/np.maximum(Dn,1e-9); M[~mask]=np.nan
        MAPS[(st,k)]=M
    nd=e[e.label_short=="Node"]; MAPS[(st,"node")]=(nd.x_um.median(), nd.y_um.median())
for k in GROUPS: print(k,[np.nanpercentile(MAPS[(s,k)],[50,99]).round(2) for s in ["CS7","CS8"]])

# --- kernel cell 920 ---
import pickle, os
xc=(XE[:-1]+XE[1:])/2; yc=(YE[:-1]+YE[1:])/2
for st in ["CS7","CS8"]:
    for k in GROUPS:
        med=np.interp(xc,xg,RES[(st,k)]["med"])
        MAPS[(st,k+"_ex")]=MAPS[(st,k)]-med[:,None]
os.makedirs("hox",exist_ok=True)
prof={f"{st}|{k}":{kk:v for kk,v in RES[(st,k)].items()} for (st,k) in RES}
pickle.dump(dict(MAPS=MAPS,xc=xc,yc=yc,xg=xg,RES=prof,PK=PK,GROUPS=GROUPS,R=R),open("hox/hox_ap_figdata.pkl","wb"))
# tables
PK.assign(paralog=PK.unit.map(lambda u: para(u) if u.startswith("HOX") and "–" not in u else np.nan)).to_csv("hox/HOX_AP_peaks_boundaries.csv",index=False)
rows=[]
for (st,k),r in RES.items():
    for i,x in enumerate(xg):
        if r["valid"][i]: rows.append(dict(stage=st,unit=k,x_um=x,score=r["p"][i],null_median=r["med"][i],null_hi=r["hi"][i],excess=r["p"][i]-r["med"][i],cell_weight=r["w"][i]))
pd.DataFrame(rows).to_csv("hox/HOX_AP_profiles.csv",index=False)
R.to_csv("hox/HOX_gene_background_screen.csv",index=False); print(len(rows))
