# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: execution log, session 824ef1ce R kernel cell 1021 (producing cell of PS6_genes_cp10k_percell.csv,
#     artifact f3932cfa); load line as in cell 995 of the same kernel
# sha256 of original: f6055aa72890ce8d17ba9ed86a77a481dd23105ae8be7989137766a7e4586c0e
# Methods paragraphs: P343, Figure 2C legend
# Produces: hm/PS6_genes_cp10k_percell.csv (per-cell CP10K of TBXT, TBX6, MESP1, MIXL1, EOMES, CER1;
#     curated_kept)
# Edits/notes: object path -> HGC_DATA; hm folder created.
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

suppressPackageStartupMessages(library(Seurat))
obj <- readRDS(file.path(DATA, "obj6_obj7_merged_curated_final.rds"))
dir.create("hm", showWarnings = FALSE)
G6 <- c("TBXT","TBX6","MESP1","MIXL1","EOMES","CER1")
out <- list()
for (s in c("CS7","CS8")) {
  k <- which(obj$curated_kept %in% TRUE & obj$stage == s)
  m <- as.matrix(LayerData(obj, assay="RNA", layer="counts")[G6, k])
  cp <- t(t(m) / obj$nCount_RNA[k] * 1e4)
  out[[s]] <- data.frame(stage=s, type=as.character(obj$`39Type`[k]), t(cp), check.names=FALSE)
}
write.csv(do.call(rbind, out), "hm/PS6_genes_cp10k_percell.csv", row.names=FALSE)