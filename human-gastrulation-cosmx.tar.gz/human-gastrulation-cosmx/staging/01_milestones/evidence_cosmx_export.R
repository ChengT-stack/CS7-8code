# staging/01_milestones/evidence_cosmx_export.R
# Source: reconstructed from transcript ce4e1bd4 (messages 37, 39)
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
HGC_DATA <- Sys.getenv('HGC_DATA', 'data')
HGC_OUT <- Sys.getenv('HGC_OUT', 'results')

# R part of the CosMx evidence review: export marker counts of the curated CosMx object.
# Reconstructed verbatim from session transcript ce4e1bd4.


# ---- cell [frame ce4e1bd4, message 37] Loading curated v3 Seurat object
suppressMessages(library(Seurat))
t0<-Sys.time(); o<-readRDS(paste0(HGC_DATA, '/obj6_obj7_merged_curated_v3.rds')); print(Sys.time()-t0)
print(o); print(Assays(o)); print(colnames(o@meta.data)); print(Reductions(o))
print(head(o@meta.data,3))


# ---- cell [frame ce4e1bd4, message 39] Exporting marker counts for curated cells
print(table(o$stage,o$curated_kept))
G<-c("MESP1","TBX6","TBXT","GSC","FOXA2","FOXJ1","CHRD","SOX17","CER1","LHX1","NOTO","SHH","HOXA1","HOXB1","NKX1-2","CDX2","HESX1","SIX3","MEOX1","TCF15","EOMES","HOXB8","NKX2-5","TNNT2","MYL7","DPPA3","NANOS3","TFAP2C","PRDM1","SOX2","ETV2","KDR","HAND1","TBX4","HOXA10","HBZ","HBE1","GATA1","CDH5","PECAM1","RUNX1","TAL1","POU5F1","NANOG")
m<-GetAssayData(o,assay='RNA',layer='counts')[G,]
df<-data.frame(cell=colnames(o),stage=o$stage,label=o$Type39_curated,kept=o$curated_kept,disc_main_body=o$disc_main_body,x_um=o$x_um,y_um=o$y_um,z_um=o$z_um,nCount=o$nCount_RNA,as.matrix(t(m)),check.names=FALSE)
dir.create(paste0(HGC_DATA, '/milestone_evidence/out_cosmx'),showWarnings=FALSE)
data.table::fwrite(df,paste0(HGC_DATA, '/milestone_evidence/out_cosmx/_full_object_markers.csv.gz'))
print(dim(df)); print(sum(df$kept)); print(table(df$stage[df$kept]))
