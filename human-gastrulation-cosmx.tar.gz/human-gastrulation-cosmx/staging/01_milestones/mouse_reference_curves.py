# staging/01_milestones/mouse_reference_curves.py
# Source: reconstructed from transcript 5113e657 (messages 3156-3191)
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Milestone metrics per stage in the Pijuan-Sala atlas and onsets (25% of maximum / 75% of peak); writes mouse_reference_curves.csv.
# Reconstructed verbatim from session transcript 5113e657 (code was run cell-by-cell in a
# persistent kernel and never saved as a file). Cells are concatenated in execution order;
# inspection-only and figure-polishing cells are omitted, and cells that stopped with an error are
# truncated at the failing line (marked). See PROVENANCE.md.
import numpy as np, pandas as pd, sys
import matplotlib.pyplot as plt
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'common')); from figure_style import apply_figure_style   # set-up added (kernel state of the original session)


# ---- cell [frame 5113e657, message 3156] Reading milestone definitions sheet
X=pd.ExcelFile((str(HGC_DATA) + '/20261030-Fig_milestone_axis_human_monkey_data.xlsx')); print(X.sheet_names)
D=X.parse(X.sheet_names[0]); print(D.shape); print(D.columns.tolist()); pd.set_option('display.width',250,'display.max_colwidth',120)
print(D.to_string()[:6000])


# ---- cell [frame 5113e657, message 3158] Reading milestone calls and rules
C=X.parse('milestone_calls'); print(C.shape, C.columns.tolist()); print(C.head(25).to_string()[:5000])
R=X.parse('rules'); print(R.shape, R.columns.tolist()); print(R.to_string()[:3000])


# ---- cell [frame 5113e657, message 3189] Recomputing mouse milestone curves and onsets
import anndata as ad
a=ad.read_h5ad((str(HGC_DATA) + '/MGA_full_atlas_116k.h5ad'),backed='r'); o=a.obs; vn=list(a.var_names)
STG=['E6.5','E6.75','E7.0','E7.25','E7.5','E7.75','E8.0','E8.25','E8.5']; SN=[6.5,6.75,7.0,7.25,7.5,7.75,8.0,8.25,8.5]
EXE=['ExE ectoderm','ExE endoderm','ExE mesoderm','Parietal endoderm','Allantois','Blood progenitors 1','Blood progenitors 2','Erythroid1','Erythroid2','Erythroid3','Haematoendothelial progenitors','Endothelium','PGC','Mesenchyme']
G=['Foxj1','Chrd','Gsc','Cer1','Hoxa1','Hoxb1','Eomes','Hoxb8']; gi=[vn.index(g) for g in G]
sel=np.where(o.stage.isin(STG))[0]; Xg=(a.X[sel][:,gi].toarray()>0); ct=o.celltype.values[sel].astype(str); st=o.stage.values[sel].astype(str)
emb=~np.isin(ct,EXE)
def g_(n): return Xg[:,G.index(n)]
curves={}
def per(stage_mask_fn, num_fn, den_fn):
    return [100*num_fn(st==s).sum()/max(den_fn(st==s).sum(),1) for s in STG]
ctpct=lambda c,den: [100*((st==s)&(ct==c)).sum()/max(((st==s)&den).sum(),1) for s in STG]
allm=np.ones(len(st),bool)
curves['m01']=('Nascent mesoderm, % of embryo-proper cells',ctpct('Nascent mesoderm',emb),'onset')
curves['m02']=('APS, % of embryo-proper cells',ctpct('Anterior Primitive Streak',emb),'onset')
nl=np.isin(ct,['Primitive Streak','Notochord','Def. endoderm'])&g_('Foxj1')&g_('Chrd')
curves['m03']=('Foxj1⁺Chrd⁺ PS/notochord/DE cells, % of embryo-proper',[100*((st==s)&nl).sum()/((st==s)&emb).sum() for s in STG],'onset')
curves['m04']=('Def. endoderm, % of all cells',ctpct('Def. endoderm',allm),'onset')
ade=(ct=='Def. endoderm')&g_('Gsc')&g_('Cer1')
curves['m05']=('Gsc⁺Cer1⁺ DE, % of embryo-proper',[100*((st==s)&ade).sum()/((st==s)&emb).sum() for s in STG],'onset')
def det(c,gene,minn=20):
    out=[]
    for s in STG:
        m=(st==s)&np.isin(ct,c if isinstance(c,list) else [c]); out.append(100*g_(gene)[m].mean() if m.sum()>=minn else np.nan)
    return out
curves['m06']=('Gsc detection in DE, %',det('Def. endoderm','Gsc'),'loss')
curves['m07']=('Notochord, % of all cells',ctpct('Notochord',allm),'onset')
h=[np.nanmax([x,y]) for x,y in zip(det('Primitive Streak','Hoxa1'),det('Primitive Streak','Hoxb1'))]
curves['m08']=('Hoxa1 / Hoxb1 detection in PS, % (max)',h,'onset')
curves['m09']=('Caudal epiblast, % of all cells',ctpct('Caudal epiblast',allm),'onset')
curves['m10']=('Rostral neurectoderm, % of all cells',ctpct('Rostral neurectoderm',allm),'onset')
curves['m11']=('Paraxial mesoderm, % of all cells',ctpct('Paraxial mesoderm',allm),'onset')
curves['m12']=('Eomes detection in PS, %',det('Primitive Streak','Eomes'),'loss')
curves['m13']=('Hoxb8 detection in caudal epiblast, %',det('Caudal epiblast','Hoxb8'),'onset')
curves['m14']=('Cardiomyocytes, % of all cells',ctpct('Cardiomyocytes',allm),'onset')
curves['m15']=('PGC, % of all cells',ctpct('PGC',allm),'onset')
curves['m16']=('Haemato-endothelial progenitors, % of all cells',ctpct('Haematoendothelial progenitors',allm),'onset')
curves['m17']=('ExE mesoderm, % of all cells',ctpct('ExE mesoderm',allm),'onset')
curves['m18']=('Allantois, % of all cells',ctpct('Allantois',allm),'onset')
curves['m19']=('Erythroid1, % of all cells',ctpct('Erythroid1',allm),'onset')
def onset(v,kind):
    v=np.array(v,float)
    if kind=='onset':
        thr=0.25*np.nanmax(v); i=int(np.argmax(np.nan_to_num(v,nan=-1)>=thr)); return (SN[i]+SN[i-1])/2 if i>0 else SN[0], thr
    pk=int(np.nanargmax(v)); thr=0.75*v[pk]
    for i in range(pk+1,len(v)):
        if not np.isnan(v[i]) and v[i]<thr: return (SN[i]+SN[i-1])/2, thr
    return np.nan,thr
MS=C.milestone.tolist(); MID=[f'm{i+1:02d}' for i in range(19)]
chk=[]
for mid,ms,on in zip(MID,MS,C.mouse_onset):
    lab_,v,k=curves[mid]; oc,thr=onset(v,k); chk.append((mid,ms[:35],on,oc,round(thr,2)))
print(pd.DataFrame(chk,columns=['id','milestone','fig_onset','recomputed','threshold']).to_string())


# ---- cell [frame 5113e657, message 3191] Drawing mouse reference panels
import os; os.makedirs('ai/milestone_atlas/mouse',exist_ok=True); plt.close('all'); apply_figure_style(sizes=(7,6.5,5.5))
LBL=dict(zip(MID,X.parse('milestone_definitions').label.tolist()[:19]))
rows=[]
for mid,on in zip(MID,C.mouse_onset):
    lab_,v,k=curves[mid]; oc,thr=onset(v,k)
    fig,ax=plt.subplots(figsize=(2.5,1.9))
    ax.plot(SN,v,'-o',color='#333333',ms=3,lw=1)
    ax.axhline(thr,color='#c0392b',ls='--',lw=0.7); ax.axvline(on,color='#2b6cb0',lw=0.9)
    ax.text(on,ax.get_ylim()[1]*0.97,f' onset E{on:g}' if k=='onset' else f' loss E{on:g}',color='#2b6cb0',fontsize=5.5,va='top')
    ax.text(SN[0],thr,('25% of max' if k=='onset' else '75% of peak'),color='#c0392b',fontsize=5,va='bottom')
    ax.set_xticks(SN[::2]); ax.set_xticklabels([f'E{s:g}' for s in SN[::2]]); ax.set_ylabel(lab_,fontsize=5.5)
    ax.set_title(f'Mouse (Pijuan-Sala 2019)\n{LBL[mid]}',fontsize=6,loc='left')
    fig.tight_layout(); fig.savefig(f'ai/milestone_atlas/mouse/mouse_{mid}.png',dpi=300); plt.close(fig)
    for s,x in zip(STG,v): rows.append(dict(milestone_id=mid,milestone=LBL[mid],metric=lab_,kind=k,stage=s,value=x,threshold=thr,onset_figure=on,onset_recomputed=oc))
MC=pd.DataFrame(rows); MC.to_csv('ai/milestone_atlas/mouse/mouse_reference_curves.csv',index=False)
