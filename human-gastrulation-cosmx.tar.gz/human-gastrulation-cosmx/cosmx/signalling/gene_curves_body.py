# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/cs8_epi_node_ps_curves/gene_curves_body.py (2026-09-28; artifact 18aa245f)
# sha256 of original: 8ae4681a9e798398473486dbbc71f3d3f569b53381b7d3db2a63d1057d9bb535
# Methods paragraphs: P358, P361
# Produces: figure body exec-ed by cs8_genes.py (not run on its own)
# Edits/notes: unchanged

# ---------------- per-gene curves ----------------
KCOL={"ligand":"#1F6FB2","receptor":"#7B4FA3","target":"#C2401A","inhibitor":"#2E8B57"}
GCOL=["#1F6FB2","#C2401A","#2E8B57","#7B4FA3","#B8860B","#17A2B8","#D6559A","#7F7F7F"]
LABF={"ligand":"ligands","receptor":"receptors","target":"targets","inhibitor":"inhibitors / antagonists"}
apb=ap7[inb]; ldb=ld5[inb]
def gene_curve(g):
    v=np.asarray(M7[gi7[g],:].todense()).ravel()[inb]/dep5[inb]*1e4
    be=np.polyfit(ldb,v,1); resid=v-(be[0]*ldb+be[1])+v.mean()
    gc,gm,gs_,h=kernel_curve(apb,resid); return gc,gm,gs_,h,float((v>0).mean())
CUR={}; rows=[]
for k in COMPLETE:
    for g in COMPLETE[k]:
        if g in gi7 and g not in CUR: CUR[g]=gene_curve(g)
also={g:[k for k in COMPLETE if g in COMPLETE[k]] for g in CUR}
plt.close("all"); apply_figure_style()
fig=plt.figure(figsize=(16.4,15.2))
L0,R0=0.045,0.985; T0=0.880; B0=0.045
gw=(R0-L0-0.032*3)/4; gh=(T0-B0-0.016*4)/5
AX={}
for i,pw in enumerate(PWS):
    for j,kd in enumerate(KINDS4):
        ax=fig.add_axes([L0+j*(gw+0.032), T0-gh-i*(gh+0.016), gw, gh]); AX[(pw,kd)]=ax
        k=f"{pw}_{kd}"; gs=[g for g in COMPLETE[k] if g in CUR]
        peak={g:float(CUR[g][1].max()) for g in gs}
        top=sorted(gs,key=lambda g:-peak[g])[:5]
        for g in gs:
            if g not in top: ax.plot(CUR[g][0],CUR[g][1],color="#D0D0D0",lw=.8,zorder=2)
        # set mean per gene (dashed, pathway-kind colour)
        gc=CUR[gs[0]][0]; sm_=np.mean([CUR[g][1] for g in gs],axis=0)
        ax.plot(gc,sm_,color=KCOL[kd],lw=1.6,ls=(0,(4,2)),zorder=4)
        lab_pos=[]
        for n_,g in enumerate(top):
            gc,gm,gs_,h,det=CUR[g]; c=GCOL[n_]
            ax.fill_between(gc,gm-gs_,gm+gs_,color=c,alpha=.13,lw=0,zorder=3); ax.plot(gc,gm,color=c,lw=1.5,zorder=5)
            ip=int(np.argmax(gm)); lab_pos.append([gc[ip],gm[ip],g,c])
        # stagger labels that share an x-neighbourhood
        ymin,ymax=ax.get_ylim() if False else (min(np.min(CUR[g][1]-CUR[g][2]) for g in gs), max(np.max(CUR[g][1]+CUR[g][2]) for g in gs))
        sep=0.075*(ymax-ymin)
        lab_pos.sort(key=lambda r:r[0])
        for _ in range(60):
            moved=False
            for a in range(len(lab_pos)):
                for b in range(a+1,len(lab_pos)):
                    if abs(lab_pos[a][0]-lab_pos[b][0])<0.18*(hi5-lo5) and abs(lab_pos[a][1]-lab_pos[b][1])<sep:
                        sh=(sep-abs(lab_pos[a][1]-lab_pos[b][1]))/2+1e-6
                        if lab_pos[a][1]<=lab_pos[b][1]: lab_pos[a][1]-=sh; lab_pos[b][1]+=sh
                        else: lab_pos[a][1]+=sh; lab_pos[b][1]-=sh
                        moved=True
            if not moved: break
        span=hi5-lo5
        for x_,y_,g,c in lab_pos:
            ha="left" if x_<lo5+0.06*span else ("right" if x_>hi5-0.06*span else "center")
            ax.annotate(g,(x_,y_),xytext=(0,4),textcoords="offset points",ha=ha,va="bottom",fontsize=5.6,color=c,style="italic",zorder=9,
                        path_effects=[pe.withStroke(linewidth=1.6,foreground="white")])
        for g,rec in zip(gs,[CUR[g] for g in gs]):
            rows.append(pd.DataFrame(dict(pathway=pw,kind=kd,gene=g,AP_um=np.round(rec[0],2),mean_CP10K=np.round(rec[1],4),sem=np.round(rec[2],4),
                                          detection_pct=round(100*rec[4],2),bandwidth_um=round(rec[3],1),labelled=g in top,
                                          also_in=";".join(x for x in also[g] if x!=k) or "")))
        ax.text(.02,.97,f"{pw} {LABF[kd]} \u00b7 {len(gs)} genes",transform=ax.transAxes,fontsize=6.3,va="top",color=KCOL[kd])
        ax.set_xlim(lo5,hi5); ax.margins(y=0.30); ax.spines[["top","right"]].set_visible(False); ax.tick_params(labelsize=5.6)
        ax.axhline(0,color="#E5E5E5",lw=.6,zorder=0)
for pw in PWS[:-1]:
    for kd in KINDS4: AX[(pw,kd)].tick_params(labelbottom=False)
for kd in KINDS4: AX[(PWS[-1],kd)].set_xlabel("anterior \u2192 posterior (\u00b5m)",fontsize=7.2)
for pw in PWS: AX[(pw,"ligand")].set_ylabel(f"{pw}\nexpression (CP10K)",fontsize=6.6,color=KCOL["ligand"] if False else "#333333")
for j,kd in enumerate(KINDS4): AX[(PWS[0],kd)].set_title(LABF[kd].capitalize() if kd!="target" else "Targets \u2014 the activity readout",loc="left",fontsize=8.6,pad=14)
for i,pw in enumerate(PWS): panel_letter(AX[(pw,"ligand")],"abcde"[i])
hb=CUR["TBXT"][3] if "TBXT" in CUR else CUR[next(iter(CUR))][3]
NP=" \u00b7 ".join(f"{k} {int((inb&(lab5==FULL7[k])).sum()):,}" for k in WANT)
fig.text(.006,.985,"Anterior\u2192posterior expression curves of every ligand, receptor, target and inhibitor of five signalling pathways \u2014 "+STAGE+", "+POPLABEL,fontsize=10.6)
fig.text(.006,.963,
 f"obj6_obj7_merged_curated_final.rds, 39Type, {STAGE} ({OBJ}), curation-kept, restricted to {len(WANT)} populations ({NP}) = {int(inb.sum()):,} cells inside the AP band [{lo5:.0f}, {hi5:.0f}] \u00b5m (their 1\u201399th percentile). Every cell in the band\n"
 f"contributes to every curve. CP10K per cell, depth-adjusted by regressing on log total counts and taking residuals about the mean, then Gaussian-kernel smoothed along AP (h = {hb:.0f} \u00b5m = 0.06 \u00d7 AP span, 80 grid points); band = SEM from the effective\n"
 "sample size, drawn for the labelled genes only. In each panel the 5 highest-peaking genes are coloured and labelled at their peak; every other gene of the set is a thin grey line (values in the CSV); the dashed line in the pathway colour is the set\n"
 "mean per gene. Per-panel y-scales are independent \u2014 compare shapes within a panel, not heights across panels. Gene sets are the COMPLETE human families used in the trend figures; the columns are not disjoint (canonical inhibitors are also direct\n"
 f"targets), see `also_in` in the CSV. Curves are pooled across the {len(WANT)} populations, so a gene confined to one population traces that population's AP footprint (panel a of the trend figure).",
 fontsize=6.1,color=META_GREY,linespacing=1.5,va="top")
for e in ["png","pdf","svg"]: fig.savefig(f"{PREFIX}_gene_curves.{e}",**({"dpi":185} if e=="png" else {}),bbox_inches="tight")
fig.canvas.draw(); r_=fig.canvas.get_renderer()
tx=[(t,t.get_window_extent(r_)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
tk={t for a_ in fig.axes for t in a_.get_xticklabels()+a_.get_yticklabels()}
ov=[(a.get_text()[:14],b.get_text()[:14]) for i_,(a,ba) in enumerate(tx) for b,bb in tx[i_+1:] if ba.overlaps(bb) and not (a in tk or b in tk)]
print("text overlaps (non-tick):",len(ov),ov[:8])
pd.concat(rows,ignore_index=True).to_csv(f"{PREFIX}_gene_curves.csv",index=False)
print("genes drawn:",len(CUR),"| csv rows:",sum(len(r) for r in rows))
