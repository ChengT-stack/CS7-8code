# cosmx/hox

HOX paralogue-group scores: Figure 3L, 3M.

Inputs, run order, Methods-to-panel table and gaps: see [../README.md](../README.md). Origin and sha256 of every file: [../PROVENANCE.md](../PROVENANCE.md).
