# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: artifact c32f0e24 export_cs8_full.R (session 0b0712b4, 2026-09-23)
# sha256 of original: 2d52277c2907ddb6744660ef652245b7f8f4432165fd55ab21ddbf2897d21b54
# Methods paragraphs: P343 (curated HuE#2 cells), input of P358/P361 and SF5C-E
# Produces: nb_bundle/counts.mtx, nb_bundle/genes.csv, nb_bundle/obs.csv = the contents of cs8_kept_counts.h5ad
#     (86,608 curation-kept HuE#2 cells x 18,934 genes; obs: label, disc, x, y, z, nCount)
# Edits/notes: object path -> HGC_DATA. The small step that packed these three files into cs8_kept_counts.h5ad
#     (AnnData with X = counts.T, obs = obs.csv indexed by cell, var_names = genes) was not found as code; the
#     h5ad (sha256 recorded in PROVENANCE) is an expected input under HGC_DATA.
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

dir.create('nb_bundle', showWarnings = FALSE)   # added: output folder inside HGC_OUT
suppressPackageStartupMessages({library(Seurat); library(Matrix)})
o <- readRDS(file.path(DATA, "obj6_obj7_merged_curated_final.rds"))
md <- o@meta.data
i7 <- which(md$source_object=="obj7" & as.logical(md$curated_kept))
cn <- LayerData(o[["RNA"]], "counts")[, i7]
cat("CS8 kept cells:", length(i7), "| genes:", nrow(cn), "| nnz:", length(cn@x), "\n")
writeMM(cn, "nb_bundle/counts.mtx")
write.csv(data.frame(gene=rownames(cn)), "nb_bundle/genes.csv", row.names=FALSE)
write.csv(data.frame(cell=colnames(cn), label=as.character(md$`39Type`[i7]), disc=as.logical(md$disc_main_body[i7]),
                     x=md$x_um[i7], y=md$y_um[i7], z=md$z_um[i7], nCount=md$nCount[i7]), "nb_bundle/obs.csv", row.names=FALSE)
cat("DONE\n")
