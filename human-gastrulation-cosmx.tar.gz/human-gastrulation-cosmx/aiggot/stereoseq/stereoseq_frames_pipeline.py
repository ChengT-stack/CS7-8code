"""Stereo-seq CS7->CS8 replication of the star matching (track 'replication_stereoseq').
Consolidated from the analysis kernel cells; run top to bottom in env `stvcr` after the R export
(export/{CS7,CS8}_counts.mtx, _genes.csv, _spots.csv from the published {CS7,CS8}-RNA-MapQ.rds objects; see 00_export_stereoseq.R).
Stages: 1 label mapping + per-section anatomical frames; 2 Harmony co-embedding + spatial smoothing +
kNN purity; 3 transition table; 4 star matching (reference + 3 sensitivity settings); 5 global
transform + Bures territory modes; 6 replication table vs our CosMx modes. The figure is in fig_replication.py.
"""
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import os
os.environ["KMP_AFFINITY"] = "disabled"; os.environ["OMP_NUM_THREADS"] = "8"; os.environ["KMP_INIT_AT_FORK"] = "FALSE"
import numpy as np, pandas as pd, scipy.io as sio, json, copy, importlib.util
import scanpy as sc, anndata as ad, harmonypy as hm
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation as Rot
from scipy.stats import binomtest, spearmanr

ART = os.path.join(DATA, "artifacts") + "/"
MAPPING = ART + "stereoseq_label_mapping.csv"
STARMATCH = ART + "starmatch.py"
REF_PARAMS = ART + "matching_reference_params.json"
TT_USED = ART + "transition_table_used.json"
OUR_EDGES = ART + "edge_displacements.csv"
OUR_GT = ART + "global_transform.json"
SPOT = 50.0   # bin50 grid step in coordinate units
for d in ["frames", "embedding", "matching", "modes"]: os.makedirs(d, exist_ok=True)

# ------------------------------------------------------------------ 1. labels + frames
MAP = pd.read_csv(MAPPING).set_index("ref_label")
SP = {}
for st in ["CS7", "CS8"]:
    s = pd.read_csv(f"export/{st}_spots.csv")
    s["section_idx"] = s.section.str.replace("S", "").astype(int)
    s["group"] = MAP.loc[s.Types, "our_group"].values; s["coarse"] = MAP.loc[s.Types, "our_coarse"].values
    s["in_disc"] = MAP.loc[s.Types, "in_disc"].values; s["disc_epi"] = MAP.loc[s.Types, "disc_epithelium"].values
    s["group"] = s.group.replace({"Heart mesoderm": "Heart.Meso"}); SP[st] = s

def build_frames(s, st, smooth_sections=1):
    """AP_frac from disc-epithelium section percentiles; per-section DV axis = unit vector from the endoderm
    (VE+DE+Gut) centroid to the epithelium centroid (smoothed +-1 section, interpolated where undefined);
    LR = DV rotated -90 deg (same handedness in every section); LR_frac/DV_gap_units mirror our CosMx frame."""
    s = s.copy(); epi_all = s[s.disc_epi]
    p1, p99 = np.percentile(epi_all.section_idx, [1, 99]); s["AP_frac"] = (s.section_idx - p1) / (p99 - p1)
    endo_mask = s.group.isin(["VE", "DE", "Gut"]).values
    idx_by_sec = {k: np.where(s.section_idx.values == k)[0] for k in sorted(s.section_idx.unique())}; ks = list(idx_by_sec)
    raw = {}
    for k, ii in idx_by_sec.items():
        d = s.iloc[ii]; XY = d[["x", "y"]].values; epi = d.disc_epi.values; en = endo_mask[ii]
        if epi.sum() >= 5 and en.sum() >= 5:
            vec = np.median(XY[epi], 0) - np.median(XY[en], 0); raw[k] = vec / np.linalg.norm(vec)
    rk = np.array(list(raw)); rv = np.array([raw[k] for k in rk]); dvdir = {}; filled = {}
    for k in ks:
        near = np.abs(rk - k) <= smooth_sections
        if near.sum() == 0: near = np.argsort(np.abs(rk - k))[:3]; filled[k] = True
        else: filled[k] = False
        v = rv[near].mean(0); dvdir[k] = v / np.linalg.norm(v)
    out = {c: np.full(len(s), np.nan) for c in ["LR_units", "DV_units", "LR_frac", "LR_halfwidth_units", "S_epi", "S_endo", "gap_units", "DV_gap_units", "DV_spots", "dv_axis_angle_deg", "lr_width_units"]}
    flags = {c: np.zeros(len(s), bool) for c in ["sec_few_epi", "sec_no_endo", "endo_from_neighbour", "dv_axis_from_neighbour"]}
    gap_by_sec = {}
    for k, ii in idx_by_sec.items():
        d = s.iloc[ii]; XY = d[["x", "y"]].values; epi = d.disc_epi.values; en = endo_mask[ii]; disc = d.in_disc.values
        v = dvdir[k]; u = np.array([v[1], -v[0]]); few = epi.sum() < 10
        refm = epi if not few else (disc if disc.sum() >= 10 else np.ones(len(ii), bool))
        mu = np.median(XY[refm], 0); lr = (XY - mu) @ u; dv = (XY - mu) @ v
        lo, hi = np.percentile(lr[refm], [1, 99]); width = max(hi - lo, SPOT); centre = np.median(lr[refm])
        out["LR_units"][ii] = lr - centre; out["DV_units"][ii] = dv; out["LR_frac"][ii] = (lr - centre) / width
        out["LR_halfwidth_units"][ii] = (lr - centre) / (width / 2); out["lr_width_units"][ii] = width
        out["dv_axis_angle_deg"][ii] = np.degrees(np.arctan2(v[1], v[0]))
        flags["sec_few_epi"][ii] = few; flags["sec_no_endo"][ii] = en.sum() < 5; flags["dv_axis_from_neighbour"][ii] = filled[k]
        def local_surface(mask):
            res = np.empty(len(lr))
            for q in range(len(lr)):
                near = mask & (np.abs(lr - lr[q]) <= 3 * SPOT); res[q] = np.median(dv[near]) if near.sum() >= 3 else np.median(dv[mask])
            return res
        Se = local_surface(epi) if epi.sum() else np.full(len(lr), np.nan); Sn = local_surface(en) if en.sum() >= 5 else np.full(len(lr), np.nan)
        out["S_epi"][ii] = Se; out["S_endo"][ii] = Sn
        if epi.sum() and en.sum() >= 5: gap_by_sec[k] = float(np.median(Se - Sn))
    gaps = pd.Series(gap_by_sec)
    for k, ii in idx_by_sec.items():
        Se, Sn = out["S_epi"][ii], out["S_endo"][ii]
        if np.isnan(Se).all():
            d = s.iloc[ii]; Se = np.full(len(ii), np.median(out["DV_units"][ii][d.in_disc.values])) if d.in_disc.sum() else np.zeros(len(ii)); out["S_epi"][ii] = Se
        if np.isnan(Sn).all():
            near = gaps.index[np.argsort(np.abs(gaps.index - k))[:3]]; Sn = Se - float(gaps.loc[near].median()); out["S_endo"][ii] = Sn; flags["endo_from_neighbour"][ii] = True
        gap = np.maximum(Se - Sn, SPOT); out["gap_units"][ii] = gap
        out["DV_gap_units"][ii] = (out["DV_units"][ii] - Se) / gap; out["DV_spots"][ii] = (out["DV_units"][ii] - Se) / SPOT
    for c, v in out.items(): s[c] = v
    for c, v in flags.items(): s[c] = v
    s["z_weight"] = 1.0
    info = dict(stage=st, AP_p1=float(p1), AP_p99=float(p99), AP_span_sections=float(p99 - p1), n_sections=len(ks), median_gap_spots=float(gaps.median() / SPOT))
    return s, info

FR, INFO = {}, {}
for st in ["CS7", "CS8"]:
    FR[st], INFO[st] = build_frames(SP[st], st); f = FR[st]
    insp = (f.section_idx >= INFO[st]["AP_p1"]) & (f.section_idx <= INFO[st]["AP_p99"])
    W = float(f.loc[insp & f.disc_epi].groupby("section_idx").lr_width_units.first().median())   # global disc width
    f["LR_frac_section"] = f["LR_frac"]; f["LR_frac"] = f["LR_units"] / W; f["LR_spots"] = f["LR_units"] / SPOT
    INFO[st]["global_disc_width_spots"] = W / SPOT
    f.to_csv(f"frames/{st}_stereoseq_frames.csv", index=False)
json.dump(INFO, open("frames/stereoseq_frame_spans.json", "w"), indent=1)

# ------------------------------------------------------------------ 2. embedding
ADs = []
for st in ["CS7", "CS8"]:
    X = sio.mmread(f"export/{st}_counts.mtx").tocsc(); genes = pd.read_csv(f"export/{st}_genes.csv").gene.values
    f = FR[st]; keep = (f.group != "exclude").values
    a = ad.AnnData(X=X[:, keep].T.tocsr().astype(np.float32), obs=f.loc[keep].set_index("spot"), var=pd.DataFrame(index=genes)); a.var_names_make_unique(); ADs.append(a)
common = ADs[0].var_names.intersection(ADs[1].var_names)
A = ad.concat([a[:, common].copy() for a in ADs], join="inner", label="stage_batch", keys=["CS7", "CS8"], index_unique=None); A.obs["stage"] = A.obs["stage"].astype(str)
cnt = A.obs.groupby(["stage", "group"]).size(); small = cnt[cnt < 10]            # drop groups with <10 spots within a stage
A = A[~A.obs.set_index(["stage", "group"]).index.isin(small.index)].copy(); A.layers["counts"] = A.X.copy()
sc.pp.highly_variable_genes(A, n_top_genes=2000, flavor="seurat_v3", batch_key="stage", layer="counts")
sc.pp.normalize_total(A, target_sum=1e4); sc.pp.log1p(A); A.raw = A
A = A[:, A.var.highly_variable].copy(); sc.pp.scale(A, max_value=10); sc.tl.pca(A, n_comps=30, svd_solver="arpack", random_state=0)
ho = hm.run_harmony(A.obsm["X_pca"], A.obs, "stage", max_iter_harmony=20, random_state=0, verbose=False)
Z = ho.Z_corr; H = np.asarray(Z.T if Z.shape[0] == 30 else Z); obs = A.obs
Hs = H.copy()                                                                     # smoothing: 15 nearest same-label spots, same section +-1
for st in ["CS7", "CS8"]:
    for g in obs.group.unique():
        ii = np.where((obs.stage.values == st) & (obs.group.values == g))[0]
        if len(ii) == 0: continue
        P = np.c_[obs.LR_units.values[ii], obs.DV_units.values[ii], obs.section_idx.values[ii] * SPOT]
        k = min(60, len(ii)); _, j = cKDTree(P).query(P, k=k); j = np.atleast_2d(j).reshape(len(ii), k); sec = obs.section_idx.values[ii]
        for q in range(len(ii)):
            sel = j[q][np.abs(sec[j[q]] - sec[q]) <= 1][:15]; Hs[ii[q]] = H[ii[sel]].mean(0)
np.save("embedding/harmony_embedding_stereoseq.npy", H); np.save("embedding/harmony_embedding_smooth_stereoseq.npy", Hs)
is7 = obs.stage.values == "CS7"; g7 = obs.group.values[is7].astype(str); g8 = obs.group.values[~is7].astype(str)
ids7 = obs.index.values[is7]; ids8 = obs.index.values[~is7]

# ------------------------------------------------------------------ 3. transition table
TT = json.load(open(TT_USED)); src_groups = sorted(set(g7)); tgt_groups = sorted(set(g8)); T = {}; rank = {"direct": 0, "allowed": 1, "indirect": 2, "penalised": 3}
def setc(g, h, c):
    if h in tgt_groups and g in src_groups: T[(g, h)] = c
for k, c in TT.items():
    g, h = k.split("->")
    if g in src_groups and h in tgt_groups: T[(g, h)] = c
for k, c in TT.items():                                   # Stereo-seq EPI covers our EPI and ECT: take the less penalised row
    g, h = k.split("->")
    if g == "ECT" and h in tgt_groups and rank[c] < rank[T.get(("EPI", h), "penalised")]: setc("EPI", h, c)
setc("PS", "APS", "allowed"); setc("APS", "APS", "direct"); setc("APS", "Gut", "indirect")
for g in ["PS", "APS", "Nas.Meso"]:
    for h in ["Adv.Meso", "Other.Meso"]: setc(g, h, "indirect")
setc("DE", "Gut", "allowed"); setc("VE", "Gut", "indirect")
for g in ["VE", "DE", "Gut", "Node", "pECT", "CLE", "NNE", "Adv.Meso", "Other.Meso", "Rostral.Meso", "LP.Meso", "Heart.Meso"]: setc(g, g, "direct")
for h in ["EPI", "CLE", "PS", "NNE"]: setc("pECT", h, "allowed")
setc("pECT", "Nas.Meso", "indirect"); setc("CLE", "PS", "allowed"); setc("CLE", "pECT", "allowed"); setc("CLE", "Nas.Meso", "indirect"); setc("CLE", "Para.Meso", "indirect")
setc("NNE", "aECT", "allowed"); setc("NNE", "EPI", "allowed")
for h in ["Para.Meso", "LP.Meso", "Rostral.Meso", "Heart.Meso"]: setc("Nas.Meso", h, "allowed")
for g in ["Rostral.Meso", "LP.Meso", "Heart.Meso"]:
    for h in ["Adv.Meso", "Other.Meso"]: setc(g, h, "indirect")          # documented exception to the task rule
setc("Rostral.Meso", "Heart.Meso", "allowed"); setc("Adv.Meso", "Other.Meso", "allowed"); setc("Other.Meso", "Adv.Meso", "allowed")
for g in src_groups:
    for h in tgt_groups: T.setdefault((g, h), "penalised")

# ------------------------------------------------------------------ 4. matching
spec = importlib.util.spec_from_file_location("starmatch", STARMATCH); sm = importlib.util.module_from_spec(spec); spec.loader.exec_module(sm)
REF = json.load(open(REF_PARAMS)); spat = ["AP_frac", "LR_frac", "DV_gap_units"]
E7, E8 = Hs[is7], Hs[~is7]; S7, S8 = obs.loc[is7, spat].values.astype(float), obs.loc[~is7, spat].values.astype(float)
a = np.ones(len(g7)); b = np.ones(len(g8))
def run(P):
    res = sm.run_matching(E7, E8, S7, S8, g7, g8, a, b, T, lam=P["lam"], k_cand=P["k_cand"], eps=P["eps"], tau=P["tau"], K=P["K"], class_penalty=P["class_penalty"], c_unmatched=P["c_unmatched"], delta=P["delta"])
    M = res["M"].tocoo(); cls = np.array([T[(g7[i], g8[j])] for i, j in zip(M.row, M.col)]); cost = np.asarray(res["C"][M.row, M.col]).ravel()
    edges = pd.DataFrame(dict(cs7_spot=ids7[M.row], cs7_group=g7[M.row], cs8_spot=ids8[M.col], cs8_group=g8[M.col], transition_class=cls, cost=cost))
    edges["star_size"] = np.asarray(res["M"].sum(1)).ravel()[M.row]; return res, edges
P0 = dict(lam=REF["lam"], k_cand=REF["k_cand"], eps=REF["eps"], tau=REF["tau"], K=REF["K"], class_penalty=REF["class_penalty"], c_unmatched=REF["c_unmatched"], delta=REF["delta"])
res0, ED0 = run(P0); ED0.to_csv("matching/matching_stereoseq_reference.csv", index=False); res0["flow"].to_csv("matching/flow_table_stereoseq_reference.csv")
P1 = copy.deepcopy(P0); P1["class_penalty"] = dict(P0["class_penalty"], penalised=2.0); P2 = copy.deepcopy(P0); P2["K"] = 4; P3 = copy.deepcopy(P0); P3["eps"] = 2 * P0["eps"]
SENS = {lab: run(P) for lab, P in [("penalised_2", P1), ("K_4", P2), ("eps_x2", P3)]}
for lab, (r, e) in SENS.items(): e.to_csv(f"matching/matching_stereoseq_{lab}.csv", index=False); r["flow"].to_csv(f"matching/flow_table_stereoseq_{lab}.csv")

# ------------------------------------------------------------------ 5. global transform + Bures modes (same functions as the CosMx Modes track)
def fit_aniso_procrustes(P, Q, w, n_iter=200, tol=1e-10):
    w = w / w.sum(); pm = (w[:, None] * P).sum(0); qm = (w[:, None] * Q).sum(0); Pc = P - pm; Qc = Q - qm
    s = np.sqrt((w[:, None] * Qc**2).sum(0) / (w[:, None] * Pc**2).sum(0)); R = np.eye(3)
    for it in range(n_iter):
        Ps = Pc * s; Hh = (Ps * w[:, None]).T @ Qc; U, _, Vt = np.linalg.svd(Hh); D = np.diag([1, 1, np.sign(np.linalg.det(Vt.T @ U.T))]); R_new = Vt.T @ D @ U.T
        Qr = Qc @ R_new; s_new = (w[:, None] * Qr * Pc).sum(0) / (w[:, None] * Pc**2).sum(0)
        if np.abs(s_new - s).max() < tol and np.abs(R_new - R).max() < tol: R, s = R_new, s_new; break
        R, s = R_new, s_new
    G = R @ np.diag(s); g = qm - G @ pm; return R, s, g, G, P @ G.T + g
def wcov(X, w):
    mu = np.average(X, axis=0, weights=w); Xc = X - mu; return mu, (Xc * w[:, None]).T @ Xc / w.sum()
def modes_pair(Pp, Qq, wp, wq):
    mu7, S7_ = wcov(Pp, wp); mu8, S8_ = wcov(Qq, wq); t = mu8 - mu7; A7 = S7_[:2, :2]; A8 = S8_[:2, :2]
    e7, v7 = np.linalg.eigh(A7); e8, v8 = np.linalg.eigh(A8)
    return dict(t_AP=t[0], t_LR=t[1], t_DV=t[2], area_ratio=np.sqrt(np.linalg.det(A8) / np.linalg.det(A7)), AP_extent_ratio=np.sqrt(A8[0, 0] / A7[0, 0]), LR_extent_ratio=np.sqrt(A8[1, 1] / A7[1, 1]),
                aniso_CS7=np.sqrt(e7[1] / e7[0]), aniso_CS8=np.sqrt(e8[1] / e8[0]), elongation_change=np.sqrt(e8[1] / e8[0]) / np.sqrt(e7[1] / e7[0]),
                major_axis_deg_CS7=np.degrees(np.arctan2(v7[1, 1], v7[0, 1])) % 180, major_axis_deg_CS8=np.degrees(np.arctan2(v8[1, 1], v8[0, 1])) % 180, DV_sd_ratio=np.sqrt(S8_[2, 2] / S7_[2, 2]))
F7s = FR["CS7"].set_index("spot"); F8s = FR["CS8"].set_index("spot"); F7s["AP_sections"] = F7s.section_idx.astype(float); F8s["AP_sections"] = F8s.section_idx.astype(float)
frames_def = {"normalised": ["AP_frac", "LR_frac", "DV_gap_units"], "physical": ["AP_sections", "LR_spots", "DV_spots"]}
E = ED0.copy()
for c in sorted(set(sum(frames_def.values(), []))): E["p_" + c] = F7s.loc[E.cs7_spot, c].values; E["q_" + c] = F8s.loc[E.cs8_spot, c].values
sel = E.transition_class.isin(["direct", "allowed"]); c90 = E.loc[sel, "cost"].quantile(0.9); sel &= E.cost <= c90; GT = {}
for name, ax in frames_def.items():
    P = E.loc[sel, ["p_" + c for c in ax]].values; Q = E.loc[sel, ["q_" + c for c in ax]].values; R, s, g, G, fit = fit_aniso_procrustes(P, Q, np.ones(int(sel.sum())))
    GT[name] = dict(axes=ax, scale=dict(zip(["AP", "LR", "DV"], s.tolist())), translation=dict(zip(["AP", "LR", "DV"], g.tolist())), rotation_angle_deg=float(Rot.from_matrix(R).magnitude() * 180 / np.pi), G=G.tolist(), n_edges_used=int(sel.sum()))
json.dump(GT, open("modes/global_transform_stereoseq.json", "w"), indent=1)
def bures_table(E, name, pairs_extra, n_boot=300, min_edges=50, seed=11):
    ax = frames_def[name]; Gm = np.array(GT[name]["G"]); gv = np.array([GT[name]["translation"][k] for k in ["AP", "LR", "DV"]])
    P7 = E[["p_" + c for c in ax]].values; Q8 = E[["q_" + c for c in ax]].values; P7g = P7 @ Gm.T + gv; w = np.ones(len(E)); rng = np.random.default_rng(seed); rows = []
    pairs = [(g, h, ((E.cs7_group == g) & (E.cs8_group == h)).to_numpy()) for (g, h), n in E.groupby(["cs7_group", "cs8_group"]).size().items() if n >= min_edges] + [(g, h, np.asarray(m)) for g, h, m in pairs_extra if m.sum() >= min_edges]
    for g, h, m in pairs:
        stars = E.loc[m].drop_duplicates("cs7_spot").index.to_numpy(); Pp, Qq = P7g[stars], Q8[m]; est = modes_pair(Pp, Qq, w[stars], w[m]); boots = {k: [] for k in est}
        for _ in range(n_boot):
            bi = rng.integers(0, len(Pp), len(Pp)); bj = rng.integers(0, len(Qq), len(Qq)); e = modes_pair(Pp[bi], Qq[bj], w[stars][bi], w[m][bj]); [boots[k].append(e[k]) for k in e]
        row = dict(cs7_group=g, cs8_group=h, n_stars=len(stars), n_edges=int(m.sum()), frame=name)
        for k, v in est.items(): lo, hi = np.percentile(boots[k], [2.5, 97.5]); row[k] = v; row[k + "_lo"] = lo; row[k + "_hi"] = hi
        rows.append(row)
    return pd.DataFrame(rows)
extra = [("PS+APS", "PS+APS", E.cs7_group.isin(["PS", "APS"]) & E.cs8_group.isin(["PS", "APS"])), ("DE", "DE+Gut", (E.cs7_group == "DE") & E.cs8_group.isin(["DE", "Gut"])),
         ("EPI+NNE+pECT", "EPI+aECT+NNE+pECT", E.cs7_group.isin(["EPI", "NNE", "pECT"]) & E.cs8_group.isin(["EPI", "aECT", "NNE", "pECT"]))]
TMs = {name: bures_table(E, name, extra) for name in frames_def}; pd.concat(TMs.values()).round(4).to_csv("modes/territory_modes_bures_stereoseq.csv", index=False)
# Our CosMx modes: um surface frame (published table, reproduced exactly) and normalised frame (for anisotropy / axis comparisons); pooled pairs added.
EDr = pd.read_csv(OUR_EDGES); GTr = json.load(open(OUR_GT)); wr = (EDr.p_z_weight * EDr.q_z_weight).values
selr = EDr.transition_class.isin(["direct", "allowed"]); selr &= EDr.cost <= EDr.loc[selr, "cost"].quantile(0.9)
our_frames = {"um_surface": ["AP_arc_um", "LR_um", "DV_um_to_surface"], "normalised": ["AP_arc_frac", "LR_frac", "DV_gap_units"]}
GTour = {"um_surface": (np.array(GTr["surface"]["G"]), np.array([GTr["surface"]["translation_um"][k] for k in ["AP", "LR", "DV"]]))}
P = EDr.loc[selr, ["p_" + c for c in our_frames["normalised"]]].values; Q = EDr.loc[selr, ["q_" + c for c in our_frames["normalised"]]].values
_, _, g_, G_, _ = fit_aniso_procrustes(P, Q, wr[selr.values]); GTour["normalised"] = (G_, g_)
# (replication table: see METHODS_NOTES_replication.md section 7 for the pairing list and direction definitions;
#  implemented in the analysis session with sgn_ci()/ang_to_AP() and binomtest(k, n, 0.5).)
