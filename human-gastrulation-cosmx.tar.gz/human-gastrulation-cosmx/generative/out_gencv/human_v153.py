# Human t0.5 readouts with the rotation-0 V1a (5 seeds) on the 153-embryo Z; decoded with the decoder retrained on the new Z.
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import sys, os, json, glob, shutil, subprocess, numpy as np, pandas as pd, scipy.sparse as sp, torch, anndata as ad
exec(open('out_gencv/gencv_lib.py').read())
H = np.load(OG + 'rot0_human_t05_latent.npz'); GV1 = H['gen_V1a']; GV2 = H['gen_final_v2']
assert np.allclose(H['linear'], HLIN.cpu().numpy(), atol=1e-5)
# plausibility: dom.py / final2.py definition (denominator = linear midpoint, emd_cen partners) and loop2.py selection-score variant (denominator emd_top)
KL_TOP = knnd(generate(('linear', None), dict(pair='emd_top'), HD), HREF_ALL)
pl = []
for nm, GG in [('V1a', GV1), ('final_v2', GV2)]:
    for s in range(5):
        G = torch.tensor(GG[s], device=dev)
        pl.append(dict(model=nm, seed=s, plaus=knnd(G, HREF_ALL) / KL_ALL, plaus_loop2_emdtop=knnd(G, HREF_ALL) / KL_TOP, plaus_heldout=knnd(G[HO], HREF_HO) / KL_HO,
                       shift_from_linear=float((G - HLIN).norm(dim=1).mean())))
PL = pd.DataFrame(pl); print(PL.groupby('model').mean().round(4).to_string(), flush=True)
DECN = load_decoder(OG + 'decoder/decoder.pt')
MK = pd.concat([markers(GV1, DECN).assign(model='V1a'), markers(GV2, DECN).assign(model='final_v2'),
                markers(H['linear'][None], DECN).assign(model='linear')])
# sanity: old V1a latent (115-embryo Z) + old decoder must reproduce the old out_domain numbers (NOTO 10.36 / TBXT 42.4)
OLDV = DATA + '/ai_t05/out_domain/best_V1a_lamh3.0/'; DECO = load_decoder(DATA + '/ai_t05/ai/step7/final_v2/decoder.pt')
MKo = markers(np.load(OLDV + 'human_t05_latent.npz')['gen'], DECO).assign(model='old_V1a_oldZ_olddecoder')
MKx = markers(GV1, DECO).assign(model='V1a_newZ_OLDdecoder_mismatch')
MK = pd.concat([MK, MKo, MKx]); MK.to_csv(OG + 'human_markers_perseed_v153.csv', index=False)
S = MK.groupby(['model', 'gene']).agg(det_expected=('det_expected', 'mean'), det_expected_sd=('det_expected', 'std'), det_sampled=('det_sampled', 'mean'),
                                     bg_expected=('bg_expected', 'mean'), bg_sampled=('bg_sampled', 'mean')).reset_index()
print(S[S.gene.isin(['NOTO', 'TBXT', 'HOXA1', 'HOXB1'])].round(2).to_string(index=False), flush=True)
# step5_milestones.py table (unchanged script, S5OUT = our export folder): decoded counts with the NEW decoder
EX = OG + 'human_rot0_V1a/'; os.makedirs(EX, exist_ok=True)
m, gi, lib05, genes = DECN
@torch.no_grad()
def dec(z, ll, seed):
    torch.manual_seed(seed); out = []
    for k in range(0, len(z), 2048):
        mu, th = m(torch.tensor(z[k:k+2048], device=dev, dtype=torch.float32), torch.tensor(np.log(ll[k:k+2048]), device=dev, dtype=torch.float32))
        r = torch.distributions.Gamma(th.expand_as(mu), th.expand_as(mu) / mu.clamp_min(1e-8)).sample(); out.append(sp.csr_matrix(torch.poisson(r).cpu().numpy()))
    return sp.vstack(out).tocsr()
D5 = [dec(GV1[s], lib05, 10 + s) for s in range(5)]
for s, Dm in enumerate(D5): sp.save_npz(EX + f't05_gen_seed{s}_decoded.npz', Dm)
sp.save_npz(EX + 't05_linear_decoded.npz', dec(H['linear'], lib05, 99))
for f in ['C7_decoded.npz', 'C8_decoded.npz']: shutil.copy(OG + 'decoder/' + f, EX + f)
o = T05.copy(); o['library'] = lib05; T = ad.AnnData(D5[0].astype(np.float32), obs=o, var=pd.DataFrame(index=genes)); T.obsm['X_rep'] = GV1[0]
T.uns['description'] = 'AI-generated CS7-CS8 t=0.5 pseudo-cells, V1a lam_h=3 retrained on the 153-embryo rebuild (rotation 0 train), decoded with the NB-MLP decoder retrained on the new Z (seed 0 sample).'
T.write_h5ad(EX + 't05_AI_generated_counts.h5ad')
json.dump(dict(note='rotation-0 V1a, 153-embryo Z', plaus=PL[PL.model == 'V1a'].plaus.mean()), open(EX + 'info.json', 'w'))
r = subprocess.run([sys.executable, 'ai/step5_milestones.py'], env=dict(os.environ, S5OUT=EX.rstrip('/')), capture_output=True, text=True); print(r.stdout[-3000:], r.stderr[-1500:], flush=True)
PL.to_csv(OG + 'human_plaus_perseed_v153.csv', index=False); S.to_csv(OG + 'human_markers_summary_v153.csv', index=False)
print('DONE', flush=True)
