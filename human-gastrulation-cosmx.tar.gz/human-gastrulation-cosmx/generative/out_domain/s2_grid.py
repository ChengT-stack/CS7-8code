# Driver: final_v2 reference, fine-tune control, V1 (human self-supervised) grid, V2 (WGAN-GP adversarial) grid, optional combos.
# usage: python s2_grid.py [phase]   phase = grid (default) | combo:<lam_h>:<lam_adv>
import time, sys as _s; _phase = _s.argv[1] if len(_s.argv) > 1 else 'grid'
exec(open('out_domain/dom.py').read())
print("STARTED", flush=True)
os.makedirs(OD + 'results', exist_ok=True)
def run_variant(name, builder, kw=None):
    fj = OD + f'results/{name}.json'
    if os.path.exists(fj): print('skip', name, flush=True); return
    t0 = time.time(); nets = []; hists = []
    for s in range(5):
        net, h = builder(s); nets.append(net); h['seed'] = s; hists.append(h)
        if name != 'final_v2': torch.save(net.state_dict(), OD + f'weights/{name}_seed{s}.pt')
    o, pm, G = full_eval(nets, name); pm.to_csv(OD + f'results/{name}_locked_per_mid.csv')
    mk = markers(G); mk.to_csv(OD + f'results/{name}_markers_perseed.csv', index=False)
    ms = marker_summary(mk, name); ms.to_csv(OD + f'results/{name}_markers.csv', index=False)
    for _, r in ms.iterrows(): o[f'{r.gene}_det_expected'] = r.det_expected; o[f'{r.gene}_det_sampled'] = r.det_sampled; o[f'{r.gene}_call'] = r.call_sampled
    pd.concat(hists).to_csv(OD + f'results/{name}_trainlog.csv', index=False)
    o['minutes'] = (time.time() - t0) / 60; o['finetune_kwargs'] = json.dumps(kw); json.dump(o, open(fj, 'w'), indent=1, default=float)
    print(name, {k: (round(v, 3) if isinstance(v, float) else v) for k, v in o.items() if not k.endswith('_call')}, flush=True)
_t=time.time(); _n,_h=finetune(0,lam_h=1.0,lam_adv=1.0,steps=30,envelope=True,center_nominal=True); print('smoke ok',round(time.time()-_t,1),'s', _h.iloc[-1].to_dict(), 'gpu GB',torch.cuda.max_memory_allocated()/1e9, flush=True)
if _phase == 'grid':
    run_variant('final_v2', lambda s: (load_v2(s), pd.DataFrame()))
    run_variant('C1_ft_mouse_only', lambda s: finetune(s))
    for lh in [0.1, 0.3, 1.0, 3.0]: run_variant(f'V1_lamh{lh}', lambda s, lh=lh: finetune(s, lam_h=lh))
    for la in [0.1, 0.3, 1.0, 3.0]: run_variant(f'V2_lamadv{la}', lambda s, la=la: finetune(s, lam_adv=la))
elif _phase == 'grid2':
    P0 = dict(use_frac=False); P2 = dict(center_nominal=True, w_end_m=0.0)
    def R(name, kw): run_variant(name, lambda s: finetune(s, **kw), kw)
    R('C_P0_continued', P0); R('C_P2_frac', P2)
    for lh in [0.1, 0.3, 1.0, 3.0]: R(f'V1a_lamh{lh}', dict(P2, lam_h=lh))
    for lh in [0.3, 1.0, 3.0]: R(f'V1b_env_lamh{lh}', dict(P2, lam_h=lh, envelope=True, hum_end=False))
    for la in [0.1, 0.3, 1.0, 3.0]: R(f'V2_lamadv{la}', dict(P0, lam_adv=la))
elif _phase.startswith('combo'):
    _, lh, la = _phase.split(':'); lh = float(lh); la = float(la)
    run_variant(f'V12_lamh{lh}_lamadv{la}', lambda s: finetune(s, lam_h=lh, lam_adv=la))
print('DONE', flush=True)
