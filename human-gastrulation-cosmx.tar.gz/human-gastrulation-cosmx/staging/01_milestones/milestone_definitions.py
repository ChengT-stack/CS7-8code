# staging/01_milestones/milestone_definitions.py
# Source: drive G: data/milestone_evidence/mz/allstage/definitions.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

import pandas as pd
S=(str(HGC_DATA) + '/staging/mouse_milestone_marker_specificity.csv')
DEF=[ # milestone (key), figure label, mouse metric, mouse markers (cell type), human criterion
("Nascent mesoderm forms","Nascent mesoderm forms (Mesp1⁺)","Nascent mesoderm, % of embryo-proper cells","Nascent mesoderm","Mesp1","Annotated nascent mesoderm, or MESP1 detected in streak above background"),
("Anterior primitive streak forms","Anterior primitive streak forms (Gsc⁺Foxa2⁺ streak)","Anterior Primitive Streak, % of embryo-proper cells","Anterior Primitive Streak","Gsc;Foxa2","Annotated APS / axial population expressing GSC and FOXA2"),
("Node-like cells appear (Foxj1+Chrd+)","Node-like cells appear (Foxj1⁺Chrd⁺)","Foxj1⁺Chrd⁺ cells among PS, notochord and DE, % of embryo-proper cells","Notochord","Foxj1;Chrd","FOXJ1⁺CHRD⁺ cells in node / axial population"),
("Definitive endoderm appears","Definitive endoderm appears (Foxa2⁺Sox17⁺)","Def. endoderm, % of all cells","Def. endoderm","Foxa2;Sox17","Annotated DE expressing FOXA2 and SOX17"),
("ADE appears (Gsc+Cer1+ DE)","ADE appears (Gsc⁺Cer1⁺ DE)","Gsc⁺Cer1⁺ Def. endoderm, % of embryo-proper cells",None,"Gsc;Cer1","GSC⁺CER1⁺ cells within DE"),
("ADE programme regresses (Gsc in DE)","ADE programme regresses (Gsc lost from DE)","Gsc detection in Def. endoderm (loss: <75% of peak)",None,"Gsc","GSC in DE fallen to background"),
("Notochord forms","Notochord forms (Noto⁺ axial cells)","Notochord, % of all cells","Notochord","Noto;Shh","Annotated notochord, or NOTO⁺ axial cells at mouse E7.5-like frequency"),
("HOX on in streak (Hoxb1)","3′ HOX on in streak (Hoxa1⁺ or Hoxb1⁺ PS)","Hoxa1 or Hoxb1 detection in Primitive Streak (both onset E7.375)",None,"Hoxa1;Hoxb1","HOXA1 or HOXB1 in PS above background"),
("Caudal epiblast forms","Caudal epiblast forms (Nkx1-2⁺Cdx2⁺)","Caudal epiblast, % of all cells","Caudal epiblast","Nkx1-2;Cdx2","Annotated CLE, or NKX1-2⁺CDX2⁺ epiblast/streak cells"),
("Neural plate (rostral neurectoderm)","Neural plate forms (Hesx1⁺Six3⁺ rostral neurectoderm)","Rostral neurectoderm, % of all cells","Rostral neurectoderm","Hesx1;Six3","Annotated anterior neurectoderm (aECT) or HESX1/SIX3-enriched anterior epiblast"),
("Paraxial mesoderm forms","Paraxial mesoderm forms (Meox1⁺Tcf15⁺)","Paraxial mesoderm, % of all cells","Paraxial mesoderm","Meox1;Tcf15","Annotated paraxial mesoderm expressing MEOX1 / TCF15"),
("EOMES switched off in streak","EOMES switched off in streak (Eomes lost from PS)","Eomes detection in Primitive Streak (loss: <75% of peak)",None,"Eomes","EOMES in PS fallen to background"),
("5′ HOX on in caudal epiblast (Hoxb8)","5′ HOX on in caudal epiblast (Hoxb8⁺)","Hoxb8 detection in Caudal epiblast",None,"Hoxb8","HOXB8 in caudal epiblast (CLE or NKX1-2⁺CDX2⁺ cells) above background"),
("Cardiomyocytes appear","Cardiomyocytes appear (Nkx2-5⁺Tnnt2⁺)","Cardiomyocytes, % of all cells","Cardiomyocytes","Nkx2-5;Tnnt2","Cardiac cells with NKX2-5 at mouse-cardiomyocyte frequency"),
("PGCs appear","PGCs appear (Dppa3⁺Nanos3⁺)","PGC, % of all cells","PGC","Dppa3;Nanos3","Annotated PGCs (NANOS3⁺ with SOX17/TFAP2C/PRDM1)"),
("Haemato-endothelial progenitors appear","Haemato-endothelial progenitors appear (Etv2⁺Kdr⁺)","Haematoendothelial progenitors, % of all cells","Haematoendothelial progenitors","Etv2;Kdr","Annotated haemato-endothelial / blood-progenitor population"),
("Extra-embryonic mesoderm expands","Extra-embryonic mesoderm expands (Hand1⁺)","ExE mesoderm, % of all cells","ExE mesoderm","Hand1","Annotated extra-embryonic / yolk-sac mesoderm"),
("Allantois forms","Allantois forms (Tbx4⁺Hoxa10⁺)","Allantois, % of all cells","Allantois","Tbx4;Hoxa10","Annotated allantois with TBX4 / HOXA10"),
("Primitive erythroid cells appear","Primitive erythroid cells appear (Hba-x⁺Gata1⁺)","Erythroid1, % of all cells","Erythroid1","Hba-x;Gata1","Annotated primitive erythroid cells with HBZ (Hba-x orthologue)")]
sp=pd.read_csv(S)
rows=[]
for key,label,metric,ct,genes,human in DEF:
    spec=''
    if ct:
        s=sp[(sp.celltype==ct)&(sp.gene.isin(genes.split(';')))]
        spec='; '.join(f"{r.gene} {r.pct_in}% vs {r.pct_other}%" for r in s.itertuples())
    rows.append(dict(milestone=key,label=label,mouse_metric=metric,mouse_celltype=ct or '',markers=genes.replace(';',', '),
                     mouse_marker_detection_in_vs_other=spec,human_criterion=human))
Df=pd.DataFrame(rows); Df.to_csv('mz/allstage/definitions.csv',index=False); print(Df[['label','mouse_marker_detection_in_vs_other']].to_string())
