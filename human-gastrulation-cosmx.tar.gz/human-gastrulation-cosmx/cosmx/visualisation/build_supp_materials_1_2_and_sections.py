# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: reconstructed from transcript of session 32c2b2b0 (this paper-finalisation session), messages 674,
#     684, 688, 698, 780 and 790 (functions build and build_sections); outputs saved as artifacts f6945297,
#     8c0c0e37, 3b16c1e0 (2026-11-22) and dac6b499, 59cf5e20 (2026-11-23)
# sha256 of original: 1691bf35266d992e1de7c0b97c933dfb3525bf040256d384e34e9ec0c7d3b6b6
# Methods paragraphs: P352 (3D reconstruction display), Supplementary Materials 1-2 legends
# Produces: sm/Supplementary_Material_1_HuE1_CS7_3D.html (83,774 cells, 27 types),
#     sm/Supplementary_Material_2_HuE2_CS8_3D.html (86,608 cells, 35 types),
#     sm/Supplementary_Materials_1-2_cell_type_key.csv, sm/Supplementary_Materials_1-2_legends.txt,
#     sm/HuE1_CS7_2D_sections.html, sm/HuE2_CS8_2D_sections.html
# Edits/notes: inputs final_meta.csv.gz, type39_scheme.csv, cell_slice_mapping.csv.gz are written to HGC_OUT by
#     preprocessing/export_meta.R and export_misc.R. Superseded intermediate calls (first builds of msgs
#     684/688) removed; the msg-790 string edits of build_sections are applied in the source instead of via
#     inspect/exec.
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

import re
import numpy as np
# --- transcript 32c2b2b0 msg 674: load the merged metadata export (cosmx/preprocessing/export_meta.R) ---
import pandas as pd
md=pd.read_csv('final_meta.csv.gz',low_memory=False)
md['hasxyz']=md[['x_um','y_um','z_um']].notna().all(1)
# --- msg 684: palette, section names, display names and the 3D map builder ---
import plotly.graph_objects as go, plotly, os
pal=pd.read_csv('type39_scheme.csv').set_index('celltype')['color'].to_dict()
sl=pd.read_csv('cell_slice_mapping.csv.gz').set_index('cell')['slice_name']
md['section']=md['cell'].map(sl)
CS7=[('Epiblast (EPI)','Epiblast (EPI)'),('Ectoderm (ECT)','Ectoderm (ECT)'),('Primitive streak (PS)','Primitive streak (PS)'),
 ('Anterior primitive streak (APS)','Anterior primitive streak (APS)'),('Node','Primitive node'),('Primordial germ cell (PGC)','Primordial germ cell (PGC)'),
 ('Amniotic epithelium progenitor (Am.Epi progenitor)','Amniotic epithelium progenitor (Am.Epi progenitor)'),('Amniotic epithelium (Am.Epi)','Amniotic epithelium (Am.Epi)'),
 ('Extraembryonic mesoderm progenitor (Exe.Meso progenitor)','Extraembryonic mesoderm progenitor (ExE.Meso progenitor)'),('Amniotic mesenchyme (Am.Mes)','Amniotic mesenchyme (Am.Mes)'),
 ('Allantois mesenchyme (Al.Mes)','Allantois mesenchyme (Al.Mes)'),('Chorion-allantois mesenchyme (ChA.Mes)','Chorion–allantois mesenchyme (ChA.Mes)'),
 ('Yolk sac mesoderm (ys.Meso)','Yolk sac mesoderm (ys.Meso)'),('Definitive endoderm (DE)','Definitive endoderm (DE)'),('Visceral endoderm 1 (VE1)','Visceral endoderm 1 (VE1)'),
 ('Visceral endoderm 2 (VE2)','Visceral endoderm 2 (VE2)'),('Parietal yolk sac endoderm (Pari.Endo)','Parietal yolk sac endoderm (Pari.ys.Endo)'),
 ('Proximal yolk sac endoderm (Prox.ys.Endo)','Proximal yolk sac endoderm (Prox.ys.Endo)'),('Distal yolk sac endoderm (Dist.ys.Endo)','Distal yolk sac endoderm (Dist.ys.Endo)'),
 ('Allantois endoderm (Al.Endo)','Allantois endoderm (Al.Endo)'),('Anterior visceral endoderm (AVE)','Anterior visceral endoderm (AVE)'),
 ('Hematopoietic progenitor (Hema)','Haematopoietic progenitor (Hema)'),('Endothelium','Endothelium'),('Macrophage','Macrophage'),('Megakaryocyte','Megakaryocyte'),
 ('Primitive erythroblast','Primitive erythroblast'),('Trophoblast','Trophoblast')]
CS8=[('Epiblast (EPI)','Epiblast 1 (EPI1)'),('Anterior ectoderm (aECT)','Ectoderm (ECT)'),('Posterior ectoderm (pECT)','Epiblast 2 (EPI2)'),('Primitive streak (PS)','Primitive streak (PS)'),
 ('Node','Node'),('Notochord','Notochord'),('Prechordal plate','Prechordal plate (PrP)'),('Caudal lateral epiblast (CLE)','Caudal lateral epiblast (CLE)'),
 ('Primordial germ cell (PGC)','Primordial germ cell (PGC)'),('Non-neural ectoderm (NNE)','Non-neural ectoderm (NNE)'),
 ('Amniotic epithelium progenitor (Am.Epi progenitor)','Amniotic epithelium progenitor (Am.Epi progenitor)'),('Amniotic epithelium (Am.Epi)','Amniotic epithelium (Am.Epi)'),
 ('Nascent mesoderm (Nas.Meso)','Nascent mesoderm (Nas.Meso)'),('Lateral plate mesoderm (LP.Meso)','Lateral plate mesoderm (LP.Meso)'),('Heart mesoderm','Heart mesoderm (Heart.Meso)'),
 ('Extraembryonic mesoderm progenitor (Exe.Meso progenitor)','Extraembryonic mesoderm progenitor (ExE.Meso progenitor)'),('Amniotic mesenchyme (Am.Mes)','Amniotic mesenchyme (Am.Mes)'),
 ('Allantois mesenchyme (Al.Mes)','Allantois mesenchyme (Al.Mes)'),('Chorion-allantois mesenchyme (ChA.Mes)','Chorion–allantois mesenchyme (ChA.Mes)'),
 ('Yolk sac mesoderm (ys.Meso)','Yolk sac mesoderm (ys.Meso)'),('Paraxial mesoderm (Para.Meso)','Paraxial mesoderm (Para.Meso)'),('Rostral mesoderm (Rostral.Meso)','Rostral mesoderm (Rostral.Meso)'),
 ('Definitive endoderm (DE)','Definitive endoderm (DE)'),('Visceral endoderm 1 (VE1)','Visceral endoderm 1 (VE1)'),('Visceral endoderm 2 (VE2)','Visceral endoderm 2 (VE2)'),
 ('Parietal yolk sac endoderm (Pari.Endo)','Parietal yolk sac endoderm (Pari.ys.Endo)'),('Proximal yolk sac endoderm (Prox.ys.Endo)','Proximal yolk sac endoderm (Prox.ys.Endo)'),
 ('Distal yolk sac endoderm (Dist.ys.Endo)','Distal yolk sac endoderm (Dist.ys.Endo)'),('Allantois endoderm (Al.Endo)','Allantois endoderm (Al.Endo)'),
 ('Hematopoietic progenitor (Hema)','Haematopoietic progenitor (Hema)'),('Endothelium','Endothelium'),('Macrophage','Macrophage'),('Megakaryocyte','Megakaryocyte'),
 ('Primitive erythroblast','Primitive erythroblast'),('Trophoblast','Trophoblast')]
def build(stage,spec,smn,emb,fname):
    s=md[(md.stage==stage)&md.hasxyz].copy()
    assert set(s['39Type'])==set(k for k,_ in spec), set(s['39Type'])^set(k for k,_ in spec)
    kept=s[s.curated_kept.astype(bool)]; exc=s[~s.curated_kept.astype(bool)]
    fig=go.Figure(); rows=[]
    for i,(lab,disp) in enumerate(spec,1):
        c=kept[kept['39Type']==lab]
        name=f'{i}. {disp} (n = {len(c):,})'
        fig.add_trace(go.Scatter3d(x=c.x_um.round(1),y=c.y_um.round(1),z=c.z_um.round(1),mode='markers',name=name,
            marker=dict(size=1.8,color=pal[lab],line=dict(width=0)),text=c.section,
            hovertemplate=f'<b>{i}. {disp}</b><br>section %{{text}}<br>x %{{x}} µm, y %{{y}} µm, z %{{z}} µm<extra></extra>'))
        rows.append(dict(stage=stage,number=i,cell_type=disp,annotation_label_39Type=lab,color=pal[lab],cells_shown=len(c),cells_spatially_excluded=int((exc['39Type']==lab).sum())))
    if len(exc):
        fig.add_trace(go.Scatter3d(x=exc.x_um.round(1),y=exc.y_um.round(1),z=exc.z_um.round(1),mode='markers',visible='legendonly',
            name=f'Cells excluded by spatial curation (n = {len(exc):,}; hidden by default)',marker=dict(size=2.2,color='#7f7f7f',line=dict(width=0)),
            text=exc['39Type'], hovertemplate='<b>excluded:</b> %{text}<br>x %{x} µm, y %{y} µm, z %{z} µm<extra></extra>'))
    title=(f'<b>Supplementary Material {smn}.</b> Interactive 3D spatial map of {emb} — {len(kept):,} cells, {len(spec)} cell types'
           '<br><span style="font-size:12px">Drag to rotate, scroll to zoom. Click a legend entry to hide or show a cell type; double-click to show it alone. Hover for cell type and section.</span>')
    fig.update_layout(title=dict(text=title,x=0.01,font=dict(size=16,family='Arial')),template='plotly_white',font=dict(family='Arial'),
        scene=dict(xaxis_title='x (µm)',yaxis_title='y (µm)',zaxis_title='z (µm, section axis)',aspectmode='data',
                   camera=dict(eye=dict(x=0.0,y=-0.25,z=2.0),up=dict(x=0,y=1,z=0))),
        legend=dict(itemsizing='constant',font=dict(size=11),tracegroupgap=0,bgcolor='rgba(255,255,255,0.85)'),
        margin=dict(l=0,r=0,t=70,b=0),height=850)
    fig.write_html(fname,include_plotlyjs=True,full_html=True,config=dict(displaylogo=False,toImageButtonOptions=dict(format='png',scale=3,filename=fname[:-5])))
    return pd.DataFrame(rows), len(kept), len(exc), os.path.getsize(fname)/1e6
os.makedirs('sm',exist_ok=True)
# --- msg 688: centre x/y of each embryo on the median of its curation-kept cells ---
for st in ['CS7','CS8']:
    m=(md.stage==st)&md.hasxyz
    for c in ['x_um','y_um']: md.loc[m,c]=md.loc[m,c]-md.loc[m&md.curated_kept.astype(bool),c].median()
# --- msg 698: final build (cells excluded by spatial curation left out), cell-type key and legends ---
_orig_md=md
def build2(stage,spec,smn,emb,fname):
    global md
    keep=md[~((md.stage==stage)&md.hasxyz&~md.curated_kept.astype(bool))]
    saved=md; md=keep
    try: out=build(stage,spec,smn,emb,fname)
    finally: md=saved
    return out
t1,k1,e1,s1=build2('CS7',CS7,1,'HuE#1 (CS7)','sm/Supplementary_Material_1_HuE1_CS7_3D.html')
t2,k2,e2,s2=build2('CS8',CS8,2,'HuE#2 (CS8)','sm/Supplementary_Material_2_HuE2_CS8_3D.html')
for f in ['sm/Supplementary_Material_1_HuE1_CS7_3D.html','sm/Supplementary_Material_2_HuE2_CS8_3D.html']:
    h=open(f).read(); print(f.split('/')[-1], 'excluded' in h, h.count('"type":"scatter3d"'))
print(k1,e1,k2,e2)
legend_md = """Supplementary Material 1. Interactive three-dimensional spatial map of HuE#1 (CS7), related to Figure 1
Each dot is one cell (83,774 cells) at its position in the three-dimensional reconstruction of the serial CosMx sections (x and y, section plane, centred on the embryo; z, section axis; µm). Cells are coloured and numbered by the 27 annotated cell types as in Figure 1E; the number of cells of each type is given in the legend. Drag to rotate, scroll to zoom, click a legend entry to hide or show a cell type and double-click to show it alone; hovering over a cell shows its cell type and section. The file opens in any web browser without an internet connection.

Supplementary Material 2. Interactive three-dimensional spatial map of HuE#2 (CS8), related to Figure 1
As in Supplementary Material 1, for HuE#2 (86,608 cells; 35 annotated cell types as in Figure 1F).
"""
open('sm/Supplementary_Materials_1-2_legends.txt','w').write(legend_md)
k=pd.concat([t1,t2]).drop(columns=['cells_spatially_excluded']); k.to_csv('sm/Supplementary_Materials_1-2_cell_type_key.csv',index=False); print(k.groupby('stage').cells_shown.sum().to_dict())
# --- msg 780 (definition) with the edits of msg 790 applied (0.1-99.9 percentile tile extent, marker size 3.0, tile 230 px) ---
import plotly.graph_objects as go, numpy as np
def build_sections(stage,spec,emb,fname,ncol=7,smn=None):
    s=md[(md.stage==stage)&md.hasxyz&md.curated_kept.astype(bool)].copy()
    secs=(s.groupby('section').agg(z=('z_um','first'),n=('cell','size')).reset_index().sort_values('z').reset_index(drop=True))
    qx=np.percentile(s.x_um,[0.1,99.9]); qy=np.percentile(s.y_um,[0.1,99.9]); mx,my=0.03*(qx[1]-qx[0]),0.03*(qy[1]-qy[0]); x0,x1=qx[0]-mx,qx[1]+mx; y0,y1=qy[0]-my,qy[1]+my
    Wd,Hd=x1-x0,y1-y0; gx,gy=0.08*Wd,0.22*Hd
    nrow=int(np.ceil(len(secs)/ncol))
    pos={}
    for k,row in secs.iterrows():
        r,c=divmod(k,ncol); pos[row.section]=(c*(Wd+gx)-x0, -r*(Hd+gy)-y1)   # shift so tile's top-left at (c*(W+gx), -r*(H+gy))
    s['X']=s.x_um+s.section.map(lambda v:pos[v][0]); s['Y']=s.y_um+s.section.map(lambda v:pos[v][1])
    s['num']=s.section.str.extract(r'-(\d+)$')[0]
    fig=go.Figure()
    for i,(lab,disp) in enumerate(spec,1):
        c=s[s['39Type']==lab]
        fig.add_trace(go.Scattergl(x=c.X.round(1),y=c.Y.round(1),mode='markers',name=f'{i}. {disp} (n = {len(c):,})',
            marker=dict(size=3.0,color=pal[lab],line=dict(width=0)),
            customdata=np.c_[c.num, c.z_um.round(0).astype(int)],
            hovertemplate=f'<b>{i}. {disp}</b><br>section #%{{customdata[0]}} (z = %{{customdata[1]}} µm)<extra></extra>'))
    shapes=[]; ann=[]; buttons=[]
    totW=ncol*(Wd+gx)-gx; totH=nrow*(Hd+gy)-gy
    full=dict(x=[-0.02*Wd,totW+0.02*Wd], y=[-totH-0.05*Hd, 0.2*Hd])
    buttons.append(dict(label='All sections',method='relayout',args=[{'xaxis.range':full['x'],'yaxis.range':full['y']}]))
    for k,row in secs.iterrows():
        r,c=divmod(k,ncol); L=c*(Wd+gx); T=-r*(Hd+gy)
        shapes.append(dict(type='rect',x0=L-0.02*Wd,x1=L+Wd+0.02*Wd,y0=T-Hd-0.02*Hd,y1=T+0.02*Hd,line=dict(color='#D9D9D9',width=0.8),fillcolor='rgba(0,0,0,0)',layer='below'))
        num=row.section.split('-')[-1]
        ann.append(dict(x=L,y=T+0.03*Hd,xanchor='left',yanchor='bottom',showarrow=False,
                        text=f'<b>#{num}</b>  z = {row.z:.0f} µm  ·  {row.n:,} cells',font=dict(size=10,color='#333')))
        buttons.append(dict(label=f'#{num} (z {row.z:.0f} µm)',method='relayout',
                            args=[{'xaxis.range':[L-0.05*Wd,L+Wd*1.05],'yaxis.range':[T-Hd*1.05,T+0.12*Hd]}]))
    # scale bar in first tile (bottom-left)
    sb=500; shapes.append(dict(type='line',x0=0.03*Wd,x1=0.03*Wd+sb,y0=-Hd*0.97,y1=-Hd*0.97,line=dict(color='black',width=2)))
    ann.append(dict(x=0.03*Wd+sb/2,y=-Hd*0.97,yanchor='bottom',showarrow=False,text=f'{sb} µm',font=dict(size=9)))
    title=(f'<b>{"Supplementary Material "+str(smn)+". " if smn else ""}Serial sections of {emb}</b> — {len(secs)} CosMx sections, {len(s):,} cells, {len(spec)} cell types'
           '<br><span style="font-size:12px">Sections are ordered by position along the section axis (left to right, top to bottom) and drawn in the common registered frame and scale. '
           'Click a legend entry to hide or show a cell type in all sections (double-click: show it alone); use the menu to zoom to one section; drag to zoom, double-click to reset.</span>')
    tile_px=230
    fig.update_layout(title=dict(text=title,x=0.01,font=dict(size=16,family='Arial')),template='plotly_white',font=dict(family='Arial'),
        shapes=shapes,annotations=ann,
        xaxis=dict(visible=False,range=full['x']),yaxis=dict(visible=False,range=full['y'],scaleanchor='x',scaleratio=1),
        legend=dict(itemsizing='constant',font=dict(size=11),tracegroupgap=0,x=1.005,y=1,bgcolor='rgba(255,255,255,0.9)'),
        updatemenus=[dict(buttons=buttons,direction='down',x=1.005,xanchor='left',y=1.035,yanchor='bottom',showactive=True,bgcolor='white',font=dict(size=11))],
        margin=dict(l=10,r=10,t=95,b=10),width=ncol*tile_px+420,height=int(nrow*tile_px*(Hd+gy)/(Wd+gx))+140,dragmode='zoom',hovermode='closest')
    fig.write_html(fname,include_plotlyjs=True,full_html=True,config=dict(displaylogo=False,scrollZoom=True,toImageButtonOptions=dict(format='png',scale=3,filename=os.path.basename(fname)[:-5])))
    return len(secs),len(s),os.path.getsize(fname)/1e6
# --- msg 790: build the 2D section pages ---
r1=build_sections('CS7',CS7,'HuE#1 (CS7)','sm/HuE1_CS7_2D_sections.html',ncol=7)
r2=build_sections('CS8',CS8,'HuE#2 (CS8)','sm/HuE2_CS8_2D_sections.html',ncol=7)
print(r1,r2)
for f in ['sm/HuE1_CS7_2D_sections.html','sm/HuE2_CS8_2D_sections.html']:
    h=open(f).read(); print(f, len(re.findall(r'<script[^>]+src="http',h)), h.count('"type":"scattergl"'), 'All sections' in h)