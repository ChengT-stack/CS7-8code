# Export of the embryonic-disc (three-germ-layer) cells of HuE#1 (CS7, obj6) and HuE#2 (CS8, obj7).
# Reconstructed verbatim from transcript frame 0f4081de (data-prep sub-agent of session 824ef1ce),
# messages [16] (export) and [22] (label_short fix: `39Type` is a factor and must be indexed as character).
# Only the input/output roots were changed. obj6 = true CS7, obj7 = true CS8.
# Input : $HGC_DATA/obj6_obj7_merged_curated_final.rds  (curated Seurat object; columns 39Type, curated_kept,
#         x_um/y_um/z_um, nCount_RNA, nFeature_RNA, disc_main_body, source_object, stage)
# Output: $HGC_DATA/cs7_cs8_matching/dataprep/export/{CS7,CS8}_counts.mtx, {CS7,CS8}_cells.csv, genes.csv,
#         cell_counts_per_type.csv, all_kept_cells_coords.csv
suppressPackageStartupMessages({library(Seurat); library(Matrix)})
DATA <- Sys.getenv("HGC_DATA", "data")
obj <- readRDS(file.path(DATA, "obj6_obj7_merged_curated_final.rds"))
md <- obj@meta.data

# ---- [16] export
short_map <- c("Epiblast (EPI)"="EPI","Ectoderm (ECT)"="ECT","Anterior ectoderm (aECT)"="aECT","Posterior ectoderm (pECT)"="pECT",
 "Caudal lateral epiblast (CLE)"="CLE","Non-neural ectoderm (NNE)"="NNE","Primitive streak (PS)"="PS","Anterior primitive streak (APS)"="APS",
 "Node"="Node","Notochord"="Notochord","Prechordal plate"="PrP","Nascent mesoderm (Nas.Meso)"="Nas.Meso","Paraxial mesoderm (Para.Meso)"="Para.Meso",
 "Rostral mesoderm (Rostral.Meso)"="Rostral.Meso","Lateral plate mesoderm (LP.Meso)"="LP.Meso","Heart mesoderm"="Heart.Meso",
 "Definitive endoderm (DE)"="DE","Anterior visceral endoderm (AVE)"="AVE","Visceral endoderm 1 (VE1)"="VE1","Visceral endoderm 2 (VE2)"="VE2")
keep <- md$curated_kept & md$`39Type` %in% names(short_map) & !is.na(md$x_um)
cat("kept:", sum(keep), "\n")
md$batch <- ifelse(md$source_object=="obj6","CS7", ifelse(grepl("^C7_CosMx42_", rownames(md)),"CS8_CosMx42FOV","CS8_main"))
md$embryo <- ifelse(md$source_object=="obj6","CS7","CS8")
counts <- LayerData(obj, assay="RNA", layer="counts")
stopifnot(all(colnames(counts)==rownames(md)))
outdir <- file.path(DATA, "cs7_cs8_matching", "dataprep", "export"); dir.create(outdir, showWarnings=FALSE, recursive=TRUE)
write.csv(data.frame(gene=rownames(counts)), file.path(outdir,"genes.csv"), row.names=FALSE)
cnt_all <- list()
for (emb in c("CS7","CS8")) {
  idx <- which(keep & md$embryo==emb)
  m <- md[idx,]
  zs <- sort(unique(m$z_um)); sec <- match(m$z_um, zs)
  cells <- data.frame(cell=rownames(m), label=m$`39Type`, label_short=unname(short_map[m$`39Type`]), stage=emb, stage_meta=m$stage,
                      x_um=m$x_um, y_um=m$y_um, z_um=m$z_um, nCount=m$nCount_RNA, nFeature=m$nFeature_RNA, batch=m$batch,
                      section=sec, disc_main_body=m$disc_main_body)
  write.csv(cells, file.path(outdir, paste0(emb,"_cells.csv")), row.names=FALSE)
  writeMM(counts[, idx], file.path(outdir, paste0(emb,"_counts.mtx")))
  tb <- table(cells$label_short); cnt_all[[emb]] <- tb
  cat(emb, ": cells", nrow(cells), " sections", length(zs), " z-range", range(zs), " nCount check", identical(m$nCount_RNA, m$nCount), "\n")
}
# full-embryo context for frame construction (all curated_kept cells, coords + label only)
ctx <- md[md$curated_kept & !is.na(md$x_um), c("cell","source_object","39Type","x_um","y_um","z_um","disc_main_body")]
ctx$embryo <- ifelse(ctx$source_object=="obj6","CS7","CS8"); colnames(ctx)[3] <- "label"
write.csv(ctx, file.path(outdir,"all_kept_cells_coords.csv"), row.names=FALSE)
cat(nrow(ctx), "\n")

# ---- [22] fix short labels (factor indexing) and rewrite the cells files; mtx column order is unaffected
for (emb in c("CS7","CS8")) {
  f <- file.path(outdir, paste0(emb,"_cells.csv")); cells <- read.csv(f)
  cells$label_short <- unname(short_map[as.character(cells$label)])
  stopifnot(!any(is.na(cells$label_short)))
  idx <- which(keep & md$embryo==emb); stopifnot(identical(cells$cell, rownames(md)[idx]))
  write.csv(cells, f, row.names=FALSE)
}
c7 <- read.csv(file.path(outdir,"CS7_cells.csv")); c8 <- read.csv(file.path(outdir,"CS8_cells.csv"))
ct <- data.frame(label_short=unname(short_map), label=names(short_map))
ct$CS7 <- sapply(ct$label_short, function(l) sum(c7$label_short==l, na.rm=TRUE))
ct$CS8 <- sapply(ct$label_short, function(l) sum(c8$label_short==l, na.rm=TRUE))
ct$total <- ct$CS7+ct$CS8
write.csv(ct, file.path(outdir,"cell_counts_per_type.csv"), row.names=FALSE)
print(ct, row.names=FALSE); cat(colSums(ct[,3:5]), "\n")
