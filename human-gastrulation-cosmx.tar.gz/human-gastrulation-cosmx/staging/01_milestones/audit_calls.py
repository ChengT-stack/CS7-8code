# staging/01_milestones/audit_calls.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/figure4_staging/milestone/audit.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Audit of milestone calls/windows for Figure 4A/B.
# Inputs: $HGC_DATA/milestone_evidence/mz/allstage/calls.csv (figure calls, 20261102 incl. 10x CS8)
#         evidence reviews out_cosmx|out_stereo|out_scrna|out_monkey (README_*.md, evidence_*.csv)
# Output: audited_calls.csv, call_changes.csv, windows_audited.csv (window rule identical to build.py)
import pandas as pd, numpy as np
B = (str(HGC_DATA) + '/milestone_evidence/')
OUT = (str(HGC_OUT) + '/figure4_staging/milestone/')
R, N, P, A = 'reached', 'not reached', 'partial', 'not assessable'
T = pd.read_csv(B + 'mz/allstage/calls.csv')
W0 = pd.read_csv(B + 'mz/allstage/windows.csv')
D = list(W0.dataset)
MID = {m: f"m{i+1:02d}" for i, m in enumerate(T.milestone)}
T.insert(0, 'milestone_id', [MID[m] for m in T.milestone])

# Changes adopted from the per-dataset evidence reviews (numbers quoted from README_*.md / evidence_*.csv)
CH = [
 ("HuE#1 CS7 (CosMx)", "m05", P, "cosmx", "GSC+CER1+ 2.55% of DE (n=2157) vs EPI 0.41%, but 0.40% of embryo-proper cells with DE alone (mouse onset threshold 0.54%); 0.57% only if the 371 AVE-labelled cells are counted; co-expression O/E 1.33, P=0.12 -> borderline"),
 ("HuE#1 CS7 (CosMx)", "m15", P, "cosmx", "PGC 53 cells (0.06% of kept cells); NANOS3 9.4% vs 5.0%, PRDM1 9.4% vs 4.2%, DPPA3 7.5% vs 7.3%: no marker meets onset rule (+5 pts and 2x)"),
 ("HuE#1 CS7 (CosMx)", "m18", P, "cosmx", "Al.Mes annotated (564 cells) but TBX4 4.6% vs 3.75%, HOXA10 3.7% vs 3.4% (background); TBX4+HOXA10+ 3/564"),
 ("HuE#2 CS8 (CosMx)", "m05", A, "cosmx", "GSC+CER1+ 1/1505 DE cells (0.07%) vs EPI 0.10%: ADE programme already regressed; 'reached' was inferred only (10x CS7/CS8 with same pattern scored not assessable)"),
 ("HuE#2 CS8 (CosMx)", "m09", P, "cosmx", "CLE annotated (2,351 cells) but NKX1-2 17.1% vs EPI 9.3% (1.84x), CDX2 21.1% vs 10.7% (1.97x): below 2x onset rule"),
 ("HuE#2 CS8 (CosMx)", "m10", A, "cosmx", "aECT HESX1 5.95% vs EPI 4.19%, SIX3 4.54% vs 2.67%; best subcluster 11.7/5.2% lower than CS7 (13.7/8.8%) - same criterion that made HuE#1 not assessable"),
 ("HuE#2 CS8 (CosMx)", "m11", A, "cosmx", "Para.Meso MEOX1 5.6% vs EPI 2.8%, TCF15 5.9% vs 4.3% (onset rule not met); best subcluster 5.7/13.2% vs CS7 8.3/11.1% - same criterion as HuE#1"),
 ("Tyser CS7 (Smart-seq2)", "m08", R, "scrna", "PS (n=202) HOXA1 43.1% vs bkg 2.0% (Fisher P=6e-16); milestone is Hoxa1+ OR Hoxb1+ PS; original call used HOXB1 only"),
 ("Tyser CS7 (Smart-seq2)", "m18", P, "scrna", "TBX4+HOXA10+ 0/1195 cells; Advanced-mesoderm subcluster (49) TBX4 12.2%, HOXA10 12.2% vs bkg 0/1.0% (mouse allantois E7.75 41.6/87.8%)"),
 ("In-house CS7 (10x)", "m13", P, "scrna", "HOXB8 23.5% (122/520; 95% CI 19.9-27.3%) in NKX1-2+CDX2+ cells vs onset threshold 22.6%: straddles threshold"),
 ("In-house CS7 (10x)", "m18", P, "scrna", "Allantois (684) TBX4 8.8%, HOXA10 17.1% vs bkg 0.1/0.8%; 2-5x below same-platform mouse allantois (41.6/87.8%)"),
 ("Cui CS7 (Stereo-seq)", "m09", P, "stereo", "CLE 282 spots NKX1-2+CDX2+ 3.2% vs 1.2% (9 spots); CS9 NMP control 26.7%"),
 ("Cui CS7 (Stereo-seq)", "m11", N, "stereo", "embryonic mesoderm MEOX1 0.1% vs 0.1%, TCF15 1.4% vs 1.3%; same-platform CS9 somite control MEOX1 62.5% -> markers detectable, absence = not reached"),
 ("Cui CS7 (Stereo-seq)", "m14", N, "stereo", "no cardiomyocyte spots; NKX2-5 0.5% in cardiac progenitors; CS9 cardiomyocyte control NKX2-5 73.9%"),
 ("Xiao CS8 (Stereo-seq)", "m11", N, "stereo", "embryonic mesoderm MEOX1 0.1% vs 0.0%, TCF15 0.9% vs 1.3%; CS9 somite control MEOX1 62.5%"),
 ("Xiao CS8 (Stereo-seq)", "m14", N, "stereo", "no cardiomyocyte spots; NKX2-5 0.5%; CS9 control NKX2-5 73.9%"),
 ("Xiao CS8 (Stereo-seq)", "m18", P, "stereo", "501 label-transferred allantois spots but TBX4 0.0% vs 0.1%, HOXA10 0.8% vs 0.5% (background; CS9 allantois control 1.5/3.4%)"),
 ("Monkey CS11-e1", "m07", A, "monkey", "best axial subcluster NOTO 0.0%, TBXT 1.7%; only 2 NOTO+ cells in embryo: notochord not sampled"),
]
TA = T.copy()
rows = []
for k, mid, new, src, why in CH:
    i = TA.index[TA.milestone_id == mid][0]
    old = TA.at[i, k]
    rows.append(dict(dataset=k, milestone_id=mid, milestone=TA.at[i, 'milestone'], mouse_onset=TA.at[i, 'mouse_onset'],
                     domain=TA.at[i, 'domain'], figure_call_20261102=old, audited_call=new, evidence_review=f"out_{src}/README_{src}.md", reason=why))
    TA.at[i, k] = new
    TA.at[i, k + ' | evidence'] = why
CHG = pd.DataFrame(rows)

def window(TT, k, onset_col='mouse_onset'):
    d = TT[(TT.domain == 'disc') & TT[onset_col].notna()]
    lo = d.loc[d[k] == R, onset_col].max(); hi = d.loc[d[k] == N, onset_col].min()
    if np.isnan(hi): hi = np.inf
    tied = lo >= hi
    if tied:
        grid = np.array([6.5, 6.75, 7.0, 7.25, 7.5, 7.75, 8.0, 8.25, 8.5]); j = np.searchsorted(grid, lo); lo, hi = grid[j-1], grid[j]
    return lo, hi, tied

def lab(lo, hi, tied):
    if np.isinf(hi): return f"≥E{lo:g}"
    if hi - lo <= 0.25 + 1e-9 and not tied: return f"≈E{(lo+hi)/2:g}"
    return f"E{lo:g}–{hi:g}"

def windows(TT, onset_col='mouse_onset'):
    out = []
    for k in D:
        lo, hi, tied = window(TT, k, onset_col)
        d = TT[(TT.domain == 'disc') & TT[onset_col].notna()]
        rmax = d.loc[d[k] == R, onset_col].max(); nmin = d.loc[d[k] == N, onset_col].min()
        out.append(dict(dataset=k, window_lo=lo, window_hi=hi, tied=tied, label=lab(lo, hi, tied),
                        latest_reached_onset=rmax, latest_reached=';'.join(d.loc[(d[k] == R) & (d[onset_col] == rmax), 'milestone_id']),
                        earliest_not_reached_onset=nmin, earliest_not_reached=';'.join(d.loc[(d[k] == N) & (d[onset_col] == nmin), 'milestone_id'])))
    return pd.DataFrame(out)

WA = windows(TA); WO = windows(T)
chk = WO.merge(W0, on='dataset', suffixes=('', '_csv'))
assert np.allclose(chk.window_lo, chk.window_lo_csv) and (chk.label == chk.label_csv).all(), 'build.py window rule not reproduced'
WA = WA.merge(WO[['dataset', 'label']].rename(columns={'label': 'label_figure_20261102'}), on='dataset')
WA['changed'] = WA.label != WA.label_figure_20261102
TA.to_csv(OUT + 'audited_calls.csv', index=False); CHG.to_csv(OUT + 'call_changes.csv', index=False); WA.to_csv(OUT + 'windows_audited.csv', index=False)
if __name__ == '__main__':
    print(WA[['dataset', 'label_figure_20261102', 'label', 'latest_reached', 'earliest_not_reached', 'changed']].to_string())
    print(len(CHG), CHG.groupby('dataset').size().to_dict())
