# cosmx/ — CosMx processing, annotation and display (human CS7/CS8 gastrulas)

Part of `human-gastrulation-cosmx` (MIT licence). Scripts in this module are the versions that produced the final figure panels of the manuscript (v8), recovered from the authors' shared folders, the analysis platform's artifact store and its execution log. They were edited only for portability: absolute paths replaced by `HGC_DATA` / `HGC_OUT`, platform-specific calls removed, font folder made optional. Algorithms, parameters, thresholds and random seeds are unchanged. Per-file origin and sha256 of the original are in [PROVENANCE.md](PROVENANCE.md) and in the header of every script.

Naming: obj6 = HuE#1 (true CS7), obj7 = HuE#2 (true CS8); older file names call them CS6/CS7. Stored HuE#2 labels `Epiblast (EPI)`, `Anterior ectoderm (aECT)`, `Posterior ectoderm (pECT)` are displayed as EPI1, ECT, EPI2; ADE in some file names is AVE. Final annotation column: `39Type`.

## Environment variables

- `HGC_DATA` (default `data`): folder with the raw inputs below.
- `HGC_OUT` (default `results`): every script changes into this folder; all intermediates and outputs are written there with the relative names used in the original runs.
- `HGC_FONTS` (optional): folder with `arial*.ttf`; without it matplotlib falls back to its default font (figure text metrics then differ slightly).

Python scripts are run as `python cosmx/<dir>/<script>.py`; R scripts as `Rscript cosmx/<dir>/<script>.R`. Scripts that take parameters read them from environment variables as in the original runs (`STAGE`, `POPS`, `EXPORT`, `PREFIX`).

## Expected inputs

| path under `$HGC_DATA` | content | produced by |
|---|---|---|
| `obj6_obj7_merged_curated_final.rds` | final merged Seurat 5 object, 171,376 cells x 18,934 genes; columns `39Type`, `Type39_curated`, `curated_kept`, `stage`, `source_object`, `x_um/y_um/z_um`, `disc_main_body`; `@misc` curation notes | authors (G:/ovary; 7.97 GB) |
| `dataprep/export/genes.csv`, `dataprep/export/{CS7,CS8}_counts.mtx`, `dataprep/export/{CS7,CS8}_cells.csv` | embryonic-disc cells (CS7 17,663; CS8 31,041) raw counts and labels (`label_short`, `nCount`, `section`, x/y/z) | AIGG-OT data-preparation module (`cs7_cs8_matching/dataprep`) |
| `dataprep/frames/{CS7,CS8}_frames.csv` | anatomical frame per disc cell (`AP_um`, `AP_arc_um`, `AP_arc_frac`, `LR_um`, `DV_um_to_surface`, ...) | AIGG-OT data-preparation module |
| `cs8_kept_counts.h5ad` | 86,608 curation-kept HuE#2 cells x 18,934 genes, raw counts; obs `label`, `disc`, `x`, `y`, `z`, `nCount` | `preprocessing/export_cs8_full.R` + packing step (see GAPS) |
| `obj6.rds`, `obj7.rds` | pre-merge single-embryo objects (HuE#1, HuE#2) | authors; only for `annotation/` |
| `CS7ref.rds`, `CS7_final_3d.RDS` | in-house 10x reference (Type3L; unpublished) and the HuE#2 object at the time of RCTD | authors; only for `annotation/rctd_main_type3l.R` |

No supplementary-table (Table S1–S4) inputs are read by this module. Intermediate folders written inside `$HGC_OUT`: `handoff/`, `hm/`, `hox/`, `lr/`, `out/`, `sm/`, `endo/`, `nb_bundle/`.

## Run order

1. preprocessing/export_meta.R  (final_meta.csv.gz)
2. preprocessing/export_misc.R  (type39_scheme.csv, cell_slice_mapping.csv.gz, curation notes)
3. preprocessing/qc_per_cell_export.R -> preprocessing/plot_SuppFig1EF_qc.py  (Supplementary Figure 1E-F)
4. preprocessing/export_cs8_full.R  (contents of cs8_kept_counts.h5ad; pack to HGC_DATA/cs8_kept_counts.h5ad)
5. [annotation, historical; needs pre-merge objects] annotation/rctd_main_type3l.R, annotation/endoderm_nohist_gnrh2.R, annotation/adjudicate_components.R
6. heatmaps/export_heatmap_tables.R, heatmaps/export_heatmap_tables_S3.R, heatmaps/export_heatmap_additions.R
7. heatmaps/merge_v2_tables.py
8. heatmaps/build_SuppFig2_heatmaps_v3_hema.py (Supplementary Figure 2A) ; heatmaps/build_SuppFig2_heatmaps_v2.py (Supplementary Figure 2B) ; heatmaps/build_SuppFig3_heatmap_v2.py (Supplementary Figure 3A)
9. visualisation/export_ps6_cp10k.R -> STAGE=CS7 visualisation/build_ps_vs_aps_bar6.py  (Figure 2C)
10. visualisation/node_dv_terciles.py (Figure 2I values) ; visualisation/node_section_categories.py (Figure 2H cell categories)
11. visualisation/build_fig_bmp2_endo.py (Supplementary Figure 5F) ; visualisation/build_cs7_3dview_gene.py GENE... (Supplementary Figure 4B-style panels)
12. signalling/export_cs7_curve_frame.R, signalling/export_five.R, signalling/export_seven.R
13. signalling/seven_pop_trends.py (CS7 set-level curves; Figure 4A/4B specification)
14. POPS=EPI,ECT,Node,APS,PS EXPORT=five PREFIX=cs7_five_pop signalling/seven_pop_genes.py (Supplementary Figure 6A) ; POPS=DE,AVE,VE1,VE2 EXPORT=seven PREFIX=cs7_endo4 signalling/seven_pop_genes.py (Supplementary Figure 6B)
15. signalling/cs8_genes.py (Supplementary Figure 6C; default POPS=EPI,Node,PS) ; POPS="Heart mesoderm,Prechordal plate,Notochord,Rostral.Meso,Node,PS" PREFIX=cs8_heart_axial (population list reconstructed from the legend; not recorded) signalling/cs8_genes.py (Supplementary Figure 6D)
16. signalling/export_cs8_meta.R -> signalling/fig4CD_SF6E_cs8_pathway_curves.py (Figure 4C, 4D; Supplementary Figure 6E)
17. hox/compute_hox_ap_figdata.py -> hox/build_fig3L_hox_ap.py -> hox/split_fig3L_3M_panels.py  (Figure 3L, 3M)
18. left_right/lr_asym_lpm.py (Supplementary Figure 5D) ; left_right/compute_lpm_map_profiles_data.py -> left_right/build_lpm_map_profiles.py (Supplementary Figure 5E) ; [optional HuE#1: left_right/export_cs7_disc.R -> STAGE=CS7 left_right/lr_asym.py]
19. visualisation/build_supp_materials_1_2_and_sections.py  (Supplementary Materials 1-2 and the 2D section pages)

## Methods → script → panel

| Methods section [P#] / legend | script(s) | figure / table panel |
|---|---|---|
| CosMx SMI data acquisition and processing [P329–P333] | — (AtoMx vendor platform) | — |
| Data processing, segmentation, 3D reconstruction [P339–P340] | — (AtoMx; Spateo serial-section alignment not recovered) | — |
| Quality control and normalization [P342–P343] | `preprocessing/qc_per_cell_export.R`, `preprocessing/plot_SuppFig1EF_qc.py`; CP10K/log1p inside each script | Supplementary Figure 1E–F |
| Cell-type annotation [P345–P346] | `annotation/rctd_main_type3l.R` (HuE#2), `annotation/endoderm_nohist_gnrh2.R`, `annotation/adjudicate_components.R`, `annotation/CURATION_NOTES.md` | labels used by all panels |
| Marker heatmaps [P348–P349] | `heatmaps/export_heatmap_tables*.R`, `heatmaps/export_heatmap_additions.R`, `heatmaps/merge_v2_tables.py`, `heatmaps/build_SuppFig2_heatmaps_v3_hema.py`, `heatmaps/build_SuppFig2_heatmaps_v2.py`, `heatmaps/build_SuppFig3_heatmap_v2.py`, `heatmaps/scheme39.py` | Supplementary Figure 2A, 2B; Supplementary Figure 3A |
| Anatomical coordinate frame and 3D projections [P351–P352] | landmark frame inside `signalling/seven_pop_trends.py`, `signalling/fig4CD_SF6E_cs8_pathway_curves.py`; `visualisation/build_fig_bmp2_endo.py`; `visualisation/build_cs7_3dview_gene.py`; `visualisation/build_supp_materials_1_2_and_sections.py` | Supplementary Figure 5F; SF4B-style gene panels; Supplementary Materials 1–2 (+2D section pages). KDE-outlined dorsal views (Fig. 1H, 1J, 2L) not recovered |
| Marker positivity and co-detection [P354–P355] | `visualisation/node_dv_terciles.py`, `visualisation/node_section_categories.py`, `visualisation/export_ps6_cp10k.R` + `visualisation/build_ps_vs_aps_bar6.py` | Figure 2I (values), 2H (cell categories), 2C |
| Anterior–posterior expression profiles [P357–P358] and signalling trends [P360–P361] | `signalling/export_cs7_curve_frame.R`, `signalling/export_five.R`, `signalling/export_seven.R`, `signalling/seven_pop_trends.py`, `signalling/seven_pop_genes.py`, `signalling/cs8_genes.py` + `gene_curves_body.py`, `signalling/export_cs8_meta.R`, `signalling/fig4CD_SF6E_cs8_pathway_curves.py`, `common/pathway_gene_sets.py` | Figure 4A/4B (specification; see uncertain), 4C, 4D; Supplementary Figure 6A–E |
| HOX group scores (Figure 3L/3M legends) | `hox/compute_hox_ap_figdata.py`, `hox/build_fig3L_hox_ap.py`, `hox/split_fig3L_3M_panels.py` | Figure 3L, 3M |
| LP.Meso left–right comparison (SF5D–E legends; labelled C–E in the task) | `left_right/lr_asym.py`, `left_right/lr_asym_lpm.py`, `left_right/compute_lpm_map_profiles_data.py`, `left_right/build_lpm_map_profiles.py`, `left_right/export_cs7_disc.R` | Supplementary Figure 5D, 5E |
| Cell–cell communication [P363–P364] | `cellphonedb/README.md` (code not recovered) | Figure 5E, 5G |
| Supplementary Materials 1–2 legends [P574–P578] | `preprocessing/export_meta.R`, `preprocessing/export_misc.R`, `visualisation/build_supp_materials_1_2_and_sections.py` | Supplementary Materials 1–2; HuE1/HuE2 2D section pages |

## Dependencies

Python: python 3.11, numpy 2.4.6, pandas 2.3.3, scipy 1.17.1, statsmodels 0.14.6, matplotlib 3.11.x (3.11.0-3.11.2 across envs), anndata 0.12.19, plotly 6.9.0 / 7.1.0 (Supplementary Materials 1-2 built with the python env, plotly 7.1.0), pymupdf 2.0 (HOX panel split), scikit-learn 1.9.x (not used by included scripts), openpyxl 3.1.5 (xlsx source data), CellPhoneDB 5.0.1 (database 5.0.0) — Methods only; script missing.

R: R 4.5.3 per KRT (scrna env currently 4.3.3), Seurat 5.5.1 per KRT (scrna env currently 5.3.0), Matrix 1.6.5, data.table 1.17.8 (fwrite), spacexr 2.2.1 (RCTD), harmony (Methods; not used by included scripts).

## Gaps (Methods steps without recovered code)

- CosMx SMI acquisition and AtoMx processing [P330-P333, P340]: run in the vendor platform (fiducial registration, decoding, nuclear+membrane segmentation, export of cell x gene matrices, metadata and transcript coordinates); no code by design.
- Serial-section 3D reconstruction with Spateo [P340]: no script found. F:/CS6-CS7/spateo_run contains a later, exploratory cross-stage Morpho registration (CS7 endoderm onto CS8; morphofield/morphopath) that the project memory records as a negative result and that no figure uses; it is NOT the serial-section alignment and is not included. The x/y/z_um coordinates entered the project already reconstructed (cell_coordinates.csv joined in F:/claude/add_coords.R, June 2026).
- Import into Seurat and the <100-transcript filter [P340, P343]: the filter was applied before the objects used here were built (pre-project / earlier project); no code found. qc_per_cell_export.R only summarises the filtered objects.
- RCTD for HuE#1 [P346]: only the HuE#2 run (annotation/rctd_main_type3l.R, object then called CS7_final_3d) was found; no HuE#1 RCTD script.
- Manual curation write-back [P346]: the steps that wrote Type39_revised -> Type39_curated -> 39Type, the spatial trimming flags (curated_kept) and the obj7 classifier adjudication were run interactively in session 0b0712b4 (R and Python kernels); only the feature-export / re-clustering scripts and the rules (annotation/CURATION_NOTES.md) are available. The final 39Type column of G:/ovary/obj6_obj7_merged_curated_final.rds was supplied by the user.
- UMAPs (Figure 1E-F): no producing script for the final per-embryo UMAP panels was identified (earlier Harmony UMAP builds exist in session 0b0712b4, e.g. umap_CS7_CS8_harmony_curated.pdf, but the final panels follow a later layout).
- Anatomical coordinate frame [P352]: the landmark frames used by most scripts (dataprep/frames/{CS7,CS8}_frames.csv: AP_um, AP_arc_um, LR_um, DV_um_to_surface ...) and dataprep/export/* were produced by the AIGG-OT data-preparation code (other module, cs7_cs8_matching/dataprep); the CS7/CS8 landmark-frame code embedded in seven_pop_trends.py and fig4CD_SF6E_cs8_pathway_curves.py is included here.
- Dorsal/lateral 3D projections with KDE outlines (Figure 1H, 1J, 2L; Supplementary Figure 4B, 5B, 4E; Figure 5D): no producing scripts found for the final panels (the KDE 50% contours and density maps). build_cs7_3dview_gene.py only reproduces the SF4B panel geometry for added genes.
- Marker positivity / co-detection panels other than 2C, 2H-I (Figure 2M, 3F, 3I; SF4E bottom): table-level code not recovered as standalone scripts (fragments build_fig2m_src.py, build_fig3_src.py, build_fig7_src.py in session 5113e657 depend on kernel state).
- Figure 2H/2I drawing (Fig2K_CS7_node_two_tiers.ai): figure code lives in session 5113e657 kernel (cells up to 2002) and is not standalone; only the statistics (node_dv_terciles.py) and the cell categories (node_section_categories.py) are included.
- Figure 4A (CS7 EPI/ECT/node/APS/PS set curves, cs7_five_pop_ap_trends, 2026-09-20): produced interactively in session 0b0712b4 kernel cells ~1732-1768 (exec id 3a01e9ac-9e81-47fb-871a-19444354c09e) and not saved as a script; seven_pop_trends.py states and asserts the same specification (frame, band, kernel, gene sets) for its population set.
- Figure 4E (CS8 endoderm DE/VE1/VE2 set curves): producer not identified among the final scripts (candidate: cs8_endo_ap_trends, session 0b0712b4, 2026-09-20, kernel code only).
- Exact POPS value used for Supplementary Figure 6D (cs8_heart_axial_gene_curves): not recorded in a file; README gives the populations named in the legend.
- CellPhoneDB (Figure 5E, 5G) [P364]: no code for the Figure 5 runs found (see cellphonedb/README.md).
- cs8_kept_counts.h5ad packing step (counts.mtx + obs.csv + genes.csv -> AnnData): not found as code.

## Points for the authors to confirm

- Figure 4B: seven_pop_trends.py is the saved script for the CS7 endoderm-containing set (DE, AVE, VE1, VE2, Node, APS, PS); the v8 legend lists only DE, AVE, VE1, VE2, so the final panel may come from a 4-population variant not saved as a file.
- Supplementary Figure 2A: two final-day versions exist (v2 at 14:43 without small types; v3_hema at 18:40 with Hema and other <MIN_CELLS types). v3_hema was chosen because the v8 legend numbers 27 HuE#1 types as in Figure 1E.
- Several scripts are reconstructions from the platform execution log (kernel cell sources concatenated in execution order); diagnostics were dropped, but state from earlier cells was not re-verified by running (no heavy re-runs, as instructed).
- node_section_categories.py uses the platform's lineage extraction text (LLM-derived) for a 10-line computation; it was checked by eye against the raw kernel tail but not executed.
- Fig 4C/4D/SF6E code uses Type39_curated (identical to 39Type for HuE#2).
- lr_asym_lpm.py on disk is the copy after an axes-height sed edit (session 0b0712b4 bash cell 2331), i.e. the version that produced the final cs8_lpm_lr_asymmetry.pdf.
- Package versions: KRT lists R 4.5.3 / Seurat 5.5.1 and matplotlib 3.11.1; the current `scrna` env reports R 4.3.3 / Seurat 5.3.0 and the `python` env matplotlib 3.11.0, so the runtime versions of individual runs may differ from the KRT.
- build_fig_bmp2_endo.py: the disk copy (post-edit) differs from artifact b87a074e; the disk copy is the one that produced the final .ai (copied there by the producing bash cell).
