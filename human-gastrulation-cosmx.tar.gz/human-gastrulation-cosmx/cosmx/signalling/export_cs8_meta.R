# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: artifact 299d4d4b exp_meta.R (session 5113e657 bash cell 1943, 2026-11-04)
# sha256 of original: dbc709194a74d07e051e10f25658de52435111a20defe2605c0c03fa197de5ad
# Methods paragraphs: P358, P361
# Produces: cs8_meta_final.csv (HuE#2 metadata incl. Type39_curated, curated_kept, x/y/z)
# Edits/notes: object path -> HGC_DATA.
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

suppressMessages(library(Seurat))
f <- file.path(DATA, "obj6_obj7_merged_curated_final.rds")
x <- readRDS(f); m <- x@meta.data
cat(f, ncol(x), "\n"); print(table(m$stage)); print(colnames(m))
m$cell <- rownames(m)
write.csv(m[m$stage=="CS8", intersect(c("cell","stage","Type39_curated","Type39_revised","label_original","curated_kept","disc_main_body","disc_status","x_um","y_um","z_um","nCount","nCount_RNA"), colnames(m))], "cs8_meta_final.csv", row.names=FALSE)
