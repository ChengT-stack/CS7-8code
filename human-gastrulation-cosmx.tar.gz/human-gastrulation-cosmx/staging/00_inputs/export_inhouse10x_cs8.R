# staging/00_inputs/export_inhouse10x_cs8.R
# Source: drive G: data/milestone_evidence/hue11/export.R
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
HGC_DATA <- Sys.getenv('HGC_DATA', 'data')
HGC_OUT <- Sys.getenv('HGC_OUT', 'results')

suppressMessages({library(Seurat);library(Matrix)})
x<-readRDS(paste0(HGC_DATA, '/hue11-100512.rds'))
md<-x@meta.data; um<-Embeddings(x,'umap')
for(s in c('CS8-16')){
  cells<-rownames(md)[md$sample==s]
  m<-LayerData(x,assay='RNA',layer='counts')[,cells]
  writeMM(m,paste0(s,'_counts.mtx')); writeLines(rownames(m),paste0(s,'_genes.txt'))
  d<-md[cells,c('sample','stage','nCount_RNA','nFeature_RNA','percent.mt','doublet2','Type','Types','Type2','Type3','cell_type','Type3L')]
  d$umap1<-um[cells,1]; d$umap2<-um[cells,2]; d$cell<-cells
  write.csv(d,paste0(s,'_meta.csv'),row.names=FALSE)
}
# all-sample table for CS7-15 check
d<-md[,c('sample','Type2')]; write.csv(as.data.frame(table(d$sample,d$Type2)),'sample_type2_counts.csv',row.names=FALSE)
cat('done\n')
