# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/cs7_cs8_matching/figure4_staging/endoderm_markers/build_fig_bmp2_endo.py (final edited
#     copy, session 824ef1ce bash cell 983; artifact b87a074e is the pre-edit version)
# sha256 of original: a53edee30a3966cf9a11194a4b485f1dbf3d8f8aa26fc6cec7f9728f92c4866a
# Methods paragraphs: P352 (lateral views), Supplementary Figure 5F legend
# Produces: endo/CS8_endoderm_BMP2_receptors_3D.{png,pdf,svg,ai} and _detection.csv (Supplementary Figure 5F;
#     artifact 173a3abf)
# Edits/notes: dataprep paths -> HGC_DATA; font folder -> HGC_FONTS.
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

import scipy.io, os
import numpy as np, pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm

FD = os.path.join(FONT_DIR, "")
for f in ["arial.ttf", "arialbd.ttf", "ariali.ttf", "arialbi.ttf"]:
    if os.path.exists(FD + f):
        fm.fontManager.addfont(FD + f)
mpl.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
                     "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
                     "axes.unicode_minus": False})

E = (str(DATA) + "/dataprep/export/")
genes = pd.read_csv(E + "genes.csv").gene.astype(str).values
cells8 = pd.read_csv(E + "CS8_cells.csv")
fr = pd.read_csv((str(DATA) + "/dataprep/frames/CS8_frames.csv"),
                 usecols=["cell", "label_short", "AP_um", "LR_um", "DV_um"])
assert (fr.cell.values == cells8.cell.values).all()
X8 = scipy.io.mmread(E + "CS8_counts.mtx").tocsr()

GL = [("ligand", ["BMP2"]),
      ("type I receptors", ["BMPR1A", "BMPR1B", "ACVR1"]),
      ("type II receptors", ["BMPR2", "ACVR2A", "ACVR2B"])]
GG = [g for _, gl in GL for g in gl]
gi = [int(np.where(genes == g)[0][0]) for g in GG]
POPS = ["DE", "VE1", "VE2"]
sel = fr.label_short.isin(POPS).values
sub = fr[sel].reset_index(drop=True)
cnt = pd.DataFrame(X8[gi][:, np.where(sel)[0]].T.toarray(), columns=GG)
ncount = cells8.nCount.values[sel]
lognorm = np.log1p(cnt.values / ncount[:, None] * 1e4)

# detection table (source data)
det = pd.DataFrame({p: (cnt[sub.label_short.values == p] > 0).mean() * 100 for p in POPS}).T
det["n_cells"] = [int((sub.label_short == p).sum()) for p in POPS]

MM = 1 / 25.4
F0, F1, F2, FL = 6.5, 6, 5, 8
PCOL = {"DE": "#2e8b57", "VE1": "#e08a1e", "VE2": "#7b52ab"}
CMAP = mpl.colors.ListedColormap(mpl.colormaps["plasma"](np.linspace(0.0, 0.9, 256)))
GREY = "#d9d9d9"

W, H = 180, 100
fig = plt.figure(figsize=(W * MM, H * MM))
def axmm(x0, y0, w, h):
    return fig.add_axes([x0 / W, y0 / H, w / W, h / H])

AP0, AP1 = -840, 620
LR0, LR1 = -305, 275
DV0, DV1 = -340, 800
COLW, GAP, X0 = 20.0, 1.4, 7.0           # column width / gap / left margin (mm)
sd = 36.0 / (AP1 - AP0)                  # dorsal row scale (mm per µm)
sl = COLW / (DV1 - DV0)                  # lateral row scale (mm per µm)
wd, hd = (LR1 - LR0) * sd, (AP1 - AP0) * sd
wl, hl = (DV1 - DV0) * sl, (AP1 - AP0) * sl
COLS = ["pop"] + GG
cx = {c: X0 + i * (COLW + GAP) + (GAP if i > 0 else 0) for i, c in enumerate(COLS)}

def panel(ax, xc, x0, x1, gene=None):
    ax.set_xlim(x0, x1); ax.set_ylim(AP1, AP0)       # anterior up
    ax.axis("off")
    x = sub[xc].values; y = sub.AP_um.values
    if gene is None:
        for p in POPS:
            m = sub.label_short.values == p
            ax.scatter(x[m], y[m], s=0.35, c=PCOL[p], lw=0, rasterized=True)
        return
    v = lognorm[:, GG.index(gene)]
    pos = v > 0
    ax.scatter(x[~pos], y[~pos], s=0.3, c=GREY, lw=0, rasterized=True)
    vmax = np.quantile(v[pos], 0.99)
    o = np.argsort(v[pos])
    ax.scatter(x[pos][o], y[pos][o], s=0.9, c=np.clip(v[pos][o] / vmax, 0, 1), cmap=CMAP,
               vmin=0, vmax=1, lw=0, rasterized=True)

def row(y0, xc, x0, x1, w, h, sc, title, letter_, groups):
    yt = y0 + h + (8.5 if groups else 3.5)
    fig.text(1 / W, yt / H, letter_, fontsize=FL, fontweight="bold", va="bottom")
    fig.text(5 / W, (yt + 0.3) / H, title, fontsize=F0, va="bottom")
    for c in COLS:
        xa = cx[c] + (COLW - w) / 2
        ax = axmm(xa, y0, w, h)
        panel(ax, xc, x0, x1, None if c == "pop" else c)
        ax.text(0.5, 1.0, "DE / VE1 / VE2" if c == "pop" else c, transform=ax.transAxes,
                ha="center", va="bottom", fontsize=F1, style="normal" if c == "pop" else "italic")
        if c == "pop":
            # anterior arrow left of panel; scale bar below panel
            fig.add_artist(mpl.patches.FancyArrowPatch(((cx[c] - 3.2) / W, (y0 + h - 7) / H),
                           ((cx[c] - 3.2) / W, (y0 + h) / H), transform=fig.transFigure,
                           arrowstyle="-|>", mutation_scale=5, lw=0.6, color="k"))
            fig.text((cx[c] - 4.9) / W, (y0 + h - 3.5) / H, "anterior", rotation=90,
                     ha="center", va="center", fontsize=F2)
            xb = xa + w - 200 * sc
            fig.add_artist(plt.Line2D([xb / W, (xa + w) / W], [(y0 - 1.2) / H] * 2, c="k", lw=0.8,
                                      solid_capstyle="butt"))
            fig.text((xb + 100 * sc) / W, (y0 - 1.7) / H, "200 µm", ha="center", va="top", fontsize=F2)
    if groups:
        for gname, gl in GL:
            a = cx[gl[0]] + 1.0; b = cx[gl[-1]] + COLW - 1.0
            fig.add_artist(plt.Line2D([a / W, b / W], [(y0 + h + 4.2) / H] * 2, c="0.25", lw=0.5))
            fig.text((a + b) / 2 / W, (y0 + h + 4.6) / H, gname, ha="center", va="bottom", fontsize=F2)

yl = 6.0
row(yl, "DV_um", DV0, DV1, wl, hl, sl, "Lateral view (ventral left, dorsal right)", "B", False)
yd = yl + hl + 12.5
row(yd, "LR_um", LR0, LR1, wd, hd, sd, "Dorsal view", "A", True)
ytit = yd + hd + 15.5
fig.text(1 / W, ytit / H, "3D reconstruction of DE, VE1 and VE2 (CS8): BMP2 and its receptors",
         fontsize=F0 + 0.5, va="bottom", fontweight="bold")

# legend (top right): populations, not detected, colourbar
lax = axmm(84, ytit - 0.6, 52, 4); lax.set_xlim(0, 52); lax.set_ylim(0, 4); lax.axis("off")
xx = 0
for p in POPS + ["not detected"]:
    lax.scatter([xx + 0.8], [2], s=6, c=PCOL.get(p, GREY), lw=0)
    t = p if p == "not detected" else f"{p} ({det.loc[p, 'n_cells']:,})"
    lax.text(xx + 1.8, 2, t, fontsize=F2, va="center")
    xx += 12.5 if p != "not detected" else 0
cax = axmm(156, ytit + 0.6, 16, 1.3)
cb = fig.colorbar(mpl.cm.ScalarMappable(norm=mpl.colors.Normalize(0, 1), cmap=CMAP), cax=cax,
                  orientation="horizontal")
cb.set_ticks([0, 1]); cb.set_ticklabels(["low", "high"])
cb.ax.tick_params(labelsize=F2, length=1, pad=0.8); cb.outline.set_linewidth(0.3)
fig.text(154.5 / W, (ytit + 1.25) / H, "expression\n(scaled per gene)", fontsize=F2, ha="right", va="center", linespacing=1.0)

os.makedirs("endo", exist_ok=True)
base = "endo/CS8_endoderm_BMP2_receptors_3D"
fig.savefig(base + ".png", dpi=600)
fig.savefig(base + ".pdf"); fig.savefig(base + ".svg"); fig.savefig(base + ".ai", format="pdf")
det.round(1).to_csv(base + "_detection.csv")
