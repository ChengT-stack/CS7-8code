# gastruloid/01_preprocess/export_hamazaki.R
# Source: reconstructed from transcript 824ef1ce (messages 4859-6166)
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
HGC_DATA <- Sys.getenv('HGC_DATA', 'data')
HGC_OUT <- Sys.getenv('HGC_OUT', 'results')

# Export counts and metadata of the Hamazaki et al. GSE208369 Seurat objects (8 samples) to MatrixMarket/CSV.
# Reconstructed verbatim from session transcript 824ef1ce (R cells run in a persistent R session).
suppressMessages({library(Seurat); library(Matrix)})
o <- readRDS(paste0(HGC_DATA, "/GSE208369/GSM6341942_hGas_72h.RDS"))   # loaded in the preceding cell (message 4859)


# ---- cell [frame 824ef1ce, message 4861] Exporting gastruloid counts and metadata
library(Matrix)
od <- paste0(HGC_DATA, "/GSE208369/export/"); dir.create(od, showWarnings=FALSE)
exp1 <- function(o, tag){
  X <- GetAssayData(o, assay="RNA", layer="counts")
  writeMM(X, paste0(od,tag,"_counts.mtx"))
  write.csv(data.frame(gene=rownames(X)), paste0(od,tag,"_genes.csv"), row.names=FALSE)
  md <- o@meta.data; md$cell <- colnames(X); um <- Embeddings(o,"umap"); md$UMAP1 <- um[,1]; md$UMAP2 <- um[,2]
  write.csv(md, paste0(od,tag,"_meta.csv"), row.names=FALSE)
  cat(tag, dim(X), "\n")
}
exp1(o,"hGas_72h"); rm(o); gc()
o96 <- readRDS(paste0(HGC_DATA, "/GSE208369/GSM6341943_hGas_96h.RDS")); print(o96); exp1(o96,"hGas_96h"); rm(o96); gc()


# ---- cell [frame 824ef1ce, message 4883] Exporting 48 h gastruloid data
o48 <- readRDS(paste0(HGC_DATA, "/GSE208369/GSM6341941_hGas_48h.RDS")); print(o48)
DefaultAssay(o48) <- "RNA"
exp1(o48,"hGas_48h"); print(table(o48$seurat_clusters)); rm(o48); gc()


# ---- cell [frame 824ef1ce, message 5992] Exporting 0 h, 24 h and RA 96 h gastruloid counts
suppressPackageStartupMessages({library(Seurat); library(Matrix)})
D <- paste0(HGC_DATA, "/GSE208369/")
for (nm in c("GSM6341939_hGas_0h","GSM6341940_hGas_24h","GSM6341944_RA_hGas_96h")) {
  f <- paste0(D, nm, ".RDS"); if (!file.exists(f)) system(paste0("gunzip -k ", f, ".gz"))
  o <- readRDS(f); tag <- sub("^GSM[0-9]+_", "", nm)
  as_ <- DefaultAssay(o); cat(tag, class(o), dim(o), "assays:", names(o@assays), "default:", as_, "\n")
  cnt <- tryCatch(GetAssayData(o, assay="RNA", layer="counts"), error=function(e) GetAssayData(o, assay="RNA", slot="counts"))
  md <- o@meta.data; md$cell <- colnames(o)
  if ("umap" %in% names(o@reductions)) { u <- Embeddings(o, "umap"); md$UMAP1 <- u[,1]; md$UMAP2 <- u[,2] }
  writeMM(cnt, paste0(D, "export/", tag, "_counts.mtx")); write.csv(data.frame(gene=rownames(cnt)), paste0(D, "export/", tag, "_genes.csv"), row.names=FALSE)
  write.csv(md, paste0(D, "export/", tag, "_meta.csv"), row.names=FALSE)
  cat("  cells", ncol(cnt), "genes", nrow(cnt), "median UMI", median(colSums(cnt)), "cols:", paste(colnames(md), collapse=","), "\n")
  rm(o, cnt); gc()
}


# ---- cell [frame 824ef1ce, message 6122] Exporting Hamazaki RA 120 h counts
suppressPackageStartupMessages({library(Seurat); library(Matrix)})
D <- paste0(HGC_DATA, "/GSE208369/")
exp1 <- function(nm) {
  f <- paste0(D, nm, ".RDS"); if (!file.exists(f)) system(paste0("gunzip -k ", f, ".gz"))
  o <- readRDS(f); tag <- sub("^GSM[0-9]+_", "", nm)
  cat(tag, class(o), dim(o), "assays:", names(o@assays), "\n")
  cnt <- tryCatch(GetAssayData(o, assay="RNA", layer="counts"), error=function(e) GetAssayData(o, assay="RNA", slot="counts"))
  md <- o@meta.data; md$cell <- colnames(o)
  if ("umap" %in% names(o@reductions)) { u <- Embeddings(o, "umap"); md$UMAP1 <- u[,1]; md$UMAP2 <- u[,2] }
  writeMM(cnt, paste0(D, "export/", tag, "_counts.mtx")); write.csv(data.frame(gene=rownames(cnt)), paste0(D, "export/", tag, "_genes.csv"), row.names=FALSE)
  write.csv(md, paste0(D, "export/", tag, "_meta.csv"), row.names=FALSE)
  cat("  cells", ncol(cnt), "genes", nrow(cnt), "median UMI", median(colSums(cnt)), "cols:", paste(colnames(md), collapse=","), "\n")
}
exp1("GSM6341945_RA_hGas_120h")


# ---- cell [frame 824ef1ce, message 6166] Exporting Hamazaki RA+LDN counts
suppressPackageStartupMessages({library(Seurat); library(Matrix)})
D <- paste0(HGC_DATA, "/GSE208369/"); src <- paste0(HGC_DATA, "/gastruloid_sc/GSE208369/GSM6341946_RA_LDN.RDS.gz"); dst <- paste0(D, "GSM6341946_RA_LDN.RDS")
if (!file.exists(dst)) system(paste0("gunzip -c ", src, " > ", dst))
o <- readRDS(dst); tag <- "RA_LDN"
cat(tag, class(o), dim(o), "assays:", names(o@assays), "\n")
cnt <- tryCatch(GetAssayData(o, assay="RNA", layer="counts"), error=function(e) GetAssayData(o, assay="RNA", slot="counts"))
md <- o@meta.data; md$cell <- colnames(o)
writeMM(cnt, paste0(D, "export/", tag, "_counts.mtx")); write.csv(data.frame(gene=rownames(cnt)), paste0(D, "export/", tag, "_genes.csv"), row.names=FALSE)
write.csv(md, paste0(D, "export/", tag, "_meta.csv"), row.names=FALSE)
cat("  cells", ncol(cnt), "genes", nrow(cnt), "median UMI", median(colSums(cnt)), "cols:", paste(colnames(md), collapse=","), "\n")
for (cn in intersect(c("batch","orig.ident","time","timepoint","day","hours","cell_type"), colnames(md))) { cat(cn, ":\n"); print(head(sort(table(md[[cn]]), decreasing=TRUE), 8)) }
