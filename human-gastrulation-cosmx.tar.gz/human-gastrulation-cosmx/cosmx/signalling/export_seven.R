# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/cs7_seven_pop_trends/export_seven.R (2026-09-28; artifact a8179a19)
# sha256 of original: 47ca7815bbbeb4b70824f7690872204c6f14c3a167094c1094e1e1b3ba7ac1c1
# Methods paragraphs: P358, P361
# Produces: handoff/seven_counts.mtx, seven_genes.csv, seven_cells.csv (HuE#1 DE, AVE, VE1, VE2, Node, APS, PS;
#     curated_kept)
# Edits/notes: object path -> HGC_DATA; handoff folder created.
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

dir.create('handoff', showWarnings = FALSE)   # added: intermediate folder inside HGC_OUT
suppressPackageStartupMessages({library(Seurat); library(Matrix)})
o <- readRDS(file.path(DATA, "obj6_obj7_merged_curated_final.rds"))
md <- o@meta.data
TG7 <- c("Definitive endoderm (DE)","Anterior visceral endoderm (AVE)","Visceral endoderm 1 (VE1)","Visceral endoderm 2 (VE2)",
         "Node","Anterior primitive streak (APS)","Primitive streak (PS)")
lab <- as.character(md$`39Type`)
cat("labels found:", paste(intersect(TG7, unique(lab)), collapse=" | "), "\n")
sel <- md$source_object=="obj6" & lab %in% TG7 & as.logical(md$curated_kept)
cn <- LayerData(o[["RNA"]], "counts")[, sel, drop=FALSE]
det <- Matrix::rowSums(cn > 0); keep <- det >= 10
cat("cells:", ncol(cn), "| genes detected in >=10 cells:", sum(keep), "\n")
print(table(lab[sel]))
writeMM(cn[keep, , drop=FALSE], "handoff/seven_counts.mtx")
write.csv(data.frame(gene=rownames(cn)[keep], n_det=as.integer(det[keep])), "handoff/seven_genes.csv", row.names=FALSE)
write.csv(data.frame(cell=md$cell[sel], label=lab[sel], x=md$x_um[sel], y=md$y_um[sel], z=md$z_um[sel], nCount=md$nCount[sel]),
          "handoff/seven_cells.csv", row.names=FALSE)
cat("written", round(file.size("handoff/seven_counts.mtx")/1e6,1), "MB\n")
