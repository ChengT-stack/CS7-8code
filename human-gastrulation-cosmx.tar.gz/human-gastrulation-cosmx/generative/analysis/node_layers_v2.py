"""Node signature score recomputed after excluding DE/AVE-enriched genes (endoderm-spillover control), and distance of
each CS7 node cell to the nearest DE/AVE cell. Adds columns to the node table and writes
ai/node_layers/cs7_node_cells_layers_v2.csv (the table read by node_dv_fate.py; its DV_layer / dest columns are those of
node_layers.py). Verbatim from session 5113e657 message [2848]; only the data path was replaced by HGC_DATA.
Run with cwd = HGC_GEN_ROOT after node_layers.py.
"""
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import scipy.io, numpy as np, pandas as pd
from scipy.stats import spearmanr
B=DATA+'/cs7_cs8_matching/'
g=pd.read_csv(B+'dataprep/export/genes.csv').gene.values
c7=pd.read_csv(B+'dataprep/export/CS7_cells.csv'); c8=pd.read_csv(B+'dataprep/export/CS8_cells.csv')
X7=scipy.io.mmread(B+'dataprep/export/CS7_counts.mtx').tocsr().T.tocsr().astype(np.float32); X8=scipy.io.mmread(B+'dataprep/export/CS8_counts.mtx').tocsr().T.tocsr().astype(np.float32)
D7=(X7>0); D8=(X8>0); l7=c7.label_short.values; l8=c8.label_short.values
det=lambda D,m: np.asarray(D[m].mean(0)).ravel()
dP,dN=det(D8,l8=='PrP'),det(D8,l8=='Node'); dDE,dAVE,dEPI=det(D7,l7=='DE'),det(D7,l7=='AVE'),det(D7,l7=='EPI')
endo=((dDE>=1.5*dEPI)&(dDE-dEPI>=0.05))|((dAVE>=1.5*dEPI)&(dAVE-dEPI>=0.05))
strict=endo|(dDE>0.10)|(dAVE>0.10)
lib=np.asarray(X7.sum(1)).ravel(); L7=X7.multiply(1e3/lib[:,None]).tocsr(); L7.data=np.log1p(L7.data)
node=np.where(l7=='Node')[0]
N=pd.read_csv('ai/node_layers/cs7_node_cells_layers.csv',index_col=0); assert (N.index.values==node).all()
def pick(excl):
    up=[j for j in np.argsort(-(dP-dN)) if dP[j]>=0.15 and not excl[j]][:30]; dn=[j for j in np.argsort(-(dN-dP)) if dN[j]>=0.15 and not excl[j]][:30]; return up,dn
res={}; 
for nm,ex in [('original',np.zeros(len(g),bool)),('no_DE_AVE_enriched',endo),('strict',strict)]:
    up,dn=pick(ex); s=np.asarray(L7[node][:,up].mean(1)).ravel()-np.asarray(L7[node][:,dn].mean(1)).ravel()
    r,p=spearmanr(N.DV,s); med=pd.Series(s,index=N.index).groupby(N.DV_layer).median()
    res[nm]=dict(up=up,dn=dn,score=s); N[f'score_{nm}']=s
    print(f'{nm:20s} rho={r:+.3f} p={p:.1e}  ventral {med["ventral"]:.3f} middle {med["middle"]:.3f} dorsal {med["dorsal"]:.3f}  n_excluded={int(ex.sum())}')
    print('   PrP-up:',', '.join(g[up][:20])); print('   node-up:',', '.join(g[dn][:12]))
print('endoderm-enriched genes removed from original PrP-up list:',[x for x in g[res['original']['up']] if x not in set(g[res['no_DE_AVE_enriched']['up']])])
# spatial-spillover control: score of node cells vs distance to nearest DE/AVE cell
from sklearn.neighbors import NearestNeighbors
xyz=c7[['x_um','y_um','z_um']].values; en=np.where(np.isin(l7,['DE','AVE']))[0]
d_endo=NearestNeighbors(n_neighbors=1).fit(xyz[en]).kneighbors(xyz[node])[0].ravel(); N['dist_to_endoderm_um']=d_endo
for nm in ['original','no_DE_AVE_enriched','strict']:
    far=N.dist_to_endoderm_um>np.median(d_endo); r,p=spearmanr(N.DV[far],N[f'score_{nm}'][far]); print(f'{nm}: cells farther than median distance from DE/AVE ({np.median(d_endo):.0f} µm): rho={r:+.3f} p={p:.1e} n={far.sum()}')
N.to_csv('ai/node_layers/cs7_node_cells_layers_v2.csv')
