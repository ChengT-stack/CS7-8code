# staging/01_milestones/build_calls.py
# Source: drive G: data/milestone_evidence/mz/allstage/build.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

import pandas as pd, numpy as np
R,N,P,A='reached','not reached','partial','not assessable'
M=[ # milestone, domain, onset
("Nascent mesoderm forms","disc",6.625),("Anterior primitive streak forms","disc",6.875),("Node-like cells appear (Foxj1+Chrd+)","disc",6.875),
("Definitive endoderm appears","disc",7.125),("ADE appears (Gsc+Cer1+ DE)","disc",7.125),("ADE programme regresses (Gsc in DE)","disc",7.375),
("Notochord forms","disc",7.375),("HOX on in streak (Hoxb1)","disc",7.375),("Caudal epiblast forms","disc",7.375),("Neural plate (rostral neurectoderm)","disc",7.375),
("Paraxial mesoderm forms","disc",7.625),("EOMES switched off in streak","disc",7.625),("5′ HOX on in caudal epiblast (Hoxb8)","disc",7.625),("Cardiomyocytes appear","disc",7.875),
("PGCs appear","extra",6.875),("Haemato-endothelial progenitors appear","extra",6.875),("Extra-embryonic mesoderm expands","extra",7.375),("Allantois forms","extra",7.625),("Primitive erythroid cells appear","extra",7.625)]
D=["Tyser CS7 (Smart-seq2)","HuE#1 CS7 (CosMx)","Xiao CS8 (Stereo-seq)","Cui CS7 (Stereo-seq)","HuE#2 CS8 (CosMx)","In-house CS7 (10x)","In-house CS8 (10x)"]
C={ # calls + evidence per dataset, in milestone order
"Tyser CS7 (Smart-seq2)":[
 (R,"Nascent mesoderm 98 cells; MESP1 79.6%"),(R,"Axial mesoderm 23 cells (FOXA2 73.9%, GSC 30.4%)"),(R,"FOXJ1+CHRD+ 7 of 23 axial cells"),
 (R,"DE 53 cells (FOXA2 66.0%)"),(P,"GSC+CER1+ 2 of 53 DE cells (≈0.2% of embryo-proper; mouse E7.0 0.26%, E7.25 2.2%)"),(A,"ADE barely formed"),
 (P,"Axial mesoderm NOTO 47.8% (mouse node-like E7.0 ~25%, E7.5 90%)"),(N,"HOXB1 in PS 5.0% (bkg 3.1%)"),(P,"NKX1-2+CDX2+ 36 cells within PS/epiblast; no separate cluster"),
 (N,"SOX1 0%, LHX2 0% in epiblast; no neural cluster"),(N,"MEOX1 ≤3.1% in all mesoderm"),(N,"EOMES in PS 14.9% (bkg 2.0%)"),(N,"HOXB8 0% in NKX1-2+CDX2+ cells"),
 (N,"Advanced mesoderm NKX2-5 2.4%"),(R,"PGC 7 cells (NANOS3 100%)"),(R,"111 haemato-endothelial cells"),(R,"YS mesoderm 83 cells"),
 (N,"TBX4 0%, HOXA10 2.4% in YS mesoderm"),(R,"Erythroblasts 32 cells (HBZ 96.9%)")],
"In-house CS7 (10x)":[
 (R,"Nas.Meso/PSM 791 cells; MESP1 64.3%"),(R,"Node 103 cells (FOXA2 75.7%); FOXA2+TBXT+ 3.5% of PS"),(R,"Node FOXJ1 76.7%, CHRD 90.3%"),
 (R,"DE 199 cells (SOX17 37.7%)"),(A,"ADE programme already regressed (GSC+CER1+ 3 DE cells)"),(R,"GSC 6.5% in DE (mouse 10x: 22.6% E7.5, 2.3% E7.75)"),
 (R,"Node NOTO 72.8% (mouse E7.5 90%)"),(R,"HOXB1 in PS 39.3% (bkg 3.3%)"),(R,"NKX1-2+CDX2+ 520 cells; EPI/ECT(p) NKX1-2 54.6%"),
 (R,"EPI/ECT(a) SIX3 19.6%, HESX1 28.5% (bkg ≤0.8%)"),(R,"Para.Meso MEOX1 43.6%, TCF15 72.4%"),(R,"EOMES in PS 6.3% (mouse PS 54.7% at E7.75)"),
 (R,"HOXB8 23.5% in NKX1-2+CDX2+ cells (mouse caudal epiblast 5.3% E7.5, 52.1% E7.75; onset threshold 22.6%) — borderline"),
 (N,"Cardiac progenitors NKX2-5 13.0% (mouse cardiomyocytes 93–97%)"),(P,"No PGC cluster; NANOS3+TFAP2C+PRDM1+ 4 cells"),(R,"Endothelial + blood progenitors 708 cells"),
 (R,"EXM 511 cells"),(R,"Allantois 684 cells (TBX4 8.8%, HOXA10 17.1%)"),(R,"Erythrocytes 338 cells (HBE1 100%)")],
}

C["In-house CS8 (10x)"]=[('reached', 'Nas.Meso/PSM 510 cells; MESP1 29.8% (152/510) (bkg 3.7%)'), ('reached', 'Node 49 cells; FOXA2 95.9% (47/49)'), ('reached', 'Node FOXJ1+CHRD+ 77.6% (38/49)'), ('reached', 'DE 93 cells; SOX17 12.9% (12/93), FOXA2+SOX17 7.5% (7/93) (bkg ≤0.2%)'), ('not assessable', 'ADE programme already regressed (GSC+CER1+ 0/93 DE cells)'), ('reached', 'GSC in DE 3.2% (3/93) (mouse 10x loss threshold 52.3%)'), ('reached', 'Node NOTO 69.4% (34/49); notochord 6 cells'), ('reached', 'PS HOXA1 69.5% (348/501), HOXB1 50.3% (252/501) (bkg 1.9/2.9%)'), ('reached', 'NKX1-2+CDX2+ 39.0% (401/1028) of PS/EPI(p)/NMP (bkg 0.2%)'), ('reached', 'EPI/ECT(a) HESX1+SIX3+ 19.8% (99/500) (bkg 0%)'), ('reached', 'Para.Meso 203 cells; MEOX1+TCF15+ 79.3% (161/203)'), ('reached', 'EOMES in PS 1.8% (9/501) (mouse 10x loss threshold 67.1%)'), ('reached', 'HOXB8 65.1% (261/401) in NKX1-2+CDX2+ cells (onset threshold 22.6%; mouse caudal epiblast 52.1% E7.75)'), ('partial', 'Cardiomyocyte cluster 65 cells (0.64% of cells; mouse 0.70% E7.75, onset threshold 0.74%): TNNT2 98.5%, MYL7 95.4%, NKX2-5 72.3% (47/65) (mouse 93–97%)'), ('reached', 'PGC 21 cells; NANOS3 85.7% (18/21)'), ('reached', 'Endothelial + blood progenitors 1,061 cells; KDR 52.4% (556/1061)'), ('reached', 'EXM 26 + YS.Meso 1,188 cells; HAND1 in EXM 100.0% (26/26)'), ('partial', 'Allantois 59 cells: TBX4 13.6% (8/59), HOXA10 25.4% (15/59) (mouse E7.75 41.6/87.8%)'), ('reached', 'Erythrocytes 513 cells; HBE1+GATA1+ 72.5% (372/513)')]
# CosMx: from final milestone table; Stereo-seq: from 4-embryo table + new early/extra calls
cm=pd.read_excel('mz/Fig_milestone_axis_CS7_CS8_data.xlsx','milestones_calls')
st=pd.read_excel('mz/Fig_milestone_axis_4embryos_data.xlsx','milestones_calls').set_index('milestone')
for k in ["HuE#1 CS7 (CosMx)","HuE#2 CS8 (CosMx)"]:
    C[k]=[(v,"see Figure 6G source data") for v in cm[k].values]
newst={"Cui CS7 (Stereo-seq)":{0:(R,"Nas.Meso 378 spots"),1:(R,"APS 610 spots"),2:(R,"Node FOXJ1 90.6%, CHRD 97.6%"),4:(P,"DE GSC 7.2%, CER1 3.1%"),
        14:(A,"PGC not resolved at spot level (0 spots)"),15:(R,"Endothelial 755 + blood progenitor 1,040 spots"),16:(R,"EXM 281 + YS.Meso 1,864 spots")},
       "Xiao CS8 (Stereo-seq)":{0:(R,"PS MESP1 36.0% (bkg 5.0%)"),1:(R,"APS 301 spots"),2:(R,"Node FOXJ1 75.3%, CHRD 95.9%"),4:(R,"DE GSC 46.9%, CER1 42.9%"),
        14:(A,"PGC not resolved at spot level (2 spots)"),15:(R,"Endothelial 2,384 + blood progenitor 2,462 spots"),16:(R,"EXM 269 + YS.Meso 7,285 spots")}}
for k,add in newst.items():
    L=[]
    for i,(m,dom,on) in enumerate(M):
        if i in add: L.append(add[i])
        elif m in st.index: L.append((st.loc[m,k],"Stereo-seq milestone table (20261028)"))
        else: raise SystemExit(f'missing {k} {m}')
    C[k]=L

MK={"Monkey CS8-e1":"CS8-e1","Monkey CS8-e2":"CS8-e2","Monkey CS9-e1":"CS9-e1","Monkey CS9-e2":"CS9-e2","Monkey CS11-e1":"CS11-e1","Monkey CS11-e2":"CS11-e2"}
ME=pd.read_csv('mz/monkey/monkey_milestone_evidence.csv',index_col=0)
RB=pd.read_csv('mz/monkey/monkey_recluster_best.csv').set_index(['sample','celltype'])
def mcalls(sm):
    e=ME[sm].astype(float); rb=lambda t:RB.loc[(sm,t)]
    c8=sm.startswith('CS8'); c9=sm.startswith('CS9'); c11=sm.startswith('CS11'); L=[]
    L.append((R,"MESP1+ mesoderm 106–129 cells; PSM annotated" if c11 else "Nas.Meso annotated"))
    L.append((R,"APS annotated")); L.append((R,f"Node FOXJ1 {e.Node_FOXJ1}%, CHRD {e.Node_CHRD}%")); L.append((R,f"DE {int(e.DE_n)} cells"))
    L.append((A,"ADE programme already regressed") if c11 else (R,f"GSC+CER1+ {e.DE_GSCCER1}% of DE"))
    L.append((N if e.DE_GSC>=52.3 else R,f"GSC in DE {e.DE_GSC}% (mouse 10x loss threshold 52.3%)"))
    b=rb('Notochord'); L.append((P if b.m1_best<40 and not c11 else R,f"best mesendoderm subcluster NOTO {b.m1_best}%, SHH {b.m2_best}%, module z {b.mod_z}"))
    L.append((R,f"HOXA1 {e.TBXT_HOXA1}% of TBXT+ cells (mouse TBXT+ threshold 19.4%; HOXB1 not detected in this dataset)"))
    b=rb('Caudal epiblast'); L.append((R if c11 else (P if c9 else N),f"NKX1-2 not detected in this dataset; best ectoderm subcluster CDX2 {b.m1_best}%, SOX2 {b.m2_best}%, module z {b.mod_z} (CS11 NMP z 2.1–3.2)"))
    b=rb('Rostral neurectoderm'); L.append((R if c11 else N,f"best ectoderm subcluster SIX3 {b.m2_best}%, HESX1 {b.m1_best}% (CS11 forebrain SIX3 47–75%)"))
    b=rb('Paraxial mesoderm'); L.append((R if c11 else N,f"best mesoderm subcluster MEOX1 {b.m1_best}%, TCF15 {b.m2_best}%"))
    v=e.TBXT_EOMES; L.append((R if v<=9.3 else (N if v>=39.6 else P),f"EOMES {v}% of TBXT+ cells (mouse TBXT+ cells: 39.6% E7.5, 9.3% E7.75)"))
    L.append((R,"HOXB8 57% in NMP") if c11 else (N,"HOXB8 ≤6% in CDX2+ caudal cells (PS, Caud.Meso)"))
    b=rb('Cardiomyocytes'); L.append((R if c11 else N,f"NKX2-5 not detected in this dataset; best mesoderm subcluster TNNT2 {b.m1_best}%, MYL7 {b.m2_best}%, module z {b.mod_z}"))
    n=int(e.PGC_n); L.append((R if n>=10 else P,f"PGC {n} cells (NANOS3 {e.PGC_NANOS3}%)"))
    L.append((R,"EC + BP annotated")); L.append((R,"ExE.Meso / ys.Meso annotated")); L.append((R,f"AI {int(e.AI_n)} cells (HOXA10 {e.AI_HOXA10}%, TBX4 {e.AI_TBX4}%)"))
    L.append((N,"2 HBZ+GATA1+ cells (smallest embryo, 3,559 cells)") if sm=='CS8-e1' else (R,"Ery1/Ery2 annotated"))
    return L
for k,sm in MK.items(): C[k]=mcalls(sm)
D=D+list(MK)
rows=[]
for i,(m,dom,on) in enumerate(M):
    r=dict(milestone=m,domain=dom,mouse_onset=on)
    for k in D: r[k]=C[k][i][0]; r[k+' | evidence']=C[k][i][1]
    rows.append(r)
T=pd.DataFrame(rows)
REV=[("Tyser CS7 (Smart-seq2)","Notochord forms",R,"Re-clustered mesendoderm: axial subcluster (22 cells) NOTO 54.5%, mouse notochord module z 4.37 (positive controls 2.2–5.7)"),
     ("Tyser CS7 (Smart-seq2)","Allantois forms",R,"Re-clustered mesoderm: Advanced-mesoderm subcluster (49 cells) TBX4 12.2%, HOXA10 12.2%, allantois module z 1.49 (10x allantois 1.39)"),
     ("Cui CS7 (Stereo-seq)","Allantois forms",R,"Re-clustered mesoderm: Adv.Meso subcluster (560 spots) HOXA10 13.8%, TBX4 4.3% (Xiao allantois 2.9% / 0.2%)"),
     ("HuE#1 CS7 (CosMx)","Neural plate (rostral neurectoderm)",A,"CosMx HESX1/SIX3 do not separate CS7 (13.7/8.8%) from CS8 aECT (11.7/5.2%); call rested on annotation"),
     ("HuE#1 CS7 (CosMx)","Paraxial mesoderm forms",A,"CosMx MEOX1/TCF15 do not separate CS7 (8.3/11.1%) from CS8 (5.7/13.2%); call rested on annotation"),
     ("Tyser CS7 (Smart-seq2)","Neural plate (rostral neurectoderm)",A,"Epiblast subcluster HESX1 27.3%, SIX3 18.2% ≈ 10x positive control (32.7/25.1%); markers also label pre-neural anterior epiblast")]
T['revised']=''
for k,m,v,e in REV:
    i=T.index[T.milestone==m][0]; old=T.at[i,k]; T.at[i,k]=v; T.at[i,k+' | evidence']=e
    T.at[i,'revised']=(T.at[i,'revised']+'; ' if T.at[i,'revised'] else '')+k
def window(k):
    d=T[T.domain=='disc']; lo=d.loc[d[k]==R,'mouse_onset'].max(); hi=d.loc[d[k]==N,'mouse_onset'].min()
    if np.isnan(hi): hi=np.inf
    tied=lo>=hi
    if tied:
        grid=np.array([6.5,6.75,7.0,7.25,7.5,7.75,8.0,8.25,8.5]); j=np.searchsorted(grid,lo); lo,hi=grid[j-1],grid[j]
    return lo,hi,tied
W=pd.DataFrame([dict(dataset=k,window_lo=window(k)[0],window_hi=window(k)[1],tied=window(k)[2]) for k in D])
def lab(r):
    if np.isinf(r.window_hi): return f"≥E{r.window_lo:g}"
    if r.window_hi-r.window_lo<=0.25+1e-9 and not r.tied: return f"≈E{(r.window_lo+r.window_hi)/2:g}"
    return f"E{r.window_lo:g}–{r.window_hi:g}"
W['label']=W.apply(lab,axis=1)
T.to_csv('mz/allstage/calls.csv',index=False); W.to_csv('mz/allstage/windows.csv',index=False)
print(T[['milestone','mouse_onset']+D].to_string()); print(W.to_string())
