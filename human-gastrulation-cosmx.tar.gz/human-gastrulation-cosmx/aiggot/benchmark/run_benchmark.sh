#!/usr/bin/env bash
# Benchmark of alternative matchings on the CosMx CS7/CS8 disc cells (Supplementary Figure 9G; Table S3 'Benchmark settings').
# Reconstructed from the command lines issued in benchmark session 520603d3 (bash calls; the moscot runs used a conda env
# with moscot 0.5.2 / ott-jax 0.6.0 / jax 0.10.2; prep_data.py used an env with scanpy/harmonypy).
# Run from aiggot/benchmark/. Results are written to results/real/<tag>/ and aggregated into out/.
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH="$PWD:${PYTHONPATH:-}"
mkdir -p bench

# 1. benchmark inputs (held-out-gene Harmony 'hhs' and full Harmony 'hs' embeddings, frames, prior)
python prep_data.py > bench/prep_data.log 2>&1

# 2. simple baselines
for m in knn_expr nn_space starmatch starmatch_nopen; do for e in hs hhs; do
  python run_real.py --method $m --embedding $e
done; done

# 3. moscot hyper-parameter grids (union of the grids that were run in several batches in the original session;
#    an earlier FGW grid without DV clipping overflowed and is not used)
# on the held-out embedding (selection by held-out rho in aggregate_real.py)
for eps in 0.0001 0.001 0.01 0.05; do for tau in 1.0 0.99 0.95; do
  python run_real.py --method moscot --embedding hhs --cfg "{\"mode\":\"linear\",\"lam_space_linear\":1.0,\"use_starmatch_scales\":true,\"epsilon\":$eps,\"tau_a\":$tau,\"tau_b\":$tau}" --tag moscot_linear_full_eps${eps}_tau${tau}_hhs || true
done; done
for eps in 0.001 0.01 0.05; do for tau in 1.0 0.99; do
  python run_real.py --method moscot --embedding hhs --subsample 0.35 --cfg "{\"mode\":\"fgw\",\"alpha\":0.5,\"epsilon\":$eps,\"tau_a\":$tau,\"tau_b\":$tau,\"max_iterations\":50,\"clip_dv\":5}" --tag moscot_fgw_sub35_eps${eps}_tau${tau}_clipdv5_hhs || true
done; done

# 4. selected configurations re-run on the full Harmony embedding (flow tables used in Supplementary Figure 9G)
#    selected: moscot_linear_full_eps0.0001_tau0.95_hhs and moscot_fgw_sub35_eps0.05_tau0.99_clipdv5_hhs
python run_real.py --method moscot --embedding hs --cfg '{"mode":"linear","lam_space_linear":1.0,"use_starmatch_scales":true,"epsilon":0.0001,"tau_a":0.95,"tau_b":0.95}' --tag moscot_linear_full_eps0.0001_tau0.95_hs
python run_real.py --method moscot --embedding hs --subsample 0.35 --cfg '{"mode":"fgw","alpha":0.5,"epsilon":0.05,"tau_a":0.99,"tau_b":0.99,"max_iterations":50,"clip_dv":5}' --tag moscot_fgw_sub35_eps0.05_tau0.99_clipdv5_hs

# 5. aggregate (writes out/benchmark_real*.csv, out/flow_table_*.csv, out/moscot_best_configs.json)
python aggregate_real.py
# The out/ tables were then copied to ${HGC_DATA}/cs7_cs8_matching/benchmark/, read by 09_compare_methods.py.
