# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/cs8_epi_node_ps_curves/cs8_genes.py (2026-09-28; artifact 8239d21e; identical copy in
#     cs8_heart_axial_curves/)
# sha256 of original: 7212ac11eb4b3f7d14a3dbfd671c7b08e43392dea44e8d128ebd9dfa3532efd6
# Methods paragraphs: P358, P361
# Produces: Supplementary Figure 6C (default POPS=EPI,Node,PS -> cs8_epi_node_ps_gene_curves.*) and 6D
#     (axial/mesoderm populations, PREFIX=cs8_heart_axial -> cs8_heart_axial_gene_curves.*)
# Edits/notes: h5ad and gene-set paths -> HGC_DATA / common; body executed from this folder.
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

"""CS8 (obj7) version of the per-gene pathway curves. Data: cs8_kept_counts.h5ad (all curation-kept CS8 cells, raw counts).
Frame: the CS8 anatomical frame established in this project (AP = +y, LR = +z, DV = +x; origin = median of disc_main_body cells),
AP sign verified below by PS lying posterior to the prechordal plate. Body of the figure = gene_curves_body.py (shared with CS7)."""
import os, sys, json
for k,v in [("KMP_AFFINITY","disabled"),("OMP_NUM_THREADS","8"),("KMP_INIT_AT_FORK","FALSE")]: os.environ.setdefault(k,v)
import numpy as np, pandas as pd, anndata as ad, scipy.sparse as ssp
import matplotlib as mpl; mpl.use("Agg"); import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
sys.path.insert(0,os.getcwd())
from figure_style import apply_figure_style, panel_letter
META_GREY="#8A8A8A"
WANT=os.environ.get("POPS","EPI,Node,PS").split(","); PREFIX=os.environ.get("PREFIX","cs8_epi_node_ps")
POPLABEL="/".join(WANT); STAGE="CS8"; OBJ="obj7"
A=ad.read_h5ad(str(DATA / "cs8_kept_counts.h5ad"))
obs=A.obs; lab_all=obs.label.astype(str).to_numpy(); present=set(lab_all)
FULL7={k:[t for t in present if t==k or t.endswith(f"({k})")][0] for k in WANT}
disc=obs.disc.to_numpy(bool); Y=obs.y.to_numpy(float); ok=np.isfinite(Y)
ap_all=Y-np.median(Y[disc&ok])
pcp=lab_all=="Prechordal plate"; ps=lab_all=="Primitive streak (PS)"
assert np.median(ap_all[ps&ok])>np.median(ap_all[pcp&ok]), "AP sign: PS must be posterior to the prechordal plate"
print(f"CS8 frame AP=+y: prechordal plate median {np.median(ap_all[pcp&ok]):+.0f}, PS {np.median(ap_all[ps&ok]):+.0f} um",flush=True)
sel_cells=np.isin(lab_all,[FULL7[k] for k in WANT])&ok
M7=ssp.csr_matrix(A.X[sel_cells].T)                       # genes x cells, raw counts
gi7={g:i for i,g in enumerate(A.var_names)}
det7=np.asarray((M7>0).sum(1)).ravel()
C7=pd.DataFrame(dict(cell=obs.index[sel_cells],label=lab_all[sel_cells],nCount=obs.nCount.to_numpy(float)[sel_cells]))
ap7=ap_all[sel_cells]; lab5=C7.label.to_numpy(); dep5=C7.nCount.to_numpy(float); ld5=np.log(dep5)
assert np.allclose(dep5,np.asarray(M7.sum(0)).ravel()), "nCount must equal the row sums"
lo5,hi5=np.percentile(ap7,[1,99]); inb=(ap7>=lo5)&(ap7<=hi5)
print(f"{len(WANT)} populations: {len(C7):,} cells | AP band 1-99 pct [{lo5:.0f}, {hi5:.0f}] (span {hi5-lo5:.0f}) -> {int(inb.sum()):,} inside",flush=True)
for k in WANT:
    m=inb&(lab5==FULL7[k]); print(f"  {k:5s} n={int(m.sum()):5d}  AP median {np.median(ap7[m]):+6.0f}  IQR {np.percentile(ap7[m],25):+.0f}..{np.percentile(ap7[m],75):+.0f}")
def kernel_curve(ap,val,h=None,n_grid=80,min_h=20):
    ap=np.asarray(ap,float); val=np.asarray(val,float)
    if h is None: h=max(min_h, 0.06*(ap.max()-ap.min()))
    grid=np.linspace(ap.min(),ap.max(),n_grid)
    w=np.exp(-0.5*((grid[:,None]-ap[None,:])/h)**2); wsum=w.sum(1)
    mean=(w*val[None,:]).sum(1)/np.where(wsum>1e-9,wsum,1)
    eff=wsum**2/(w**2).sum(1)
    var=(w*(val[None,:]-mean[:,None])**2).sum(1)/np.where(wsum>1e-9,wsum,1)
    return grid, mean, np.sqrt(var/np.where(eff>1,eff,1)), h
GSJ=__import__("pathway_gene_sets").PATHWAY_GENE_SETS; COMPLETE=GSJ["COMPLETE"]
PWS=["WNT","NODAL","NOTCH","SHH","FGF"]; KINDS4=["ligand","receptor","target","inhibitor"]
miss={k:[g for g in v if g not in gi7] for k,v in COMPLETE.items()}
print("genes absent from CS8:",{k:v for k,v in miss.items() if v} or "none")
exec(open(SCRIPT_DIR / "gene_curves_body.py").read())
