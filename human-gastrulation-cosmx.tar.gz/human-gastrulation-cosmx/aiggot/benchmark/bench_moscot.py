"""moscot wrapper: SpatioTemporalProblem (fused GW) and TemporalProblem (linear) on the same inputs
as starmatch (smoothed Harmony = expression features, normalised frame coordinates = space)."""
import os, time, numpy as np, pandas as pd, anndata as ad, warnings
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
warnings.filterwarnings("ignore")


def coupling_summaries(P, g7, g8, b, rows, cols, unmatched_ratio=0.5):
    """P: dense (n7 x n8) coupling (numpy). Returns hard argmax assignment, soft column-normalised
    flow table, per-CS8 entropy, unmatched calls (received mass < unmatched_ratio x target marginal)."""
    P = np.asarray(P, dtype=np.float64)
    bad = not np.isfinite(P).all() or P.sum() <= 0
    if bad:
        P = np.nan_to_num(P, nan=0.0, posinf=0.0, neginf=0.0)
    colsum = P.sum(0); rowsum = P.sum(1)
    parent = P.argmax(0)
    b = np.asarray(b, float); expected = b / b.sum() * P.sum()
    ratio = colsum / expected
    unmatched8 = ratio < unmatched_ratio
    parent_h = np.where(unmatched8, -1, parent)
    Pn = P / np.where(colsum > 0, colsum, 1.0)
    with np.errstate(divide="ignore", invalid="ignore"):
        H = -(Pn * np.log(np.where(Pn > 0, Pn, 1.0))).sum(0)
    G7 = pd.get_dummies(pd.Categorical(g7, categories=rows)).to_numpy(np.float64)
    G8 = pd.get_dummies(pd.Categorical(g8, categories=cols)).to_numpy(np.float64)
    flow_soft = pd.DataFrame(G7.T @ (Pn @ G8), index=rows, columns=cols)          # each CS8 cell = 1 unit
    flow_mass = pd.DataFrame(G7.T @ (P @ G8), index=rows, columns=cols)           # raw transported mass
    # CS7 cells 'matched' = row mass >= unmatched_ratio x its own marginal share
    a_exp = rowsum.sum() / len(rowsum)
    return dict(parent_argmax=parent, parent=parent_h, unmatched8=unmatched8, Pn=Pn,
                mean_entropy=float(H.mean()), eff_parents=float(np.exp(H.mean())),
                flow_soft=flow_soft, flow_mass=flow_mass, colsum=colsum, rowsum=rowsum,
                failed=bool(bad), frac_unmatched8=float(unmatched8.mean()), frac_unmatched7_mass=float((rowsum < unmatched_ratio * a_exp).mean()))


def run_moscot(E7, E8, S7, S8, g7, g8, a=None, b=None, mode="fgw", alpha=0.5, epsilon=1e-2, tau_a=1.0, tau_b=1.0,
               lam_space_linear=0.0, max_iterations=None, batch_size=None, rows=None, cols=None, device=None,
               scale_space=None, scale_expr=None, **kw):
    """mode 'fgw': SpatioTemporalProblem, quadratic term = within-slice spatial distances (frame coords),
    linear term = sq. Euclidean distance in smoothed Harmony (optionally concatenated with sqrt(lam) x space).
    mode 'linear': TemporalProblem (plain unbalanced Sinkhorn) on the same linear features."""
    from moscot.problems.spatiotemporal import SpatioTemporalProblem
    from moscot.problems.time import TemporalProblem
    import jax
    if os.environ.get("BENCH_X64", "1") == "0":
        jax.config.update("jax_enable_x64", False)     # float32 couplings: the WSL2 GPU refuses single allocations > ~3.6 GiB
    n7, n8 = len(g7), len(g8)
    if scale_expr is not None:   # same dimensionless scaling as starmatch
        E7, E8 = E7 / scale_expr, E8 / scale_expr; S7, S8 = S7 / scale_space, S8 / scale_space
    F7, F8 = E7, E8
    if lam_space_linear > 0:
        F7 = np.hstack([E7, np.sqrt(lam_space_linear) * S7]); F8 = np.hstack([E8, np.sqrt(lam_space_linear) * S8])
    obs = pd.DataFrame({"time": np.r_[np.zeros(n7), np.ones(n8)].astype(float), "g": np.r_[g7, g8]},
                       index=[f"c{i}" for i in range(n7 + n8)])
    obs["time"] = obs["time"].astype("category"); obs["g"] = obs["g"].astype("category")
    if a is not None:   # marginals must carry equal total mass (1 each side) or the balanced Sinkhorn diverges to NaN
        a = np.asarray(a, float); b = np.asarray(b, float)
        obs["zw"] = np.r_[a / a.sum(), b / b.sum()]
    A = ad.AnnData(X=np.zeros((n7 + n8, 1), np.float32), obs=obs)
    A.obsm["spatial"] = np.vstack([S7, S8]).astype(np.float32); A.obsm["X_feat"] = np.vstack([F7, F8]).astype(np.float32)
    t0 = time.time()
    mk = dict(a="zw", b="zw") if a is not None else {}
    if mode == "fgw":
        prob = SpatioTemporalProblem(A).prepare(time_key="time", spatial_key="spatial", joint_attr="X_feat", policy="sequential", **mk)
        skw = dict(alpha=alpha, epsilon=epsilon, tau_a=tau_a, tau_b=tau_b)
        if max_iterations is not None: skw["max_iterations"] = max_iterations
        if batch_size is not None: skw["batch_size"] = batch_size
        prob = prob.solve(**skw, **kw)
    else:
        prob = TemporalProblem(A).prepare(time_key="time", joint_attr="X_feat", policy="sequential", **mk)
        skw = dict(epsilon=epsilon, tau_a=tau_a, tau_b=tau_b)
        if max_iterations is not None: skw["max_iterations"] = max_iterations
        if batch_size is not None: skw["batch_size"] = batch_size
        prob = prob.solve(**skw, **kw)
    key = list(prob.solutions.keys())[0]
    sol = prob.solutions[key]
    P = np.asarray(sol.transport_matrix, dtype=np.float32)
    t_solve = time.time() - t0
    rows = rows if rows is not None else sorted(set(g7)); cols = cols if cols is not None else sorted(set(g8))
    out = coupling_summaries(P, g7, g8, b if b is not None else np.ones(n8), rows, cols)
    try:
        ct = prob.cell_transition(source=key[0], target=key[1], source_groups="g", target_groups="g", forward=True, normalize=True)
        out["cell_transition_fwd"] = ct
    except Exception as e:
        out["cell_transition_fwd"] = None; out["cell_transition_error"] = repr(e)
    out.update(dict(converged=bool(sol.converged), cost=float(sol.cost) if sol.cost is not None else np.nan,
                    time_solve_s=t_solve, mode=mode, alpha=alpha, epsilon=epsilon, tau_a=tau_a, tau_b=tau_b,
                    n_iters=getattr(sol, "n_iters", None) if hasattr(sol, "n_iters") else None))
    return out
