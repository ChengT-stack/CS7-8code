# Nested-CV statistics for the 153-embryo rebuild (unit = mid embryo), identical stats() to old out_robustness/analyse.py
# (B=10000 bootstrap, rng seed 0, pooled = stratified by rotation); subsets ALL / NEW / OLD mid embryos; old 115-embryo numbers side by side.
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import json, numpy as np, pandas as pd
from scipy.stats import wilcoxon
O = 'out_gencv/'; OLD = DATA + '/ai_t05/'; B = 10000; rng = np.random.default_rng(0)
def per_mid(df):   # final2.py: per seed, mean over triplets per mid embryo; then mean over seeds
    g = df.groupby(['seed', 'em']).agg(ED=('ED', 'mean'), terr=('terr', 'mean'), tm=('tm', 'mean')).reset_index()
    return g.groupby('em').agg(ED=('ED', 'mean'), terr=('terr', 'mean'), tm=('tm', 'mean'))
def stats(m, ref, strata=None):
    v = np.log(m.ED / ref.ED.reindex(m.index)).values; tm = m.terr.abs().values; tr = ref.terr.reindex(m.index).abs().values; n = len(v)
    f = lambda v, tm, tr: (100 * (np.exp(np.median(v)) - 1), (v < 0).mean(), np.median(tm), np.median(tm - tr))
    pt = f(v, tm, tr)
    if strata is None: idx = [rng.integers(n, size=n) for _ in range(B)]
    else:
        S = [np.where(strata == s)[0] for s in np.unique(strata)]; idx = [np.concatenate([s[rng.integers(len(s), size=len(s))] for s in S]) for _ in range(B)]
    bs = np.array([f(v[i], tm[i], tr[i]) for i in idx]); lo, hi = np.percentile(bs, [2.5, 97.5], axis=0)
    return dict(n_mid=n, median_pct_ED=pt[0], median_pct_lo95=lo[0], median_pct_hi95=hi[0], frac_mid_improved=pt[1], frac_lo95=lo[1], frac_hi95=hi[1],
                n_improved=int((v < 0).sum()), wilcoxon_p=float(wilcoxon(v).pvalue) if n >= 2 else np.nan, abs_terr_model_h=pt[2], abs_terr_lo95=lo[2], abs_terr_hi95=hi[2],
                abs_terr_ref_h=float(np.median(tr)), median_delta_abs_terr_h=pt[3], delta_abs_terr_lo95=lo[3], delta_abs_terr_hi95=hi[3])
MODELS = ['final_v2', 'V1a', 'linear', 'linear_noise', 'linear_noise_valsigma']
COMP = [('final_v2', 'linear'), ('final_v2', 'linear_noise'), ('V1a', 'linear'), ('V1a', 'linear_noise'), ('V1a', 'final_v2'), ('linear_noise', 'linear'),
        ('final_v2', 'linear_noise_valsigma'), ('V1a', 'linear_noise_valsigma')]
PM = {}; SIG = {}; SPL = {}
for r in range(4):
    df = pd.read_csv(O + f'rot{r}_locked_triplets_long.csv'); SPL[r] = pd.read_csv(f'ai/mz_bench/rot/split_rot{r}.csv', index_col=0)
    SIG[r] = float(pd.read_csv(O + f'sigma_val_rot{r}.csv').query('selected').sigma.iloc[0])
    for mdl in MODELS:
        assert (df.model == mdl).any(), (r, mdl); PM[(r, mdl)] = per_mid(df[df.model == mdl]).assign(rotation=r, new_mid=lambda x: SPL[r].new_embryo.reindex(x.index).values.astype(bool))
rows = []
for sub in ['all', 'new', 'old']:
    keep = lambda m: m if sub == 'all' else m[m.new_mid == (sub == 'new')]
    for r in range(4):
        for mdl, ref in COMP:
            m = keep(PM[(r, mdl)])
            if len(m) == 0: continue
            rows.append(dict(subset=sub, rotation=str(r), model=mdl, comparison='vs_' + ref, sigma_ref=(0.4 if ref == 'linear_noise' else SIG[r] if ref == 'linear_noise_valsigma' else np.nan), **stats(m, PM[(r, ref)])))
    for mdl, ref in COMP:
        m = keep(pd.concat([PM[(r, mdl)] for r in range(4)])); f = pd.concat([PM[(r, ref)] for r in range(4)]); assert m.index.is_unique
        rows.append(dict(subset=sub, rotation='pooled (stratified bootstrap)', model=mdl, comparison='vs_' + ref, **stats(m, f, strata=m.rotation.values)))
NC = pd.DataFrame(rows); NC.insert(0, 'dataset', '153 embryos (v153)')
# ---------------- old 115-embryo reference rows
OLDNC = pd.read_csv(OLD + 'out_robustness/nested_cv_results.csv'); OLDNC = OLDNC[OLDNC.model.isin(['fixed', 'linear_noise'])].copy()
OLDNC['model'] = OLDNC.model.replace({'fixed': 'final_v2'}); OLDNC['subset'] = 'all (old 68-embryo split)'; OLDNC['dataset'] = '115 embryos (old)'
OLDNC = OLDNC.drop(columns=['val_score_selected', 'retuned_is_final_v2'])
od = OLD + 'out_domain/results/'; ov = pd.read_csv(od + 'V1a_lamh3.0_locked_per_mid.csv', index_col=0); of = pd.read_csv(od + 'final_v2_locked_per_mid.csv', index_col=0)
mk = lambda d, c, t: pd.DataFrame(dict(ED=d[c], terr=d[t]))
oV = mk(ov, 'ED_model', 'terr_model'); oF = mk(of, 'ED_model', 'terr_model'); oL = mk(ov, 'ED_linear', 'terr_linear') if 'terr_linear' in ov else None; oB = mk(ov, 'ED_linear_noise', 'terr_linear_noise') if 'terr_linear_noise' in ov else None
orow = []
for nm, m, ref in [('V1a', oV, 'linear'), ('V1a', oV, 'linear_noise'), ('V1a', oV, 'final_v2')]:
    R_ = {'linear': oL, 'linear_noise': oB, 'final_v2': oF}[ref]
    if R_ is None: R_ = pd.DataFrame(dict(ED=ov['ED_' + ref], terr=np.nan * ov['ED_' + ref]))
    orow.append(dict(dataset='115 embryos (old)', subset='all (old 68-embryo split)', rotation='0', model=nm, comparison='vs_' + ref,
                     note='out_domain (original locked set; final_v2 = saved GPU weights)', **stats(m, R_)))
OLDALL = pd.concat([OLDNC, pd.DataFrame(orow)], ignore_index=True)
ALL = pd.concat([NC, OLDALL], ignore_index=True); ALL.to_csv(O + 'nested_cv_results_v153.csv', index=False)
# per-mid table
pmt = []
for r in range(4):
    t = pd.concat([PM[(r, m)][['ED', 'terr']].add_prefix(m + '_') for m in MODELS], axis=1); t['tm'] = PM[(r, 'final_v2')].tm; t['rotation'] = r
    t['new_mid'] = PM[(r, 'final_v2')].new_mid; t['n_triplets'] = pd.read_csv(O + f'rot{r}_locked_triplets_long.csv').query("model=='linear'").groupby('em').size().reindex(t.index).values
    for m, ref in COMP[:5]: t[f'logratio_{m}_vs_{ref}'] = np.log(t[m + '_ED'] / t[ref + '_ED'])
    pmt.append(t)
PMT = pd.concat(pmt); PMT.index.name = 'em'
oldpm = pd.read_csv(OLD + 'out_robustness/nested_cv_per_mid.csv', index_col=0)
PMT['in_old_locked'] = PMT.index.isin(oldpm.index); PMT['old_rotation'] = oldpm.rotation.reindex(PMT.index).values
PMT['old_fixed_ED'] = oldpm.fixed_ED.reindex(PMT.index).values; PMT['old_logratio_fixed_vs_linear_noise'] = np.log(oldpm.fixed_ED / oldpm.linear_noise_ED).reindex(PMT.index).values
PMT.to_csv(O + 'nested_cv_per_mid_v153.csv')
pd.set_option('display.width', 250)
cols = ['dataset', 'subset', 'rotation', 'model', 'comparison', 'n_mid', 'median_pct_ED', 'median_pct_lo95', 'median_pct_hi95', 'n_improved', 'wilcoxon_p', 'abs_terr_model_h', 'abs_terr_ref_h']
print(ALL[cols].round(4).to_string(index=False))
print('old locked mids', len(oldpm), 'new locked mids', len(PMT), 'old mids also locked now', PMT.in_old_locked.sum(), 'old mids lost', sorted(set(oldpm.index) - set(PMT.index)))
print('rotation of old mids unchanged:', (PMT.dropna(subset=['old_rotation']).old_rotation == PMT.dropna(subset=['old_rotation']).rotation).all(), 'sigma val', SIG)
