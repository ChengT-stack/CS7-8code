# staging/01_milestones/evidence_stereoseq.py
# Source: reconstructed from transcript 18ae5ceb
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Milestone evidence review, Stereo-seq CS7/CS8 with CS9 positive controls (input to audit_calls.py).
# Reconstructed verbatim from session transcript 18ae5ceb (code was run cell-by-cell in a
# persistent kernel and never saved as a file). Cells are concatenated in execution order;
# inspection-only and figure-polishing cells are omitted, and cells that stopped with an error are
# truncated at the failing line (marked). See PROVENANCE.md.


# ---- cell [frame 18ae5ceb, message 7] Reading workbook rules and Stereo-seq staging tables
import pandas as pd, os
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',200); pd.set_option('display.max_columns',30)
B=(str(HGC_DATA) + '/milestone_evidence/')
wb=pd.read_excel(B+'20261030-Fig_milestone_axis_human_monkey_data.xlsx',sheet_name=None)
print(list(wb))
print(wb['rules'].to_string())
print(wb['milestone_definitions'].to_string())


# ---- cell [frame 18ae5ceb, message 10] Printing rules and definitions compactly
for r in wb['rules'].iloc[:,0]: print('-',r)
d=wb['milestone_definitions']; print(d.columns.tolist())
for _,r in d.iterrows(): print(' | '.join(str(v) for v in r.values))


# ---- cell [frame 18ae5ceb, message 12] Reading Stereo-seq staging workbooks
for f in ['mz/20261028-Stereoseq_milestone_staging.xlsx','mz/Fig_milestone_axis_4embryos_data.xlsx']:
    x=pd.read_excel(B+f,sheet_name=None)
    print('=====',f,list(x))
    for k,v in x.items():
        print('---',k,v.shape); print(v.head(45).to_string()[:6000])


# ---- cell [frame 18ae5ceb, message 14] Inspecting final calls sheet and build script for Stereo-seq
mc=wb['milestone_calls']; print(mc.columns.tolist()); print(mc.shape)
print(mc.head(3).to_string()[:3000])
import subprocess
print(subprocess.run("grep -n -i 'stereo\\|Cui\\|Xiao\\|CS8_milestone\\|CS7_milestone' "+B+"mz/allstage/build.py "+B+"mz/allstage/definitions.py | head -80",shell=True,capture_output=True,text=True).stdout)


# ---- cell [frame 18ae5ceb, message 18] Extracting final Stereo-seq calls and loading spot data
DS=['Cui CS7 (Stereo-seq)','Xiao CS8 (Stereo-seq)']
calls=mc[['milestone']+[c for k in DS for c in (k,k+' | evidence')]]
print(calls.to_string())
E=(str(HGC_DATA) + '/external/human_stereoseq/')
lab=pd.read_csv(E+'stereoseq_cell_labels.csv'); print(lab.shape); print(lab.head(3).to_string()); print(lab.stage.value_counts())
mp=pd.read_csv(E+'stereoseq_label_mapping.csv'); print(mp.shape); print(mp.head(5).to_string())
for f in ['CS7_milestone_genes','CS8_milestone_genes','CS7_cardiac_genes','CS8_cardiac_genes']:
    g=pd.read_csv(B+'mz/stereo/'+f+'.csv',nrows=3); print(f,g.columns.tolist())


# ---- cell [frame 18ae5ceb, message 26] Extracting milestone marker counts from full Stereo-seq matrices
import scipy.io, numpy as np, scipy.sparse as ssp, time
P=(str(HGC_DATA) + '/published_compare/data/')
GENES=['MESP1','GSC','FOXA2','FOXJ1','CHRD','SOX17','CER1','LHX1','NOTO','SHH','HOXA1','HOXB1','NKX1-2','CDX2','CDX1','HESX1','SIX3','OTX2','SOX2','SOX1','LHX2','MEOX1','TCF15','TBX6','MSGN1','EOMES','TBXT','HOXB8','HOXB9','NKX2-5','TNNT2','MYL7','DPPA3','NANOS3','TFAP2C','PRDM1','ETV2','KDR','TAL1','HAND1','TBX4','HOXA10','HBZ','HBE1','GATA1','POU5F1','NANOG']
X={}
for st in ['CS7','CS8']:
    t=time.time()
    g=pd.read_csv(P+f'pub_{st}_genes.csv').gene.values; ob=pd.read_csv(P+f'pub_{st}_obs.csv',usecols=['cell','nCount_RNA'])
    M=scipy.io.mmread(P+f'pub_{st}_counts.mtx').tocsr()
    print(st,M.shape,len(g),len(ob),time.time()-t)
    gi={x:i for i,x in enumerate(g)}
    miss=[x for x in GENES if x not in gi]; print('missing',miss)
    keep=[x for x in GENES if x in gi]
    sub=M[[gi[x] for x in keep],:].T.toarray()
    df=pd.DataFrame(sub,columns=keep,index=ob.cell.values); df['nCount_check']=np.asarray(M.sum(0)).ravel()
    df['nCount_RNA']=ob.nCount_RNA.values
    X[st]=df; df.to_parquet(f'/tmp/{st}_markers.parquet')
    del M
print({k:v.shape for k,v in X.items()})
print((X['CS7'].nCount_check-X['CS7'].nCount_RNA).abs().max())


# ---- cell [frame 18ae5ceb, message 28] Cross-checking extracted counts against bundle per-spot CSVs
for st in ['CS7','CS8']:
    bg=pd.read_csv(B+f'mz/stereo/{st}_milestone_genes.csv').set_index('spot')
    cg=pd.read_csv(B+f'mz/stereo/{st}_cardiac_genes.csv').set_index('spot')
    L=lab[lab.stage==st].set_index('cell')
    x=X[st]
    print(st, len(bg), len(L), x.index.isin(L.index).mean(), bg.index.isin(x.index).mean())
    for gname in ['GSC','MESP1','HBZ','NOTO','FOXA2']:
        print(' ',gname,(bg[gname]-x.loc[bg.index,gname]).abs().max(), bg[gname].dtype)
    for gname in ['KDR','HAND1']:
        print(' ',gname,(cg[gname]-x.loc[cg.index,gname]).abs().max())
print(lab.Type2.str.split(n=1).str[1].value_counts().head(60).to_string())


# ---- cell [frame 18ae5ceb, message 32] Reverse-engineering background definition of detection table
det=pd.read_excel(B+'mz/20261028-Stereoseq_milestone_staging.xlsx','stereoseq_detection')
L=lab.set_index('cell')
def pct(m): return 100*m.mean()
for st in ['CS7','CS8']:
    x=X[st]; l=L.loc[x.index]
    for grp in ['PS','Node','DE']:
        r=det[(det.stage==st)&(det.group==grp)].iloc[0]
        tg=l.our_group_fine==grp
        cands={'disc_other':l.in_disc_fine & ~tg,'all_other':~tg,'disc_epi?':l.in_disc_fine,'nonexcl_other':(l.our_group_fine!='exclude')&~tg}
        print(st,grp,tg.sum(),r.n, 'GSC',round(pct(x.loc[tg,'GSC']>0),1),r.GSC,'| bg table',r.GSC_bg, {k:round(pct(x.loc[v,'GSC']>0),1) for k,v in cands.items()}, 'HBZ_bg',r.HBZ_bg,{k:round(pct(x.loc[v,'HBZ']>0),1) for k,v in cands.items()})


# ---- cell [frame 18ae5ceb, message 34] Checking label counts and rescue reclustering for Stereo-seq
for st in ['CS7','CS8']:
    l=lab[lab.stage==st]
    t2=l.Type2.str.split(n=1).str[1]
    print(st, 'in_disc',l.in_disc_fine.sum(), t2.value_counts().to_dict())
    print('  fine', l.our_group_fine.value_counts().to_dict())
for f in ['layer_rescue_results.csv','recluster_best_subclusters.csv','recluster_all_subclusters.csv']:
    r=pd.read_csv(B+'mz/rescue/'+f); print(f,r.shape, r.columns.tolist())
    c=[c for c in r.columns if r[c].astype(str).str.contains('Stereo|CS7_st|Cui|Xiao|stereo',case=False).any()]
    print(' cols with stereo',c)
    if c: print(r[r[c[0]].astype(str).str.contains('Stereo|Cui|Xiao|stereo',case=False)].to_string()[:5000])


# ---- cell [frame 18ae5ceb, message 37] Printing Stereo-seq rescue rows compactly
r=pd.read_csv(B+'mz/rescue/layer_rescue_results.csv')
s=r[r.dataset.str.contains('Stereo|Cui|Xiao|CS7_st|CS8_st',case=False)]
print(r.dataset.unique())
for _,x in s.iterrows(): print(' | '.join(f'{k}={v}' for k,v in x.items()))
rb=pd.read_csv(B+'mz/rescue/recluster_best_subclusters.csv'); print(rb.columns.tolist()); print(rb.dataset.unique() if 'dataset' in rb else rb.iloc[:,0].unique())


# ---- cell [frame 18ae5ceb, message 39] Printing Stereo-seq recluster best subclusters
s=rb[rb.dataset.str.contains('Stereo')]
for _,x in s.iterrows(): print(' | '.join(f'{k}={v}' for k,v in x.items() if k not in ['pool_set_score','best_set_score']))


# ---- cell [frame 18ae5ceb, message 41] Reading mouse calibration sheets and label vocabularies
for k in ['mouse_10x_calibration','mouse_marker_specificity','windows']:
    print('---',k); print(wb[k].to_string()[:3500])
for st in ['CS7','CS8']:
    l=lab[lab.stage==st]
    print(st,'Types allant/ery/PGC/cardio:',l.Types[l.Types.str.contains('Allant|Eryth|PGC|Germ|Cardi|Endoth|Blood|Haem|Hem|Notoch|Node',case=False)].value_counts().to_dict())
    print(st,'Type3 notochord/allantois:',l.Type3[l.Type3.str.contains('notoch|allant',case=False)].value_counts().to_dict())
import glob; print(glob.glob((str(HGC_DATA) + '/*RNA-MapQ*')), glob.glob((str(HGC_DATA) + '/*CS9*')))


# ---- cell [frame 18ae5ceb, message 45] Building per-spot tables and population masks
import numpy as np
DSN={'CS7':'Cui CS7 (Stereo-seq)','CS8':'Xiao CS8 (Stereo-seq)'}
T={}
for st in ['CS7','CS8']:
    l=L.loc[X[st].index].copy()
    l['T2']=l.Type2.str.split(n=1).str[1]
    T[st]=pd.concat([l,X[st].drop(columns=['nCount_RNA','nCount_check'])],axis=1)
def pos(df,g): return df[g].values>0
def pc(mask_t, v): return 100*v[mask_t].mean() if mask_t.sum() else np.nan
# quick table of key numbers
for st in ['CS7','CS8']:
    d=T[st]; disc=d.in_disc_fine.values
    for grp,genes in [('APS',['GSC','FOXA2','TBXT','CHRD']),('Node',['GSC','FOXA2','NOTO','SHH','FOXJ1','CHRD']),('DE',['FOXA2','SOX17','GSC','CER1']),('CLE',['NKX1-2','CDX2','HOXB8','SOX2','TBXT']),('Nas.Meso',['MESP1','TBX6']),('EPI',['HESX1','SIX3','OTX2']),('aECT',['HESX1','SIX3']),('PS',['MESP1','HOXA1','EOMES'])]:
        t=(d.our_group_fine==grp).values; b=disc&~t
        print(st,grp,t.sum(),' '.join(f"{g}:{pc(t,pos(d,g)):.1f}/{pc(b,pos(d,g)):.1f}" for g in genes))


# ---- cell [frame 18ae5ceb, message 47] Computing evidence rows for all 19 milestones
MID=['m01','m02','m03','m04','m05','m06','m07','m08','m09','m10','m11','m12','m13','m14','m15','m16','m17','m18','m19']
MNAME=['Nascent mesoderm forms (Mesp1+)','Anterior primitive streak forms (Gsc+Foxa2+ streak)','Node-like cells appear (Foxj1+Chrd+)','Definitive endoderm appears (Foxa2+Sox17+)','ADE appears (Gsc+Cer1+ DE)','ADE programme regresses (Gsc lost from DE)','Notochord forms (Noto+ axial cells)',"3' HOX on in streak (Hoxa1+ or Hoxb1+ PS)",'Caudal epiblast forms (Nkx1-2+Cdx2+)','Neural plate forms (Hesx1+Six3+ rostral neurectoderm)','Paraxial mesoderm forms (Meox1+Tcf15+)','EOMES switched off in streak',"5' HOX on in caudal epiblast (Hoxb8+)",'Cardiomyocytes appear (Nkx2-5+Tnnt2+)','PGCs appear (Dppa3+Nanos3+)','Haemato-endothelial progenitors appear (Etv2+Kdr+)','Extra-embryonic mesoderm expands (Hand1+)','Allantois forms (Tbx4+Hoxa10+)','Primitive erythroid cells appear (Hba-x+Gata1+; human HBZ/HBE1 + GATA1)']
FIGCALL={DSN[st]:dict(zip(MID,mc[DSN[st]].values)) for st in DSN}
FIGEV={DSN[st]:dict(zip(MID,mc[DSN[st]+' | evidence'].values)) for st in DSN}
ms=wb['mouse_marker_specificity']
def mref(ct,genes): 
    s=ms[(ms.celltype==ct)&ms.gene.isin(genes)]
    return '; '.join(f"mouse {ct} {r.gene} {r.pct_in}% vs {r.pct_other}% other" for r in s.itertuples())
ONSET=dict(zip(MID,[6.625,6.875,6.875,7.125,7.125,7.375,7.375,7.375,7.375,7.375,7.625,7.625,7.625,7.875,6.875,6.875,7.375,7.625,7.625]))
rows=[]
def mask(d,kind,val):
    if kind=='fine': return (d.our_group_fine.isin(val if isinstance(val,list) else [val])).values
    if kind=='T2': return (d.T2.isin(val if isinstance(val,list) else [val])).values
    if kind=='Types': return d.Types.str.contains(val,regex=True).values
    if kind=='Type3': return d.Type3.str.contains(val,regex=True).values
def gpos(d,expr):
    gs=expr.split('+'); m=np.ones(len(d),bool)
    for g in gs: m&=d[g].values>0
    return m
def add(st,mid,tname,t,metric,genes=None,bname=None,b=None,mouse='',note='',count=False):
    d=T[st]; r=dict(dataset=DSN[st],milestone_id=mid,milestone=MNAME[MID.index(mid)],figure_call=FIGCALL[DSN[st]][mid],
        target_population=tname,n_target=int(t.sum()),metric=metric,mouse_reference=mouse,note=note)
    if count: r.update(value_target=int(t.sum()),background_population='',n_background=np.nan,value_background=np.nan)
    else:
        v=gpos(d,genes); r.update(value_target=round(pc(t,v),2) if t.sum() else np.nan,background_population=bname,n_background=int(b.sum()),value_background=round(pc(b,v),2),
                                  n_pos_target=int((v&t).sum()))
    rows.append(r); return r
def disc_bg(d,t): return d.in_disc_fine.values & ~t
def all_bg(d,t): return ~t
DB='other in-disc spots (in_disc_fine, excl. target)'; AB='all other spots of the embryo (excl. target)'
for st in ['CS7','CS8']:
    d=T[st]; disc=d.in_disc_fine.values
    # m01
    t=mask(d,'fine','Nas.Meso'); add(st,'m01','Nas.Meso (fine label 80 Nascent Mesoderm)',t,'spots annotated as nascent mesoderm',count=True,mouse='mouse nascent mesoderm onset E6.625')
    if t.sum(): add(st,'m01','Nas.Meso',t,'MESP1 detection %','MESP1',DB,disc_bg(d,t),mref('Nascent mesoderm',['Mesp1']))
    t=mask(d,'fine','PS'); add(st,'m01','PS (77 Primitive Streak)',t,'MESP1 detection %','MESP1',DB,disc_bg(d,t),mref('Nascent mesoderm',['Mesp1']))
    # m02
    t=mask(d,'fine','APS'); add(st,'m02','APS (76 Anterior Primitive Streak)',t,'spots annotated as APS',count=True,mouse='mouse APS onset E6.875')
    for g in ['GSC','FOXA2','GSC+FOXA2']: add(st,'m02','APS',t,f'{g} detection %',g,DB,disc_bg(d,t),mref('Anterior Primitive Streak',['Gsc','Foxa2']))
    t=mask(d,'fine','Node')
    for g in ['GSC','FOXA2','GSC+FOXA2']: add(st,'m02','Node/axial (62-63 Node)',t,f'{g} detection %',g,DB,disc_bg(d,t),mref('Anterior Primitive Streak',['Gsc','Foxa2']),note='axial population alternative allowed by human criterion')
    # m03
    t=mask(d,'fine','Node'); add(st,'m03','Node (62-63 Node)',t,'spots annotated as node',count=True,mouse='mouse node-like cells onset E6.875')
    for g in ['FOXJ1','CHRD','FOXJ1+CHRD']: add(st,'m03','Node',t,f'{g} detection %',g,DB,disc_bg(d,t),mref('Notochord',['Foxj1','Chrd']))
    # m04
    t=mask(d,'fine','DE'); add(st,'m04','DE (137 Definitive Endoderm)',t,'spots annotated as DE',count=True,mouse='mouse DE onset E7.125')
    for g in ['FOXA2','SOX17','FOXA2+SOX17']: add(st,'m04','DE',t,f'{g} detection %',g,DB,disc_bg(d,t),mref('Def. endoderm',['Foxa2','Sox17']))
    # m05
    for g in ['GSC','CER1','GSC+CER1']: add(st,'m05','DE',t,f'{g} detection % of DE',g,DB,disc_bg(d,t),mref('Def. endoderm',['Cer1'])+'; mouse Gsc+Cer1+ DE: 0.26% (E7.0), 2.2% (E7.25) of embryo-proper cells')
    v=gpos(d,'GSC+CER1')&t; add(st,'m05','GSC+CER1+ DE spots',v,'GSC+CER1+ DE spots, % of in-disc spots',count=True,mouse='mouse 0.26% (E7.0), 2.2% (E7.25) of embryo-proper cells',note=f'{100*v.sum()/disc.sum():.2f}% of {disc.sum()} in-disc spots')
    # m06
    add(st,'m06','DE',t,'GSC detection % of DE','GSC',DB,disc_bg(d,t),'mouse 10x DE Gsc 52→70% (E7.0–7.25), 22.6% (E7.5), 2.3% (E7.75); loss threshold 52.3% (75% of peak); human criterion: GSC in DE fallen to background')
    # m07
    t3=mask(d,'Type3','early notochord'); add(st,'m07','early notochord (Type3 62)',t3,'spots annotated as early notochord',count=True,mouse='mouse notochord onset E7.375')
    t=mask(d,'fine','Node')
    for g in ['NOTO','SHH','NOTO+FOXA2']: add(st,'m07','Node/axial (62-63 Node)',t,f'{g} detection %',g,DB,disc_bg(d,t),'mouse node-like E7.0 Noto ~25%; node/notochord E7.5 90%; '+mref('Notochord',['Noto','Shh']))
    if t3.sum(): add(st,'m07','early notochord (Type3)',t3,'NOTO detection %','NOTO',DB,disc_bg(d,t3),'mouse notochord Noto 91.2% vs 0.7%')
    # m08
    t=mask(d,'fine','PS')
    for g in ['HOXA1','HOXB1']: add(st,'m08','PS (77 Primitive Streak)',t,f'{g} detection %',g,DB,disc_bg(d,t),'mouse PS Hoxa1 0.4→5.2→15.6% (E7.0→E7.5→E7.75; onset threshold 3.9% = 25% of max 15.6%); Hoxb1 2.2→10.0→21.9%')
    t=mask(d,'fine',['PS','APS']); add(st,'m08','PS+APS',t,'HOXA1 detection %','HOXA1',DB,disc_bg(d,t),'mouse PS Hoxa1 onset threshold 3.9%')
    # m09
    t=mask(d,'fine','CLE'); add(st,'m09','CLE (78 Caudal Lateral Epiblast)',t,'spots annotated as CLE',count=True,mouse='mouse caudal epiblast onset E7.375')
    for g in ['NKX1-2','CDX2','NKX1-2+CDX2']: add(st,'m09','CLE',t,f'{g} detection %',g,DB,disc_bg(d,t),mref('Caudal epiblast',['Nkx1-2','Cdx2']))
    te=mask(d,'fine',['EPI','pECT','CLE','PS','APS'])
    add(st,'m09','epiblast+streak (EPI,pECT,CLE,PS,APS)',te,'NKX1-2+CDX2+ detection %','NKX1-2+CDX2',DB,disc_bg(d,te),'mouse caudal epiblast Nkx1-2 89.8%, Cdx2 97.2%')
    # m10
    tn=mask(d,'fine',['EPI','aECT']); 
    for g in ['HESX1','SIX3','HESX1+SIX3']: add(st,'m10','anterior epiblast/aECT (1 Anterior Epiblast + aECT)',tn,f'{g} detection %',g,DB,disc_bg(d,tn),mref('Rostral neurectoderm',['Hesx1','Six3']))
    ta=mask(d,'fine','aECT'); add(st,'m10','aECT (neural ectoderm labels)',ta,'spots annotated as aECT/forebrain/neural ectoderm',count=True,mouse='mouse rostral neurectoderm onset E7.375')
    # m11
    tp=mask(d,'fine','Para.Meso'); add(st,'m11','Para.Meso (82 PSM/somite labels)',tp,'spots annotated as paraxial mesoderm',count=True,mouse='mouse paraxial mesoderm onset E7.625')
    tm=mask(d,'fine',['Nas.Meso','Para.Meso','Adv.Meso','Rostral.Meso','LP.Meso','Other.Meso','Heart mesoderm'])
    for g in ['MEOX1','TCF15','MEOX1+TCF15']: add(st,'m11','embryonic mesoderm (all mesoderm fine groups)',tm,f'{g} detection %',g,DB,disc_bg(d,tm),mref('Paraxial mesoderm',['Meox1','Tcf15']))
    # m12
    t=mask(d,'fine','PS'); add(st,'m12','PS',t,'EOMES detection %','EOMES',DB,disc_bg(d,t),'mouse PS Eomes 89→75→55% (E7.0→E7.5→E7.75); human criterion: EOMES in PS fallen to background')
    t=mask(d,'fine',['PS','APS']); add(st,'m12','PS+APS',t,'EOMES detection %','EOMES',DB,disc_bg(d,t),'mouse PS Eomes 54.7% at E7.75 (10x)')
    # m13
    t=mask(d,'fine','CLE'); add(st,'m13','CLE',t,'HOXB8 detection %','HOXB8',DB,disc_bg(d,t),'mouse caudal epiblast Hoxb8 5.3% (E7.5), 52.1% (E7.75); onset threshold 22.6%')
    tc=gpos(d,'NKX1-2+CDX2')&te; add(st,'m13','NKX1-2+CDX2+ epiblast/streak spots',tc,'HOXB8 detection %','HOXB8',DB,disc_bg(d,tc),'mouse caudal epiblast Hoxb8 onset threshold 22.6%')
    # m14
    tcp=mask(d,'T2','Cardiac progenitor'); tcm=mask(d,'T2','Cardiomyocyte')
    add(st,'m14','Cardiomyocyte (Type2)',tcm,'spots annotated as cardiomyocyte (Type2)',count=True,mouse='mouse cardiomyocyte onset E7.875')
    for g in ['NKX2-5','TNNT2','MYL7','NKX2-5+TNNT2']: add(st,'m14','Cardiac progenitor (Type2)',tcp,f'{g} detection %',g,AB,all_bg(d,tcp),'mouse cardiomyocytes Nkx2-5 93–97%, Tnnt2 99.8% (10x)')
    th=mask(d,'fine','Heart mesoderm')
    if th.sum()>=10:
        for g in ['NKX2-5','MYL7']: add(st,'m14','Heart mesoderm (93 Endocardial Fibroblast)',th,f'{g} detection %',g,DB,disc_bg(d,th),'mouse cardiomyocytes Nkx2-5 93–97%')
    # m15
    add(st,'m15','PGC (Type2)',mask(d,'T2','PGC'),'spots annotated as PGC (Type2)',count=True,mouse='mouse PGC onset E6.875')
    tpg=mask(d,'Types','Primordial Germ'); add(st,'m15','PGC (Types 65)',tpg,'spots annotated as PGC (Types, fine)',count=True)
    if tpg.sum():
        for g in ['NANOS3','DPPA3','NANOS3+TFAP2C']: add(st,'m15','PGC (Types 65)',tpg,f'{g} detection %',g,AB,all_bg(d,tpg),mref('PGC',['Dppa3','Nanos3']))
    for g in ['NANOS3','DPPA3','NANOS3+TFAP2C','NANOS3+DPPA3']:
        allm=np.ones(len(d),bool); add(st,'m15','all spots',allm,f'{g}+ spots, % of all spots',g,'none',np.zeros(len(d),bool),mref('PGC',['Dppa3','Nanos3']))
    # m16
    the=mask(d,'T2',['Endothelial cell','Blood progenitor'])
    add(st,'m16','Endothelial cell + Blood progenitor (Type2)',the,'spots annotated as endothelial + blood progenitor',count=True,mouse='mouse haemato-endothelial progenitors onset E6.875',
        note=f"Endothelial {mask(d,'T2','Endothelial cell').sum()} + Blood progenitor {mask(d,'T2','Blood progenitor').sum()}")
    for g in ['ETV2','KDR','TAL1','ETV2+KDR']: add(st,'m16','Endothelial + Blood progenitor',the,f'{g} detection %',g,AB,all_bg(d,the),mref('Haematoendothelial progenitors',['Etv2','Kdr','Tal1']))
    # m17
    tx=mask(d,'T2',['EXM','YS.Meso'])
    add(st,'m17','EXM + YS.Meso (Type2)',tx,'spots annotated as EXM + YS mesoderm',count=True,mouse='mouse ExE mesoderm onset E7.375',note=f"EXM {mask(d,'T2','EXM').sum()} + YS.Meso {mask(d,'T2','YS.Meso').sum()}")
    add(st,'m17','EXM + YS.Meso',tx,'HAND1 detection %','HAND1',AB,all_bg(d,tx),mref('ExE mesoderm',['Hand1']))
    # m18
    tal=mask(d,'Types','Allantois'); add(st,'m18','Allantois (Types 117)',tal,'spots annotated as allantois (Types)',count=True,mouse='mouse allantois onset E7.625',note=f"Type2 Allantois {mask(d,'T2','Allantois').sum()}; Type3 allantois {mask(d,'Type3','allantois').sum()}")
    for g in ['TBX4','HOXA10','TBX4+HOXA10']:
        if tal.sum(): add(st,'m18','Allantois (Types 117)',tal,f'{g} detection %',g,AB,all_bg(d,tal),mref('Allantois',['Tbx4','Hoxa10']))
    tad=mask(d,'fine','Adv.Meso')
    for g in ['TBX4','HOXA10','TBX4+HOXA10']: add(st,'m18','Adv.Meso (106 Advanced Mesoderm)',tad,f'{g} detection %',g,AB,all_bg(d,tad),mref('Allantois',['Tbx4','Hoxa10']),note='whole Adv.Meso group; the 560-spot re-clustered subcluster cited for Cui is not recoverable (membership not saved)')
    # m19
    te_=mask(d,'Types','Erythrocyte'); add(st,'m19','Erythrocyte (Types 134-136)',te_,'spots annotated as erythrocyte',count=True,mouse='mouse Erythroid1 onset E7.625')
    nb=~mask(d,'T2',['Erythrocyte','Blood progenitor','Endothelial cell'])&~te_
    for g in ['HBZ','HBE1','GATA1','HBZ+GATA1']: add(st,'m19','Erythrocyte',te_,f'{g} detection %',g,'non-blood, non-endothelial spots',nb,mref('Erythroid1',['Hba-x','Gata1']))
    for g in ['HBZ','GATA1']: add(st,'m19','Erythrocyte',te_,f'{g} detection % (disc background)',g,'in-disc spots (excl. erythrocyte)',disc&~te_,'HBZ ambient check')
R=pd.DataFrame(rows); print(R.shape)
pd.set_option('display.max_colwidth',40)
print(R[['dataset','milestone_id','target_population','n_target','metric','value_target','n_background','value_background']].to_string())


# ---- cell [frame 18ae5ceb, message 50] Printing compact evidence table
R['ds']=R.dataset.str[:3]
for _,r in R.iterrows():
    print(f"{r.ds} {r.milestone_id} {r.target_population[:28]:28s} n={r.n_target:<5} {r.metric[:40]:40s} {r.value_target} | bg {r.value_background} (n={r.n_background}) {r.note[:50] if isinstance(r.note,str) else ''}")


# ---- cell [frame 18ae5ceb, message 57] Computing CS9 same-platform positive controls
c9=pd.read_csv((str(HGC_DATA) + '/milestone_evidence/out_stereo/work/CS9_markers.csv'))
c9['T2']=c9.Type2.str.split(n=1).str[1]
print(c9.shape, c9.T2.value_counts().to_dict())
print(c9.Types.value_counts().head(70).to_dict())


# ---- cell [frame 18ae5ceb, message 59] Scoring marker detection in CS9 positive-control populations
def c9m(pat): return c9.Types.str.contains(pat,regex=True).values
CTRL=[('m10','Neural Ectoderm + Forebrain (CS9)','6 Neural Ectoderm|Forebrain',['HESX1','SIX3','HESX1+SIX3','OTX2']),
      ('m11','Somite + Somitomere + PSM (CS9)','84-85 Somite|83 Somitomere|82 Presomite',['MEOX1','TCF15','MEOX1+TCF15']),
      ('m13','NMP (CS9)','79 Neuromesodermal',['HOXB8','NKX1-2','CDX2']),
      ('m14','Atrial + Ventricle cardiomyocyte (CS9)','Cardiomyocyte|Cardiaomyocyte',['NKX2-5','TNNT2','MYL7','NKX2-5+TNNT2']),
      ('m15','PGC (CS9)','Primordial Germ',['NANOS3','DPPA3']),
      ('m16','Hemogenic endothelium + haematopoietic progenitor (CS9)','121-122 Hemogenic|132 Hematopoietic',['ETV2','KDR','TAL1']),
      ('m18','Allantois (CS9)','117 Allantois',['TBX4','HOXA10','TBX4+HOXA10']),
      ('m19','Erythrocyte (CS9)','Erythrocyte',['HBZ','GATA1'])]
ctrl_rows=[]
for mid,name,pat,genes in CTRL:
    t=c9m(pat); b=~t
    for g in genes:
        v=np.ones(len(c9),bool)
        for gg in g.split('+'): v&=c9[gg].values>0
        ctrl_rows.append(dict(milestone_id=mid,population=name,n=int(t.sum()),gene=g,pct=round(100*v[t].mean(),2) if t.sum() else np.nan,n_bg=int(b.sum()),pct_bg=round(100*v[b].mean(),2)))
CT=pd.DataFrame(ctrl_rows); print(CT.to_string())
print('CS9 median nCount',c9.nCount_RNA.median(), {st:T[st].nCount_RNA.median() for st in T})


# ---- cell [frame 18ae5ceb, message 61] Adding CS9 NMP and node controls, assigning recomputed calls
for mid,name,pat,genes in [('m09','NMP (CS9)','79 Neuromesodermal',['NKX1-2+CDX2']),('m07','Node (CS9)','62-63 Node',['NOTO','FOXJ1'])]:
    t=c9m(pat); b=~t
    for g in genes:
        v=np.ones(len(c9),bool)
        for gg in g.split('+'): v&=c9[gg].values>0
        ctrl_rows.append(dict(milestone_id=mid,population=name,n=int(t.sum()),gene=g,pct=round(100*v[t].mean(),2),n_bg=int(b.sum()),pct_bg=round(100*v[b].mean(),2)))
CT=pd.DataFrame(ctrl_rows); print(CT.tail(3).to_string())
def ctrl(mid):
    s=CT[CT.milestone_id==mid]
    return 'CS9 Stereo-seq control: '+'; '.join(f"{r.population.replace(' (CS9)','')} n={r.n} {r.gene} {r.pct}% vs {r.pct_bg}%" for r in s.itertuples()) if len(s) else ''
print(ctrl('m11'))


# ---- cell [frame 18ae5ceb, message 63] Assigning recomputed calls and support verdicts
def V(st,mid,metric_start,pop_start=None):
    s=R[(R.dataset==DSN[st])&(R.milestone_id==mid)&R.metric.str.startswith(metric_start)]
    if pop_start: s=s[s.target_population.str.startswith(pop_start)]
    r=s.iloc[0]; return r
def f(r): 
    if pd.isna(r.value_background): return f"{r.value_target:g} (n={r.n_target})"
    return f"{r.value_target:.1f}% vs {r.value_background:.1f}% (n={r.n_target}/{r.n_background})"
def enr(r): return (r.value_target>=2*max(r.value_background,0.01)) and (r.value_target-r.value_background>=5)
DEC={}
for st in ['CS7','CS8']:
    D_={}
    # m01
    if st=='CS7':
        r=V(st,'m01','MESP1','Nas.Meso'); D_['m01']=('reached','yes',f"Nas.Meso 378 spots; MESP1 {f(r)}")
    else:
        r=V(st,'m01','MESP1','PS'); D_['m01']=('reached' if enr(r) else 'partial','yes' if enr(r) else 'partly',f"no Nas.Meso label; PS MESP1 {f(r)}")
    # m02
    a1,a2=V(st,'m02','GSC detection','APS'),V(st,'m02','FOXA2 detection','APS'); n1=V(st,'m02','GSC+FOXA2','Node')
    D_['m02']=('reached','partly',f"cited APS label is not GSC/FOXA2-enriched (APS GSC {f(a1)}, FOXA2 {f(a2)}); call holds via axial (Node) spots GSC+FOXA2+ {f(n1)}")
    # m03
    r=V(st,'m03','FOXJ1+CHRD'); D_['m03']=('reached','yes',f"Node FOXJ1+CHRD+ {f(r)}")
    # m04
    r=V(st,'m04','FOXA2+SOX17'); a=V(st,'m04','SOX17'); D_['m04']=('reached','yes',f"DE FOXA2+SOX17+ {f(r)}; SOX17 {f(a)}")
    # m05
    r=V(st,'m05','GSC+CER1 detection'); g=V(st,'m05','GSC detection'); c=V(st,'m05','CER1 detection')
    rc='reached' if (r.value_target>=10 and enr(r)) else ('partial' if (enr(g) or enr(c)) else 'not reached')
    D_['m05']=(rc,'yes' if rc==FIGCALL[DSN[st]]['m05'] else 'no',f"GSC+CER1+ {f(r)} of DE ({int(r.n_pos_target)} spots); GSC {f(g)}, CER1 {f(c)}")
    # m06
    g=V(st,'m06','GSC'); rc='not reached' if g.value_target>=22.6 else ('reached' if g.value_target<=2*g.value_background else 'partial')
    D_['m06']=(rc,'yes' if rc==FIGCALL[DSN[st]]['m06'] else 'no',f"DE GSC {f(g)}; rule: ≥22.6% (mouse E7.5) not reached, ≤2× background reached, else partial")
    # m07
    e=V(st,'m07','spots annotated'); n=V(st,'m07','NOTO detection','Node'); nf=V(st,'m07','NOTO+FOXA2')
    D_['m07']=('reached','yes',f"early-notochord (Type3) {int(e.value_target)} spots; Node NOTO {f(n)}; NOTO+FOXA2+ {f(nf)}; NOTO% lies between mouse E7.0 (~25%) and E7.5 (90%)")
    # m08
    h=V(st,'m08','HOXA1','PS ('); hb=V(st,'m08','HOXB1'); pa=V(st,'m08','HOXA1','PS+APS')
    D_['m08']=('reached' if (h.value_target>=3.9 and h.value_target>=2*h.value_background) else 'partial','yes',
               f"PS HOXA1 {f(h)} ({int(h.n_pos_target)} positive spots) ≥ mouse onset threshold 3.9%; HOXB1 {f(hb)} not enriched; PS+APS HOXA1 {f(pa)}"+(' — rests on 5 spots (provisional)' if st=='CS8' else ''))
    # m09
    k=V(st,'m09','NKX1-2 detection'); c=V(st,'m09','CDX2'); kc=V(st,'m09','NKX1-2+CDX2 detection'); ep=V(st,'m09','NKX1-2+CDX2+','epiblast')
    D_['m09']=('partial','no' if FIGCALL[DSN[st]]['m09']=='reached' else 'yes',
               f"CLE {k.n_target} spots; NKX1-2 {f(k)}, CDX2 {f(c)}; NKX1-2+CDX2+ {f(kc)} ({int(kc.n_pos_target)} spots); epiblast+streak NKX1-2+CDX2+ {f(ep)}; CS9 NMP control NKX1-2+CDX2+ 26.7% vs 0.3% — co-expression detectable on platform but weak here")
    # m10
    h=V(st,'m10','HESX1 detection'); s_=V(st,'m10','SIX3 detection'); hs=V(st,'m10','HESX1+SIX3')
    D_['m10']=('not assessable','yes',f"anterior epiblast HESX1 {f(h)}, SIX3 {f(s_)}, HESX1+SIX3+ {f(hs)}; markers not detected even in CS9 neural ectoderm/forebrain (HESX1 0.9%, SIX3 0.9%, n=760) → platform cannot detect them")
    # m11
    m_=V(st,'m11','MEOX1 detection'); t_=V(st,'m11','TCF15 detection'); mt=V(st,'m11','MEOX1+TCF15'); pp=V(st,'m11','spots annotated')
    D_['m11']=('not reached','no',f"Para.Meso label {int(pp.value_target)} spots; all embryonic mesoderm MEOX1 {f(m_)}, TCF15 {f(t_)}, MEOX1+TCF15+ {int(mt.n_pos_target)} spots; same-platform CS9 somite/PSM control MEOX1 62.5%, TCF15 43.3% (n=323) → markers are detectable, so absence = not reached")
    # m12
    e=V(st,'m12','EOMES','PS'); D_['m12']=('not reached','yes',f"PS EOMES {f(e)} — still >3× background")
    # m13
    h=V(st,'m13','HOXB8','CLE'); D_['m13']=('not reached','yes',f"CLE HOXB8 {f(h)}; HOXB8 detectable on platform (CS9 NMP 25.0% vs 4.1%, n=116)"+(' — CLE n=94 (provisional)' if st=='CS8' else ''))
    # m14
    nk=V(st,'m14','NKX2-5 detection','Cardiac'); tn=V(st,'m14','TNNT2'); my=V(st,'m14','MYL7','Cardiac'); cm=V(st,'m14','spots annotated')
    D_['m14']=('not reached','no',f"Cardiomyocyte label {int(cm.value_target)} spots; cardiac progenitor NKX2-5 {f(nk)}, TNNT2 {f(tn)}, MYL7 {f(my)}; CS9 cardiomyocyte control NKX2-5 73.9%, TNNT2 100% (n=429) → NKX2-5 detectable on platform, so absence = not reached")
    # m15
    p2=V(st,'m15','spots annotated as PGC (Type2)'); pt=V(st,'m15','spots annotated as PGC (Types'); na=V(st,'m15','NANOS3+ spots'); nt=V(st,'m15','NANOS3+TFAP2C+')
    D_['m15']=('not assessable','yes',f"PGC label Type2 {int(p2.value_target)}, Types {int(pt.value_target)} spots"+(" (NANOS3 0/12, DPPA3 0/12)" if st=='CS8' else '')+f"; NANOS3+ {na.value_target:.2f}% of all spots, NANOS3+TFAP2C+ {int(nt.n_pos_target)} spots; no CS9 PGC control (0 PGC spots) → sensitivity for PGCs unknown")
    # m16
    k=V(st,'m16','KDR'); ta=V(st,'m16','TAL1'); et=V(st,'m16','ETV2 detection'); n_=V(st,'m16','spots annotated')
    D_['m16']=('reached','yes',f"{n_.note} spots; KDR {f(k)}, TAL1 {f(ta)}; ETV2 {f(et)} not enriched (also not in CS9 HE control 2.0% vs 1.8%) — TAL1 used as substitute")
    # m17
    h=V(st,'m17','HAND1'); n_=V(st,'m17','spots annotated'); D_['m17']=('reached','yes',f"{n_.note} spots; HAND1 {f(h)}")
    # m18
    al=V(st,'m18','spots annotated')
    if st=='CS7':
        a=V(st,'m18','TBX4 detection','Adv'); b_=V(st,'m18','HOXA10 detection','Adv'); ab=V(st,'m18','TBX4+HOXA10','Adv')
        D_['m18']=('reached (provisional, marker-level)','partly',f"only {int(al.value_target)} spots labelled allantois; Adv.Meso TBX4 {f(a)}, HOXA10 {f(b_)}, TBX4+HOXA10+ {int(ab.n_pos_target)} spots ({ab.value_target:.2f}% vs {ab.value_background:.2f}%) ≈ CS9 allantois control (TBX4 1.5%, HOXA10 3.4%); cited 560-spot subcluster not reproducible (membership not saved)")
    else:
        a=V(st,'m18','TBX4 detection','Allantois'); b_=V(st,'m18','HOXA10 detection','Allantois')
        D_['m18']=('partial','no',f"{int(al.value_target)} spots labelled allantois (label transfer) but TBX4 {f(a)}, HOXA10 {f(b_)} — at background, below CS9 allantois control (TBX4 1.5%, HOXA10 3.4%); call rests on label only")
    # m19
    hz=V(st,'m19','HBZ detection %'); ga=V(st,'m19','GATA1 detection %'); n_=V(st,'m19','spots annotated')
    D_['m19']=('reached','yes',f"erythrocyte {int(n_.value_target)} spots; HBZ {f(hz)} (ambient: bkg high), GATA1 {f(ga)}; CS9 erythrocyte GATA1 4.0% → GATA1 low-sensitivity on platform")
    DEC[DSN[st]]=D_
for k,D_ in DEC.items():
    for mid,(rc,sup,nt) in D_.items():
        if sup!='yes': print(k[:3],mid,FIGCALL[k][mid],'->',rc,sup)


# ---- cell [frame 18ae5ceb, message 65] Checking window impact of recomputed calls
DOM=dict(zip(MID,['disc']*14+['extra']*5))
def window(calls):
    lo=max(ONSET[m] for m in MID if DOM[m]=='disc' and calls[m]=='reached'); nr=[ONSET[m] for m in MID if DOM[m]=='disc' and calls[m]=='not reached']; hi=min(nr) if nr else np.inf
    tied=lo>=hi
    if tied:
        grid=np.array([6.5,6.75,7.0,7.25,7.5,7.75,8.0,8.25,8.5]); j=np.searchsorted(grid,lo); lo,hi=grid[j-1],grid[j]
    return lo,hi,tied
WIN={}
for k in DEC:
    rc={m:DEC[k][m][0].split(' (')[0] for m in MID}
    WIN[k]=(window(FIGCALL[k]),window(rc)); print(k,'figure',WIN[k][0],'recomputed',WIN[k][1])


# ---- cell [frame 18ae5ceb, message 67] Writing evidence and positive-control CSVs
OUT=(str(HGC_DATA) + '/milestone_evidence/out_stereo/')
R2=R.copy()
R2['recomputed_call']=[DEC[d][m][0] for d,m in zip(R2.dataset,R2.milestone_id)]
R2['supports_figure_call']=[DEC[d][m][1] if not DEC[d][m][0].startswith('not assessable') else ('not assessable' if FIGCALL[d][m]=='not assessable' else DEC[d][m][1]) for d,m in zip(R2.dataset,R2.milestone_id)]
# schema asks 'yes/partly/no/not assessable'; for agreed NA calls use 'not assessable'
R2['note']=[(n+' | ' if isinstance(n,str) and n else '')+DEC[d][m][2]+(' | '+ctrl(m) if ctrl(m) else '') for n,d,m in zip(R2.note,R2.dataset,R2.milestone_id)]
R2['figure_evidence_string']=[FIGEV[d][m] for d,m in zip(R2.dataset,R2.milestone_id)]
R2['detection_rule']='>=1 UMI per bin50 spot'
cols=['dataset','milestone_id','milestone','figure_call','target_population','n_target','metric','value_target','n_pos_target','background_population','n_background','value_background','mouse_reference','recomputed_call','supports_figure_call','note','figure_evidence_string','detection_rule']
R2=R2[cols]; R2.to_csv(OUT+'evidence_stereo.csv',index=False)
CT.to_csv(OUT+'positive_controls_CS9_stereo.csv',index=False)
print(R2.shape, R2.groupby('dataset').milestone_id.nunique().to_dict(), R2.supports_figure_call.value_counts().to_dict())
