import sys, json, os, numpy as np, pandas as pd, optuna, torch
sys.argv=[sys.argv[0],'0']; sys.path.insert(0,'ai/step7')
exec(open('ai/step7/loop.py').read().split('# ---------- search space')[0])      # evaluate(), score(), BASE (val), SIG
from scipy.stats import wilcoxon
O='ai/step7/final/'; os.makedirs(O,exist_ok=True)
st=optuna.load_study(study_name='s7',storage='sqlite:///ai/step7/opt.db')
TRs=[t for t in st.trials if t.value is not None]; TRs.sort(key=lambda t:t.value)
seen=set(); top=[]
for t in TRs:
    key=json.dumps(t.params,sort_keys=True)
    if key in seen: continue
    seen.add(key); top.append(t)
    if len(top)==5: break
def cfg_of(t):
    p=dict(t.params); p['h']=p.pop('net_h',p.pop('flow_h',None)); return p
BL=evaluate(('linear_noise',None),BCFG,'locked'); LL=evaluate(('linear',None),dict(pair='emd_cen'),'locked')
def per_mid(df): return df.groupby('em').agg(ta=('ta','mean'),ED=('ED','mean'),terr=('terr','mean'))
bl,ll=per_mid(BL),per_mid(LL); rows=[]
for rank,t in enumerate(top):
    cfg=cfg_of(t); eds=[]; ters=[]
    for seed in range(5):
        df=per_mid(evaluate(fit(cfg,seed),cfg,'locked',seed)); eds.append(df.ED); ters.append(df.terr)
    ed=pd.concat(eds,axis=1).mean(1); te=pd.concat(ters,axis=1).mean(1)
    for nm,ref in [('vs_linear',ll),('vs_linear_noise',bl)]:
        v=np.log(ed/ref.ED); rows.append(dict(rank=rank,trial=t.number,family=cfg['family'],val_score=t.value,comparison=nm,n_mid=len(v),median_pct=100*(np.exp(v.median())-1),
                frac_better=float((v<0).mean()),p=float(wilcoxon(v).pvalue),abs_terr_model_h=float(te.abs().median()),abs_terr_ref_h=float(ref.terr.abs().median())))
    pd.DataFrame({'ED_model':ed,'terr_model':te,'ED_linear':ll.ED,'ED_linear_noise':bl.ED,'terr_linear':ll.terr,'terr_linear_noise':bl.terr,'ta':ll.ta}).to_csv(O+f'locked_per_mid_rank{rank}.csv')
    print(pd.DataFrame(rows).tail(2).round(4).to_string(index=False),flush=True)
v=np.log(bl.ED/ll.ED); rows.append(dict(rank=-1,trial=-1,family='linear+noise',comparison='vs_linear',n_mid=len(v),median_pct=100*(np.exp(v.median())-1),frac_better=float((v<0).mean()),p=float(wilcoxon(v).pvalue),abs_terr_model_h=float(bl.terr.abs().median()),abs_terr_ref_h=float(ll.terr.abs().median())))
pd.DataFrame(rows).to_csv(O+'locked_test.csv',index=False)
# ---------- final model -> human t0.5
best=cfg_of(top[0]); H=dict(HUM); H['ta']=7.25; H['tb']=7.625; gens=[]
for seed in range(5):
    M=fit(best,seed); gens.append(generate(M,best,H,seed=seed).cpu().numpy())
    if M[0]=='net': torch.save(M[1].state_dict(),O+f'generator_seed{seed}.pt')
    elif M[0]=='calib': torch.save({g:(m.cpu(),s.cpu()) for g,(m,s) in M[1].items()},O+f'generator_seed{seed}.pt')
lin=(0.5*(Zt[torch.as_tensor(H['ia'],device=dev)]+tt(H[best['pair']]))).cpu().numpy()
np.savez_compressed(O+'human_t05_latent.npz',gen=np.stack(gens),linear=lin,h_a=H['ia'])
np.savez('ai/step5_cache_concat_harm_mz.npz',Z=Z)
json.dump(dict(best_trial=top[0].number,val_score=top[0].value,config=best|{'rep':'concat_harm_mz'},human_D_days=0.375,human_t_CS7=7.25,n_trials=len(st.trials)),open(O+'generator_config.json','w'),indent=1,default=str)
print('human t05 shift from linear',float(np.linalg.norm(np.stack(gens).mean(0)-lin,axis=1).mean()))
