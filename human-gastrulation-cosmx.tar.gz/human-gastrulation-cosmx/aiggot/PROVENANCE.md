# PROVENANCE — aiggot/

## Edits applied to every file

These are the only changes made. Algorithms, parameters, seeds and output names are unchanged.
- Absolute paths were replaced by `HGC_DATA`, `HGC_OUT` or `HGC_GEN_ROOT`, following the path mapping in the README.
- Platform-only calls were removed: artifact look-ups, uploads, and copies into shared folders.
- Interactive `print` diagnostics were kept. Dead exploratory branches were removed only where they were marked as unused; each removal is listed below.
- Comments are in English. The original comments use the names that were current at the time; the README gives the name mapping.

Reconstructed files were assembled verbatim from the code cells of the analysis sessions, with the message indices given below. Lines added to join the cells together are marked `# [glue]`.

Path mapping applied:

| original | replaced by |
|---|---|
| `[F:]/CS6-CS7/cs7_cs8_matching/` | `$HGC_DATA/cs7_cs8_matching/` |
| `[G:]/data/bridge_bundle/` | `$HGC_DATA/bridge_bundle/` |
| `[G:]/data/ai_t05_v153/` | `$HGC_GEN_ROOT` |
| `[G:]/data/ai_t05/` | `$HGC_DATA/ai_t05/` |
| `[G:]/data/UCE/` | `$HGC_DATA/UCE/` |
| `[F:]/CS6-CS7/figure7/supplementary/` | `$HGC_DATA/figure7_supplementary/` |
| project artifacts | `$HGC_DATA/artifacts/<file name>` |

## Why these versions

- `lib/` matches the latest files on disk exactly (by sha256) and the copies used by the benchmark and the Stereo-seq replication. `ggot_synth.py` (synthetic benchmark only) is not imported by any paper script and was left out.
- `matching/05_run_aiggot.py ref` re-ran the default call. It reproduced 31,127 coupling pairs and 1,473 unmatched CS8 cells, with 0.9727 parent agreement with the published ancestor table; the published ancestor is the argmax of each coupling column. The branch for the variant without VE is a no-op for the tag `ref` and was left in.
- `sensitivity/08_parameter_sensitivity.py` asserts that its default run reproduces Figure 7 (penalised share 0.030617; 285 unmatched CS7 cells).
- Table S3 benchmark values are read from the benchmark flow tables (`09_compare_methods.py`, function `pen_from_flow`).
- Removed variants:
  - streak-gated AIGG-OT (τ = 25), in `10_aiggot_stereoseq_replication.py` and `09_compare_methods.py`;
  - 'Euclidean + table', in `09`;
  - QC figure code, in `02`.
- Artifact lineage code from the platform was not used. It is a reconstruction and does not match the files on disk.

## Files

| repo path | status | source | sha256 of original | Methods | figure / table |
|---|---|---|---|---|---|
| `benchmark/aggregate_real.py` | verbatim (paths/headers only) | [F:]/CS6-CS7/cs7_cs8_matching/benchmark/aggregate_real.py | `e328447e921fdfd35480a95cbb18ec90ecac3da6516dd41206cb93a8b2709ec6` | P405 | SF9G; Table S3 |
| `benchmark/bench_common.py` | verbatim (paths/headers only) | [F:]/CS6-CS7/cs7_cs8_matching/benchmark/bench_common.py | `b8c539977faf723ac2b45edf75d2357bb73d73cea72abd223f215c1e8a406c3b` | P405 | SF9G; Table S3 |
| `benchmark/bench_moscot.py` | verbatim (paths/headers only) | [F:]/CS6-CS7/cs7_cs8_matching/benchmark/bench_moscot.py | `a7467892cfa5e1940b707053b147acbbb5e99c4f0f728904f5e1f4f802245057` | P405 | SF9G; Table S3 |
| `benchmark/prep_data.py` | verbatim (paths/headers only) | [F:]/CS6-CS7/cs7_cs8_matching/benchmark/prep_data.py | `ce1d3ea43f2893515b9000f1b59ee980b90d301b94a230e2450510cdbdfb43dd` | P405 | SF9G; Table S3 |
| `benchmark/run_real.py` | verbatim (paths/headers only) | [F:]/CS6-CS7/cs7_cs8_matching/benchmark/run_real.py | `905081416514ba8bf85a84ef40a0075fee9ab538c2553725e4b19fee7c5728b9` | P405 | SF9G; Table S3 |
| `figures/build_SF9.py` | verbatim (paths/headers only) | [G:]/file/20261028-figures/build_SF9_v5.py | `e35a306371602f49af19d56a3ad1d653267bb64ccabadea3f09cf19388fdbb5e` | — | SF9A–H |
| `lib/ggot.py` | verbatim (paths/headers only) | [F:]/CS6-CS7/cs7_cs8_matching/ggot_proposal/final/ggot.py | `8bb81edecb41547fd5b052fd64ec5064313947eb8f96764a2c5a632f7819cc08` | P399–P400 | Fig 7, SF9 |
| `lib/ggot_match.py` | verbatim (paths/headers only) | [F:]/CS6-CS7/cs7_cs8_matching/ggot_proposal/final/ggot_match.py | `22780f440ea2c1c7610f6dadaa8cb027e404da9be6f2126e3377e50140e4f246` | P399–P400 | Fig 7, SF9 |
| `lib/starmatch.py` | verbatim (paths/headers only) | [F:]/CS6-CS7/cs7_cs8_matching/starmatch.py | `5fe7e603d3d6165e71c47a815fd55a073cbf444f1901aaf2c2b2c0ff2f2a291a` | P399–P400 | Fig 7, SF9 |
| `matching/05_run_aiggot.py` | verbatim (paths/headers only) | [G:]/file/20261030-AI_bridge/step9_PS_domains/run_ggot.py | `0d5ff3a072770f3947a2b3bdeec25bb2fc21fea50b099e96146eb86a17aac88b` | P400 | Fig 7B–D |
| `matching/07_control_couplings.py` | verbatim (paths/headers only) | [G:]/data/bridge_bundle/tracks/Fate_timing/run_couplings.py | `70535b9a5b1f26ab12d97ca4914c7dcf47c3d2e726d20adbc9e69ee2db2a2fb2` | P415 | SF10B |
| `sensitivity/08_parameter_sensitivity.py` | verbatim (paths/headers only) | [F:]/CS6-CS7/figure7/supplementary/ggot_sensitivity_final.py | `fd61354bec817000f150c15a9f2833fce1e9a8d24e9ab5aa26a3c8a931729907` | P402–P403 | SF9A–D; Table S3 |
| `stereoseq/build_mapping.R` | verbatim (paths/headers only) | [F:]/CS6-CS7/cs7_cs8_matching/external/human_stereoseq/build_mapping.R | `866143fa6728fb1a1dd226f35038e4118061c57d2851d725c564734180291375` | P406 | SF9H |
| `stereoseq/stereoseq_frames_pipeline.py` | verbatim (paths/headers only) | [F:]/CS6-CS7/cs7_cs8_matching/replication_stereoseq/stereoseq_frames_pipeline.py | `818ff03104f6faeee08a54503ebdaa8fc704ded61ca1f7d91673209d2edfdafa` | P406 | SF9H |
| `benchmark/09_compare_methods.py` | reconstructed | reconstructed from transcript: session 824ef1ce [1322], [1328], [1332], [1334], [1336], [1338], [1340], [1374], [1455], [1685], [1697] (subsets) | `n/a` | P405 | SF9G; Table S3 |
| `benchmark/run_benchmark.sh` | reconstructed | reconstructed from transcript: command lines of benchmark sub-agent 520603d3 (bash calls; grid loops merged) | `n/a` | P405 | SF9G; Table S3 |
| `dataprep/01_export_disc_cells.R` | reconstructed | reconstructed from transcript: transcript 0f4081de (data-prep sub-agent of 824ef1ce) [16], [22] | `n/a` | P399 | Fig 7A (input cells) |
| `dataprep/02_build_frames.py` | reconstructed | reconstructed from transcript: transcript 0f4081de [30], [32], [34], [38], [40] (CSV part), [46] | `n/a` | P399 | Fig 7A |
| `dataprep/03_joint_embedding.py` | reconstructed | reconstructed from transcript: transcript 0f4081de [60], [62] | `n/a` | P399 | — |
| `dataprep/04_transition_prior_and_smoothing.py` | reconstructed | reconstructed from transcript: transcript 0f4081de [76]; session 824ef1ce [677], [683], [687], [691] (subsets) | `n/a` | P399–P400 | Fig 7A, SF9E |
| `matching/06_derive_figure7_tables.py` | reconstructed | reconstructed from transcript: session 824ef1ce [1689], [1691], [1697] (subset) | `n/a` | P400 | Fig 7B–D; SM3/SM4 inputs |
| `stereoseq/00_export_stereoseq.R` | reconstructed | reconstructed from transcript: Stereo-seq sub-agent 048691a1 [26] | `n/a` | P406 | SF9H |
| `stereoseq/10_aiggot_stereoseq_replication.py` | reconstructed | reconstructed from transcript: session 824ef1ce [1435], [1437] (one line), [1439] | `n/a` | P406 | SF9H; Table S3 |
