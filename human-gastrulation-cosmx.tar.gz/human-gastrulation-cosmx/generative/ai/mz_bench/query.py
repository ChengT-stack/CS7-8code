# scArches-style query mapping of Mittnenzweig (MARS-seq) cells into the frozen integrated scVI reference
import numpy as np, anndata as ad, scvi, torch, warnings; warnings.filterwarnings('ignore')
scvi.settings.seed=0
q=ad.read_h5ad('ai/mz_bench/mz_hvg_counts.h5ad'); q.layers['counts']=q.X.copy(); q.obs['batch']='MARS_mouse'
scvi.model.SCVI.prepare_query_anndata(q,'ai/scvi_model')
m=scvi.model.SCVI.load_query_data(q,'ai/scvi_model',accelerator='cpu')
m.train(max_epochs=200,plan_kwargs=dict(weight_decay=0.0),accelerator='cpu',early_stopping=True,check_val_every_n_epoch=5)
Z=m.get_latent_representation(); np.save('ai/mz_bench/mz_scvi30.npy',Z.astype(np.float32))
# sanity: does the reference latent stay fixed?  (query mapping freezes encoder/decoder weights except batch embeddings)
H=ad.read_h5ad('ai/integrated_scvi.h5ad'); idx=np.random.default_rng(0).choice(H.n_obs,2000,replace=False)
Hs=H[idx].copy(); Zr=m.get_latent_representation(Hs) if False else None
print('query latent',Z.shape,'epochs',m.history['elbo_train'].shape[0])
