# Annotation curation notes (verbatim from the final merged object)

Source: `@misc$obj6_spatial_trim_note` and `@misc$obj7_curation_note` of `obj6_obj7_merged_curated_final.rds`, printed by `cosmx/preprocessing/export_misc.R` in session 32c2b2b0 (2026-11-22). Text reproduced unchanged.

Naming: obj6 = HuE#1 (true CS7), obj7 = HuE#2 (true CS8). The final label column is `39Type`; it differs from `Type39_curated` only in 748–749 HuE#1 cells (LP.Meso reassigned to ExE.Meso progenitor). Spatial trimming is stored as a flag (`curated_kept`), not a relabel. Final CS8 display names EPI1/ECT/EPI2 correspond to the stored labels Epiblast (EPI) / Anterior ectoderm (aECT) / Posterior ectoderm (pECT); AVE in HuE#1 is displayed as AVE (formerly ADE).

## obj6_spatial_trim_note (HuE#1)

spatial_trimmed / spatial_kept / spatial_trim_rule / spatial_trim_basis: 536 of 84,672 obj6 cells (0.63%) marked as scattered periphery, under TWO criteria recorded per cell in spatial_trim_rule. (1) 'distance gap from own centroid' - the project's established rule, applied to all 28 Type39_curated subtypes: 3D distance from that subtype's own centroid, cut only where the 20-bin histogram has a genuinely EMPTY interior bin with cells beyond it, and only where those cells have <25% own-type 15-NN and an own-type share below half the retained body's. This takes 77 cells across 15 subtypes. (2) '3x ratio' - the project's established scale-free criterion (5th nearest OWN-TYPE neighbour distance divided by that subtype's own median), applied at 3x to FOUR subtypes ONLY - APS, Node, ECT, EPI - by user decision, because those four have continuous sparse tails that criterion (1) cannot see: it only cuts at a fully empty histogram bin, and APS has no empty bin at all. This adds 459 cells (APS 105, ECT 210, EPI 86, Node 70; 12 cells satisfy both criteria). The other 24 subtypes are governed by criterion (1) alone (65 cells) - so the rule is NOT uniform across the object and spatial_trim_rule must be consulted to know why a given cell was removed. WHY NOT UNIFORM 3x: applying 3x object-wide would remove 2,898 cells (3.44%), including 211 Am.Epi progenitor and 12.4% of Al.Endo, much of which is ordinary sparseness rather than true isolation. NOT REMOVED, deliberately: Dist.ys.Endo has 288 cells >1077 um from its centroid, but their own-type neighbour share is 0.669 (HIGHER than the body's 0.632) with 9.5 um internal spacing across 3 sections - a distant but self-contiguous lobe, not strays. The ratio criterion also leaves it intact (3x would take 29 of 288). EXEMPT and untouched: PGC, Primitive erythroblast, Endothelium, Megakaryocyte, Macrophage, Hema (9,788 cells). TRIMMED CELLS KEEP THEIR Type39_curated LABEL - filter on spatial_kept.

## obj7_curation_note (HuE#2)

Type39_curated = Type39_revised plus three evidence-backed edits, all in obj7 (stage CS8) only. (1) 15 cells trimmed from Allantois endoderm: displaced component whose classifier control PASSED (own-label precision 0.83; main body 73.6% self-called); 0/15 called Al.Endo, 60% called VE2, matching their dominant spatial neighbour. Marker tests were underpowered (min detectable OR 5.6-17.6) and neither confirm nor refute. (2) 81 cells trimmed from Heart mesoderm: displaced component at 5.9 SD. FOXF1 rises 4.9% -> 18.5% (FDR 0.005), a lateral-plate marker. CAVEAT: cardiac markers only TREND down and do NOT survive correction (TNNT2 FDR 0.418, MYL7 FDR 0.621), and the classifier control FAILED for this class (precision 0.32; its main body is itself called Exe.Meso progenitor), so the classifier was not used. (3) 57 cells relabelled Notochord -> Node: the outer flank of the Node domain. 96% lie within 60um of a Node cell (median 15um vs 194um for the main notochord); 0 of 7 node markers differ from Node (bounded at 2.2-2.7x, an equivalence not a power failure); 4 of 7 differ from the main notochord (MNX1 OR 4.6, NOTO OR 4.3, both FDR<0.001). Their lower node_posterior is NOT independent evidence against the merge: that field score correlates -0.948 with distance to the Node core, the very thing in question. This is a BOUNDARY choice - Node widens by ~15-30um - not the correction of an error. Node 436 -> 493, Notochord 565 -> 508. Trims are FLAGS, not relabellings: trimmed cells keep their Type39_curated label and are marked in curation_status. Type39_revised, Type5 and disc_status are preserved unchanged.

## Type39_scheme (order and colour of the 38 annotation levels)

| order | 39Type label | colour |
|---|---|---|
| 1 | Epiblast (EPI) | #4C4FA3 |
| 2 | Ectoderm (ECT) | #2F80ED |
| 3 | Anterior ectoderm (aECT) | #0057B8 |
| 4 | Posterior ectoderm (pECT) | #00A6D6 |
| 5 | Primitive streak (PS) | #9ACD32 |
| 6 | Anterior primitive streak (APS) | #2E8B57 |
| 7 | Node | #00441B |
| 8 | Notochord | #008B8B |
| 9 | Prechordal plate | #00C49A |
| 10 | Caudal lateral epiblast (CLE) | #6A5ACD |
| 11 | Primordial germ cell (PGC) | #FF1493 |
| 12 | Non-neural ectoderm (NNE) | #40C4FF |
| 13 | Amniotic epithelium progenitor (Am.Epi progenitor) | #8C6FF7 |
| 14 | Amniotic epithelium (Am.Epi) | #AFCBFF |
| 15 | Nascent mesoderm (Nas.Meso) | #F4A261 |
| 16 | Lateral plate mesoderm (LP.Meso) | #E76F51 |
| 17 | Heart mesoderm | #E31A1C |
| 18 | Extraembryonic mesoderm progenitor (Exe.Meso progenitor) | #F7B6D2 |
| 19 | Amniotic mesenchyme (Am.Mes) | #E75480 |
| 20 | Allantois mesenchyme (Al.Mes) | #F768A1 |
| 21 | Chorion-allantois mesenchyme (ChA.Mes) | #C51B8A |
| 22 | Yolk sac mesoderm (ys.Meso) | #8E3A9C |
| 23 | Paraxial mesoderm (Para.Meso) | #D97706 |
| 24 | Rostral mesoderm (Rostral.Meso) | #F43F5E |
| 25 | Definitive endoderm (DE) | #FF5A1F |
| 26 | Visceral endoderm 1 (VE1) | #FF8C00 |
| 27 | Visceral endoderm 2 (VE2) | #FFCA3A |
| 28 | Parietal yolk sac endoderm (Pari.Endo) | #D4A017 |
| 29 | Proximal yolk sac endoderm (Prox.ys.Endo) | #FFE08A |
| 30 | Distal yolk sac endoderm (Dist.ys.Endo) | #FFF1B8 |
| 31 | Allantois endoderm (Al.Endo) | #8F6B00 |
| 32 | Anterior visceral endoderm (AVE) | #C2410C |
| 33 | Hematopoietic progenitor (Hema) | #C4A1FF |
| 34 | Endothelium | #3B82A0 |
| 35 | Macrophage | #3C1361 |
| 36 | Megakaryocyte | #7B2CBF |
| 37 | Primitive erythroblast | #D65DB1 |
| 38 | Trophoblast | #7A4A00 |
