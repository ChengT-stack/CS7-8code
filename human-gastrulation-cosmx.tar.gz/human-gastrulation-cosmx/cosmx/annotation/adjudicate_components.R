# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/adjudicate_components.R (2026-09-16, session 0b0712b4)
# sha256 of original: fd20aa9c5642366eab0609793d1b3edaa77e49d735aea85572ae89711ad62c72
# Methods paragraphs: P346 (manual curation; displaced Heart.Meso / Al.Endo components)
# Produces: PCA + marker features for the classifier adjudication recorded in obj7_curation_note (edits 1-2)
# Edits/notes: object path template -> HGC_DATA. The Python classifier step and the write-back of
#     Type39_curated/39Type were run interactively and are not available as code (see GAPS).
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

## Transcriptomic adjudication of the displaced second components in
## Heart mesoderm (obj7) and Allantois endoderm (obj6, obj7).
##
## Exports, per object: 50 PCs (features for an identity classifier) plus a
## marker panel read as normalized expression. Classification itself is done in
## Python. Nothing here decides anything - it only produces the features.
##
## Rule 25 of this project's memory is binding: spatial discordance is NOT
## evidence of mislabelling, because a migrating cell looks identical to a
## mislabelled one. The classifier must therefore be trained ONLY on spatially
## concordant cells, and a displaced cell is called mislabelled only when the
## classifier and its dominant neighbour agree.
suppressPackageStartupMessages({library(Seurat); library(Matrix)})

MARKERS <- c(
  # cardiac / heart field
  "TNNT2","MYL7","NKX2-5","TBX5","HAND1","HAND2","ISL1","GATA4","MEF2C",
  # lateral plate / extraembryonic mesoderm
  "FOXF1","PRRX1","BMP4","POSTN","VIM","TWIST1",
  # endoderm backbone
  "SOX17","FOXA2","CXCR4","HHEX","GATA6",
  # visceral / yolk-sac endoderm (the neighbour identity for Al.Endo)
  "TTR","APOA1","APOA2","AFP","RBP4","APOE","FGA",
  # allantois
  "TBX4","HOXA13","HOXA11","CDX2","ISL2",
  # germ line, as the migratory control
  "NANOS3","DDX4","DAZL","POU5F1")

for (nm in c("obj6","obj7")) {
  o <- readRDS(file.path(DATA, sprintf("%s.rds", nm)))
  DefaultAssay(o) <- "RNA"
  o <- NormalizeData(o, verbose = FALSE)
  o <- FindVariableFeatures(o, nfeatures = 2000, verbose = FALSE)
  o <- ScaleData(o, verbose = FALSE)
  o <- RunPCA(o, npcs = 50, verbose = FALSE)
  E <- Embeddings(o, "pca")
  mk <- intersect(MARKERS, rownames(o))
  X <- t(as.matrix(LayerData(o[["RNA"]], "data")[mk, , drop = FALSE]))
  out <- data.frame(cell = colnames(o),
                    label = as.character(o$Type39_revised),
                    nCount = o$nCount_RNA,
                    check.names = FALSE)
  out <- cbind(out, setNames(as.data.frame(E), paste0("PC", 1:50)),
               setNames(as.data.frame(X), paste0("mk_", mk)))
  f <- sprintf("handoff/%s_pca_markers.csv", nm)
  write.csv(out, f, row.names = FALSE)
  cat(nm, "->", f, nrow(out), "cells |", length(mk), "markers present |",
      "missing:", paste(setdiff(MARKERS, mk), collapse = ","), "\n")
  rm(o, E, X, out); invisible(gc())
}
cat("DONE\n")
