"""D-V and A-P terciles of the 529 CS7 (HuE#1) node cells in the t = 0.5 state, their AIGG-OT destinations, and
expression-only controls (PrP-vs-node signature score; scVI-latent kNN destination among all CS8 cells).
The terciles (DV_layer) define the ventral / middle / dorsal node groups of Figure 7E-F and Supplementary Figure 10B.
Verbatim from session 5113e657 message [2821] (written there as ai/node_layers/node_layers.py; run with cwd =
HGC_GEN_ROOT, which contains the CosMx scVI model ai/scvi_cosmx_full from latent/train_scvi.py); only the data path was
replaced by HGC_DATA. Inputs: dataprep/export (01_export_disc_cells.R), figure/final_ggot/ggot_table_t05_pseudocells.csv
and ggot_table_cs8_ancestor.csv (aiggot/matching/06_derive_figure7_tables.py; copy them to
HGC_DATA/cs7_cs8_matching/figure/final_ggot/). Outputs: ai/node_layers/cs7_node_cells_layers.csv, markers_by_layer.csv,
signature_genes.csv.
"""
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import numpy as np, pandas as pd, scipy.io, scipy.sparse as sp, anndata as ad, scvi, torch, warnings; warnings.filterwarnings('ignore')
from scipy.stats import spearmanr, chi2_contingency, mannwhitneyu
B=DATA+'/cs7_cs8_matching/'; O='ai/node_layers/'; rng=np.random.default_rng(0)
g=pd.read_csv(B+'dataprep/export/genes.csv').gene.values; gi={x:i for i,x in enumerate(g)}
c7=pd.read_csv(B+'dataprep/export/CS7_cells.csv'); c8=pd.read_csv(B+'dataprep/export/CS8_cells.csv')
X7=scipy.io.mmread(B+'dataprep/export/CS7_counts.mtx').tocsr().T.tocsr().astype(np.float32); X8=scipy.io.mmread(B+'dataprep/export/CS8_counts.mtx').tocsr().T.tocsr().astype(np.float32)
t05=pd.read_csv(B+'figure/final_ggot/ggot_table_t05_pseudocells.csv').set_index('cs7_idx'); anc=pd.read_csv(B+'figure/final_ggot/ggot_table_cs8_ancestor.csv'); anc=anc[anc.cls!='unmatched']
print('DV sign check (mean DV): VE',round(t05[t05.cs7_group.isin(['VE1','VE2'])].DV.mean(),2),' EPI',round(t05[t05.cs7_group=='EPI'].DV.mean(),2),' DE',round(t05[t05.cs7_group=='DE'].DV.mean(),2))
node=np.where(c7.label_short.values=='Node')[0]; N=t05.loc[node,['AP','LR','DV']].copy()
# --- GG-OT destination per CS7 node cell
cnt=anc[anc.ancestor_idx.isin(node)].groupby(['ancestor_idx','cs8_group']).size().unstack(fill_value=0).reindex(node,fill_value=0)
N=N.join(cnt); N['n_desc']=cnt.sum(1); N['dest']=np.where(N.n_desc>0,cnt.idxmax(1),'none')
for k in ['Node','Notochord','PrP']: N[f'frac_{k}']=N.get(k,0)/N.n_desc.replace(0,np.nan)
# --- position-defined layers (independent of destination)
N['DV_layer']=pd.qcut(N.DV,3,labels=['ventral','middle','dorsal']) if t05[t05.cs7_group.isin(['VE1','VE2'])].DV.mean()<t05[t05.cs7_group=='EPI'].DV.mean() else pd.qcut(N.DV,3,labels=['dorsal','middle','ventral'])
N['AP_layer']=pd.qcut(N.AP,3,labels=['anterior','middle','posterior'])   # AP: 0 = anterior (PrP most anterior previously)
T1=pd.crosstab(N.DV_layer,N.dest); T2=pd.crosstab(N.AP_layer,N.dest)
print('\nGG-OT destination by DV layer\n',T1.to_string(),'\nchi2 p',chi2_contingency(T1.drop(columns=[c for c in T1 if c=='none']))[1])
print('\nGG-OT destination by AP layer\n',T2.to_string(),'\nchi2 p',chi2_contingency(T2.drop(columns=[c for c in T2 if c=='none']))[1])
print('\nSpearman with PrP fraction: AP',spearmanr(N.AP,N.frac_PrP,nan_policy='omit')[0].round(3),' DV',spearmanr(N.DV,N.frac_PrP,nan_policy='omit')[0].round(3))
# --- expression-only test 1: CS8-derived PrP vs node signature scored on CS7 node cells
lab8=c8.label_short.values; D8=(X8>0)
def det(M,mask): return np.asarray(M[mask].mean(0)).ravel()
dP=det(D8,lab8=='PrP'); dN=det(D8,lab8=='Node'); dC=det(D8,lab8=='Notochord')
upP=np.argsort(-(dP-dN)); upP=[j for j in upP if dP[j]>=0.15][:30]; upN=np.argsort(-(dN-dP)); upN=[j for j in upN if dN[j]>=0.15][:30]
print('\nPrP-up genes:',', '.join(g[upP][:15])); print('Node-up genes:',', '.join(g[upN][:15]))
lib=np.asarray(X7.sum(1)).ravel(); L7=X7.multiply(1e3/lib[:,None]).tocsr(); L7.data=np.log1p(L7.data)
def sc(ix,genes): return np.asarray(L7[ix][:,genes].mean(1)).ravel()
N['PrP_minus_Node_score']=sc(node,upP)-sc(node,upN)
print('\nsignature score by DV layer:',N.groupby('DV_layer').PrP_minus_Node_score.median().round(3).to_dict(),' by AP layer:',N.groupby('AP_layer').PrP_minus_Node_score.median().round(3).to_dict())
print('Spearman score~AP',spearmanr(N.AP,N.PrP_minus_Node_score)[0].round(3),'p',f"{spearmanr(N.AP,N.PrP_minus_Node_score)[1]:.1e}",' score~DV',spearmanr(N.DV,N.PrP_minus_Node_score)[0].round(3),'p',f"{spearmanr(N.DV,N.PrP_minus_Node_score)[1]:.1e}")
MK=['GSC','LHX1','CER1','HHEX','OTX2','FOXA2','CHRD','FOXJ1','NOTO','TBXT','SHH','NODAL','SOX2','FOXA1']
D7=(X7>0); rows=[]
for lay in ['DV_layer','AP_layer']:
    for v,ix in N.groupby(lay).groups.items():
        ii=np.array(list(ix)); rows.append(dict(axis=lay,layer=v,n=len(ii),**{m:round(100*float(D7[ii][:,gi[m]].mean()),1) for m in MK if m in gi}))
MKT=pd.DataFrame(rows); print('\n% detected by layer\n',MKT.to_string(index=False))
# --- expression-only test 2: kNN of CS7 node cells among ALL CS8 cells in the CosMx scVI latent (no position, no prior)
A=ad.concat([ad.AnnData(X7,obs=pd.DataFrame({'stage':'CS7'},index=[f'a{i}' for i in range(X7.shape[0])])),ad.AnnData(X8,obs=pd.DataFrame({'stage':'CS8'},index=[f'b{i}' for i in range(X8.shape[0])]))])
A.var_names=g; A.layers['counts']=A.X.copy(); scvi.model.SCVI.setup_anndata(A,layer='counts'); m=scvi.model.SCVI.load('ai/scvi_cosmx_full',adata=A)
Zq=m.get_latent_representation(); z7=Zq[:X7.shape[0]]; z8=Zq[X7.shape[0]:]
from sklearn.neighbors import NearestNeighbors
nn=NearestNeighbors(n_neighbors=30).fit(z8); _,nb=nn.kneighbors(z7[node]); L8=lab8[nb]
types=['Node','Notochord','PrP','DE','aECT','pECT','NNE','EPI','Rostral.Meso','Nas.Meso']
for t in types: N[f'knn_{t}']=(L8==t).mean(1)
N['knn_axial_dest']=pd.Series([pd.Series(r).value_counts().idxmax() for r in L8],index=N.index)
print('\nexpression-only kNN destination (all CS8 types) by DV layer\n',pd.crosstab(N.DV_layer,N.knn_axial_dest).to_string())
print('\nexpression-only kNN destination by AP layer\n',pd.crosstab(N.AP_layer,N.knn_axial_dest).to_string())
print('\nmean kNN fractions by DV layer\n',N.groupby('DV_layer')[[f'knn_{t}' for t in types]].mean().round(3).to_string())
print('\nmean kNN fractions by AP layer\n',N.groupby('AP_layer')[[f'knn_{t}' for t in types]].mean().round(3).to_string())
for t in ['PrP','Notochord','Node','aECT','pECT']:
    r1=spearmanr(N.AP,N[f'knn_{t}']); r2=spearmanr(N.DV,N[f'knn_{t}']); print(f'knn_{t}: rho AP {r1[0]:+.3f} (p {r1[1]:.1e}); rho DV {r2[0]:+.3f} (p {r2[1]:.1e})')
print('\nagreement GG-OT dest vs kNN dest (axial cells):'); print(pd.crosstab(N.dest,N.knn_axial_dest).to_string())
N.to_csv(O+'cs7_node_cells_layers.csv'); MKT.to_csv(O+'markers_by_layer.csv',index=False)
pd.DataFrame({'PrP_up':g[upP],'Node_up':g[upN]}).to_csv(O+'signature_genes.csv',index=False)
