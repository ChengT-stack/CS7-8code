# gastruloid/02_milestone_scoring/assess_v2.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/assess_v2.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Final assessability table: time-aware calls for all 55 samples + 'marker outside the probe set' rule; model-level summary.
import sys, numpy as np, pandas as pd; sys.path.insert(0, str(Path(__file__).resolve().parent)); import stage_lib as L
R, N, P, A = L.R, L.N, L.P, L.A; OUT = 'gall/out_v2/'
LG = pd.read_csv(OUT + 'milestone_assessability_long.csv'); INFO = pd.read_csv(OUT + 'groups.csv', index_col=0); G = pd.read_csv(OUT + 'marker_gene_measured_by_library.csv')
MS = sorted(L.ONSET); CALLS = {g: d.set_index('milestone_id').call_observed.to_dict() for g, d in LG.groupby('group')}
SERIES = {g: list(INFO[(INFO.series == r.series) & (INFO.order < r.order)].sort_values('order').index) for g, r in INFO.iterrows()}
DS = ['Hamazaki 2024', 'Budjan 2022', 'Yamanaka 2023', 'Makwana 2025', 'Gribaudo 2023', 'Olmsted & Paluh 2021', 'Minn 2020', 'Heemskerk 2024', 'Chen 2025', 'Liu 2023', 'Pedroza 2023', 'Weatherbee 2023', 'Rossi 2021', 'Veenvliet 2020']
INFO['dso'] = INFO.dataset.map({d: i for i, d in enumerate(DS)}); assert INFO.dso.notna().all(), INFO[INFO.dso.isna()].dataset.unique()
ORDER = list(INFO.sort_values(['dso', 'series', 'order']).index)
KW = dict(naive_first=['Ham_0h'], hours=INFO.hours.to_dict(), naive_series=['Ham'], series_id=INFO.series.to_dict())
C = pd.DataFrame(L.onset_logic(ORDER, CALLS, SERIES, mode='timeaware', **KW)).loc[MS, ORDER]; CS = pd.DataFrame(L.onset_logic(ORDER, CALLS, SERIES, mode='strict', **KW)).loc[MS, ORDER]
# marker genes that a library cannot measure: targeted probe-set libraries (Chen D6-D10; rep2 of Chen 48-96 h) lack the gene in their feature list
GEN = {'m01': ['MESP1', 'TBX6'], 'm02': ['GSC', 'FOXA2'], 'm03': ['FOXJ1', 'CHRD'], 'm04': ['FOXA2', 'SOX17'], 'm05': ['FOXA2', 'SOX17', 'GSC', 'CER1'], 'm06': ['FOXA2', 'SOX17', 'GSC'], 'm07': ['NOTO'], 'm08': ['TBXT', 'HOXA1|HOXB1'],
       'm09': ['NKX1-2', 'CDX2'], 'm10': ['HESX1', 'SIX3'], 'm11': ['MEOX1', 'TCF15'], 'm12': ['TBXT', 'EOMES'], 'm13': ['NKX1-2', 'CDX2', 'HOXB8'], 'm14': ['NKX2-5', 'TNNT2'], 'm15': ['NANOS3', 'TFAP2C'], 'm16': ['KDR', 'ETV2'], 'm17': ['HAND1'],
       'm18': ['TBX4', 'HOXA10'], 'm19': ['HBE1', 'GATA1']}
PROBE_ONLY = ['Chen_D6', 'Chen_D8', 'Chen_D10']; HAM_RA = ['Ham_RA96', 'Ham_RA120', 'Ham_RALDN']   # RA-treated Hamazaki samples: an absent population is recorded as 'no corresponding cell population', not as 'sample too late'
inm = G.groupby(['group', 'gene']).in_matrix.any()
def unmeasured(g, m): return [x.replace('|', '/') for x in GEN[m] if g in PROBE_ONLY and not any(inm.get((g, y), False) for y in x.split('|'))]
rows = []
for r in LG.itertuples():
    call = C.loc[r.milestone_id, r.group]; reason = ''
    if call == A:
        ev = str(r.evidence)
        reason = 'no corresponding cell population (no endoderm-like cells in which GSC loss can be read)' if (r.milestone_id == 'm06' and 'no DE-like population' in ev) else ('reference pool < 15 cells' if '(<15)' in ev else ('no corresponding cell population (Hamazaki gastruloid with RA)' if r.group in HAM_RA else 'transient population absent, sample too late'))
    um = unmeasured(r.group, r.milestone_id)
    if um and not call.startswith(R): call = A; reason = 'marker outside the probe set (' + ', '.join(um) + ')'
    rows.append((call, CS.loc[r.milestone_id, r.group], call != A, reason))
LG[['call', 'call_strict', 'testable', 'reason_not_testable']] = pd.DataFrame(rows, index=LG.index); LG['reason_not_testable'] = LG.reason_not_testable.fillna('')
LG['dataset'] = LG.group.map(INFO.dataset); LG.to_csv(OUT + 'milestone_assessability_long.csv', index=False)
CA = LG.pivot(index='milestone_id', columns='group', values='call').loc[MS, ORDER]; CA.to_csv(OUT + 'calls_all_samples.csv')
def model_state(d):
    c = d.call; t = d.testable
    if c.str.startswith(R).any(): return 'reached in at least one sample'
    if (c == P).any(): return 'partial (population present below the onset frequency)'
    if t.any(): return 'testable, not reached'
    rs = d.reason_not_testable.value_counts(); return 'not testable: ' + rs.index[0]
M = LG.groupby(['dataset', 'milestone_id']).apply(model_state).unstack(0).loc[MS, DS]; M.insert(0, 'milestone', [L.MNAME[m] for m in MS]); M.insert(1, 'domain', [L.DOM[m] for m in MS]); M.insert(2, 'mouse_onset', [L.ONSET[m] for m in MS]); M.to_csv(OUT + 'milestone_assessability_by_model.csv')
S = LG.groupby('dataset').apply(lambda d: pd.Series(dict(samples=d.group.nunique(), testable_in_any_sample=int(d.groupby('milestone_id').testable.any().sum()), reached_in_any_sample=int(d.groupby('milestone_id').call.apply(lambda s: s.str.startswith(R).any()).sum()),
      testable_in_every_sample=int(d.groupby('milestone_id').testable.all().sum()), not_testable_in_any_sample=int((~d.groupby('milestone_id').testable.any()).sum())))).loc[DS]
S['testable_not_reached'] = S.testable_in_any_sample - S.reached_in_any_sample; S.to_csv(OUT + 'milestone_assessability_summary_by_model.csv')
pd.set_option('display.width', 250); print(S.to_string()); print(LG.call.value_counts().to_dict()); print(LG[~LG.testable].reason_not_testable.str.slice(0, 62).value_counts().to_dict())
print(LG.groupby('milestone_id').testable.sum().to_string()); print('models testing each milestone:', (M[DS].apply(lambda c: ~c.str.startswith('not testable'))).sum(1).to_dict())
old = pd.read_csv('gall/out/calls.csv', index_col=0); print('Hee_42 old -> new:', {m: (old.loc[m, 'Hee_42'], CA.loc[m, 'Hee_42']) for m in MS if old.loc[m, 'Hee_42'] != CA.loc[m, 'Hee_42']})
same = [g for g in old.columns[3:] if g != 'Hee_42']; d = (CA[same].values != old.loc[MS, same].values); print('other changes vs previous calls:', [(MS[i], same[j], old.loc[MS[i], same[j]], CA.loc[MS[i], same[j]]) for i, j in zip(*np.where(d))])
