# gastruloid/05_celltype_comparison/celltypes_cs78.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/celltypes_cs78.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Which CS7 / CS8 embryo cell types have a counterpart in the gastruloid samples staged CS7-like, transitional or CS8-like.
# Evidence per sample and embryo type: (1) de novo annotated populations (curated label -> embryo type correspondence), present if >=1% of annotated cells and >=20 cells;
#                                      (2) marker-defined cells from the milestone analysis (raw per-sample call 'reached').
import numpy as np, pandas as pd
OUT = 'gall/out_v2/'
TYPES = [  # key, row label, lineage block, CosMx types, de novo labels, milestone
 ('EPI', 'Epiblast (EPI)', 'Epiblast and ectoderm', ['EPI'], ['Epiblast-like (pluripotent)', 'Epiblast-like, streak-primed', 'Epiblast-like, anterior-biased'], None),
 ('aECT', 'Anterior ectoderm / neural plate (ECT, aECT)', 'Epiblast and ectoderm', ['ECT', 'aECT'], ['Anterior neuroectoderm-like', 'Epiblast-like, anterior-biased'], 'm10'),
 ('pECT', 'Posterior ectoderm (pECT)', 'Epiblast and ectoderm', ['pECT'], ['Caudal neural plate progenitor'], None),
 ('NNE', 'Non-neural ectoderm (NNE)', 'Epiblast and ectoderm', ['NNE'], ['Surface ectoderm-like'], None),
 ('CLE', 'Caudal lateral epiblast (CLE)', 'Epiblast and ectoderm', ['CLE'], ['NMP/caudal epiblast-like'], 'm09'),
 ('PS', 'Primitive streak (PS)', 'Streak and axial mesoderm', ['PS'], ['Primitive streak-like'], None),
 ('APS', 'Anterior primitive streak (APS)', 'Streak and axial mesoderm', ['APS'], ['Anterior PS/mesendoderm', 'Axial/caudal mesendoderm progenitor'], 'm02'),
 ('Node', 'Node', 'Streak and axial mesoderm', ['Node'], ['Node/notochord-like'], 'm03'),
 ('Notochord', 'Notochord', 'Streak and axial mesoderm', ['Notochord'], [], 'm07'),
 ('PrP', 'Prechordal plate (PrP)', 'Streak and axial mesoderm', ['PrP'], [], None),
 ('Nas.Meso', 'Nascent mesoderm', 'Mesoderm', ['Nas.Meso'], ['Nascent mesoderm', 'Posterior nascent mesoderm'], 'm01'),
 ('Para.Meso', 'Paraxial mesoderm', 'Mesoderm', ['Para.Meso'], ['Posterior PSM', 'Paraxial mesoderm, early (FOXC1/2+)', 'Anterior PSM/nascent somite', 'Somite'], 'm11'),
 ('Rostral.Meso', 'Rostral mesoderm', 'Mesoderm', ['Rostral.Meso'], [], None),
 ('LP.Meso', 'Lateral plate mesoderm', 'Mesoderm', ['LP.Meso'], ['Lateral plate mesoderm', 'Lateral plate/cardiogenic mesoderm', 'Posterior LPM/allantois-like mesenchyme'], None),
 ('Heart.Meso', 'Heart mesoderm', 'Mesoderm', ['Heart.Meso'], ['Lateral plate/cardiogenic mesoderm', 'Cardiomyocyte'], 'm14'),
 ('DE', 'Definitive endoderm (DE)', 'Endoderm', ['DE'], ['Definitive endoderm', 'Anterior definitive endoderm', 'Endoderm with visceral features'], 'm04'),
 ('ADE', 'Anterior endoderm (ADE)', 'Endoderm', ['ADE'], ['Anterior definitive endoderm'], 'm05'),
 ('VE', 'Visceral endoderm (VE1, VE2)', 'Endoderm', ['VE1', 'VE2'], ['Hypoblast/visceral endoderm-like'], None),
 ('Amnion', 'Amnion', 'Extra-embryonic and germline', ['Am.Epi.prog', 'Am.Epi'], ['Amnion-like (early)', 'Amnion-like', 'Amnion-like (late)', 'Epiblast-like, TFAP2A+ (amnion-primed)'], None),
 ('PGC', 'Primordial germ cells', 'Extra-embryonic and germline', ['PGC'], ['PGC-like', 'Naive-like pluripotent/PGC-like'], 'm15'),
 ('ExE.Meso', 'Extra-embryonic mesoderm', 'Extra-embryonic and germline', ['ExE.Meso.prog', 'ys.Meso', 'Am.Mes', 'ChA.Mes', 'Al.Mes'], ['ExE/lateral mesenchyme', 'Posterior LPM/allantois-like mesenchyme'], None),
 ('Endothelium', 'Endothelium', 'Extra-embryonic and germline', ['Endothelium', 'Hema'], ['Endothelium'], 'm16'),
 ('Blood', 'Blood', 'Extra-embryonic and germline', ['Erythroblast', 'Megakaryocyte', 'Macrophage'], [], 'm19'),
 ('YS.Endo', 'Yolk-sac endoderm', 'Extra-embryonic and germline', ['Dist.ys.Endo', 'Prox.ys.Endo', 'Pari.Endo', 'Al.Endo'], ['Yolk-sac endoderm-like'], None),
 ('Trophoblast', 'Trophoblast', 'Extra-embryonic and germline', ['Trophoblast'], [], None)]
h = pd.read_csv('tb/out/embryo_units_cosmx38_half.csv'); EN = h.groupby(['label', 'stage']).n_cells.sum().unstack().fillna(0)
R = pd.read_csv(OUT + 'gastruloid_stage_vs_CS7_CS8.csv').set_index('unit'); INFO = pd.read_csv(OUT + 'groups.csv', index_col=0); ML = pd.read_csv(OUT + 'milestone_assessability_long.csv').set_index(['group', 'milestone_id'])
KEEP = ['Hamazaki 2024', 'Budjan 2022', 'Minn 2020', 'Heemskerk 2024', 'Chen 2025', 'Liu 2023', 'Rossi 2021', 'Veenvliet 2020']; STG = ['CS7-like', 'CS7-to-CS8 transitional', 'CS8-like']
S = [g for st in STG for g in INFO.index if INFO.dataset[g] in KEEP and R.stage[g] == st]; S = sorted(S, key=lambda g: (STG.index(R.stage[g]), KEEP.index(INFO.dataset[g]), INFO.hours[g]))
a = pd.read_parquet('reanno/out/all_cells_annotated.parquet', columns=['group', 'label', 'excluded']); a = a[a.group.isin(S) & ~a.excluded]; NL = a.groupby(['group', 'label']).size(); NT = a.groupby('group').size()
rows = []
for key, lab, blk, ctypes, labels, ms in TYPES:
    n7 = int(sum(EN.CS7.get(c, 0) for c in ctypes)); n8 = int(sum(EN.CS8.get(c, 0) for c in ctypes)); in7, in8 = n7 > 0, n8 > 0
    for u, n_, st_ in [('Human embryo CS7 (CosMx)', n7, in7), ('Human embryo CS8 (CosMx)', n8, in8)]:
        rows.append(dict(unit=u, kind='embryo', stage='', type=key, type_label=lab, block=blk, in_CS7=in7, in_CS8=in8, n_cells=n_, pct=np.nan, labels='; '.join(ctypes), milestone=ms or '', milestone_call='', state='present' if st_ else 'absent'))
    for g in S:
        n = int(sum(NL.get((g, l), 0) for l in labels)); pct = 100 * n / NT[g]; clus = (pct >= 1.0) and (n >= 20); mc = ML.loc[(g, ms), 'call_observed'] if ms else ''; mark = mc == 'reached'
        stg = R.stage[g]; exp = {'CS7-like': in7, 'CS8-like': in8, 'CS7-to-CS8 transitional': in7 and in8}[stg]; one = stg == 'CS7-to-CS8 transitional' and (in7 != in8)
        state = 'present (annotated population)' if clus else 'present (marker-defined cells only)' if mark else 'absent, present in the stage-matched embryo' if exp else 'absent, present in one of the two embryos' if one else 'absent, not expected'
        rows.append(dict(unit=g, kind='sample', stage=stg, type=key, type_label=lab, block=blk, in_CS7=in7, in_CS8=in8, n_cells=n, pct=round(pct, 2), labels='; '.join(l for l in labels if NL.get((g, l), 0) > 0), milestone=ms or '', milestone_call=mc, state=state))
T = pd.DataFrame(rows); T['dataset'] = T.unit.map(INFO.dataset).fillna(''); T.to_csv(OUT + 'celltypes_vs_CS7_CS8_long.csv', index=False)
P = T[T.kind == 'sample'].pivot(index='type', columns='unit', values='state').loc[[t[0] for t in TYPES], S]
ab = {'present (annotated population)': 'P', 'present (marker-defined cells only)': 'm', 'absent, present in the stage-matched embryo': 'X', 'absent, present in one of the two embryos': 'x', 'absent, not expected': '.'}
pd.set_option('display.width', 250); print(P.replace(ab).assign(CS7=[int(sum(EN.CS7.get(c, 0) for c in t[3]) > 0) for t in TYPES], CS8=[int(sum(EN.CS8.get(c, 0) for c in t[3]) > 0) for t in TYPES]).to_string())
emb = [t[0] for t in TYPES if t[2] != 'Extra-embryonic and germline']
summ = pd.DataFrame({g: dict(stage=R.stage[g], missing_embryonic=';'.join(t for t in emb if P.loc[t, g].startswith('absent, present in the stage')), missing_one_embryo_only=';'.join(t for t in emb if P.loc[t, g].startswith('absent, present in one')),
                             missing_extraembryonic=';'.join(t for t in P.index if t not in emb and P.loc[t, g].startswith('absent, present in the stage')), marker_only=';'.join(t for t in P.index if P.loc[t, g].startswith('present (marker'))) for g in S}).T
summ.to_csv(OUT + 'celltypes_missing_by_sample.csv'); pd.set_option('display.max_colwidth', 90); print(summ.to_string())
