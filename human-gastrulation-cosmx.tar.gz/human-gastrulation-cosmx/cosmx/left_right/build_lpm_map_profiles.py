# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/lr_asymmetry/SuppFig5E_map_profiles/build_lpm_map_profiles.py (2026-11-11; final edited
#     copy of artifact 7357ff72, session 824ef1ce cell 2134)
# sha256 of original: dce7815c398163632525d40542c7bd030f8d63bf25aae7ef162358b1591628e9
# Methods paragraphs: Supplementary Figure 5E
# Produces: lr/SuppFig5E_LPMeso_LR_map_profiles.{png,pdf,ai} (artifact 6c4d1a62)
# Edits/notes: inputs/outputs in HGC_OUT/lr (originally the script folder); font folder -> HGC_FONTS.
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass


import os, numpy as np, pandas as pd, matplotlib as mpl
mpl.use("Agg"); import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.lines import Line2D
HERE = str(OUT / "lr")
for f in ["arial.ttf", "arialbd.ttf", "ariali.ttf", "arialbi.ttf"]:
    p = os.path.join(FONT_DIR, "") + f
    if os.path.exists(p): fm.fontManager.addfont(p)
mpl.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Arial"], "pdf.fonttype": 42, "ps.fonttype": 42,
                     "svg.fonttype": "none", "axes.unicode_minus": True, "axes.linewidth": 0.5,
                     "xtick.major.width": 0.5, "ytick.major.width": 0.5, "xtick.major.size": 2, "ytick.major.size": 2})
Z = np.load(os.path.join(HERE, "lpm_map_profiles_data.npz")); T = pd.read_csv(os.path.join(HERE, "lpm_map_profiles_tests.csv")).set_index("gene")
LRp, arc, lp, axial = Z["LRp"], Z["arcn"], Z["is_lp"], Z["is_axial"]; wmax, MID = float(Z["wmax"]), float(Z["MID"])
PG = ["DLL1", "NOTCH1", "NODAL", "LEFTY2", "PITX2", "DAND5"]; TARGET = ["DLL1", "NOTCH1"]
inwin = lp & (np.abs(LRp) >= MID) & (np.abs(LRp) <= wmax); out = lp & ~inwin
nL, nR = int((inwin & (LRp < 0)).sum()), int((inwin & (LRp > 0)).sum())
assert (nL, nR) == (int(T.nL.iloc[0]), int(T.nR.iloc[0])), (nL, nR)
C_LP, C_OUT, C_BG, C_AX = "#D9480F", "#F3B8A0", "#E4E4E4", "#9C9C9C"
XL = (-365.0, 305.0); XT = np.arange(-300, 301, 100)
MM = 1 / 25.4; W = 78.0; L0, AW = 15.0, 58.0
MAP_H, GAPL, PH, PG_GAP, TOP, BOT = 26.0, 13.0, 8.2, 5.0, 7.5, 9.5
H = TOP + MAP_H + GAPL + len(PG) * PH + (len(PG) - 1) * PG_GAP + BOT
fig = plt.figure(figsize=(W * MM, H * MM))
def axes_mm(x, y_top, w, h): return fig.add_axes([x / W, 1 - (y_top + h) / H, w / W, h / H])
# ---- map: dorsal view, x = LR' (shared with the profiles), y = A-P arc position relative to the node
am = axes_mm(L0, TOP, AW, MAP_H)
bg = ~lp
am.scatter(LRp[bg & ~axial], arc[bg & ~axial], s=0.25, c=C_BG, lw=0, rasterized=True, zorder=1)
am.scatter(LRp[axial], arc[axial], s=0.3, c=C_AX, lw=0, rasterized=True, zorder=2)
am.scatter(LRp[out], arc[out], s=1.3, c=C_OUT, lw=0, zorder=3)
am.scatter(LRp[inwin], arc[inwin], s=1.3, c=C_LP, lw=0, zorder=4)
YL = (1010.0, -930.0)                                   # anterior at the top
am.set_xlim(*XL); am.set_ylim(*YL); am.set_xticks(XT); am.set_yticks([-800, -400, 0, 400, 800])
am.tick_params(labelsize=5.5, labelbottom=False, pad=1.5)
am.set_ylabel("A\u2013P position\n(\u00b5m from node)", fontsize=6.5, labelpad=2)
for s in ("top", "right"): am.spines[s].set_visible(False)
am.text(0.012, 0.985, "anterior", transform=am.transAxes, fontsize=5.5, va="top", ha="left", color="#555555")
am.text(0.012, 0.012, "posterior", transform=am.transAxes, fontsize=5.5, va="bottom", ha="left", color="#555555")
am.text((-wmax - MID) / 2, YL[1] - 25, f"L ({nL:,} cells)", fontsize=6, ha="center", va="bottom", clip_on=False)
am.text((wmax + MID) / 2, YL[1] - 25, f"R ({nR:,} cells)", fontsize=6, ha="center", va="bottom", clip_on=False)
fig.text(L0 / W, 1 - 1.0 / H, "CS8 LP.Meso, dorsal view", fontsize=7, va="top", ha="left")
# legend under the map
hd = [Line2D([], [], ls="", marker="o", ms=3, mfc=C_LP, mec="none", label="LP.Meso, compared"),
      Line2D([], [], ls="", marker="o", ms=3, mfc=C_OUT, mec="none", label="LP.Meso, excluded"),
      Line2D([], [], ls="", marker="o", ms=3, mfc=C_AX, mec="none", label="axial populations"),
      Line2D([], [], ls="", marker="o", ms=3, mfc=C_BG, mec="none", label="other disc cells")]
fig.legend(handles=hd, loc="upper left", bbox_to_anchor=(L0 / W, 1 - (TOP + MAP_H + 1.2) / H), ncol=2, frameon=False, fontsize=5.5,
           handletextpad=0.2, columnspacing=1.2, labelspacing=0.3, borderaxespad=0, borderpad=0)
# ---- profiles (same x axis)
axs = [am]
y = TOP + MAP_H + GAPL
for r, g in enumerate(PG):
    a = axes_mm(L0, y, AW, PH); axs.append(a); y += PH + PG_GAP
    ctr, dd, lo, hi = Z[f"prof_{g}"]; col = "#C2401A" if g in TARGET else "#1F6FB2"
    a.fill_between(ctr, 100 * lo, 100 * hi, color=col, alpha=0.18, lw=0); a.plot(ctr, 100 * dd, color=col, lw=1.0)
    top = max(np.nanmax(100 * hi) if np.isfinite(hi).any() else 5, 2) * 1.08
    a.set_xlim(*XL); a.set_ylim(0, top); a.set_xticks(XT)
    a.set_yticks([0, 10, 20, 30] if top > 31 else ([0, 10, 20] if top > 21 else [0, 10]))
    a.tick_params(labelsize=5.5, pad=1.5, labelbottom=(r == len(PG) - 1))
    for s in ("top", "right"): a.spines[s].set_visible(False)
    a.set_ylabel("% cells", fontsize=6, labelpad=2)
    rr = T.loc[g]
    a.text(0.0, 1.06, g, transform=a.transAxes, fontsize=6.5, style="italic", va="bottom", ha="left", color=col, bbox=dict(fc="white", ec="none", pad=0.8), zorder=6)
    a.text(1.0, 1.06, f"L {rr.detL_pct:.1f}%   R {rr.detR_pct:.1f}%   AI {rr.asym_index:+.2f}   Z {rr.z_vs_genome:+.1f}   P = {rr.perm_p:.2f}".replace("-", "\u2212"),
           transform=a.transAxes, fontsize=5.3, va="bottom", ha="right", color="#555555", bbox=dict(fc="white", ec="none", pad=0.8), zorder=6)
axs[-1].set_xlabel("LR\u2032, distance from the midline (\u00b5m)", fontsize=6.5, labelpad=2)
# ---- shared guides: excluded midline band, midline, limits of the mirrored window
for a in axs:
    a.axvspan(-MID, MID, color="#BDBDBD", alpha=0.45, lw=0, zorder=0.5)
    a.axvline(0, color="#222222", lw=0.5, zorder=5)
    for s_ in (-1, 1): a.axvline(s_ * wmax, color="#222222", lw=0.5, ls=(0, (1, 2)), zorder=5)
def xf(x): return (L0 + (x - XL[0]) / (XL[1] - XL[0]) * AW) / W
ytop, ybot = 1 - (TOP + MAP_H + 8.0) / H, 1 - (H - BOT - PH) / H
for xx, ls, c in [(0, "-", "#BBBBBB"), (-wmax, (0, (1, 2)), "#999999"), (wmax, (0, (1, 2)), "#999999")]:
    fig.add_artist(Line2D([xf(xx)] * 2, [ybot, ytop], color=c, lw=0.4, ls=ls, zorder=-1))
out_ = os.path.join(HERE, "SuppFig5E_LPMeso_LR_map_profiles")
fig.savefig(out_ + ".png", dpi=600); fig.savefig(out_ + ".pdf", dpi=600); fig.savefig(out_ + ".ai", format="pdf", dpi=600)
# overlap check on text
fig.canvas.draw(); R = fig.canvas.get_renderer()
tx = [(t, t.get_window_extent(R)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
tk = {t for a_ in fig.axes for t in a_.get_xticklabels() + a_.get_yticklabels()}
print("overlaps:", [(a.get_text()[:16], b.get_text()[:16]) for i, (a, ba) in enumerate(tx) for b, bb in tx[i + 1:] if ba.overlaps(bb) and not (a in tk and b in tk)][:8])
fb = fig.bbox; print("outside:", [t.get_text()[:20] for t, b in tx if b.x0 < 0 or b.y0 < 0 or b.x1 > fb.x1 or b.y1 > fb.y1])
print(round(W), round(H), nL, nR, int(out.sum()), int(lp.sum()))
