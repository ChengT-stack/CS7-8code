# staging/00_inputs/export_stereoseq_cs9_markers.R
# Source: drive G: data/milestone_evidence/out_stereo/work/cs9_export.R
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
HGC_DATA <- Sys.getenv('HGC_DATA', 'data')
HGC_OUT <- Sys.getenv('HGC_OUT', 'results')

suppressPackageStartupMessages({library(Seurat); library(Matrix)})
o <- readRDS(paste0(HGC_DATA, "/CS9-28798-RNA-MapQ.rds"))
cn <- LayerData(o[["RNA"]], "counts")
g <- c('MESP1','GSC','FOXA2','FOXJ1','CHRD','SOX17','CER1','NOTO','SHH','HOXA1','HOXB1','NKX1-2','CDX2','HESX1','SIX3','OTX2','SOX2','LHX2','MEOX1','TCF15','TBX6','EOMES','TBXT','HOXB8','NKX2-5','TNNT2','MYL7','DPPA3','NANOS3','TFAP2C','PRDM1','ETV2','KDR','TAL1','HAND1','TBX4','HOXA10','HBZ','HBE1','GATA1')
g2 <- intersect(g, rownames(cn)); cat("missing:", setdiff(g, rownames(cn)), "\n")
m <- as.matrix(t(cn[g2, , drop=FALSE]))
md <- o@meta.data; keep <- intersect(c("nCount_RNA","Types","Type2","Type3"), colnames(md))
df <- data.frame(cell=colnames(o), md[, keep], m, check.names=FALSE)
write.csv(df, "CS9_markers.csv", row.names=FALSE); cat("cells", ncol(cn), "\n")
