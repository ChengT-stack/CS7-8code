# AIGG-OT CS7 -> CS8 animations (whole embryonic disc; one panel per CS7 group).
# Inputs (same tables as Figure 7B-D): ggot_cs7_coords.csv (17,663 CS7 disc cells), ggot_table_cs8_ancestor.csv (31,041 CS8 disc cells
# with the index of their CS7 ancestor in the default AIGG-OT matching; -1 = unmatched).
# Each dot is one matched CS8 cell that moves on a straight line, in the normalised disc frame, from the position of its CS7 ancestor
# to its own CS8 position. The frame is drawn at physical scale (A-P span 904 -> 1,138 -> 1,434 um).
import os, sys, textwrap
import numpy as np, pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import imageio.v2 as iio

mpl.rcParams.update({"font.family": "Arial", "font.size": 9, "savefig.facecolor": "white"})
WHICH = sys.argv[1] if len(sys.argv) > 1 else "both"
HERE = os.path.dirname(os.path.abspath(__file__))
# [repo] input tables (from aiggot/matching/06_derive_figure7_tables.py) and outputs; the original script read and wrote next to itself
IN = os.environ.get("HGC_SM_INPUT", HERE)
OUTD = os.path.join(os.environ.get("HGC_OUT", "results"), "animations"); os.makedirs(OUTD, exist_ok=True)

G7 = ["EPI", "ECT", "PS", "APS", "Node", "DE", "AVE", "VE1", "VE2"]
COL7 = {"EPI": "#5B6CC2", "ECT": "#2CA02C", "PS": "#D62728", "APS": "#FF7F0E", "Node": "#7B3FA0",
        "DE": "#8C564B", "AVE": "#E377C2", "VE1": "#17BECF", "VE2": "#BCBD22"}
COL8 = {"EPI": "#5B6CC2", "aECT": "#2E9E44", "pECT": "#9ACD7E", "NNE": "#B8E186", "CLE": "#1B7F8C",
        "PS": "#D62728", "Nas.Meso": "#F28E2B", "Para.Meso": "#E15759", "Rostral.Meso": "#FFBE7D",
        "LP.Meso": "#B6992D", "Heart.Meso": "#9C1F3A", "Node": "#7B3FA0", "Notochord": "#B07AA1", "PrP": "#D4A6C8",
        "DE": "#8C564B", "VE1": "#17BECF", "VE2": "#BCBD22"}
NAME8 = {"EPI": "EPI1", "aECT": "ECT", "pECT": "EPI2"}          # CS8 names as in the current figures
NAME7 = {"Node": "Primitive node"}
ORDER8 = ["EPI", "aECT", "pECT", "NNE", "CLE", "PS", "Nas.Meso", "Para.Meso", "Rostral.Meso", "LP.Meso", "Heart.Meso",
          "Node", "Notochord", "PrP", "DE", "VE1", "VE2"]
FIG7B = {"EPI": 7896, "ECT": 9000, "PS": 2850, "APS": 4166, "Node": 1106, "DE": 1446, "AVE": 183, "VE1": 1518, "VE2": 1403}

F7 = pd.read_csv(os.path.join(IN, "ggot_cs7_coords.csv"))
F8 = pd.read_csv(os.path.join(IN, "ggot_table_cs8_ancestor.csv"))
assert len(F7) == 17663 and len(F8) == 31041
M = F8[F8.ancestor_idx >= 0].reset_index(drop=True)
M["ancestor_idx"] = M.ancestor_idx.astype(int)
assert len(M) == 29568 and (M.ancestor_group.values == F7.cs7_group.values[M.ancestor_idx]).all()
assert M.ancestor_group.value_counts().to_dict() == FIG7B, "matched-cell numbers differ from Figure 7B"

A7, A5, A8 = (904.0, 450.0), (1138.0, 497.5), (1434.0, 550.0)       # A-P and L-R extent of the frame at CS7, t = 0.5 and CS8 (um)
n0 = np.c_[F7.X.values[M.ancestor_idx] / A7[0], F7.Y.values[M.ancestor_idx] / A7[1]]
n1 = np.c_[M.X.values / A8[0], M.Y.values / A8[1]]
rng = np.random.default_rng(0)
jit = rng.uniform(-6, 6, len(M))
c0 = np.array([mpl.colors.to_rgb(COL7[g]) for g in M.ancestor_group])
c1 = np.array([mpl.colors.to_rgb(COL8[g]) for g in M.cs8_group])
order = rng.permutation(len(M))
grp = M.ancestor_group.values
NODEFIX = len(sys.argv) > 2 and sys.argv[2] == "nodefix"            # translate every frame so that the node stays at the origin
nn = ((M.ancestor_group == "Node") & (M.cs8_group == "Node")).values  # cells that are node at both stages (reference)
SUF = "_node_fixed" if NODEFIX else ""

def span(t, a, b, c):
    return a + (b - a) * 2 * t if t <= 0.5 else b + (c - b) * 2 * (t - 0.5)

ease = lambda t: t * t * (3 - 2 * t)
T = np.r_[np.zeros(12), np.linspace(0, 1, 65), np.ones(18)]
XL, YL = (-170, 1630), (-390, 300)

def state(tr):
    t = ease(float(tr))
    sx, sy = span(t, A7[0], A5[0], A8[0]), span(t, A7[1], A5[1], A8[1])
    p = (1 - t) * n0 + t * n1
    XY = np.c_[p[:, 0] * sx, p[:, 1] * sy + jit]
    if NODEFIX:
        XY = XY - np.median(XY[nn], axis=0)
    return t, sx, XY, (1 - t) * c0 + t * c1

if NODEFIX:
    ext = np.vstack([state(v)[2] for v in (0, 0.5, 1)])
    XL = (float(np.floor(ext[:, 0].min() / 10) * 10 - 20), float(np.ceil(ext[:, 0].max() / 10) * 10 + 20))
    YL = (float(ext[:, 1].min() - 95), float(ext[:, 1].max() + 20))
YB = YL[0] + 22

def cross(ax, ms=12, label=True):
    if NODEFIX:
        ax.plot(0, 0, "+", color="k", ms=ms, mew=1.6, zorder=6)
        if label:
            ax.text(16, 30, "node (fixed)", fontsize=9, fontweight="bold", zorder=6,
                    bbox=dict(fc="white", ec="none", alpha=0.75, pad=1.0))

def stage_text(tr, t):
    return "CS7 (observed)" if tr == 0 else ("CS8 (observed)" if tr == 1 else ("interpolated; t = 0.5 as in Figure 7D" if abs(t - 0.5) < 1e-9 else "interpolated"))

def furniture(ax, fs=8):
    ax.set_xlim(*XL); ax.set_ylim(*YL); ax.set_aspect("equal"); ax.axis("off")

def grab(fig):
    fig.canvas.draw()
    a = np.asarray(fig.canvas.buffer_rgba())[:, :, :3].copy()
    return a[: a.shape[0] // 2 * 2, : a.shape[1] // 2 * 2]

def write(frames, stem):
    iio.mimsave(os.path.join(OUTD, stem + ".gif"), frames, fps=12, loop=0)
    iio.mimsave(os.path.join(OUTD, stem + ".mp4"), frames, fps=15, quality=8, macro_block_size=2)
    for k, nm in [(0, "CS7"), (12 + 32, "t0.5"), (len(frames) - 1, "CS8")]:
        iio.imwrite(os.path.join(OUTD, f"{stem}_frame_{nm}.png"), frames[k])
    print(stem, len(frames), frames[0].shape, round(os.path.getsize(os.path.join(OUTD, stem + ".gif")) / 1e6, 1), "MB gif",
          round(os.path.getsize(os.path.join(OUTD, stem + ".mp4")) / 1e6, 1), "MB mp4")

NOTE = ("Each dot is one CS8 cell matched by AIGG-OT (29,568 cells). It moves on a straight line, in the normalised disc frame drawn at physical scale, "
        "from the position of its CS7 ancestor to its own position at CS8. Positions between CS7 and CS8 are interpolated, not observed cell tracks; "
        "t is an interpolation parameter, not developmental time.")
if NODEFIX:
    NOTE += (f" Every frame is shifted so that the node stays at the cross (median position of the {int(nn.sum())} cells that are node at both stages), "
             "so movement is read relative to the node; part of the separation from the node is growth of the disc.")
h8 = [Line2D([], [], marker="o", ls="", ms=5, color=COL8[h], label=NAME8.get(h, h)) for h in ORDER8]
h7 = [Line2D([], [], marker="o", ls="", ms=5, color=COL7[g], label=NAME7.get(g, g)) for g in G7]

# ---------------------------------------------------------------- 1. whole embryonic disc
if WHICH in ("both", "all"):
    fig = plt.figure(figsize=(12.8, 6.4), dpi=100)
    ax = fig.add_axes([0.02, 0.13, 0.735, 0.72]); furniture(ax)
    t, sx, XY, C = state(0)
    sc = ax.scatter(XY[order, 0], XY[order, 1], s=2.2, c=C[order], lw=0)
    cross(ax)
    ax.annotate("", (XL[0] + 10, YB), (XL[0] + 170, YB), arrowprops=dict(arrowstyle="->", lw=0.9))
    ax.text(XL[0] + 180, YB, "anterior", fontsize=9, va="center")
    ax.plot([XL[1] - 210, XL[1] - 10], [YB] * 2, color="k", lw=1.8)
    ax.text(XL[1] - 110, YB + 13, "200 µm", fontsize=9, ha="center", va="bottom")
    fig.text(0.02, 0.945, "Supplementary Material 3. AIGG-OT: CS7 → CS8, all matched cells of the embryonic disc (dorsal view)" + (", node held fixed" if NODEFIX else ""), fontsize=14, fontweight="bold")
    fig.text(0.02, 0.105, textwrap.fill(NOTE + " Colour changes from the CS7 group of the ancestor to the CS8 group of the cell.", 235),
             fontsize=8, color="#555555", va="top", linespacing=1.4)
    tt = fig.text(0.775, 0.865, "", fontsize=16, fontweight="bold", color="#222222")
    ts = fig.text(0.775, 0.825, "", fontsize=10, color="#444444")
    ta = fig.text(0.775, 0.79, "", fontsize=9, color="#444444")
    bar = fig.add_axes([0.775, 0.755, 0.2, 0.012]); bar.set_xlim(0, 1); bar.set_ylim(0, 1); bar.axis("off")
    bar.barh(0.5, 1, height=1, color="#E3E3E3"); pb = bar.barh(0.5, 0, height=1, color="#444444")[0]
    fig.legend(handles=h7, loc="upper left", bbox_to_anchor=(0.77, 0.73), fontsize=8.5, frameon=False, ncol=2,
               title="CS7 group of the ancestor (start colour)", title_fontsize=9, handletextpad=0.2, columnspacing=1.0, labelspacing=0.4, alignment="left")
    fig.legend(handles=h8, loc="upper left", bbox_to_anchor=(0.77, 0.475), fontsize=8.5, frameon=False, ncol=2,
               title="CS8 group of the cell (end colour)", title_fontsize=9, handletextpad=0.2, columnspacing=1.0, labelspacing=0.4, alignment="left")
    frames = []
    for tr in T:
        t, sx, XY, C = state(tr)
        sc.set_offsets(XY[order]); sc.set_facecolors(C[order])
        tt.set_text(f"t = {t:.2f}"); ts.set_text(stage_text(tr, t)); ta.set_text(f"A–P extent {sx:,.0f} µm"); pb.set_width(t)
        frames.append(grab(fig))
    plt.close(fig)
    write(frames, "Supplementary_Material_3_AIGGOT_disc_CS7_to_CS8" + SUF)

# ---------------------------------------------------------------- 2. one panel per CS7 group
if WHICH in ("both", "groups"):
    fig = plt.figure(figsize=(15.0, 9.6), dpi=100)
    axs, scg, scb = [], [], []
    t, sx, XY, C = state(0)
    for j, g in enumerate(G7):
        r, c = divmod(j, 3)
        a = fig.add_axes([0.012 + c * 0.329, 0.635 - r * 0.262, 0.322, 0.235]); furniture(a)
        m = grp == g
        o = order[m[order]]
        scb.append((a.scatter(XY[~m, 0], XY[~m, 1], s=0.5, color="#E6E6E6", lw=0), ~m))
        scg.append((a.scatter(XY[o, 0], XY[o, 1], s=2.4 if m.sum() > 3000 else 4.0, c=C[o], lw=0), o))
        a.text(0.0, 1.0, f"CS7 {NAME7.get(g, g)}", transform=a.transAxes, fontsize=12, fontweight="bold", color=COL7[g], va="bottom")
        a.text(1.0, 1.0, f"{int((F7.cs7_group == g).sum()):,} CS7 cells → {int(m.sum()):,} matched CS8 cells", transform=a.transAxes,
               fontsize=9.5, color="#333333", va="bottom", ha="right")
        cross(a, ms=9, label=(j == 0))
        axs.append(a)
    a = axs[6]
    a.annotate("", (XL[0] + 10, YB), (XL[0] + 200, YB), arrowprops=dict(arrowstyle="->", lw=0.9))
    a.text(XL[0] + 215, YB, "anterior", fontsize=9, va="center")
    a = axs[8]
    a.plot([XL[1] - 210, XL[1] - 10], [YB] * 2, color="k", lw=1.8); a.text(XL[1] - 110, YB + 13, "200 µm", fontsize=9, ha="center", va="bottom")
    fig.text(0.012, 0.955, "Supplementary Material 4. AIGG-OT: CS8 cells matched to each of the nine CS7 groups" + (", node held fixed" if NODEFIX else " (dorsal view)"), fontsize=15, fontweight="bold")
    tt = fig.text(0.70, 0.905, "", fontsize=15, fontweight="bold", color="#222222")
    ts = fig.text(0.785, 0.907, "", fontsize=10.5, color="#444444")
    bar = fig.add_axes([0.70, 0.89, 0.285, 0.008]); bar.set_xlim(0, 1); bar.set_ylim(0, 1); bar.axis("off")
    bar.barh(0.5, 1, height=1, color="#E3E3E3"); pb = bar.barh(0.5, 0, height=1, color="#444444")[0]
    fig.legend(handles=h8, loc="lower left", bbox_to_anchor=(0.008, 0.052), fontsize=9.5, frameon=False, ncol=9,
               title="CS8 group of the cell (end colour); each panel starts in the colour of its CS7 group", title_fontsize=10,
               handletextpad=0.2, columnspacing=1.3, labelspacing=0.4, alignment="left")
    fig.text(0.012, 0.045, textwrap.fill(NOTE + " Grey, cells matched to the other CS7 groups. Each CS8 cell is shown with one CS7 ancestor, as in Figure 7B and 7C.", 262),
             fontsize=8.5, color="#555555", va="top", linespacing=1.4)
    frames = []
    for tr in T:
        t, sx, XY, C = state(tr)
        for (s_, o) in scg:
            s_.set_offsets(XY[o]); s_.set_facecolors(C[o])
        for (s_, mm) in scb:
            s_.set_offsets(XY[mm])
        tt.set_text(f"t = {t:.2f}"); ts.set_text(stage_text(tr, t)); pb.set_width(t)
        frames.append(grab(fig))
    plt.close(fig)
    write(frames, "Supplementary_Material_4_AIGGOT_by_CS7_group" + SUF)
