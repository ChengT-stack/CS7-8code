# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: execution log, session 824ef1ce kernel cell 115 (producing cell of artifact qc_per_cell.csv 4ee2266f);
#     first 5 lines (load) taken from the lineage record of the same artifact
# sha256 of original: defd4155720016821d79db313a9253726de61eebed4e3f6812a03261bc650259
# Methods paragraphs: P342-P343
# Produces: qc_per_cell.csv; printed QC summary (Table S2 values: 84,310 / 86,704 cells; medians)
# Edits/notes: reconstructed from kernel log; object path -> HGC_DATA.
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

suppressMessages(library(Seurat))
f <- file.path(DATA, "obj6_obj7_merged_curated_final.rds")
stopifnot(file.exists(f))
o <- readRDS(f)
md <- o@meta.data
md$has_xyz <- is.finite(md$x_um) & is.finite(md$y_um) & is.finite(md$z_um)
print(table(md$source_object, md$stage))
print(table(md$source_object, has_xyz=md$has_xyz, kept=md$curated_kept))
print(all.equal(md$nCount_RNA, md$nCount)); print(all.equal(md$nFeature_RNA, md$nFeature))
summ <- function(sel, lab){ x <- md[sel,]; data.frame(set=lab, n=nrow(x),
  med_tx=median(x$nCount_RNA), med_genes=median(x$nFeature_RNA), mean_tx=round(mean(x$nCount_RNA),1), mean_genes=round(mean(x$nFeature_RNA),1),
  min_tx=min(x$nCount_RNA), min_genes=min(x$nFeature_RNA), q01_tx=quantile(x$nCount_RNA,.01), max_tx=max(x$nCount_RNA), max_genes=max(x$nFeature_RNA)) }
st <- md$source_object
res <- rbind(summ(st=="obj6", "CS7 all"), summ(st=="obj6" & md$has_xyz, "CS7 with xyz (84,310)"), summ(st=="obj6" & md$curated_kept, "CS7 curated"),
             summ(st=="obj7", "CS8 all (86,704)"), summ(st=="obj7" & md$curated_kept, "CS8 curated"))
print(res, row.names=FALSE)
qc <- md[(st=="obj6" & md$has_xyz) | st=="obj7", c("source_object","nCount_RNA","nFeature_RNA")]
qc$stage <- ifelse(qc$source_object=="obj6","CS7","CS8")
write.csv(qc[,c("stage","nCount_RNA","nFeature_RNA")], "qc_per_cell.csv", row.names=TRUE)
cat(nrow(qc), "\n")