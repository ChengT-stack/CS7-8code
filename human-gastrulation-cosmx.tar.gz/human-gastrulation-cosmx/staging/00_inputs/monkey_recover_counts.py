# staging/00_inputs/monkey_recover_counts.py
# Source: reconstructed from transcript c88279b5 (messages 86, 88, 102)
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Recover integer UMI counts of the monkey (GSE193007) log-normalised matrix: expm1(x)/expm1(min non-zero x of the cell).
# Reconstructed verbatim from session transcript c88279b5 (code was run cell-by-cell in a
# persistent kernel and never saved as a file). Cells are concatenated in execution order;
# inspection-only and figure-polishing cells are omitted, and cells that stopped with an error are
# truncated at the failing line (marked). See PROVENANCE.md.


# ---- cell [frame c88279b5, message 86] Loading matrix and recovering integer counts
import pandas as pd, numpy as np, scipy.sparse as sp, time
t=time.time()
D=(str(HGC_DATA) + '/GSE193007/')
df=pd.read_csv(D+'MFE56636MTX/matrix.mtx',sep=' ',skiprows=2,header=None,dtype={0:np.int32,1:np.int32,2:np.float32},engine='c')
X=sp.csc_matrix((df[2].values,(df[0].values-1,df[1].values-1)),shape=(26135,56636)).T.tocsr()
del df
genes=pd.read_csv(D+'MFE56636MTX/features.tsv',header=None)[0].tolist()
bc=pd.read_csv(D+'MFE56636MTX/barcodes.tsv',header=None)[0].tolist()
meta=pd.read_csv(D+'MFE56636-meta.csv',index_col=0)
assert list(meta.index)==bc
# recover counts
mn=np.array([X.data[X.indptr[i]:X.indptr[i+1]].min() for i in range(X.shape[0])])
unit=np.expm1(mn.astype(np.float64))
C=X.copy().astype(np.float64); C.data=np.expm1(C.data.astype(np.float64))
C=sp.diags(1/unit)@C
dev=np.abs(C.data-np.round(C.data))
print(time.time()-t, X.shape, np.percentile(dev,[50,99,99.9,100]), np.percentile(1e4/unit,[1,50,99]))
print(len(genes),len(set(genes)), [g for g in ['TBXT','T','EOMES','NKX1-2','MYCL','APELA','ELABELA','TDGF1','CDX4','DPPA5','CXX1','RTL8A','CER1','GSC'] if g in genes])


# ---- cell [frame c88279b5, message 88] Checking totals and ortholog symbol coverage



# ---- cell [frame c88279b5, message 102] Saving recovered integer count matrix
sp.save_npz((str(HGC_DATA) + '/GSE193007/counts_recovered_int.npz'), C.astype(np.float32))
pd.Series(genes).to_csv((str(HGC_DATA) + '/GSE193007/genes.csv'),index=False)
print('ok')
