"""Fates of the ventral, middle and dorsal CS7 node terciles under AIGG-OT and three control matchings
(Figure 7E-F; Supplementary Figure 10B; Methods 'Analysis of the reconstructed transition').
For each CS7 node cell the coupling mass to CS8 types is normalised per cell and averaged within tercile; ventral vs
dorsal is tested with two-sided Fisher's exact tests on each cell's dominant destination (Node vs not, PrP vs not).
Reconstructed verbatim from session 5113e657 messages [4836], [4057] (subset), [4874], [4880], [4882], [4884], [4886],
[4892], [4898] (subset), [4894]/[4905] (colours) and [4931] (panel figure). The session-only consistency check of the
bridge-bundle destinations ([4057]) was dropped. Run with cwd = HGC_GEN_ROOT after node_layers.py / node_layers_v2.py.
Outputs (cwd): node_DV_fate.xlsx (README + fate_by_layer; input of figure_SF10B_node_couplings.py),
Fig6_panels_DE_node.pdf/.png (draft Figure 7E-F panels).
"""
import os, shutil
import numpy as np, pandas as pd
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
OUT_AIGGOT = os.path.join(os.environ.get('HGC_OUT', 'results'), 'aiggot') + '/'   # outputs of the aiggot/ module

# ---- [4836]
import numpy as np, pandas as pd, scipy.sparse as sp, scipy.io as sio
EX=DATA+'/cs7_cs8_matching/dataprep/export/'; FR=DATA+'/cs7_cs8_matching/dataprep/frames/'
TMAP={'EPI':'EctoEpi','aECT':'EctoEpi','pECT':'EctoEpi','NNE':'EctoEpi','CLE':'EctoEpi','ECT':'EctoEpi','PS':'PS','APS':'PS',
 'Rostral.Meso':'Meso','Nas.Meso':'Meso','LP.Meso':'Meso','Para.Meso':'Meso','Heart.Meso':'Meso','Node':'Axial','Notochord':'Axial','PrP':'Axial','DE':'DE'}
genes=pd.read_csv(EX+'genes.csv').gene.values; gidx={g:i for i,g in enumerate(genes)}
rc7=pd.read_csv(EX+'CS7_cells.csv'); rc8=pd.read_csv(EX+'CS8_cells.csv'); rf7=pd.read_csv(FR+'CS7_frames.csv'); rf8=pd.read_csv(FR+'CS8_frames.csv')
assert (rc7.cell.values==rf7.cell.values).all() and (rc8.cell.values==rf8.cell.values).all()
RX7=sio.mmread(EX+'CS7_counts.mtx'); RX8=sio.mmread(EX+'CS8_counts.mtx')
print(RX7.shape,RX8.shape,len(rc7),len(rc8))

# ---- [4057] (subset)
t05=pd.read_csv(DATA+'/bridge_bundle/t05_table.csv')   # [4057] (subset; used only as the grey background of the panel figure)

# ---- [4874]
N=pd.read_csv('ai/node_layers/cs7_node_cells_layers_v2.csv')   # [glue] session read the uploaded copy of this table; print(N.shape); print(N.columns.tolist()); print(N.head(3).T.to_string()[:3000])

# ---- [4880]
FT=OUT_AIGGOT+'control_couplings/'   # original: bridge_bundle/tracks/Fate_timing/couplings/ (written by aiggot/matching/07_control_couplings.py)
h7=pd.read_csv(FT+'h5ad_cs7_cells.csv').cell.values; h8=pd.read_csv(FT+'h5ad_cs8_cells.csv').cell.values
pos7={c:i for i,c in enumerate(rc7.cell.values)}; pos8={c:i for i,c in enumerate(rc8.cell.values)}
r7=np.array([pos7.get(c,-1) for c in h7]); r8=np.array([pos8.get(c,-1) for c in h8]); print((r7<0).sum(),(r8<0).sum(),len(h7),len(h8))
Mref=np.load(OUT_AIGGOT+'couplings/M_ref.npz',allow_pickle=True)   # original: bridge_bundle/M_ref.npz (copy of the AIGG-OT reference coupling, aiggot/matching/05_run_aiggot.py); print(list(Mref.keys()))

# ---- [4882]
def loadM(f):
    M=sp.load_npz(f).tocsr()
    return M
Ms={'GG-OT (reference)':sp.csr_matrix((Mref['data'],Mref['indices'],Mref['indptr']),shape=tuple(Mref['shape'])),
    'no transition prior':loadM(FT+'M_gated_noprior.npz'),'expression only':loadM(FT+'M_expr_only_table.npz'),'expression only, no prior':loadM(FT+'M_expr_only_noprior.npz')}
for k,M in Ms.items(): print(k,M.shape,M.nnz)
# reference M row order: check against N (cs7_idx -> Node/Notochord/PrP counts?) 
lab8=rc8.label_short.values

# ---- [4884]
def fate_counts(M,rows,order='cs7'):
    out=[]
    for i in rows:
        s,e=M.indptr[i],M.indptr[i+1]; out.append(pd.Series(M.data[s:e],index=lab8[M.indices[s:e]] if order=='cs7' else lab8[r8[M.indices[s:e]]]).groupby(level=0).sum())
    return pd.DataFrame(out).fillna(0)
ri=N.cs7_idx.values
A_=fate_counts(Ms['GG-OT (reference)'],ri)
print(A_.columns.tolist()); print((A_.idxmax(1).values==N.dest.values).mean())
inv7=np.empty(len(r7),int); inv7[r7]=np.arange(len(r7))  # cs7 idx -> h5ad row
B_=fate_counts(Ms['no transition prior'],inv7[ri],order='h5ad'); print(B_.sum(0).round(1).sort_values(ascending=False).head(8).to_dict())

# ---- [4886]
comp={}
for k,M in Ms.items():
    F=fate_counts(M,ri) if k=='GG-OT (reference)' else fate_counts(M,inv7[ri],order='h5ad')
    F=F.div(F.sum(1).replace(0,np.nan),axis=0); F['layer']=N.DV_layer.values; F['matched']=F.drop(columns='layer').sum(1)>0
    comp[k]=F
    t=F[F.matched].groupby('layer').mean(numeric_only=True)*100
    keep=[c for c in ['PrP','Notochord','Node','Rostral.Meso','DE'] if c in t]; t['other']=100-t[keep].sum(1)
    print('==',k, 'matched',F.matched.sum()); print(t.loc[['ventral','middle','dorsal'],keep+['other']].round(1).to_string())

# ---- [4892]
from scipy.stats import fisher_exact
STAT={}
for k,F in comp.items():
    Fm=F[F.matched]; d=Fm.drop(columns=['layer','matched']).idxmax(1); L=Fm.layer
    v=d[L=='ventral']; dd=d[L=='dorsal']
    t=[[ (v=='Node').sum(), (v!='Node').sum()],[(dd=='Node').sum(),(dd!='Node').sum()]]
    t2=[[ (v=='PrP').sum(), (v!='PrP').sum()],[(dd=='PrP').sum(),(dd!='PrP').sum()]]
    STAT[k]=(fisher_exact(t)[1],fisher_exact(t2)[1],len(v),len(dd))
    print(k,t,'%.1e'%fisher_exact(t)[1],t2,'%.1e'%fisher_exact(t2)[1])

# ---- [4898] (subset; the copy of the outputs to a host folder was removed)
import os
rows=[]
for k,F in comp.items():
    Fm=F[F.matched]
    for L in ['ventral','middle','dorsal']:
        r=Fm[Fm.layer==L].drop(columns=['layer','matched']).mean()*100
        rows.append(dict(coupling=k,layer=L,n_cells=int((Fm.layer==L).sum()),PrP=r.get('PrP',0),Notochord=r.get('Notochord',0),Node=r.get('Node',0),other=100-r.get('PrP',0)-r.get('Notochord',0)-r.get('Node',0),
                         Fisher_P_Node_ventral_vs_dorsal=STAT[k][0],Fisher_P_PrP_ventral_vs_dorsal=STAT[k][1]))
T=pd.DataFrame(rows)
rd=pd.DataFrame({'note':['529 CS7 (HuE#1) Node cells split into D–V terciles (ventral/middle/dorsal; DV from bridge t05 table).',
 'Fate = coupling mass to CS8 types, normalised per CS7 cell and averaged within layer (%).',
 'Couplings: GG-OT reference (M_ref); GG-OT without transition prior; expression-only (spatial term set to zero) with prior; expression-only without prior (12 node cells unmatched).',
 'Fisher exact tests use each cell\'s dominant destination: Node vs not, PrP vs not, ventral vs dorsal.',
 'A (right): CS8 axial cells (light, by type) and CS8 cells receiving GG-OT mass from ventral or dorsal CS7 node cells (point size ~ mass).']})
with pd.ExcelWriter('node_DV_fate.xlsx') as w: rd.to_excel(w,sheet_name='README',index=False); T.to_excel(w,sheet_name='fate_by_layer',index=False)

# ---- [4894]/[4905] colour definitions + [4931] panel builder (draft panels of Figure 7E-F, built when the figure was numbered 6)
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
LC={'ventral':'#542788','middle':'#35978F','dorsal':'#E08214'}   # [4905]
FCn={'PrP':'#33BBEE','Notochord':'#0077BB','Node':'#CC3311','Rostral.Meso':'#E69F00','other':'#9E9E9E'}   # [4894]
def build_nodeDE():
    W_in=519/72; H_in=108/72
    fig=plt.figure(figsize=(W_in,H_in))
    LBL=dict(fontsize=7.9,fontweight='bold',va='top',ha='left')
    fig.text(0.012,0.985,'D',**LBL)
    ax=fig.add_axes([0.075,0.2,0.165,0.6])
    ax.scatter(t05.AP,t05.DV,s=0.15,c='#E8E8E8',lw=0,rasterized=True)
    for L in ['ventral','middle','dorsal']:
        q=N[N.DV_layer==L]; ax.scatter(q.AP,q.DV,s=1.2,c=LC[L],lw=0,label=L,zorder=3,rasterized=True)
    ax.set_xlim(N.AP.min()-0.05,N.AP.max()+0.05); ax.set_ylim(-1.8,1.6); ax.set_yticks([-1,0,1]); ax.set_xticks([0.2,0.4,0.6])
    ax.tick_params(labelsize=4.8,length=2,pad=1)
    ax.set_xlabel('A–P (CS7)',fontsize=5.2,labelpad=1); ax.set_ylabel('ventral ← D–V → dorsal',fontsize=5,labelpad=1)
    ax.set_title('CS7 node (n = 529): D–V terciles',fontsize=5.8,loc='left',pad=2)
    h,l=ax.get_legend_handles_labels(); ax.legend(h[::-1],l[::-1],fontsize=4.6,frameon=False,loc='upper left',handletextpad=0.05,markerscale=2.5,borderaxespad=0.05,labelspacing=0.1)
    M=Ms['GG-OT (reference)']; sel8=np.isin(lab8,['Node','Notochord','PrP'])
    for c_,L in enumerate(['ventral','middle','dorsal']):
        ax=fig.add_axes([0.29+c_*0.128,0.2,0.118,0.6])
        ax.scatter(rf8.AP_arc_frac[sel8],rf8.DV_gap_units[sel8],s=0.3,c=[FCn[l] for l in lab8[sel8]],alpha=0.2,lw=0,rasterized=True)
        rows=N.cs7_idx.values[N.DV_layer.values==L]; Wm=M[rows]; Wm=sp.diags(1/np.asarray(Wm.sum(1)).ravel())@Wm; m=np.asarray(Wm.sum(0)).ravel()
        j=np.where(m>0)[0]; ax.scatter(rf8.AP_arc_frac.values[j],rf8.DV_gap_units.values[j],s=0.6+2.2*m[j]/m[j].max(),c=LC[L],alpha=0.85,lw=0,zorder=3,rasterized=True)
        ax.set_xlim(0.0,0.62); ax.set_ylim(-1.5,0.15); ax.set_yticks([-1.2,-0.6,0]); ax.set_xticks([0,0.3,0.6])
        ax.tick_params(labelsize=4.8,length=2,pad=1)
        if c_>0: ax.set_yticklabels([])
        else: ax.set_ylabel('D–V (CS8)',fontsize=5.2,labelpad=1)
        if c_==1: ax.set_xlabel('A–P (CS8)',fontsize=5.2,labelpad=1)
        ax.text(0.03,0.97,f'from {L}',transform=ax.transAxes,fontsize=5,color=LC[L],ha='left',va='top',fontweight='bold')
        for t,x in {'PrP':0.12,'Noto.':0.29,'Node':0.50}.items(): ax.text(x,-1.47,t,fontsize=4.3,color=FCn['Notochord' if t=='Noto.' else t],ha='center',va='bottom',fontweight='bold')
        if c_==0: ax.set_title('CS8 descendants (GG-OT)',fontsize=5.8,loc='left',pad=2)
    fig.text(0.685,0.985,'E',**LBL)
    ax=fig.add_axes([0.775,0.27,0.205,0.5])
    Fm=comp['GG-OT (reference)'][comp['GG-OT (reference)'].matched]
    for y,L in zip([2,1,0],['ventral','middle','dorsal']):
        r_=Fm[Fm.layer==L].drop(columns=['layer','matched']).mean()*100; left=0
        for f in ['PrP','Notochord','Node']:
            v=r_.get(f,0); ax.barh(y,v,left=left,color=FCn[f],height=0.72,lw=0)
            if v>6: ax.text(left+v/2,y,f'{v:.0f}%',fontsize=4.6,color='w',ha='center',va='center')
            left+=v
        ax.text(-2,y,L,fontsize=5,ha='right',va='center',color=LC[L])
    ax.set_yticks([]); ax.set_xlim(0,100); ax.set_ylim(-0.5,2.5); ax.spines['left'].set_visible(False)
    ax.tick_params(labelsize=4.8,length=2,pad=1); ax.set_xticks([0,50,100])
    ax.set_xlabel('% of CS8 descendants',fontsize=5.2,labelpad=1)
    ax.set_title('CS8 fate by layer',fontsize=5.8,loc='left',pad=9)
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color=FCn[f],label=f) for f in ['PrP','Notochord','Node']],fontsize=4.6,frameon=False,ncol=3,loc='lower left',bbox_to_anchor=(-0.02,0.99),handlelength=0.8,handletextpad=0.25,columnspacing=0.6,borderaxespad=0)
    p1,p2=STAT['GG-OT (reference)'][:2]
    fmt=lambda p: (lambda m,e: rf'{m}$\times10^{{{int(e)}}}$')(*f'{p:.0e}'.split('e'))
    ax.text(0,-0.55,'ventral vs dorsal: node $P$ = '+fmt(p1)+', PrP $P$ = '+fmt(p2)+' (Fisher)',fontsize=4.3,va='top',transform=ax.transAxes)
    return fig
fig=build_nodeDE(); fig.savefig('Fig6_panels_DE_node.pdf'); fig.savefig('Fig6_panels_DE_node.png',dpi=300); plt.close(fig)
