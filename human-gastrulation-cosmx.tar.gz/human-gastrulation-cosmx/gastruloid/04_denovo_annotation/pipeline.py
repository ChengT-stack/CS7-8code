# gastruloid/04_denovo_annotation/pipeline.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/reannotation_denovo/code/pipeline.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

"""De novo re-analysis of one gastruloid / embryo-model dataset (no author labels, no reference atlas).
usage: python reanno/pipeline.py UNIT
"""
import sys, os, json, warnings, time
import numpy as np, pandas as pd, scipy.sparse as sp, anndata as ad, scanpy as sc
warnings.filterwarnings('ignore')
sc.settings.verbosity = 0
sys.path.insert(0, str(Path(__file__).resolve().parent))
from markers import SIG, PANEL, KEY, S_GENES, G2M_GENES, HOX_GROUPS

G0, G1 = 'gall/groups', 'gall/groups_new'
UNITS = {
 'Hamazaki':   dict(groups=['Ham_0h','Ham_24h','Ham_48h','Ham_72h','Ham_96h','Ham_RA96','Ham_RA120','Ham_RALDN'], join='outer'),
 'Budjan':       dict(groups=['Som_d1','Som_d2','Som_d3','Som_d5']),
 'Yamanaka':   dict(groups=['Ax_48h','Ax_72h','Ax_96h','Ax_96h_MG','Ax_96h_MG_RA','Ax_96h_MG_RAL','Ax_120h','Ax_120h_MG','Ax_120h_MG_RA','Ax_120h_MG_RAL']),
 'Makwana':    dict(groups=['Mak_72','Mak_96','Mak_120']),
 'Gribaudo':   dict(groups=['Gri_spinoid7']),
 'Olmsted':    dict(groups=['Emloc_D7','Emloc_D16']),
 'Minn':       dict(groups=['Min_44','Min_48re'], rep='replicate', harmony=True),
 'Heemskerk':  dict(groups=['Hee_42'], rep='replicate', harmony=True, dir='gall/groups_fix'),
 'Chen_polyA': dict(groups=['Chen_48','Chen_72','Chen_96'], rep='replicate', keep_rep=['rep1']),
 'Chen_probe': dict(groups=['Chen_48','Chen_72','Chen_96','Chen_D6','Chen_D8','Chen_D10'], rep='replicate',
                    keep_rep={'Chen_48':['rep2'],'Chen_72':['rep2'],'Chen_96':['rep2']}),
 'Rossi':      dict(groups=['Ros_d4','Ros_d5','Ros_d6','Ros_d7'], rep='batch', harmony=True, mouse=True),
 'Veenvliet':  dict(groups=['Vee_G120','Vee_TLS96','Vee_TLSMG108','Vee_TLSMG120','Vee_TLSMGCL120'], mouse=True),
 'Liu':        dict(groups=['Liu_PG_d11'], new=True),
 'Pedroza':    dict(groups=['Ped_hEE_D4','Ped_hEE_D6'], new=True),
 'Weatherbee': dict(groups=['Wea_d4','Wea_d6','Wea_d8'], new=True),
}
ALIAS = {'T': 'TBXT', 'MLF1IP': 'CENPU', 'FAM64A': 'PIMREG', 'HN1': 'JPT1', 'BAPX1': 'NKX3-2', 'LINC-ROR': 'LINC01206'}
ORTH = (str(HGC_DATA) + '/external/mouse_pijuan_sala/mouse_human_orthologs_one2one_Ensembl116.csv')

def load_unit(unit):
    cfg = UNITS[unit]; parts = []; presence = {}
    for g in cfg['groups']:
        a = ad.read_h5ad(f"{cfg.get('dir') or (G1 if cfg.get('new') else G0)}/{g}.h5ad")
        a.obs['group'] = g
        rep = cfg.get('rep')
        a.obs['rep'] = a.obs[rep].astype(str).values if rep and rep in a.obs else 'r1'
        kr = cfg.get('keep_rep')
        if kr is not None:
            k = kr.get(g) if isinstance(kr, dict) else kr
            if k is not None: a = a[a.obs['rep'].isin(k)].copy()
        a.obs['lib'] = a.obs['group'].astype(str) + '|' + a.obs['rep'].astype(str)
        keep = [c for c in ['group','rep','lib','sub','n_umi','n_genes','Phase','doublet.score','seurat_clusters','cell_assignment2','sample_type','percent.mt','author_annotation'] if c in a.obs]
        a.obs = a.obs[keep].copy(); inall = a.var['in_all_libs'].values.copy() if 'in_all_libs' in a.var else None; a.var = a.var[[]].copy()
        _vs = set(a.var_names)
        if not cfg.get('mouse'): a.var_names = [ALIAS[x] if x in ALIAS and ALIAS[x] not in _vs else x for x in a.var_names]
        a.var_names_make_unique()
        if inall is not None: a.var['in_all_libs'] = inall
        presence[g] = set(a.var_names)
        a.X = sp.csr_matrix(a.X).astype(np.float32)
        a.obs_names = [f'{g}:{x}' for x in a.obs_names]
        parts.append(a)
    A = ad.concat(parts, join=cfg.get('join', 'inner'), fill_value=0) if len(parts) > 1 else parts[0]
    A.X = sp.csr_matrix(A.X).astype(np.float32); A.obs_names_make_unique()
    A.var['in_all'] = [all(v in p for p in presence.values()) for v in A.var_names]
    if 'in_all_libs' in A.var: A.var['in_all'] = A.var['in_all'].values & A.var['in_all_libs'].values.astype(bool)
    A.uns['missing_by_group'] = {g: [k for k in KEY if k in A.var_names and k not in p] for g, p in presence.items()}
    if cfg.get('mouse'):
        o = pd.read_csv(ORTH)
        m = dict(zip(o['mouse_symbol'].astype(str), o['human_symbol'].astype(str)))
        pset = set(PANEL) | set(S_GENES) | set(G2M_GENES); taken = set(m.values())
        new = [m[g] if g in m else (g.upper() if g.upper() in pset and g.upper() not in taken else 'mm:' + g) for g in A.var_names]
        A.var['mouse_symbol'] = A.var_names.values; A.var_names = new; A.var_names_make_unique()
    return A, cfg

def main(unit, res_main=1.0):
    t0 = time.time(); out = f'reanno/out/{unit}'; os.makedirs(out, exist_ok=True)
    A, cfg = load_unit(unit)
    # genes detected in every library (so that no library carries structural zeros)
    libs = sorted(A.obs['lib'].unique()); det = np.ones(A.n_vars, bool); libinfo = {}
    for l in libs:
        x = A.X[(A.obs['lib'] == l).values]; nz = np.asarray((x > 0).sum(0)).ravel()
        libinfo[l] = dict(cells=int(x.shape[0]), genes_detected=int((nz > 0).sum()))
    n_all = A.n_vars; A = A[:, det].copy()
    sc.pp.filter_genes(A, min_cells=10)
    vn = pd.Index(A.var_names)
    mt = np.asarray(vn.str.startswith('MT-') | vn.str.startswith('mm:mt-')); rp = np.asarray(vn.str.match(r'^(RP[SL]\d|mm:Rp[sl]\d)'))
    A.obs['n_umi2'] = np.asarray(A.X.sum(1)).ravel(); A.obs['n_genes2'] = np.asarray((A.X > 0).sum(1)).ravel()
    A.obs['pct_mt'] = np.asarray(A.X[:, mt].sum(1)).ravel() / A.obs['n_umi2'].values * 100 if mt.any() else np.nan
    A.obs['pct_rp'] = np.asarray(A.X[:, rp].sum(1)).ravel() / A.obs['n_umi2'].values * 100 if rp.any() else np.nan
    # doublets (scrublet, per library)
    A.obs['dbl_score'] = np.nan; A.obs['dbl_pred'] = False; dbl = {}
    for l in libs:
        ix = np.where((A.obs['lib'] == l).values)[0]
        try:
            b = A[ix].copy(); sc.pp.scrublet(b, random_state=0)
            s = b.obs['doublet_score'].values; p = b.obs['predicted_doublet'].values.astype(bool)
            thr = b.uns['scrublet'].get('threshold', np.nan)
            if p.mean() > 0.12 or not np.isfinite(thr):       # automatic threshold unreliable
                thr = float(max(0.35, np.quantile(s, 0.95))); p = s > thr
            A.obs.iloc[ix, A.obs.columns.get_loc('dbl_score')] = s
            A.obs.iloc[ix, A.obs.columns.get_loc('dbl_pred')] = p
            dbl[l] = dict(threshold=round(float(thr), 3), n_doublet=int(p.sum()), frac=round(float(p.mean()), 4))
        except Exception as e:
            dbl[l] = dict(error=str(e)[:80])
    n_before = A.n_obs; A = A[~A.obs['dbl_pred'].values].copy()
    sc.pp.normalize_total(A, target_sum=1e4); sc.pp.log1p(A)
    # cell cycle
    ok_all = set(A.var_names[A.var['in_all'].values]); s_g = [g for g in S_GENES if g in ok_all]; g2 = [g for g in G2M_GENES if g in ok_all]
    cc_ok = len(s_g) >= 15 and len(g2) >= 15
    if cc_ok: sc.tl.score_genes_cell_cycle(A, s_genes=s_g, g2m_genes=g2)
    else: A.obs['phase'] = 'not assessed'; A.obs['S_score'] = np.nan; A.obs['G2M_score'] = np.nan
    # HVG without MT / RP / cell-cycle genes
    vn = pd.Index(A.var_names)
    excl = np.asarray(vn.str.startswith('MT-') | vn.str.match(r'^RP[SL]\d') | vn.isin(S_GENES + G2M_GENES) | vn.str.startswith('mm:mt-') | vn.str.match(r'^mm:Rp[sl]\d'))
    bk = 'lib' if len(libs) > 1 and min(v['cells'] for v in libinfo.values()) >= 200 else None
    sc.pp.highly_variable_genes(A, n_top_genes=3000, flavor='seurat', batch_key=bk)
    hv = A.var['highly_variable'].values & ~excl & A.var['in_all'].values
    B = A[:, hv].copy(); sc.pp.scale(B, max_value=10); sc.tl.pca(B, n_comps=50, random_state=0)
    A.obsm['X_pca'] = B.obsm['X_pca']; rep_use = 'X_pca'
    if cfg.get('harmony') and A.obs['rep'].nunique() > 1:
        import harmonypy
        ho = harmonypy.run_harmony(A.obsm['X_pca'], A.obs, 'rep', random_state=0)
        Z = np.asarray(ho.Z_corr); Z = Z.T if Z.shape[0] != A.n_obs else Z
        A.obsm['X_harmony'] = Z; rep_use = 'X_harmony'
    del B
    sc.pp.neighbors(A, n_neighbors=15, n_pcs=30, use_rep=rep_use, random_state=0)
    for r in (0.5, 1.0, 2.0):
        sc.tl.leiden(A, resolution=r, key_added=f'leiden_{r}', flavor='igraph', n_iterations=2, directed=False, random_state=0)
    sc.tl.umap(A, random_state=0)
    cls = sorted(A.obs[f'leiden_{res_main}'].astype(str).unique(), key=int)
    A.obs['cl'] = pd.Categorical(A.obs[f'leiden_{res_main}'].astype(str), categories=cls)
    # markers
    sc.tl.rank_genes_groups(A, 'cl', method='wilcoxon', pts=True, tie_correct=False)
    mk = []
    for c in cls:
        d = sc.get.rank_genes_groups_df(A, c)
        d = d[(d['pvals_adj'] < 0.01) & (d['logfoldchanges'] > 0.5) & (d['pct_nz_group'] >= 0.15)].head(60).copy(); d.insert(0, 'cluster', c); mk.append(d)
    mk = pd.concat(mk); mk.to_csv(f'{out}/markers.csv', index=False)
    # cluster means / pct
    onehot = sp.csr_matrix((np.ones(A.n_obs, np.float32), (np.arange(A.n_obs), A.obs['cl'].cat.codes.values)), shape=(A.n_obs, len(cls)))
    n = np.asarray(onehot.sum(0)).ravel()
    mean = (onehot.T @ A.X).toarray() / n[:, None]; pct = (onehot.T @ (A.X > 0).astype(np.float32)).toarray() / n[:, None]
    pd.DataFrame(mean, index=cls, columns=A.var_names).T.astype(np.float32).to_parquet(f'{out}/cl_mean.parquet')
    pd.DataFrame(pct, index=cls, columns=A.var_names).T.astype(np.float32).to_parquet(f'{out}/cl_pct.parquet')
    obs = A.obs.copy(); obs['umap1'] = A.obsm['X_umap'][:, 0]; obs['umap2'] = A.obsm['X_umap'][:, 1]
    for c in obs.columns:
        if obs[c].dtype.name == 'category' or obs[c].dtype == object: obs[c] = obs[c].astype(str)
    obs.to_parquet(f'{out}/cells.parquet')
    np.save(f'{out}/pca.npy', A.obsm[rep_use].astype(np.float32))
    pg = [g for g in PANEL if g in A.var_names]
    pd.DataFrame(A[:, pg].X.toarray().astype(np.float32), index=A.obs_names, columns=pg).to_parquet(f'{out}/panel_expr.parquet')
    # signatures
    M = pd.DataFrame(mean, index=cls, columns=A.var_names); P = pd.DataFrame(pct, index=cls, columns=A.var_names)
    z = (M - M.mean(0)) / (M.std(0) + 0.1)
    sig = {}
    for k, gs in SIG.items():
        g = [x for x in gs if x in M.columns]
        sig[k] = (0.5 * P[g].mean(1) + 0.5 * (z[g].clip(-2, 3).mean(1) / 3)) if len(g) >= 2 else pd.Series(np.nan, index=cls)
    sig = pd.DataFrame(sig); sig.to_csv(f'{out}/signature_scores.csv')
    hox = {}
    for k, gs in HOX_GROUPS.items():
        g = [x for x in gs if x in P.columns]; hox[k] = P[g].max(1) if g else pd.Series(np.nan, index=cls)
    hox = pd.DataFrame(hox)
    # summary text
    L = [f'# {unit}: {A.n_obs} cells after doublet removal ({n_before - A.n_obs} removed of {n_before}); genes used {A.n_vars} of {n_all}; libs {json.dumps(libinfo)}',
         f'# doublets {json.dumps(dbl)}', f'# key genes missing from a group matrix (author gene filter; zeros are structural): {json.dumps(A.uns["missing_by_group"])}', f'# cell cycle assessed: {cc_ok}; HVG {int(hv.sum())}; integration: {rep_use}',
         f'# key genes absent from matrix (<10 cells or not in annotation): {" ".join(g for g in KEY if g not in A.var_names)}', '']
    comp = pd.crosstab(A.obs['cl'], A.obs['group'], normalize='index')
    for c in cls:
        m = (A.obs['cl'] == c).values; o = A.obs[m]
        gtxt = ', '.join(f'{g} {v:.0%}' for g, v in comp.loc[c].sort_values(ascending=False).items() if v >= 0.05)
        ph = o['phase'].value_counts(normalize=True)
        L.append(f'## c{c} n={m.sum()} ({m.mean():.1%}) | {gtxt} | umi {o.n_umi2.median():.0f} genes {o.n_genes2.median():.0f} mt {o.pct_mt.median():.1f}% dbl {o.dbl_score.median():.2f} | ' + ' '.join(f'{k}:{v:.0%}' for k, v in ph.items()))
        d = mk[mk.cluster == c].head(25)
        L.append('  top: ' + ' '.join(f'{r.names}({r.logfoldchanges:.1f};{r.pct_nz_group*100:.0f}/{r.pct_nz_reference*100:.0f})' for r in d.itertuples()))
        pp = P.loc[c, [g for g in KEY if g in P.columns]]; pp = pp[pp >= 0.15].sort_values(ascending=False)
        L.append('  key>=15%: ' + ' '.join(f'{g}:{v*100:.0f}' for g, v in pp.items()))
        s = sig.loc[c].dropna().sort_values(ascending=False).head(5)
        L.append('  sig: ' + '; '.join(f'{k} {v:.2f}' for k, v in s.items()) + ' | HOX pct: ' + ' '.join(f'{k}:{v*100:.0f}' for k, v in hox.loc[c].items()))
    open(f'{out}/summary.txt', 'w').write('\n'.join(L))
    json.dump(dict(unit=unit, cells=int(A.n_obs), removed_doublets=int(n_before - A.n_obs), cells_in=int(n_before), genes=int(A.n_vars), libs=libinfo, doublets=dbl,
                   cc_ok=bool(cc_ok), n_hvg=int(hv.sum()), integration=rep_use, n_clusters=len(cls), minutes=(time.time() - t0) / 60), open(f'{out}/run.json', 'w'), indent=1)
    print(unit, 'done', A.n_obs, len(cls), f'{(time.time()-t0)/60:.1f} min')

if __name__ == '__main__':
    main(sys.argv[1])
