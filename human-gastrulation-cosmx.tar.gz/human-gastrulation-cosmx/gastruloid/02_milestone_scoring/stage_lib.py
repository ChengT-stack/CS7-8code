# gastruloid/02_milestone_scoring/stage_lib.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/code/stage_lib.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Library: milestone staging of gastruloid scRNA-seq groups on the Figure 6A/B milestone axis (rules as in stage_gastruloid.py, generalised to mouse and human groups).
# A group = one dataset x condition x time point (replicates merged). Counts are raw UMIs.
import scanpy as sc, anndata as ad, numpy as np, pandas as pd, scipy.sparse as sp, warnings; warnings.filterwarnings('ignore')
R, N, P, A = 'reached', 'not reached', 'partial', 'not assessable'
GAS = 'gall/'
T2 = pd.read_excel(os.environ.get('HGC_TABLE_S2', str(HGC_DATA / 'Table_S2_milestones.xlsx')), sheet_name='milestones').query("`Row type` == 'milestone'").set_index('Milestone ID')   # Table S2, sheet 'milestones' (originally exported to gall/tableS2_milestones.csv)
ONSET = T2['Mouse onset, Pijuan-Sala (E)'].to_dict(); THR = T2['Threshold value (%)'].to_dict(); DOM = T2['Domain'].to_dict(); MNAME = T2['Milestone'].to_dict()
# defining markers (human symbols): gene -> detection (%) in the mouse defining cell type (Table S2); nan = marker not in the Table S2 pair
DEF_H = {'m01': {'MESP1': 98.6, 'TBX6': np.nan}, 'm02': {'GSC': 91.7, 'FOXA2': 81.7}, 'm03': {'FOXJ1': 90.9, 'CHRD': 64.2}, 'm04': {'FOXA2': 70.8, 'SOX17': 53.0},
         'm07': {'NOTO': 91.2}, 'm09': {'NKX1-2': 89.8, 'CDX2': 97.2}, 'm10': {'HESX1': 38.9, 'SIX3': 22.8}, 'm11': {'MEOX1': 53.0, 'TCF15': 72.1},
         'm14': {'NKX2-5': 94.4, 'TNNT2': 99.8}, 'm15': {'NANOS3': 28.8, 'TFAP2C': np.nan}, 'm16': {'KDR': 83.0, 'ETV2': 88.1}, 'm17': {'HAND1': 80.6},
         'm18': {'TBX4': 31.6, 'HOXA10': 79.3}, 'm19': {'HBE1': 99.6, 'GATA1': 92.2}}
DEF_M = dict(DEF_H); DEF_M['m15'] = {'NANOS3': 28.8, 'DPPA3': 56.9}; DEF_M['m19'] = {'HBA-X': 99.6, 'GATA1': 92.2}   # mouse definitions as in Table S2
SHOW_H = {'m07': ['SHH', 'FOXA2'], 'm17': ['FOXF1', 'POSTN'], 'm15': ['SOX17', 'PRDM1'], 'm19': ['HBZ']}; SHOW_M = {'m07': ['SHH', 'FOXA2'], 'm17': ['FOXF1', 'POSTN'], 'm15': ['SOX17', 'PRDM1', 'TFAP2C']}
SPECIAL = {'TBXT': 'T', 'HBA-X': 'Hba-x', 'HBZ': 'Hba-x'}
def sym(g, sp_):
    return g if sp_ == 'human' else SPECIAL.get(g, g[0] + g[1:].lower())
TRANSIENT = [m for m in DEF_H if T2.loc[m, 'Mouse metric at E8.5 (%)'] < THR[m]] + ['m05']

def det(a, g): return np.asarray((a[:, g].X > 0).todense()).ravel() if g in a.var_names else np.zeros(a.n_obs, bool)
def pct(k, n): return 100 * k / n if n else np.nan

def qc(a, sp_, min_genes=500, max_mt=20.0):
    X = sp.csr_matrix(a.X); a.X = X.astype(np.float32)
    ng = np.asarray((X > 0).sum(1)).ravel(); mt = np.array([v.upper().startswith('MT-') for v in a.var_names])
    pm = 100 * np.asarray(X[:, mt].sum(1)).ravel() / np.maximum(np.asarray(X.sum(1)).ravel(), 1)
    keep = (ng >= min_genes) & (pm <= max_mt)
    info = dict(cells_in=int(a.n_obs), cells_kept=int(keep.sum()), genes_lt500=int((ng < min_genes).sum()), mt_gt20=int((pm > max_mt).sum()))
    b = a[keep].copy(); b.obs['n_umi'] = np.asarray(b.X.sum(1)).ravel(); b.obs['n_genes'] = np.asarray((b.X > 0).sum(1)).ravel()
    return b, info

def subcl(a):
    Q = a.copy(); sc.pp.normalize_total(Q, target_sum=1e4); sc.pp.log1p(Q)
    sc.pp.highly_variable_genes(Q, n_top_genes=2000); Q = Q[:, Q.var.highly_variable].copy()
    sc.pp.scale(Q, max_value=10); sc.tl.pca(Q, n_comps=30, random_state=0); sc.pp.neighbors(Q, n_neighbors=15, random_state=0)
    sc.tl.leiden(Q, resolution=2.0, flavor='igraph', n_iterations=2, key_added='sub', random_state=0); sc.tl.umap(Q, random_state=0)
    return Q.obs['sub'].astype(str).values, Q.obsm['X_umap']

def mthr(CV, gid):   # fixed (Table S2 / monkey rule) and depth-matched thresholds for the gene milestones
    c = CV[CV['sample'] == gid]; g = lambda ref, gene: c[(c.reference == ref) & (c.gene == gene)].detection_pct
    return dict(fixed=dict(HOXA1=19.4, HOXB1=20.3, EOMES=67.2, HOXB8=THR['m13']),
                depth=dict(HOXA1=0.25 * g('T+ pool', 'Hoxa1').max(), HOXB1=0.25 * g('T+ pool', 'Hoxb1').max(), EOMES=0.75 * g('T+ pool', 'Eomes').max(), HOXB8=0.25 * g('caudal epiblast', 'Hoxb8').max()))

def place(v, E_, y, rising):
    E_, y = np.asarray(E_, float), np.asarray(y, float); y = np.maximum.accumulate(y) if rising else np.minimum.accumulate(y)
    if not rising: y, v = -y, -v
    if v <= y[0]: return f"<=E{E_[0]:g}", np.nan
    if v >= y[-1]: return f">=E{E_[-1]:g}", np.nan
    e = float(np.interp(v, y, E_)); return f"E{e:.2f}", e
SEG = {'EOMES': ('T+ pool', 'Eomes', False, 7.0, 8.0), 'HOXA1': ('T+ pool', 'Hoxa1', True, 6.5, 8.0), 'HOXB1': ('T+ pool', 'Hoxb1', True, 6.5, 8.0), 'HOXB8': ('caudal epiblast', 'Hoxb8', True, 7.5, 8.25), 'HOXB9': ('caudal epiblast', 'Hoxb9', True, 7.5, 8.25)}

def stage_group(a, sp_, gid, CV):
    """a: AnnData (raw counts, obs['sub'] sub-clusters). Returns evidence rows, calls (fixed / depth-matched thresholds), gene-clock rows."""
    DEF = DEF_H if sp_ == 'human' else DEF_M; SHOW = SHOW_H if sp_ == 'human' else SHOW_M
    def d(g):
        n_ = sym(g, sp_)
        if n_ not in a.var_names and g == 'TBXT' and 'T' in a.var_names: n_ = 'T'   # older human annotations name TBXT 'T'
        return det(a, n_)
    Ncell = a.n_obs; sub = a.obs['sub'].values; vc = pd.Series(sub).value_counts(); big = vc[vc >= 15].index
    ev = []; c = {}; cd = {}; POP = {}; TH = mthr(CV, gid)
    def rec(m, call, metric, text, call_d=None, **k):
        c[m] = call; cd[m] = call if call_d is None else call_d
        ev.append(dict(sample=gid, milestone_id=m, call_observed=call, call_observed_depth_matched=cd[m], metric=metric, evidence=text, **k))
    for m, mk in DEF.items():
        D = {g: d(g) for g in mk}; co = np.logical_and.reduce(list(D.values())); passing = []; tab = []
        for s in big:
            i = sub == s; ok = True; row = [s, int(i.sum())]
            for g, mouse in mk.items():
                p = pct(D[g][i].sum(), i.sum()); r = pct(D[g][~i].sum(), (~i).sum()); row += [p, r]
                ok &= (p >= r + 5) and (p >= 2 * r) and (np.isnan(mouse) or p >= 0.25 * mouse)
            tab.append(row + [ok])
            if ok: passing.append(s)
        ip = np.isin(sub, passing); popn = int(ip.sum()); pf = pct(popn, Ncell); cf = pct(co.sum(), Ncell) if len(mk) > 1 else 0.0
        metric = max(pf, cf); POP[m] = ip; g = list(mk)
        if popn: txt = f"{len(passing)} sub-cluster(s), {popn} cells ({pf:.2f}%): " + ', '.join(f"{x} {pct(D[x][ip].sum(), popn):.1f}% vs {pct(D[x][~ip].sum(), Ncell - popn):.1f}% elsewhere" for x in g)
        else:
            bt = max(tab, key=lambda r_: np.prod([max(r_[2 + 2 * j], 0.1) / max(r_[3 + 2 * j], 0.1) for j in range(len(g))])) if tab else None
            txt = "no sub-cluster passes" + (f"; best {bt[1]} cells: " + ', '.join(f"{x} {bt[2 + 2 * j]:.1f}% vs {bt[3 + 2 * j]:.1f}%" for j, x in enumerate(g)) if bt else '')
        if len(mk) > 1: txt += f"; {'+'.join(g)} co-detected in {int(co.sum())} cells ({cf:.2f}%)"
        for x in SHOW.get(m, []):
            dx = d(x); txt += f"; {x} {pct(dx[ip].sum(), popn):.1f}% in population" if popn else f"; {x} {pct(dx.sum(), Ncell):.1f}% of all cells"
        txt += f"; mouse onset frequency {THR[m]:g}%"
        rec(m, R if metric >= THR[m] else (P if popn else N), round(metric, 2), txt, pool_n=popn)
    de = POP['m04']; nde = int(de.sum()); gsc = d('GSC'); cer = d('CER1')
    if nde >= 15:
        k = int((gsc & cer & de).sum()); f = pct(k, Ncell)
        rec('m05', R if f >= THR['m05'] else (P if k >= 10 else N), round(f, 2), f"GSC+CER1+ cells within DE-like population {k}/{nde} = {f:.2f}% of all cells; mouse onset frequency {THR['m05']:g}%", pool_n=nde)
        g_ = pct(gsc[de].sum(), nde)
        rec('m06', R if g_ < THR['m06'] else N, round(g_, 1), f"GSC {g_:.1f}% of DE-like cells ({int(gsc[de].sum())}/{nde}); loss threshold <{THR['m06']:.1f}%", pool_n=nde)
    else:
        k = int((gsc & cer).sum())
        rec('m05', N, 0.0, f"no DE-like population (FOXA2+SOX17+); GSC+CER1+ cells in the whole sample {k} ({pct(k, Ncell):.2f}%), outside DE", pool_n=nde)
        rec('m06', A, np.nan, "no DE-like population in which GSC loss could be read", pool_n=nde)
    tp = d('TBXT'); nt = int(tp.sum()); v = {g: pct(d(g)[tp].sum(), nt) for g in ['EOMES', 'HOXA1', 'HOXB1']}; F, Dm = TH['fixed'], TH['depth']
    if nt >= 15:
        f8 = lambda q: R if (v['HOXA1'] >= q['HOXA1'] or v['HOXB1'] >= q['HOXB1']) else N
        rec('m08', f8(F), round(max(v['HOXA1'], v['HOXB1']), 1), f"TBXT+ pool n={nt}: HOXA1 {v['HOXA1']:.1f}% (onset >={F['HOXA1']:.1f}%; depth-matched >={Dm['HOXA1']:.1f}%), HOXB1 {v['HOXB1']:.1f}% (onset >={F['HOXB1']:.1f}%; depth-matched >={Dm['HOXB1']:.1f}%)", call_d=f8(Dm), pool_n=nt)
        rec('m12', R if v['EOMES'] < F['EOMES'] else N, round(v['EOMES'], 1), f"TBXT+ pool n={nt}: EOMES {v['EOMES']:.1f}% (loss threshold <{F['EOMES']:.1f}%; depth-matched <{Dm['EOMES']:.1f}%)", call_d=R if v['EOMES'] < Dm['EOMES'] else N, pool_n=nt)
    else:
        rec('m08', A, np.nan, f"TBXT+ pool n={nt} (<15)", pool_n=nt); rec('m12', A, np.nan, f"TBXT+ pool n={nt} (<15)", pool_n=nt)
    cp = d('NKX1-2') & d('CDX2'); ncp = int(cp.sum()); h8 = pct(d('HOXB8')[cp].sum(), ncp); h9 = pct(d('HOXB9')[cp].sum(), ncp)
    if ncp >= 15: rec('m13', R if h8 >= F['HOXB8'] else N, round(h8, 1), f"NKX1-2+CDX2+ pool n={ncp}: HOXB8 {h8:.1f}% (onset >={F['HOXB8']:.1f}%; depth-matched >={Dm['HOXB8']:.1f}%), HOXB9 {h9:.1f}%", call_d=R if h8 >= Dm['HOXB8'] else N, pool_n=ncp)
    else: rec('m13', A, np.nan, f"NKX1-2+CDX2+ pool n={ncp} (<15)", pool_n=ncp)
    ax = POP['m07'] | POP['m03']; ck = []
    for g, (ref, col, rising, e0, e1) in SEG.items():
        pool = tp if ref == 'T+ pool' else cp; n = int(pool.sum()); vv = pct(d(g)[pool].sum(), n)
        row = dict(sample=gid, gene=g, pool='TBXT+ cells' if ref == 'T+ pool' else 'NKX1-2+CDX2+ cells', pool_n=n, pool_pct_of_cells=round(pct(n, Ncell), 2), pool_pct_in_node_like_population=round(pct((pool & ax).sum(), n), 1), detection_pct=round(vv, 1), mouse_reference=ref)
        for tag, key in [('native', 'native'), ('depth_matched', gid)]:
            c_ = CV[(CV['sample'] == key) & (CV.reference == ref) & (CV.gene == col) & (CV.E >= e0) & (CV.E <= e1)].sort_values('E')
            lab, e = place(vv, c_.E, c_.detection_pct, rising) if n >= 15 else ('pool <15 cells', np.nan)
            row[f'mouse_equivalent_{tag}'] = lab; row[f'mouse_equivalent_E_{tag}'] = e
        ck.append(row)
    return ev, c, cd, ck

def onset_logic(groups, calls, series, naive_first=(), hours=None, naive_series=(), series_id=None, early_h=48, mode='timeaware'):
    """groups: ordered list of group ids; series: {gid: earlier group ids of the same time course}. Reached stays reached ('reached (earlier)').
    An absent transient population (mouse metric below its onset frequency at E8.5, plus m05) is 'not reached' only where its absence is informative:
    time courses starting from the pluripotent state (naive_series / naive_first), or samples taken <= early_h after induction; otherwise it cannot be
    told from 'already passed' and is 'not assessable'.  mode='strict': only the first sample of a time course without an earlier time point is 'not assessable'."""
    final = {}
    for g in groups:
        prev = series.get(g, []); f = dict(calls[g])
        for m in calls[g]:
            if calls[g][m] != R and any(calls[s][m] == R for s in prev): f[m] = R + ' (earlier)'
            elif calls[g][m] in (N, P) and m in TRANSIENT and g not in naive_first:
                if mode == 'strict': inform = bool(prev)
                else: inform = (series_id is not None and series_id[g] in naive_series) or (hours is not None and hours[g] <= early_h)
                if not inform: f[m] = A
        final[g] = f
    return final

def window(C, k, sel=None):
    d = C[C.domain == 'embryonic disc'] if sel is None else C.loc[sel]
    isr = d[k].str.startswith(R); lo = d.loc[isr, 'mouse_onset'].max(); hi = d.loc[d[k] == N, 'mouse_onset'].min()
    lo = -np.inf if np.isnan(lo) else lo; hi = np.inf if np.isnan(hi) else hi
    out = dict(latest_reached_onset=lo, latest_reached=';'.join(d.index[isr & (d.mouse_onset == lo)]), earliest_not_reached_onset=hi, earliest_not_reached=';'.join(d.index[(d[k] == N) & (d.mouse_onset == hi)]),
               n_reached=int(isr.sum()), n_not_reached=int((d[k] == N).sum()), n_partial=int((d[k] == P).sum()), n_not_assessable=int((d[k] == A).sum()))
    out['conflict_days'] = max(0.0, lo - hi) if np.isfinite(lo) and np.isfinite(hi) else 0.0
    out['out_of_order_pairs'] = int(sum(1 for i in d.index[isr] for j in d.index[d[k] == N] if d.mouse_onset[i] > d.mouse_onset[j]))
    tied = lo >= hi; wl, wh = lo, hi
    if tied:
        grid = np.array([6.5, 6.75, 7.0, 7.25, 7.5, 7.75, 8.0, 8.25, 8.5]); q = np.searchsorted(grid, lo); wl, wh = grid[q - 1], grid[q]
    out.update(window_lo=wl, window_hi=wh, tied=bool(tied), label=(f">=E{wl:g}" if np.isinf(wh) and np.isfinite(wl) else ("no reached milestone" if not np.isfinite(wl) else (f"~E{(wl + wh) / 2:g}" if wh - wl <= 0.25 + 1e-9 and not tied else f"E{wl:g}-{wh:g}"))))
    return out
POST = ['m01', 'm08', 'm09', 'm11', 'm12', 'm13']
