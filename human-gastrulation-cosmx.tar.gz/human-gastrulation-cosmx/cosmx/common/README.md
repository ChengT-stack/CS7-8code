# cosmx/common

Shared plotting style and pathway gene-set constants.

Inputs, run order, Methods-to-panel table and gaps: see [../README.md](../README.md). Origin and sha256 of every file: [../PROVENANCE.md](../PROVENANCE.md).
