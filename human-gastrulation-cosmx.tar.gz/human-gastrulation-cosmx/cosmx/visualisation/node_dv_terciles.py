# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: execution log, frame 723f1529 (sub-agent of session 5113e657) python kernel cells 10-16 and 37 (37 =
#     producing cell of Fig7AB_CS7_node_DV_tiers.csv, artifact db664915)
# sha256 of original: 1d9d977234b462a912a9f1e4955255d8d37f4f8338f00fedd3eac1936f2e0b5c
# Methods paragraphs: P354-P355
# Produces: out/Fig7AB_CS7_node_DV_tiers.csv (Figure 2I values: % positive cells in dorsal/ventral terciles of
#     the 529 HuE#1 node cells, Fisher and depth/endoderm-contact-adjusted logistic tests); CS7_X.npz/CS8_X.npz
#     caches
# Edits/notes: reconstructed from kernel log; exploratory loops and prints of cells 11-15 removed (cell 14 tier
#     definition kept but superseded by the rank-based 176/177/176 split of cell 15, as executed); only the CSV-
#     export lines of cell 37 kept. The lineage record of this CSV (LLM-extracted) computes terciles over all
#     cells and should not be used.
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

import pandas as pd, os
os.makedirs('out', exist_ok=True)
# --- kernel cell 10 ---
import numpy as np, scipy.io, scipy.sparse as sp, time
E=(str(DATA) + "/dataprep/")
genes=pd.read_csv(E+'export/genes.csv')['gene'].values
D={}
for st in ['CS7','CS8']:
    t=time.time()
    cells=pd.read_csv(E+f'export/{st}_cells.csv')
    fr=pd.read_csv(E+f'frames/{st}_frames.csv')
    assert (cells.cell.values==fr.cell.values).all()
    M=scipy.io.mmread(E+f'export/{st}_counts.mtx').tocsr().T.tocsr()  # cells x genes
    sp.save_npz(f'{st}_X.npz',M)
    D[st]=dict(cells=cells,fr=fr,X=M)
    print(st,M.shape,len(cells),round(time.time()-t),'s')
    print(cells.label_short.value_counts().to_dict())
gidx={g:i for i,g in enumerate(genes)}
print([g for g in ['PKD1L1','CIROP','DNAH11','FGF17','FGF8','CFC1','TDGF1','LEFTY1','LEFTY2','NOG','SHH','NOTO','TBXT','FOXJ1','GSC','LHX1','CER1','DKK1','CHRD','NANOG','POU5F1'] if g not in gidx])
# --- kernel cell 11 (definitions; exploratory loop removed) ---
def det(X,g,mask=None):
    v=X[:,gidx[g]]
    v=(v>0).toarray().ravel() if sp.issparse(v) else v>0
    return v if mask is None else v[mask]
c7=D['CS7']; fr7=c7['fr']; X7=c7['X']
node=(c7['cells'].label_short=='Node').values
# --- kernel cell 12 (imports) ---
from scipy.stats import fisher_exact, rankdata
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
# --- kernel cell 13 ---
sv=pd.Series(fr7.loc[node,'DV_um_to_surface'].values)
# --- kernel cell 14 (G7 list; quantile tiers, superseded by cell 15) ---
a=sv.values
lo,hi=np.quantile(a,[1/3,2/3])
tier=np.where(a>=hi,'dorsal',np.where(a<=lo,'ventral','mid'))
G7=['FOXJ1','CHRD','TBXT','NOTO','GSC','LHX1','CER1','DKK1','SOX17','POU5F1','CDH2','FGF17']
# --- kernel cell 15 (final tiers: 176 dorsal / 177 middle / 176 ventral) ---
order=np.argsort(-a)  # most dorsal first
tier=np.array(['mid']*len(a),dtype=object); tier[order[:176]]='dorsal'; tier[order[-176:]]='ventral'
# --- kernel cell 16 ---
from scipy.spatial import cKDTree
cl7=c7['cells']
endo=cl7.label_short.isin(['DE','AVE','VE1','VE2']).values
nb=np.zeros(len(cl7))
for s,idx in cl7.groupby('section').indices.items():
    xy=cl7[['x_um','y_um']].values[idx]
    t=cKDTree(xy[endo[idx]]) if endo[idx].any() else None
    if t is None: continue
    cnt=np.array([len(l) for l in t.query_ball_point(xy,r=20)])
    nb[idx]=cnt
nbn=nb[node]; ncount=cl7.nCount.values[node]
rows=[]
m=(tier!='mid')
for g in G7+['DNAH5']:
    y=det(X7,g,node)
    d1=y[tier=='dorsal'];v1=y[tier=='ventral']
    OR,p=fisher_exact([[d1.sum(),len(d1)-d1.sum()],[v1.sum(),len(v1)-v1.sum()]])
    Xd=pd.DataFrame({'dorsal':(tier[m]=='dorsal').astype(float),'endo_nb':nbn[m],'logn':np.log(ncount[m])})
    Xd=sm.add_constant(Xd)
    try:
        fit=sm.Logit(y[m].astype(float),Xd).fit(disp=0); ORa=np.exp(fit.params['dorsal']); pa=fit.pvalues['dorsal']
    except Exception as e: ORa,pa=np.nan,np.nan
    rows.append(dict(gene=g,dorsal_pct=100*d1.mean(),mid_pct=100*y[tier=='mid'].mean(),ventral_pct=100*v1.mean(),OR_dorsal_vs_ventral=OR,p=p,OR_adj_dorsal=ORa,p_adj_model=pa))
tt=pd.DataFrame(rows); tt['q']=multipletests(tt.p,method='fdr_bh')[1]; tt['q_adj_model']=multipletests(tt.p_adj_model.fillna(1),method='fdr_bh')[1]
print(tt.round(4).to_string())
# --- kernel cell 37 (table export) ---
tt_out=tt.copy(); tt_out.insert(0,'stage','CS7'); tt_out['n_dorsal']=176; tt_out['n_mid']=177; tt_out['n_ventral']=176
tt_out.round(4).to_csv('out/Fig7AB_CS7_node_DV_tiers.csv',index=False)
