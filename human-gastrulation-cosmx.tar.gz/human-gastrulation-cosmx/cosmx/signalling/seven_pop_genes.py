# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/cs7_five_pop_curves/seven_pop_genes.py (2026-10-03; parametrised version of artifact
#     7e941263; copy also in cs7_endo4_curves/)
# sha256 of original: 10e2cc20bc7834ec118922bc1b045956d124a09b43e2b2911d1730985b7f56bd
# Methods paragraphs: P358, P361
# Produces: Supplementary Figure 6A (POPS=EPI,ECT,Node,APS,PS EXPORT=five PREFIX=cs7_five_pop ->
#     cs7_five_pop_gene_curves.*) and 6B (POPS=DE,AVE,VE1,VE2 EXPORT=seven PREFIX=cs7_endo4 ->
#     cs7_endo4_gene_curves.*)
# Edits/notes: gene-set JSON path -> common/pathway_gene_sets.py.
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

"""Per-gene AP curves (every ligand, receptor, target and inhibitor) for the seven CS7 populations.
Shares the data-preparation block with seven_pop_trends.py.

ORIGINAL DOCSTRING OF THE SHARED BLOCK:
AP trends of five signalling pathways (ligand / receptor / target / inhibitor sets) restricted to seven CS7
populations: DE, AVE, VE1, VE2, Node, APS, PS. Same specification as cs7_five_pop_ap_trends (EPI/ECT/Node/APS/PS):
frame = landmark-anchored CS7 frame (AP sign from PS vs anterior landmarks, view axis from extraembryonic side),
AP band = 1-99th pct of these cells; set CP10K summed / set size, depth-adjusted, Gaussian kernel h = 0.06 x span;
slopes = OLS with log depth + population fixed effects; BH over the 20 sets of each version; 200 detection-matched
random sets; leave-one-out of the strongest genes."""
import os, re, json, sys
for k,v in [("KMP_AFFINITY","disabled"),("OMP_NUM_THREADS","8"),("KMP_INIT_AT_FORK","FALSE")]: os.environ.setdefault(k,v)
import numpy as np, pandas as pd, scipy.sparse as ssp
from scipy.io import mmread
from scipy.stats import binomtest
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
import matplotlib as mpl; mpl.use("Agg"); import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
sys.path.insert(0,os.getcwd())
from figure_style import apply_figure_style, panel_letter
META_GREY="#8A8A8A"

# ---------------- frame (identical to the five-population run) ----------------
E7=pd.read_csv(sys.argv[1] if len(sys.argv)>1 else "handoff/cs7_proj_curves_export.csv")
E7["curated_kept"]=E7.curated_kept.astype(str).isin(["True","TRUE","true"])
X7=E7[["x","y","z"]].to_numpy(float); fin7=np.isfinite(X7).all(1)
lab7=E7.label.to_numpy(); kept7=E7.curated_kept.to_numpy(); present=set(lab7)
ANT=[t for t in ["Anterior ectoderm (aECT)","Rostral mesoderm (Rostral.Meso)","Anterior visceral endoderm (AVE)"] if t in present]
POST=[t for t in ["Primitive streak (PS)","Caudal lateral epiblast (CLE)","Nascent mesoderm (Nas.Meso)"] if t in present]
EXE=[t for t in ["Trophoblast","Distal yolk sac endoderm (Dist.ys.Endo)","Proximal yolk sac endoderm (Prox.ys.Endo)",
                 "Parietal yolk sac endoderm (Pari.Endo)","Yolk sac mesoderm (ys.Meso)","Chorion-allantois mesenchyme (ChA.Mes)"] if t in present]
an,po,ex=np.isin(lab7,ANT)&fin7, np.isin(lab7,POST)&fin7, np.isin(lab7,EXE)&fin7
sa2=1.0 if np.median(X7[po,0])>np.median(X7[an,0]) else -1.0
sp2=1.0 if np.median(X7[ex,1])>np.median(X7[~ex&fin7,1]) else -1.0
C_fig=np.c_[sa2*X7[:,0], X7[:,2], sp2*X7[:,1]]; C_fig=C_fig-np.nanmedian(C_fig,axis=0)
assert np.median(C_fig[po,0])>np.median(C_fig[an,0]) and np.median(C_fig[ex,2])>0
# reproduce the earlier band check as a frame-fidelity assertion
TARG={"EPI":"Epiblast (EPI)","APS":"Anterior primitive streak (APS)","PS":"Primitive streak (PS)","Node":"Node"}
CUT={"PS":600.0,"APS":900.0,"EPI":720.0,"Node":760.0}; ci=[]
for s_,f_ in TARG.items():
    m=(lab7==f_)&kept7&fin7; d=np.hypot(C_fig[m,0]-np.median(C_fig[m,0]), C_fig[m,1]-np.median(C_fig[m,1])); ci.append(np.where(m)[0][d<=CUT[s_]])
ap_lo,ap_hi=np.percentile(C_fig[np.unique(np.concatenate(ci)),0],[1,99])
print(f"frame: AP = {sa2:+.0f}*x | earlier all-cell band reproduced [-482, 440]: {abs(ap_lo+482)<1 and abs(ap_hi-440)<1} ([{ap_lo:.0f}, {ap_hi:.0f}])",flush=True)

def kernel_curve(ap,val,h=None,n_grid=80,min_h=20):
    ap=np.asarray(ap,float); val=np.asarray(val,float)
    if h is None: h=max(min_h, 0.06*(ap.max()-ap.min()))
    grid=np.linspace(ap.min(),ap.max(),n_grid)
    w=np.exp(-0.5*((grid[:,None]-ap[None,:])/h)**2); wsum=w.sum(1)
    mean=(w*val[None,:]).sum(1)/np.where(wsum>1e-9,wsum,1)
    eff=wsum**2/(w**2).sum(1)
    var=(w*(val[None,:]-mean[:,None])**2).sum(1)/np.where(wsum>1e-9,wsum,1)
    return grid, mean, np.sqrt(var/np.where(eff>1,eff,1)), h

# ---------------- the seven populations ----------------
WANT=os.environ.get("POPS","DE,AVE,VE1,VE2,Node,APS,PS").split(",")
PREFIX=os.environ.get("PREFIX","cs7_seven_pop")
POPLABEL="/".join(WANT)
PCOL={"DE":"#D95F02","AVE":"#1F6FB2","VE1":"#E6AB02","VE2":"#7E7E1F","Node":"#2E8B57","APS":"#7B4FA3","PS":"#C2401A"}
FULL7={k:[t for t in present if t==k or t.endswith(f"({k})")][0] for k in WANT}
EXP=os.environ.get("EXPORT","seven")
M7=ssp.csr_matrix(mmread(f"handoff/{EXP}_counts.mtx"))
G7=pd.read_csv(f"handoff/{EXP}_genes.csv"); C7=pd.read_csv(f"handoff/{EXP}_cells.csv")
gi7={g:i for i,g in enumerate(G7.gene)}; det7=G7.n_det.to_numpy()
pos={c:i for i,c in enumerate(E7.cell)}
keep7=C7.label.isin([FULL7[k] for k in WANT]).to_numpy(); C7=C7[keep7].reset_index(drop=True); M7=M7[:,np.where(keep7)[0]]
ordr=np.array([pos[c] for c in C7.cell]); assert (lab7[ordr]==C7.label.to_numpy()).all()
ap7=C_fig[ordr,0]; lab5=C7.label.to_numpy(); dep5=C7.nCount.to_numpy(float); ld5=np.log(dep5)
sel=np.isfinite(ap7)
lo5,hi5=np.percentile(ap7[sel],[1,99])
inb=sel&(ap7>=lo5)&(ap7<=hi5)
print(f"{len(WANT)} populations: {len(C7):,} cells | AP band 1-99 pct [{lo5:.0f}, {hi5:.0f}] (span {hi5-lo5:.0f}) -> {int(inb.sum()):,} inside",flush=True)
for k in WANT:
    m=inb&(lab5==FULL7[k]); print(f"  {k:5s} n={int(m.sum()):5d}  AP median {np.median(ap7[m]):+6.0f}  IQR {np.percentile(ap7[m],25):+.0f}..{np.percentile(ap7[m],75):+.0f}")
POP=np.column_stack([(lab5==FULL7[k]).astype(float) for k in WANT[1:]])

# ---------------- gene sets (recovered from the project's curve tables; identical to the earlier figures) ----------------
COMPLETE=__import__("pathway_gene_sets").PATHWAY_GENE_SETS["COMPLETE"]
CONCISE=dict(COMPLETE)
CONCISE.update({"WNT_ligand":["WNT1","WNT2B","WNT3","WNT3A","WNT4","WNT5A","WNT5B","WNT6","WNT7A","WNT7B","WNT8A","WNT9A","WNT11","RSPO1","RSPO2","RSPO3"],
 "FGF_ligand":["FGF2","FGF3","FGF4","FGF5","FGF8","FGF9","FGF10","FGF17","FGF18"],
 "WNT_receptor":["FZD1","FZD2","FZD3","FZD4","FZD5","FZD6","FZD7","FZD8","FZD10","LRP5","LRP6"],
 "NODAL_receptor":["ACVR1B","ACVR2A","ACVR2B","SMAD2","SMAD3"],"NOTCH_receptor":["NOTCH1","NOTCH2","NOTCH3","NOTCH4"],
 "SHH_receptor":["PTCH1","SMO","GAS1","CDON","BOC"],"FGF_receptor":["FGFR1","FGFR2","FGFR3","FGFR4"],
 "NODAL_ligand":["NODAL","GDF3","CFC1","LEFTY1"],"NOTCH_ligand":["DLL1","DLL3","DLL4","JAG1","JAG2"],"SHH_ligand":["SHH","IHH","DHH"]})
PWS=["WNT","NODAL","NOTCH","SHH","FGF"]; KINDS4=["ligand","receptor","target","inhibitor"]
assert set(COMPLETE)=={f"{p}_{k}" for p in PWS for k in KINDS4}
diff={k for k in COMPLETE if sorted(COMPLETE[k])!=sorted(CONCISE[k])}
missing={k:[g for g in COMPLETE[k]+CONCISE[k] if g not in gi7] for k in COMPLETE}
print("genes absent from the export:",{k:v for k,v in missing.items() if v} or "none")


# ---------------- per-gene curves ----------------
KCOL={"ligand":"#1F6FB2","receptor":"#7B4FA3","target":"#C2401A","inhibitor":"#2E8B57"}
GCOL=["#1F6FB2","#C2401A","#2E8B57","#7B4FA3","#B8860B","#17A2B8","#D6559A","#7F7F7F"]
LABF={"ligand":"ligands","receptor":"receptors","target":"targets","inhibitor":"inhibitors / antagonists"}
apb=ap7[inb]; ldb=ld5[inb]
def gene_curve(g):
    v=np.asarray(M7[gi7[g],:].todense()).ravel()[inb]/dep5[inb]*1e4
    be=np.polyfit(ldb,v,1); resid=v-(be[0]*ldb+be[1])+v.mean()
    gc,gm,gs_,h=kernel_curve(apb,resid); return gc,gm,gs_,h,float((v>0).mean())
CUR={}; rows=[]
for k in COMPLETE:
    for g in COMPLETE[k]:
        if g in gi7 and g not in CUR: CUR[g]=gene_curve(g)
also={g:[k for k in COMPLETE if g in COMPLETE[k]] for g in CUR}
plt.close("all"); apply_figure_style()
fig=plt.figure(figsize=(16.4,15.2))
L0,R0=0.045,0.985; T0=0.880; B0=0.045
gw=(R0-L0-0.032*3)/4; gh=(T0-B0-0.016*4)/5
AX={}
for i,pw in enumerate(PWS):
    for j,kd in enumerate(KINDS4):
        ax=fig.add_axes([L0+j*(gw+0.032), T0-gh-i*(gh+0.016), gw, gh]); AX[(pw,kd)]=ax
        k=f"{pw}_{kd}"; gs=[g for g in COMPLETE[k] if g in CUR]
        peak={g:float(CUR[g][1].max()) for g in gs}
        top=sorted(gs,key=lambda g:-peak[g])[:5]
        for g in gs:
            if g not in top: ax.plot(CUR[g][0],CUR[g][1],color="#D0D0D0",lw=.8,zorder=2)
        # set mean per gene (dashed, pathway-kind colour)
        gc=CUR[gs[0]][0]; sm_=np.mean([CUR[g][1] for g in gs],axis=0)
        ax.plot(gc,sm_,color=KCOL[kd],lw=1.6,ls=(0,(4,2)),zorder=4)
        lab_pos=[]
        for n_,g in enumerate(top):
            gc,gm,gs_,h,det=CUR[g]; c=GCOL[n_]
            ax.fill_between(gc,gm-gs_,gm+gs_,color=c,alpha=.13,lw=0,zorder=3); ax.plot(gc,gm,color=c,lw=1.5,zorder=5)
            ip=int(np.argmax(gm)); lab_pos.append([gc[ip],gm[ip],g,c])
        # stagger labels that share an x-neighbourhood
        ymin,ymax=ax.get_ylim() if False else (min(np.min(CUR[g][1]-CUR[g][2]) for g in gs), max(np.max(CUR[g][1]+CUR[g][2]) for g in gs))
        sep=0.075*(ymax-ymin)
        lab_pos.sort(key=lambda r:r[0])
        for _ in range(60):
            moved=False
            for a in range(len(lab_pos)):
                for b in range(a+1,len(lab_pos)):
                    if abs(lab_pos[a][0]-lab_pos[b][0])<0.18*(hi5-lo5) and abs(lab_pos[a][1]-lab_pos[b][1])<sep:
                        sh=(sep-abs(lab_pos[a][1]-lab_pos[b][1]))/2+1e-6
                        if lab_pos[a][1]<=lab_pos[b][1]: lab_pos[a][1]-=sh; lab_pos[b][1]+=sh
                        else: lab_pos[a][1]+=sh; lab_pos[b][1]-=sh
                        moved=True
            if not moved: break
        span=hi5-lo5
        for x_,y_,g,c in lab_pos:
            ha="left" if x_<lo5+0.06*span else ("right" if x_>hi5-0.06*span else "center")
            ax.annotate(g,(x_,y_),xytext=(0,4),textcoords="offset points",ha=ha,va="bottom",fontsize=5.6,color=c,style="italic",zorder=9,
                        path_effects=[pe.withStroke(linewidth=1.6,foreground="white")])
        for g,rec in zip(gs,[CUR[g] for g in gs]):
            rows.append(pd.DataFrame(dict(pathway=pw,kind=kd,gene=g,AP_um=np.round(rec[0],2),mean_CP10K=np.round(rec[1],4),sem=np.round(rec[2],4),
                                          detection_pct=round(100*rec[4],2),bandwidth_um=round(rec[3],1),labelled=g in top,
                                          also_in=";".join(x for x in also[g] if x!=k) or "")))
        ax.text(.02,.97,f"{pw} {LABF[kd]} \u00b7 {len(gs)} genes",transform=ax.transAxes,fontsize=6.3,va="top",color=KCOL[kd])
        ax.set_xlim(lo5,hi5); ax.margins(y=0.30); ax.spines[["top","right"]].set_visible(False); ax.tick_params(labelsize=5.6)
        ax.axhline(0,color="#E5E5E5",lw=.6,zorder=0)
for pw in PWS[:-1]:
    for kd in KINDS4: AX[(pw,kd)].tick_params(labelbottom=False)
for kd in KINDS4: AX[(PWS[-1],kd)].set_xlabel("anterior \u2192 posterior (\u00b5m)",fontsize=7.2)
for pw in PWS: AX[(pw,"ligand")].set_ylabel(f"{pw}\nexpression (CP10K)",fontsize=6.6,color=KCOL["ligand"] if False else "#333333")
for j,kd in enumerate(KINDS4): AX[(PWS[0],kd)].set_title(LABF[kd].capitalize() if kd!="target" else "Targets \u2014 the activity readout",loc="left",fontsize=8.6,pad=14)
for i,pw in enumerate(PWS): panel_letter(AX[(pw,"ligand")],"abcde"[i])
hb=CUR["TBXT"][3] if "TBXT" in CUR else CUR[next(iter(CUR))][3]
NP=" \u00b7 ".join(f"{k} {int((inb&(lab5==FULL7[k])).sum()):,}" for k in WANT)
fig.text(.006,.985,"Anterior\u2192posterior expression curves of every ligand, receptor, target and inhibitor of five signalling pathways \u2014 CS7, "+POPLABEL,fontsize=10.6)
fig.text(.006,.963,
 f"obj6_obj7_merged_curated_final.rds, 39Type, CS7 (obj6), curation-kept, restricted to {len(WANT)} populations ({NP}) = {int(inb.sum()):,} cells inside the AP band [{lo5:.0f}, {hi5:.0f}] \u00b5m (their 1\u201399th percentile). Every cell in the band\n"
 f"contributes to every curve. CP10K per cell, depth-adjusted by regressing on log total counts and taking residuals about the mean, then Gaussian-kernel smoothed along AP (h = {hb:.0f} \u00b5m = 0.06 \u00d7 AP span, 80 grid points); band = SEM from the effective\n"
 "sample size, drawn for the labelled genes only. In each panel the 5 highest-peaking genes are coloured and labelled at their peak; every other gene of the set is a thin grey line (values in the CSV); the dashed line in the pathway colour is the set\n"
 "mean per gene. Per-panel y-scales are independent \u2014 compare shapes within a panel, not heights across panels. Gene sets are the COMPLETE human families used in the trend figures; the columns are not disjoint (canonical inhibitors are also direct\n"
 f"targets), see `also_in` in the CSV. Curves are pooled across the {len(WANT)} populations, so a gene confined to one population traces that population's AP footprint (panel a of the trend figure).",
 fontsize=6.1,color=META_GREY,linespacing=1.5,va="top")
for e in ["png","pdf","svg"]: fig.savefig(f"{PREFIX}_gene_curves.{e}",**({"dpi":185} if e=="png" else {}),bbox_inches="tight")
fig.canvas.draw(); r_=fig.canvas.get_renderer()
tx=[(t,t.get_window_extent(r_)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
tk={t for a_ in fig.axes for t in a_.get_xticklabels()+a_.get_yticklabels()}
ov=[(a.get_text()[:14],b.get_text()[:14]) for i_,(a,ba) in enumerate(tx) for b,bb in tx[i_+1:] if ba.overlaps(bb) and not (a in tk or b in tk)]
print("text overlaps (non-tick):",len(ov),ov[:8])
pd.concat(rows,ignore_index=True).to_csv(f"{PREFIX}_gene_curves.csv",index=False)
print("genes drawn:",len(CUR),"| csv rows:",sum(len(r) for r in rows))
