# staging/00_inputs/export_tenx_tyser.R
# Source: drive G: data/milestone_evidence/out_scrna/work/export.R
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
HGC_DATA <- Sys.getenv('HGC_DATA', 'data')
HGC_OUT <- Sys.getenv('HGC_OUT', 'results')

suppressMessages({library(Seurat); library(Matrix)})
t <- readRDS(paste0(HGC_DATA, '/tyser_raw_reads.rds')); u <- readRDS(paste0(HGC_DATA, '/tyser_umap.rds'))
cat('umap X sequential:', all(u$X==0:(nrow(u)-1)), '\n')
m <- Matrix(as.matrix(t), sparse=TRUE); writeMM(m, 'tyser_counts.mtx'); writeLines(colnames(t), 'tyser_genes.txt')
write.csv(data.frame(cell=as.character(u$cell_name), cluster=as.character(u$cluster_id), label=u$sub_cluster, UMAP1=u$X0, UMAP2=u$X1, nreads=rowSums(t)), 'tyser_meta.csv', row.names=FALSE)
s <- readRDS(paste0(HGC_DATA, '/CS7ref.rds'))
cnt <- LayerData(s, assay='RNA', layer='counts'); writeMM(cnt, 'tenx_counts.mtx'); writeLines(rownames(cnt), 'tenx_genes.txt')
um <- Embeddings(s,'umap'); md <- s@meta.data
write.csv(data.frame(cell=colnames(s), Type2=as.character(md$Type2), Type=as.character(md$Type), Types=as.character(md$Types), nCount=md$nCount_RNA, UMAP1=um[,1], UMAP2=um[,2]), 'tenx_meta.csv', row.names=FALSE)
cat('done', dim(cnt), '\n')
