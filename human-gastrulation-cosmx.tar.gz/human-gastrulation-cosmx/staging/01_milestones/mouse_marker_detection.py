# staging/01_milestones/mouse_marker_detection.py
# Source: drive G: data/milestone_evidence/mz/milestones_mouse.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

import anndata as ad, numpy as np, pandas as pd
a=ad.read_h5ad((str(HGC_DATA) + '/MGA_full_atlas_116k.h5ad'),backed='r')
o=a.obs; vn=list(a.var_names)
order=['E6.5','E6.75','E7.0','E7.25','E7.5','E7.75','E8.0','E8.25','E8.5']
o2=o[o.stage.isin(order)]
cnt=pd.crosstab(o2.celltype,o2.stage)[order]
frac=(cnt/cnt.sum(0)*100).round(2)
types=['Anterior Primitive Streak','Notochord','Def. endoderm','Gut','Caudal epiblast','NMP','Rostral neurectoderm','Surface ectoderm','Somitic mesoderm','Paraxial mesoderm','Pharyngeal mesoderm','Cardiomyocytes','Haematoendothelial progenitors','Blood progenitors 1','Erythroid1','Allantois','PGC','ExE mesoderm']
print(cnt.loc[types].to_string()); print(frac.loc[types].to_string())
cnt.to_csv('mz/mouse_celltype_counts_by_stage.csv')
genes=['Noto','Foxj1','Chrd','Shh','Gsc','Lhx1','Cer1','Hoxa1','Hoxb1','Hoxb2','Hoxb8','Hoxb9','Nkx1-2','Cdx2','Cdx1','Eomes','Mesp1','T','Sox2','Nkx2-5','Hbb-bh1','Hba-x']
gi=[vn.index(g) for g in genes if g in vn]; genes=[g for g in genes if g in vn]
T={'PS':['Primitive Streak'],'Node/notochord':['Notochord'],'DE':['Def. endoderm'],'Caudal epiblast':['Caudal epiblast','NMP'],'Epiblast':['Epiblast']}
rows=[]
for k,tl in T.items():
  for s in order:
    m=np.where(o.celltype.isin(tl)&(o.stage==s))[0]
    if len(m)<20: continue
    X=a.X[m][:,gi].toarray()>0
    rows.append(dict(type=k,stage=s,n=len(m),**{g:round(100*X[:,i].mean(),1) for i,g in enumerate(genes)}))
D=pd.DataFrame(rows); D.to_csv('mz/mouse_milestone_genes.csv',index=False)
pd.set_option('display.width',300); print(D.to_string(index=False))
