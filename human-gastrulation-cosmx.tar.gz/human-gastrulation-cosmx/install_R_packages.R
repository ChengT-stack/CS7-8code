# R 4.5.x packages used by the R scripts of this repository
# Key Resources Table: R 4.5.3, Seurat 5.5.1, SeuratObject 5.4.0, harmony 2.0.5, spacexr (RCTD)
options(repos = c(CRAN = "https://cloud.r-project.org"))
cran <- c("Seurat", "SeuratObject", "Matrix", "data.table", "harmony", "remotes")
for (p in cran) if (!requireNamespace(p, quietly = TRUE)) install.packages(p)
if (!requireNamespace("spacexr", quietly = TRUE))
  remotes::install_github("dmcable/spacexr", build_vignettes = FALSE)
for (p in c(cran, "spacexr")) cat(sprintf("%-14s %s\n", p, as.character(packageVersion(p))))
