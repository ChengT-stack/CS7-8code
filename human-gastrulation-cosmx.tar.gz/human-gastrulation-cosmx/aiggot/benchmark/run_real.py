"""Run one method on the real CS7->CS8 data (full 17,663 x 31,041 cells) in its own process so that
wall time and peak RSS are per method. Usage:
  python run_real.py --method starmatch|starmatch_nopen|knn_expr|nn_space|moscot --embedding hs|hhs
                     [--shuffle SEED] [--cfg '{"mode":"fgw","epsilon":0.01,"tau_a":1.0,"tau_b":1.0,"alpha":0.5}'] [--tag NAME]
Outputs in results/real/<tag>/: parent.npy (CS8 -> CS7 index, -1 = unmatched), flow_hard.csv, [flow_soft.csv,
flow_cell_transition.csv, soft_pred_heldout.npy], heldout_genes.csv (hhs only), meta.json"""
import os, sys, time, json, argparse, resource
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
for k, v in [("KMP_AFFINITY", "disabled"), ("OMP_NUM_THREADS", "8"), ("KMP_INIT_AT_FORK", "FALSE")]: os.environ.setdefault(k, v)
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bench_common as bc

ap = argparse.ArgumentParser()
ap.add_argument("--method", required=True); ap.add_argument("--embedding", default="hs")
ap.add_argument("--shuffle", type=int, default=None); ap.add_argument("--cfg", default="{}"); ap.add_argument("--tag", default=None)
ap.add_argument("--subsample", type=float, default=None, help="stratified (per group) fraction of cells on each side, seed 0")
A = ap.parse_args()
cfg = json.loads(A.cfg)
tag = A.tag or (A.method + ("_" + "_".join(f"{k}{v}" for k, v in cfg.items()) if cfg else "") + f"_{A.embedding}" + (f"_shuf{A.shuffle}" if A.shuffle is not None else ""))
OUT = os.path.join(bc.HERE, "results", "real", tag); os.makedirs(OUT, exist_ok=True)

D = bc.load_inputs()
E7, E8 = (D["Hs7"], D["Hs8"]) if A.embedding == "hs" else (D["Hhs7"], D["Hhs8"])
E7, E8 = E7.astype(np.float64), E8.astype(np.float64)
S7, S8, g7, g8, a, b, trans = D["S7"], D["S8"], D["g7"].astype(str), D["g8"].astype(str), D["a"], D["b"], D["trans"]
R7, R8 = list(D["cs7_groups"].astype(str)), list(D["cs8_groups"].astype(str))
D["E7s_full"], D["E8s_full"] = D["E7s"], D["E8s"]
if A.subsample is not None:
    rng = np.random.default_rng(0)
    def strat(g):
        keep = []
        for grp in np.unique(g):
            idx = np.where(g == grp)[0]; keep.append(rng.choice(idx, max(1, int(round(A.subsample * len(idx)))), replace=False))
        return np.sort(np.concatenate(keep))
    k7, k8 = strat(g7), strat(g8)
    E7, E8, S7, S8, g7, g8, a, b = E7[k7], E8[k8], S7[k7], S8[k8], g7[k7], g8[k8], a[k7], b[k8]
    D["E7s"], D["E8s"] = D["E7s"][k7], D["E8s"][k8]
    np.save(os.path.join(OUT, "idx7.npy"), k7); np.save(os.path.join(OUT, "idx8.npy"), k8)
g7_used = g7.copy()
if A.shuffle is not None:
    g7_used = np.random.default_rng(A.shuffle).permutation(g7)        # labels shuffled for the METHOD; flows reported by TRUE labels
meta = dict(method=A.method, embedding=A.embedding, shuffle=A.shuffle, cfg=dict(cfg), n7=len(g7), n8=len(g8), subsample=A.subsample)
clip_dv = cfg.pop("clip_dv", None)
if clip_dv is not None:      # moscot only: clip the DV_gap_units coordinate (outliers to +-118) to avoid overflow in the GW term
    S7 = S7.copy(); S8 = S8.copy(); S7[:, 2] = np.clip(S7[:, 2], -clip_dv, clip_dv); S8[:, 2] = np.clip(S8[:, 2], -clip_dv, clip_dv)
if cfg.pop("use_starmatch_scales", False):
    import starmatch
    cfg["scale_expr"] = starmatch.knn_scale(np.vstack([E7, E8])); cfg["scale_space"] = starmatch.knn_scale(np.vstack([S7, S8]))
t0 = time.time(); extra = {}
if A.method == "starmatch":
    R = bc.run_starmatch(E7, E8, S7, S8, g7_used, g8, a, b, trans); extra = dict(sinkhorn=R["info"], summary=R["summary"], scales=R["scales"])
elif A.method == "starmatch_nopen":
    R = bc.run_starmatch(E7, E8, S7, S8, g7_used, g8, a, b, trans, pen=bc.PEN_ZERO, kc=bc.KC_UNIF); extra = dict(sinkhorn=R["info"], summary=R["summary"], scales=R["scales"])
elif A.method == "knn_expr":
    R = bc.run_knn_expr(E7, E8)
elif A.method == "nn_space":
    R = bc.run_nn_space(S7, S8)
elif A.method == "moscot":
    import bench_moscot as bm, moscot, ott, jax
    meta.update(moscot_version=moscot.__version__, ott_version=ott.__version__, jax_version=jax.__version__, jax_device=str(jax.devices()[0]))
    R = bm.run_moscot(E7, E8, S7, S8, g7_used, g8, a, b, rows=R7, cols=R8, max_iterations=cfg.pop("max_iterations", 200), **cfg)
    extra = {k: R[k] for k in ["converged", "failed", "cost", "time_solve_s", "mean_entropy", "eff_parents", "frac_unmatched8", "frac_unmatched7_mass", "n_iters"]}
    R["flow_soft"].to_csv(os.path.join(OUT, "flow_soft.csv")); R["flow_mass"].to_csv(os.path.join(OUT, "flow_mass.csv"))
    if R.get("cell_transition_fwd") is not None:
        R["cell_transition_fwd"].to_csv(os.path.join(OUT, "flow_cell_transition_fwd.csv"))
    else:
        extra["cell_transition_error"] = R.get("cell_transition_error")
    np.save(os.path.join(OUT, "colsum.npy"), R["colsum"].astype(np.float32)); np.save(os.path.join(OUT, "parent_argmax.npy"), R["parent_argmax"])
    np.save(os.path.join(OUT, "soft_pred_heldout.npy"), (R["Pn"].T @ D["E7s"]).astype(np.float32))
    if A.embedding == "hs":
        # soft (coupling-weighted) parent-coordinate expectations are not needed; keep nothing else large
        pass
else:
    raise SystemExit("unknown method")
dt = time.time() - t0
par = np.asarray(R["parent"]).astype(int)
np.save(os.path.join(OUT, "parent.npy"), par)
F = bc.flow_from_parent(par, g7, g8, R7, R8); F.to_csv(os.path.join(OUT, "flow_hard.csv"))
if A.embedding == "hhs":
    soft = (R["Pn"].T @ D["E7s"]) if A.method == "moscot" else None
    HO = bc.heldout_rho(D["E7s"], D["E8s"], par, g7, g8, soft_pred=soft); HO["gene"] = D["held"].astype(str)
    HO.round(4).to_csv(os.path.join(OUT, "heldout_genes.csv"), index=False)
    meta["heldout_median"] = {c: float(HO[c].median()) for c in HO.columns if c != "gene"}
meta.update(time_s=dt, peak_rss_gb=bc.peak_rss_gb(), n8_unmatched=int((par < 0).sum()), n7_unmatched=int(len(g7) - len(np.unique(par[par >= 0]))),
            frac_penalised=bc.class_fraction(F, trans, {"penalised"}), frac_indirect_or_penalised=bc.class_fraction(F, trans, {"indirect", "penalised"}),
            top_target_concentration=bc.top_target_concentration(F).round(4).to_dict(), **{k: (v if not isinstance(v, dict) else {kk: (float(vv) if isinstance(vv, (int, float, np.floating, np.integer)) else vv) for kk, vv in v.items()}) for k, v in extra.items()})
json.dump(meta, open(os.path.join(OUT, "meta.json"), "w"), indent=1, default=lambda o: float(o) if isinstance(o, (np.floating, np.integer)) else str(o))
print(json.dumps({k: meta[k] for k in ["method", "embedding", "time_s", "peak_rss_gb", "n8_unmatched", "n7_unmatched", "frac_penalised"] + (["heldout_median"] if "heldout_median" in meta else []) + (["converged", "eff_parents"] if "converged" in meta else [])}, default=str))
