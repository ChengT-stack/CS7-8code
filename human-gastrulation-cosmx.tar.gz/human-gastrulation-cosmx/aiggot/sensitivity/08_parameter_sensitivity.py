"""Parameter sensitivity of GG-OT + table with the FINAL Figure-7 call:
GM.match(E7, E8, S7, S8, g7, g8, a, b, trans, space="gated", prior=True) with the module defaults
(no streak gate; h = 50/50/100/30/30/50/50 um; reverse +1,000 um; mesoderm edges x0.25; 20-um grid;
eps 0.1; marginal relaxation 3; <=5 descendants; unmatched cost 4; star-size cost 0.25; 40 candidates kept).
Each row changes ONE parameter. Stability vs the default: share of CS8 cells with the same CS7 ancestor group,
and the total-variation distance of each CS7 group's CS8 composition (Figure 7b) from the default."""
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import os, sys, json, time, glob
os.environ.update(KMP_AFFINITY="disabled", OMP_NUM_THREADS="8", KMP_INIT_AT_FORK="FALSE")
import numpy as np, pandas as pd, anndata as ad
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lib"))
import ggot, ggot_match as GM
B = DATA + "/cs7_cs8_matching/"
A = ad.read_h5ad(B + "dataprep/embedding/cs7_cs8_germlayers_harmony.h5ad"); obs = A.obs
g_all = obs.label_short.astype(str).to_numpy(); emb = obs.embryo.astype(str).to_numpy()
i7 = np.where(emb == "CS7")[0]; i8 = np.where(emb == "CS8")[0]; g7 = g_all[i7]; g8 = g_all[i8]
Hs = np.load(B + "matching/harmony_smoothed.npy"); E7, E8 = Hs[i7], Hs[i8]
Sp = obs[["AP_arc_frac", "LR_frac", "DV_gap_units"]].to_numpy(float); S7, S8 = Sp[i7], Sp[i8]
a = obs.z_weight.to_numpy(float)[i7]; b = obs.z_weight.to_numpy(float)[i8]
TT = json.load(open(B + "matching/transition_table_used.json")); trans = {tuple(k.split("->")): v for k, v in TT.items()}
LO = ggot.LAYER_OF; PEN0 = dict(GM.PEN)
GROUPS = ["EPI", "ECT", "PS", "APS", "Node", "DE", "AVE", "VE1", "VE2"]

def run(prior=True, pen_scale=1.0, **kw):
    GM.PEN.clear(); GM.PEN.update({k: v * pen_scale for k, v in PEN0.items()})
    try:
        r = GM.match(E7, E8, S7, S8, g7, g8, a, b, trans, space="gated", prior=prior, **kw)
    finally:
        GM.PEN.clear(); GM.PEN.update(PEN0)
    return r["M"].tocsc()

def ancestor(M):
    par = np.full(M.shape[1], -1)
    for j in range(M.shape[1]):
        s, e = M.indptr[j], M.indptr[j + 1]
        if e > s: par[j] = M.indices[s + np.argmax(M.data[s:e])]
    return par

def comp(par):
    ok = par >= 0
    return pd.crosstab(pd.Series(g7[par[ok]], name="g7"), pd.Series(g8[ok], name="g8"), normalize="index")

def metrics(M, ref=None):
    coo = M.tocoo(); cls = np.array([trans.get((g7[i], g8[j]), "penalised") for i, j in zip(coo.row, coo.col)])
    cross = np.array([LO[g7[i]] != LO[g8[j]] for i, j in zip(coo.row, coo.col)])
    out = np.asarray(M.sum(1)).ravel(); inn = np.asarray(M.sum(0)).ravel()
    par = ancestor(M); cp = comp(par)
    res = dict(pen=(cls == "penalised").mean(), pen_cross=((cls == "penalised") & cross).mean(),
               n7_unmatched=int((out == 0).sum()), n8_matched=int((inn > 0).sum()))
    for g in GROUPS: res[f"prior_consistent_{g}"] = (cls[g7[coo.row] == g] != "penalised").mean()
    if ref is not None:
        rpar, rcp = ref; both = (par >= 0) & (rpar >= 0)
        res["same_ancestor_group"] = (g7[par[both]] == g7[rpar[both]]).mean()
        cols = sorted(set(cp.columns) | set(rcp.columns))
        tv = 0.5 * (cp.reindex(index=GROUPS, columns=cols, fill_value=0)
                    - rcp.reindex(index=GROUPS, columns=cols, fill_value=0)).abs().sum(1)
        res["composition_TV_median"] = float(tv.median()); res["composition_TV_max"] = float(tv.max())
        res["composition_TV_max_group"] = tv.idxmax()
        for g in GROUPS: res[f"TV_{g}"] = float(tv[g])
    return res, (par, cp)

t0 = time.time()
M0 = run(); m0, ref0 = metrics(M0)
print(f"default: pen {m0['pen']:.4f} cross {m0['pen_cross']:.4f} n7_unmatched {m0['n7_unmatched']} "
      f"n8_matched {m0['n8_matched']} [{time.time()-t0:.0f}s]", flush=True)
ANC = pd.read_csv(B + "figure/final_ggot/ggot_table_cs8_ancestor.csv")   # Figure-7 ancestor table (originally read from its artifact copy; identical sha256)
paf = np.full(len(i8), -1); ok = ANC.ancestor_idx >= 0
paf[ANC.cs8_idx[ok].astype(int)] = ANC.ancestor_idx[ok].astype(int)
both = (paf >= 0) & (ref0[0] >= 0)
print(f"vs Figure-7 table: same CS7 cell {np.mean(paf[both] == ref0[0][both]):.4f} | matched CS8 {m0['n8_matched']} vs 29568", flush=True)
assert abs(m0["pen"] - 0.030617) < 0.0015 and abs(m0["n7_unmatched"] - 285) <= 5, "default does not reproduce Figure 7"
CFG = [("default", {}),
       ("layer-change cost h ×0.5", dict(h_scale=0.5)), ("layer-change cost h ×2", dict(h_scale=2.0)),
       ("reverse penalty +500 µm", dict(reverse=500.0)), ("reverse penalty +2,000 µm", dict(reverse=2000.0)),
       ("mesoderm edge weight 0.5", dict(layer_cost={"M": 0.5})), ("mesoderm edge weight 1.0", dict(layer_cost={"M": 1.0})),
       ("grid 15 µm", dict(grid_step=15.0)), ("grid 30 µm", dict(grid_step=30.0)),
       ("table penalty ×0.5", dict(pen_scale=0.5)), ("table penalty ×2", dict(pen_scale=2.0)),
       ("entropy ε 0.05", dict(eps=0.05)), ("entropy ε 0.2", dict(eps=0.2)),
       ("marginal relaxation 1", dict(tau_sk=1.0)), ("marginal relaxation 10", dict(tau_sk=10.0)),
       ("max descendants 4", dict(K=4)), ("max descendants 6", dict(K=6)),
       ("unmatched cost 3", dict(c_unmatched=3.0)), ("unmatched cost 6", dict(c_unmatched=6.0)),
       ("star-size cost 0.5", dict(delta=0.5)), ("candidates kept 20", dict(k_keep=20)), ("candidates kept 60", dict(k_keep=60))]
ROWS = []
for name, kw in CFG:
    t1 = time.time(); M = M0 if name == "default" else run(**kw)
    r, _ = metrics(M, ref0); ROWS.append(dict(config=name, **r))
    print(f"{name:28s} pen {r['pen']:.3f} cross {r['pen_cross']:.3f} unm7 {r['n7_unmatched']:5d} "
          f"same-anc {r['same_ancestor_group']:.3f} TVmed {r['composition_TV_median']:.3f} "
          f"TVmax {r['composition_TV_max']:.3f} ({r['composition_TV_max_group']}) [{time.time()-t1:.0f}s]", flush=True)
    pd.DataFrame(ROWS).to_csv("ggot_sensitivity_final.csv", index=False)
print("done", round(time.time() - t0), "s")
