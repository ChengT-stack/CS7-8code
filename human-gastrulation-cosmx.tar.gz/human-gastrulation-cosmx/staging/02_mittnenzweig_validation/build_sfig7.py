# staging/02_mittnenzweig_validation/build_sfig7.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/figure6/SuppFig8/build_supp8.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
import os
from matplotlib import font_manager as fm
FD=os.environ.get("HGC_FONTS", "fonts") + "/"
for f in ["arial.ttf","arialbd.ttf","ariali.ttf","arialbi.ttf"]:
    if os.path.exists(FD+f): fm.fontManager.addfont(FD+f)
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from scipy.stats import spearmanr

# Load data
MC = pd.read_csv((str(HGC_DATA) + '/mouse_reference_curves.csv'))
C = pd.read_csv((str(HGC_DATA) + '/calls.csv'))
Dm = pd.read_csv((str(HGC_DATA) + '/mz_cells_markers.csv.gz'))

# Figure style setup
mpl.rcParams.update({
    'font.size': 7,
    'axes.labelsize': 7,
    'axes.titlesize': 7,
    'xtick.labelsize': 6,
    'ytick.labelsize': 6,
    'legend.fontsize': 6,
    'figure.dpi': 100,
    'font.family': 'sans-serif', 'font.sans-serif': ['Arial','DejaVu Sans'],
    'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'mathtext.fontset': 'custom', 'mathtext.rm': 'Arial', 'mathtext.it': 'Arial:italic',
})

def apply_figure_style(sizes=(8, 7, 6)):
    mpl.rcParams['font.size'] = sizes[1]
    mpl.rcParams['axes.labelsize'] = sizes[1]
    mpl.rcParams['axes.titlesize'] = sizes[1]
    mpl.rcParams['xtick.labelsize'] = sizes[2]
    mpl.rcParams['ytick.labelsize'] = sizes[2]
    mpl.rcParams['legend.fontsize'] = sizes[2]

def panel_letter(ax, letter, dx=-0.18, dy=1.05):
    ax.text(dx, dy, letter, transform=ax.transAxes, fontsize=9, fontweight='bold', va='top', ha='left')

apply_figure_style(sizes=(7, 6.5, 5.5))

# Constants
MID = [f'm{i+1:02d}' for i in range(19)]
SN = [6.5, 6.75, 7.0, 7.25, 7.5, 7.75, 8.0, 8.25, 8.5]
STG = ['E6.5', 'E6.75', 'E7.0', 'E7.25', 'E7.5', 'E7.75', 'E8.0', 'E8.25', 'E8.5']
grid = np.array(SN)

# Build LBL from calls.csv
LBL = dict(zip(MID, C.milestone.tolist()[:19]))

# Build dom and ons from calls.csv
dom = dict(zip(MID, C.domain.tolist()[:19]))
ons = dict(zip(MID, C.mouse_onset.tolist()[:19]))

# Build curves from mouse_reference_curves.csv
curves = {}
KIND = {}
PS = {}
for mid in MID:
    sub = MC[MC.milestone_id == mid]
    if len(sub) == 0:
        continue
    kind = sub.kind.iloc[0]
    KIND[mid] = kind
    vals = sub.set_index('stage').reindex(STG)['value'].values.astype(float)
    PS[mid] = pd.Series(vals, index=SN)
    metric = sub.metric.iloc[0]
    curves[mid] = (metric, vals, kind)

PS_df = pd.DataFrame(PS)

# Extra-embryonic types
EXM = ['Amnion/Chorion', 'ExE endoderm', 'Visceral endoderm', 'ExE mesoderm',
       'Allantois', 'Haematoendothelial progenitors', 'Blood progenitors',
       'Erythroid 1', 'Erythroid 2', 'PGC']

DISC = [m for m in MID if dom[m] == 'disc']
EARLY = ['m01', 'm02', 'm03', 'm04', 'm05']
LATE = ['m06', 'm07', 'm08', 'm09', 'm10', 'm11', 'm12', 'm13', 'm14']

def onset_g(x, v, kind):
    x = np.array(x, float)
    v = np.array(v, float)
    ok = ~np.isnan(v)
    x, v = x[ok], v[ok]
    if len(v) == 0 or np.nanmax(v) <= 0:
        return np.nan, np.nan
    if kind == 'onset':
        thr = 0.25 * v.max()
        i = int(np.argmax(v >= thr))
        return ((x[i] + x[i-1]) / 2 if i > 0 else x[0] - 0.125), thr
    pk = int(np.argmax(v))
    thr = 0.75 * v[pk]
    for i in range(pk + 1, len(v)):
        if v[i] < thr:
            return (x[i] + x[i-1]) / 2, thr
    return np.nan, thr

# Compute onset times
O8_rows = []
for mid in MID:
    if mid not in PS:
        continue
    pv = PS_df[mid] if mid in PS_df.columns else pd.Series([np.nan]*len(SN), index=SN)
    kind = KIND.get(mid, 'onset')
    p_sub = pv[pv.index <= 8.0]
    ps_on, _ = onset_g(p_sub.index, p_sub.values, kind)
    O8_rows.append(dict(milestone_id=mid, PS_onset=ps_on, domain=dom.get(mid, ''), kind=kind))

ON_base = pd.DataFrame(O8_rows)

# Compute MZ onset times
Dm['tbin'] = np.round(Dm.transcriptional_time * 4) / 4

def metrics(df, minn=10):
    ct = df.author_cell_type.values
    pos = lambda g: (df[g].values > 0) if g in df.columns else np.zeros(len(df), bool)
    prop = ~np.isin(ct, EXM)
    n = len(df)
    npr = prop.sum()
    def frac(types, den): return 100 * np.isin(ct, types).sum() / max(den, 1)
    def det(types, gene):
        m = np.isin(ct, types)
        return 100 * pos(gene)[m].mean() if m.sum() >= minn else np.nan
    de = ct == 'Definitive endoderm'
    r = {}
    r['m01'] = frac(['Early nascent mesoderm'], npr)
    r['m02'] = frac(['Anterior Primitive Streak'], npr)
    r['m03'] = 100 * (np.isin(ct, ['Primitive streak', 'Node/Notochord', 'Definitive endoderm']) & pos('Foxj1') & pos('Chrd')).sum() / max(npr, 1)
    r['m04'] = frac(['Definitive endoderm'], n)
    r['m05'] = 100 * (de & pos('Gsc') & pos('Cer1')).sum() / max(npr, 1)
    r['m06'] = det(['Definitive endoderm'], 'Gsc')
    r['m07'] = frac(['Node/Notochord'], n)
    a, b = det(['Primitive streak'], 'Hoxa1'), det(['Primitive streak'], 'Hoxb1')
    r['m08'] = np.nanmax([a, b]) if not (np.isnan(a) and np.isnan(b)) else np.nan
    r['m09'] = frac(['Caudal epiblast'], n)
    r['m10'] = frac(['Rostral neural plate'], n)
    r['m11'] = frac(['Paraxial mesoderm'], n)
    r['m12'] = det(['Primitive streak'], 'Eomes')
    r['m13'] = det(['Caudal epiblast'], 'Hoxb8')
    r['m14'] = frac(['Cardiomyocytes'], n)
    r['m15'] = frac(['PGC'], n)
    r['m16'] = frac(['Haematoendothelial progenitors'], n)
    r['m17'] = frac(['ExE mesoderm'], n)
    r['m18'] = frac(['Allantois'], n)
    r['m19'] = frac(['Erythroid 1'], n)
    r['n'] = n
    return r

MZc = pd.DataFrame({b: metrics(g) for b, g in Dm.groupby('tbin')}).T

# Compute MZ onset times
O8_rows2 = []
mzx = MZc.index.values
for mid in MID:
    if mid not in MZc.columns:
        O8_rows2.append(dict(milestone_id=mid, MZ_onset=np.nan, diff_days=np.nan))
        continue
    kind = KIND.get(mid, 'onset')
    q = MZc[(MZc.index <= 8.0)][mid]
    mz_on, _ = onset_g(q.index, q.values, kind)
    O8_rows2.append(dict(milestone_id=mid, MZ_onset=mz_on))

O8_mz = pd.DataFrame(O8_rows2)
O8 = ON_base.merge(O8_mz, on='milestone_id')
O8['PS_onset'] = O8.milestone_id.map(ons)  # use the audited onsets of Figure 6A
O8['diff_days'] = O8['MZ_onset'] - O8['PS_onset']

# Thresholds
thr_PS = {}
for mid in MID:
    if mid in PS_df.columns:
        p = PS_df[mid]
        _, thr = onset_g(p.index, p.values, KIND.get(mid, 'onset'))
        thr_PS[mid] = thr
    else:
        thr_PS[mid] = np.nan

thr_MZ = {}
for mid in MID:
    if mid in MZc.columns:
        q = MZc[MZc.index <= 8.0][mid]
        _, thr = onset_g(q.index, q.values, KIND.get(mid, 'onset'))
        thr_MZ[mid] = thr
    else:
        thr_MZ[mid] = np.nan

def call_embryo(r, thr):
    c = {}
    for m in DISC:
        v = r[m]
        if np.isnan(v) or np.isnan(thr.get(m, np.nan)):
            c[m] = 'na'
            continue
        ok = (v < thr[m]) if KIND.get(m, 'onset') == 'loss' else (v >= thr[m])
        c[m] = 'R' if ok else 'N'
    if any(c[m] == 'R' for m in LATE if m not in ('m06', 'm12')):
        for m in EARLY:
            if c[m] == 'N':
                c[m] = 'R*'
    if c.get('m06') == 'R' and not any(c.get(m) in ('R', 'R*') for m in ['m04', 'm05']):
        c['m06'] = 'N'
    if c.get('m12') == 'R' and not any(c.get(m) == 'R' for m in ['m07', 'm08', 'm09', 'm10', 'm11', 'm13', 'm14']):
        c['m12'] = 'N'
    return c

def win(c):
    R_ = [ons[m] for m in DISC if c.get(m) in ('R', 'R*')]
    N_ = [ons[m] for m in DISC if c.get(m) == 'N']
    lo = max(R_) if R_ else 6.5
    hi = min(N_) if N_ else np.inf
    tied = lo >= hi
    if tied:
        j = np.searchsorted(grid, lo)
        lo, hi = grid[j-1], grid[j]
    return lo, hi, tied

ER = []
for e, g in Dm.groupby('embryo_id'):
    r = metrics(g)
    t = g.transcriptional_time.iloc[0]
    for nm, thr in [('PS_absolute', thr_PS), ('MZ_calibrated', thr_MZ)]:
        c = call_embryo(r, thr)
        lo, hi, tied = win(c)
        mid_val = lo + 0.125 if np.isinf(hi) else (lo + hi) / 2
        row = dict(embryo=e, n=len(g), t=t, dpc=g.dpc.iloc[0],
                   stage=g.stage.iloc[0], strain=g.strain.iloc[0],
                   thr=nm, lo=lo, hi=hi, tied=tied, mid=mid_val,
                   **{f'c_{m}': c.get(m, 'na') for m in DISC},
                   **{f'v_{m}': r.get(m, np.nan) for m in MID})
        ER.append(row)

ER = pd.DataFrame(ER)
ER['err'] = ER.mid - ER.t
ER['inwin'] = [(r.lo - 1e-9 <= r.t <= r.hi + 1e-9) for r in ER.itertuples()]
ER['within_tol'] = [(r.lo - 0.125 - 1e-9 <= r.t <= r.hi + 0.125 + 1e-9) for r in ER.itertuples()]
ER['tb'] = np.round(ER.t * 4) / 4

# Compute ACC
acc = []
for nm in ['PS_absolute', 'MZ_calibrated']:
    d = ER[ER.thr == nm]
    for m in DISC:
        on = ons[m]
        c = d[f'c_{m}']
        ok = c != 'na'
        exp = np.where(d.t > on + 0.125, 'R', np.where(d.t < on - 0.125, 'N', 'amb'))
        sel = ok & (exp != 'amb')
        obs = np.where(c.isin(['R', 'R*']), 'R', 'N')
        a = (obs[sel] == exp[sel]).mean()
        early = ((obs == 'R') & (exp == 'N') & sel).sum()
        late = ((obs == 'N') & (exp == 'R') & sel).sum()
        acc.append(dict(thresholds=nm, milestone_id=m, milestone=LBL.get(m, m),
                        onset=on, n_scored=int(sel.sum()), n_na=int((~ok).sum()),
                        agreement=100*a, called_reached_too_early=int(early),
                        called_not_reached_too_late=int(late)))
ACC = pd.DataFrame(acc)

SUM = []
for nm in ['PS_absolute', 'MZ_calibrated']:
    for nmin in [0, 150, 300]:
        d = ER[(ER.thr == nm) & (ER.n >= nmin)]
        f = d[np.isfinite(d.hi)]
        SUM.append(dict(thresholds=nm, min_cells=nmin, embryos=len(d),
                        in_window=100*d.inwin.mean(),
                        within_0125=100*d.within_tol.mean(),
                        spearman_mid_vs_t=spearmanr(f.mid, f.t)[0] if len(f) > 1 else np.nan,
                        MAE_days=f.err.abs().mean() if len(f) > 0 else np.nan,
                        bias_days=f.err.mean() if len(f) > 0 else np.nan,
                        open_ended=int((~np.isfinite(d.hi)).sum()),
                        open_ended_correct=int(((~np.isfinite(d.hi)) & d.inwin).sum())))
SUM = pd.DataFrame(SUM)

SHT = {
    'm01': 'Nascent meso', 'm02': 'APS', 'm03': 'Node-like', 'm04': 'DE',
    'm05': 'ADE', 'm06': 'ADE regresses', 'm07': 'Notochord',
    'm08': "3′ HOX in PS", 'm09': 'Caudal epiblast', 'm10': 'Neural plate',
    'm11': 'Paraxial meso', 'm12': 'EOMES off', 'm13': "5′ HOX (Hoxb8)",
    'm14': 'Cardiomyocytes', 'm15': 'PGC', 'm16': 'Haemato-endo',
    'm17': 'ExE meso', 'm18': 'Allantois', 'm19': 'Erythroid'
}

# Build figure
plt.close('all')
apply_figure_style(sizes=(7, 6.5, 5.5))

fig = plt.figure(figsize=(7.2, 8.75))
gs = fig.add_gridspec(2, 1, height_ratios=[2.35, 1.05], hspace=0.3,
                      left=0.105, right=0.985, top=0.9168, bottom=0.0816)
g1 = gs[0].subgridspec(1, 2, width_ratios=[1, 1.85], wspace=0.2)
gL = g1[0].subgridspec(2, 1, height_ratios=[1, 1.12], hspace=0.42)

# Panel A: onset comparison
ax = fig.add_subplot(gL[0]); ax.set_anchor('W')
d = O8.dropna(subset=['MZ_onset'])
ax.fill_between([6.4, 8.1], [6.15, 7.85], [6.65, 8.35], color='#eeeeee', lw=0)
ax.plot([6.4, 8.1], [6.4, 8.1], color='k', lw=0.6)
from collections import defaultdict
seen = defaultdict(int)
OFFL = {}
for r in d.itertuples():
    k = (r.PS_onset, r.MZ_onset)
    j = seen[k]
    seen[k] += 1
    col = '#2b6cb0' if r.domain == 'disc' else '#b5853a'
    x = r.PS_onset + (j - 1.5) * 0.03
    ax.plot(x, r.MZ_onset, 'o', ms=3.5, color=col, mec='white', mew=0.3)
    if abs(r.diff_days) >= 0.5 - 1e-9:
        OFFL.setdefault(k, []).append((x, SHT[r.milestone_id]))
for k_, v_ in OFFL.items():
    ax.annotate(', '.join(t for _, t in v_), (min(x_ for x_, _ in v_), k_[1]), xytext=(-3, 4), textcoords='offset points', fontsize=5.5, ha='left', va='bottom', linespacing=1.0)
ax.set_xlim(6.45, 8.05)
ax.set_ylim(6.45, 8.05)
ax.set_aspect('equal')
ax.set_xlabel('onset in Pijuan-Sala 2019 (E)')
ax.set_ylabel('onset in Mittnenzweig 2021 (E)')
ax.set_title('Milestone onset times', loc='left')
n_ = len(d)
sp_val = spearmanr(d.PS_onset, d.MZ_onset)[0]
mean_abs = d.diff_days.abs().mean()
n_ident = int((d.diff_days.abs() < 1e-9).sum())
n_025 = int((d.diff_days.abs() <= 0.25 + 1e-9).sum())
ax.text(6.5, 7.98,
        f'{n_} milestones (EOMES-off not estimable)\nSpearman ρ = {sp_val:.2f}\nmean |Δ| = {mean_abs:.2f} d\nidentical {n_ident}/{n_}; within ±0.25 d {n_025}/{n_}',
        fontsize=5.5, va='top')
ax.legend([Line2D([], [], marker='o', ls='', color='#2b6cb0'),
           Line2D([], [], marker='o', ls='', color='#b5853a'),
           Rectangle((0, 0), 1, 1, fc='#eeeeee')],
          ['embryonic disc', 'extra-embryonic', '±0.25 d'],
          fontsize=5.5, frameon=False, loc='lower right')
panel_letter(ax, 'A')

# Panel C: agreement
ax = fig.add_subplot(gL[1])
A1 = ACC[ACC.thresholds == 'PS_absolute'].set_index('milestone_id')
A2 = ACC[ACC.thresholds == 'MZ_calibrated'].set_index('milestone_id')
y = np.arange(len(DISC))
ax.barh(y - 0.2, A1.loc[DISC, 'agreement'], height=0.38, color='#2b6cb0',
        label='Pijuan-Sala thresholds')
ax.barh(y + 0.2, A2.loc[DISC, 'agreement'], height=0.38, color='#9ecae1',
        label='Mittnenzweig-calibrated')
for yy, m in zip(y, DISC):
    ax.text(101, yy, f'n={A1.loc[m, "n_scored"]}', fontsize=5, va='center')
ax.set_yticks(y)
ax.set_yticklabels([SHT[m] for m in DISC])
ax.invert_yaxis()
ax.set_xlim(0, 118)
ax.set_xticks([0, 25, 50, 75, 100])
ax.set_xlabel('% embryos whose call matches their time')
ax.set_title('Per-milestone agreement (153 embryos)', loc='left')
ax.legend(fontsize=5.5, frameon=False, loc='upper center',
          bbox_to_anchor=(0.4, -0.17), ncol=2, handlelength=1)
panel_letter(ax, 'C')

# Panel C: small multiples
g2 = g1[1].subgridspec(5, 4, hspace=0.75, wspace=0.32)
mzx = MZc.index.values
axC0 = None
for k, m in enumerate(MID):
    ax = fig.add_subplot(g2[k//4, k%4])
    if k == 18:
        axC0 = ax
    if m in PS_df.columns:
        pv = PS_df[m].values
        pmx = np.nanmax(pv)
        if pmx > 0:
            ax.plot(SN, pv / pmx, '-o', ms=1.6, lw=0.8, color='#333333')
        else:
            ax.plot(SN, pv, '-o', ms=1.6, lw=0.8, color='#333333')
    if m in MZc.columns:
        mv = MZc[m].values.astype(float)
        mmx = np.nanmax(mv)
        if mmx > 0:
            ax.plot(mzx, mv / mmx, '-o', ms=1.6, lw=0.8, color='#d95f02')
        else:
            ax.plot(mzx, mv, '-o', ms=1.6, lw=0.8, color='#d95f02')
    row = O8[O8.milestone_id == m]
    if len(row) > 0:
        a = row.iloc[0]
        ax.axvline(a.PS_onset, color='#333333', lw=0.5, ls=':')
        if not np.isnan(a.MZ_onset):
            ax.axvline(a.MZ_onset, color='#d95f02', lw=0.5, ls=':')
    ax.set_xlim(6.4, 8.6)
    ax.set_ylim(-0.05, 1.12)
    ax.set_xticks([6.5, 7.5, 8.5])
    ax.set_yticks([0, 1])
    ax.tick_params(labelsize=5)
    color = '#2b6cb0' if dom.get(m, '') == 'disc' else '#b5853a'
    ax.set_title(f'{m} {SHT[m]}', fontsize=5.8, pad=2, color=color)
    if k == 0:
        panel_letter(ax, 'B', dx=-0.42, dy=1.3)

axC0.legend(
    [Line2D([], [], color='#333333', marker='o', ms=2, lw=0.8),
     Line2D([], [], color='#d95f02', marker='o', ms=2, lw=0.8),
     Line2D([], [], color='grey', ls=':', lw=0.8)],
    ['Pijuan-Sala 2019\n(10x, by stage)',
     'Mittnenzweig 2021\n(MARS-seq, by\ntranscriptional time)',
     'onset (25% of max\n/ 75% of peak)'],
    ncol=1, fontsize=5.5, frameon=False, loc='center left', bbox_to_anchor=(1.12, 0.5), labelspacing=0.9, handlelength=1.6)

# Panel D: staging
g4 = gs[1].subgridspec(1, 2, width_ratios=[1.3, 1], wspace=0.3)
ax = fig.add_subplot(g4[0])
d = ER[ER.thr == 'PS_absolute'].sort_values('t')
for r in d.itertuples():
    hi = min(r.hi, 8.25)
    col = '#2b6cb0' if r.inwin else ('#9ecae1' if r.within_tol else '#c0392b')
    ax.plot([r.t, r.t], [r.lo, hi], color=col, lw=1.0, alpha=0.85, solid_capstyle='butt')
    if np.isinf(r.hi):
        ax.plot(r.t, 8.25, marker='^', ms=2.5, color=col)
ax.plot([6.4, 8.15], [6.4, 8.15], color='k', lw=0.6)
ax.set_xlim(6.38, 8.16)
ax.set_ylim(6.4, 8.35)
ax.set_xlabel('Mittnenzweig transcriptional time of the embryo (E)')
ax.set_ylabel('milestone window (E)')
s_row = SUM[(SUM.thresholds == 'PS_absolute') & (SUM.min_cells == 0)].iloc[0]
ax.set_title(
    f'Each embryo staged with the Pijuan-Sala milestone axis (n = 153):\n'
    f'window midpoint vs time ρ = {s_row.spearman_mid_vs_t:.2f}, '
    f'mean |error| = {s_row.MAE_days:.2f} d ({s_row.MAE_days*24:.1f} h), '
    f'bias {s_row.bias_days:+.2f} d',
    loc='left', fontsize=6.3)
ax.legend(
    [Line2D([], [], color='#2b6cb0', lw=2),
     Line2D([], [], color='#9ecae1', lw=2),
     Line2D([], [], color='#c0392b', lw=2),
     Line2D([], [], marker='^', ls='', color='#555555', ms=3)],
    [f'time inside window ({s_row.in_window:.0f}%)',
     f'within 0.125 d of window ({s_row.within_0125 - s_row.in_window:.0f}%)',
     f'further off ({100 - s_row.within_0125:.0f}%)',
     'open-ended window (≥)'],
    fontsize=5.5, frameon=False, loc='upper left')
panel_letter(ax, 'D', dx=-0.13, dy=1.2)

# Panel E: LEFTY1/LEFTY2 in human vs mouse streak/organiser (former Figure 7D)
import pandas as _pd
EE = _pd.read_csv('SuppFig8E_LEFTY_detection.csv', header=[0, 1], index_col=0)
axE = fig.add_subplot(g4[1])
MxE = EE.values.astype(float)
axE.imshow(np.nan_to_num(MxE, nan=0), cmap='Blues', vmin=0, vmax=100, aspect='auto')
for i in range(MxE.shape[0]):
    for j in range(MxE.shape[1]):
        v = MxE[i, j]
        if np.isnan(v):
            axE.add_patch(Rectangle((j - 0.5, i - 0.5), 1, 1, fc='#E0E0E0', ec='none'))
            axE.text(j, i, 'n.p.', ha='center', va='center', fontsize=4.8, color='#444')
        else:
            axE.text(j, i, f'{v:.0f}', ha='center', va='center', fontsize=5, color='white' if v > 55 else 'black')
axE.set_yticks(range(MxE.shape[0])); axE.set_yticklabels(list(EE.index), fontstyle='italic', fontsize=6)
axE.set_xticks(range(MxE.shape[1])); axE.set_xticklabels([c for _, c in EE.columns], fontsize=5.2, rotation=90)
axE.tick_params(axis='both', length=0, pad=2)
grp = [g for g, _ in EE.columns]
bounds = [k for k in range(1, len(grp)) if grp[k] != grp[k - 1]]
for b in bounds: axE.axvline(b - 0.5, c='white' if grp[b].split()[0] == grp[b - 1].split()[0] else 'k', lw=1.2 if grp[b].split()[0] == grp[b - 1].split()[0] else 0.7)
for x in [1.5, 3.5]: axE.axvline(x, c='white', lw=1.2)
hdrE = {}
for k, g in enumerate(grp): hdrE.setdefault(g, []).append(k)
shortE = {'Human CS7': 'Human CS7', 'Human CS8': 'CS8', 'Mouse organiser': 'Mouse organiser', 'Mouse APS': 'Mouse', 'CosMx control': 'Ctrl'}
for g in ['Mouse APS', 'CosMx control']: pass
for g, ks in hdrE.items():
    a_, b_ = min(ks), max(ks)
    axE.plot([a_ - 0.4, b_ + 0.4], [-0.66, -0.66], c='k', lw=0.6, clip_on=False)
    axE.text((a_ + b_) / 2, -0.74, shortE[g], ha='center', va='bottom', fontsize=5.0 if a_ == b_ else 5.2, clip_on=False)
axE.set_ylim(MxE.shape[0] - 0.5, -0.5)
for sp_ in axE.spines.values(): sp_.set_visible(False)
axE.set_title('Streak feedback: LEFTY2 in human, Lefty1 in mouse\n% cells (spots) with ≥1 transcript', loc='left', pad=16, fontsize=6.3)
panel_letter(axE, 'E', dx=-0.2, dy=1.2)

fig.text(0.012, 1 - 0.12 / 8.75, "Supplementary Figure 8", fontsize=10, fontweight="bold", ha="left", va="top")
os.makedirs("supp_mz", exist_ok=True)
O8.to_csv("supp_mz/SuppFig8A_onsets.csv", index=False); ACC.to_csv("supp_mz/SuppFig8C_agreement.csv", index=False); SUM.to_csv("supp_mz/SuppFig8D_summary.csv", index=False)
fig.canvas.draw()
for ext in ("png","pdf","svg"):
    fig.savefig(f"supp_mz/FigS_Mittnenzweig_milestone_validation.{ext}", dpi=600 if ext=="png" else None)
fig.savefig("supp_mz/FigS_Mittnenzweig_milestone_validation.ai", format="pdf")
