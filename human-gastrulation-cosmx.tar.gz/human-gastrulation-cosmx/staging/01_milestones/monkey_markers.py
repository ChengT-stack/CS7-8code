# staging/01_milestones/monkey_markers.py
# Source: drive G: data/milestone_evidence/mz/monkey/markers.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

import numpy as np, pandas as pd, scipy.sparse as sp
D=(str(HGC_DATA) + '/GSE193007/')
z=np.load(D+'counts_recovered_int.npz'); X=sp.csr_matrix((z['data'],z['indices'],z['indptr']),shape=tuple(z['shape']))
g=pd.read_csv(D+'genes.csv').iloc[:,0].astype(str).values; m=pd.read_csv(D+'MFE56636-meta.csv')
print('T' in set(g), 'TBXT' in set(g))
G=["MESP1","TBX6","GSC","FOXA2","FOXJ1","CHRD","NOTO","SHH","SOX17","CER1","HOXA1","HOXB1","NKX1-2","CDX2","HOXB8","HESX1","SIX3","MEOX1","TCF15","EOMES","T","NKX2-5","TNNT2","MYL7","NANOS3","DPPA3","TFAP2C","PRDM1","ETV2","KDR","HAND1","TBX4","HOXA10","HBZ","HBE1","GATA1"]
G=[x for x in G if x in set(g)]; gi=[int(np.where(g==x)[0][0]) for x in G]
B=pd.DataFrame((X[:,gi].toarray()>0).astype(np.int8),columns=G); B=B.rename(columns={'T':'TBXT'})
B['sample']=m['sample'].values; B['ct']=m.cell_type.values; B['doublet']=m.doublet.values; B['nCount']=np.asarray(X.sum(1)).ravel()
B=B[B.doublet==0]
B.to_parquet('mz/monkey/monkey_marker_binary.parquet')
pct=B.groupby(['sample','ct'])[[c for c in B.columns if c not in ('sample','ct','doublet','nCount')]].mean().mul(100).round(1)
pct.insert(0,'n',B.groupby(['sample','ct']).size())
pct.to_csv('mz/monkey/monkey_detection_by_sample_celltype.csv')
print(B.groupby(['sample']).size().to_string())
print(pd.crosstab(B.ct,B['sample']).to_string())
