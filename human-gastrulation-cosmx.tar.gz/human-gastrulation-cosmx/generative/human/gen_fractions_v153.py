# Human CS7->CS8 states at 12 fractions with the 153-embryo rotation-0 V1a generator (5 seeds) = the model behind bridge.npz AI / Figure 6.
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
GEN_ROOT = os.environ.get('HGC_GEN_ROOT', '.')   # generative working directory (original ai_t05_v153 layout)
import os, numpy as np, torch
os.chdir(GEN_ROOT)
exec(open('out_gencv/gencv_lib.py').read())
H = np.load(OG + 'rot0_human_t05_latent.npz')
fr_grid = np.round(np.linspace(0, 1, 12), 4); out = []
for s in range(5):
    net = NetF(d, CFG['h'], CFG['L'], CFG['drop'], CFG['sig_init']).to(dev)
    net.load_state_dict(torch.load(OG + f'weights/rot0_V1a_seed{s}.pt', map_location=dev)); net.eval()
    g05 = gen_human(net, s, 0.5).cpu().numpy(); print('seed', s, 'max|gen(0.5)-saved|', float(np.abs(g05 - H['gen_V1a'][s]).max()), flush=True)
    out.append(np.stack([gen_human(net, s, float(f)).cpu().numpy().astype(np.float32) for f in fr_grid]))
np.savez_compressed(DATA + '/ai_t05/out_trajectory/human_traj_12fr_v153.npz', gen=np.stack(out), fr=fr_grid, h_a=H['h_a'])
print('saved', np.stack(out).shape)
