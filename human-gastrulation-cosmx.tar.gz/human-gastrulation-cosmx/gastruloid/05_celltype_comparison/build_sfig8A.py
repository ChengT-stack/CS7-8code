# gastruloid/05_celltype_comparison/build_sfig8A.py
# Source: artifact build_sf8A_human_only.py (version b6231863; session 824ef1ce, 2026-11-17)
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))


# Supplementary gastruloid staging panel A, human samples only (mouse datasets Rossi 2021 and Veenvliet 2020 removed).
import sys, glob, shutil, numpy as np, pandas as pd, matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt, matplotlib.font_manager as fm
from matplotlib.patches import Rectangle, Patch
from matplotlib.lines import Line2D
LGS_path, R_path, INFO_path, ORDER_path, ASSESS_path, OUT = sys.argv[1:7]
for f_ in glob.glob(os.environ.get('HGC_FONTS', 'fonts') + '/arial*.ttf'): fm.fontManager.addfont(f_)
mpl.rcParams.update({'font.family': 'Arial', 'pdf.fonttype': 42, 'svg.fonttype': 'none', 'font.size': 6, 'xtick.labelsize': 6, 'ytick.labelsize': 6})
LGS = pd.read_csv(LGS_path); R = pd.read_csv(R_path).fillna('').set_index('unit'); INFO = pd.read_csv(INFO_path, index_col=0)
src = open(ASSESS_path).read(); exec(src[src.index('SHORT = {'):src.index('assert all(g in SL')])
ALL = list(pd.read_csv(ORDER_path, index_col=0).index); assert len(ALL) == 31
UNITS = [u for u in ALL if INFO.species[u] == 'human']
REMOVED = [u for u in ALL if u not in UNITS]
EMBS = ['Human embryo CS7 (CosMx)', 'Human embryo CS8 (CosMx)']; meta = LGS.drop_duplicates('milestone_id').set_index('milestone_id')
SO = ['A', 'B', 'C', 'unused']; MSO = [m for k in SO for m in sorted(meta.index[meta.milestone_set == k])]; SETL = {'A': 'CS7 and CS8', 'B': 'CS8 only', 'C': 'neither', 'unused': 'no clear call'}
ABBR = {'m01': 'Nas.Meso: Mesp1+ onset', 'm02': 'APS: Gsc+Foxa2+ onset', 'm03': 'Node: Foxj1+Chrd+ onset', 'm04': 'DE: Foxa2+Sox17+ onset', 'm05': 'AVE: Gsc+Cer1+ onset',
        'm06': 'AVE: Gsc regression', 'm07': 'Notochord: Noto+ onset', 'm08': 'PS: Hoxa1+/Hoxb1+ onset', 'm09': 'CLE: Nkx1-2+Cdx2+ onset', 'm10': 'NP: Hesx1+Six3+ onset',
        'm11': 'Para.Meso: Meox1+Tcf15+ onset', 'm12': 'PS: Eomes loss', 'm13': 'CLE: Hoxb8+ onset', 'm14': 'CM: Nkx2-5+Tnnt2+ onset'}
assert set(MSO) == set(ABBR), sorted(set(MSO) ^ set(ABBR))
COL = {'reached': '#1F5FA8', 'present below onset frequency': '#9CC3E6', 'expected, not reached': '#D55E00', 'not testable': '#BDBDBD'}
MUT = {'not used: reached': '#C7D8EC', 'not used: partial': '#E4ECF6', 'not used: not testable': '#EDEDED'}
SCOL = {'CS7-like': '#CBC9E2', 'CS7-to-CS8 transitional': '#9E9AC8', 'CS8-like': '#6A51A3', 'beyond CS8': '#3F007D', 'not stageable': '#FFFFFF'}; SLAB = {'CS7-to-CS8 transitional': 'CS7–CS8 transitional'}
GAPS = {'B': 0.6, 'C': 0.6, 'unused': 1.2}; mp = {}; cur = 0.0; sl, sr = {}, {}
for k in SO:
    cur += GAPS.get(k, 0); sl[k] = cur
    for m in MSO:
        if meta.milestone_set[m] == k: mp[m] = cur; cur += 1
    sr[k] = cur
MT = cur; rows = [(u, 'embryo') for u in EMBS] + [(g, INFO.dataset[g]) for g in UNITS]; sp_ = {}; cur = 0.0; prev = None
for u, d in rows:
    if prev is not None and d != prev: cur += 0.45 if prev != 'embryo' else 0.8
    sp_[u] = cur; cur += 1; prev = d
ST = cur; BAR = {'CS7 set': sr['A'] + 0.3, 'CS8-only set': sr['B'] + 0.3}; DS = list(dict.fromkeys(d for u, d in rows[2:]))
HS = [Patch(fc=COL['reached'], label='reached'), Patch(fc=COL['present below onset frequency'], label='present, below the onset frequency'), Patch(fc=COL['expected, not reached'], label='expected, not reached'),
      Patch(fc='white', ec='#C8C8C8', lw=0.4, label='not reached, not yet expected'), Patch(fc=COL['not testable'], label='not testable'), Patch(fc=MUT['not used: reached'], label='pale: not used for staging'),
      Line2D([0], [0], color='black', lw=1.6, label='most advanced set reached')]
cw, rh = 0.178, 0.162; x0 = 1.5; hdr = 1.75; RW = 1.75; bot = 0.62; W = x0 + MT * cw + RW; H = 0.1 + hdr + ST * rh + bot
fig = plt.figure(figsize=(W, H)); ax = fig.add_axes([x0 / W, bot / H, MT * cw / W, ST * rh / H]); ax.set_xlim(0, MT); ax.set_ylim(ST, 0)
for u, d in rows:
    st = LGS[LGS.unit == u].set_index('milestone_id').state
    for m in MSO:
        s = st[m]
        if s in COL or s in MUT: ax.add_patch(Rectangle((mp[m] + 0.05, sp_[u] + 0.05), 0.9, 0.9, fc=COL.get(s, MUT.get(s)), ec='none'))
        else: ax.add_patch(Rectangle((mp[m] + 0.09, sp_[u] + 0.09), 0.82, 0.82, fc='white', ec='#C8C8C8' if not s.startswith('not used') else '#E2E2E2', lw=0.4))
    if R.most_advanced_set[u] in BAR:
        xb = BAR[R.most_advanced_set[u]]; ax.plot([xb, xb], [sp_[u] + 0.02, sp_[u] + 0.98], color='black', lw=1.6, solid_capstyle='butt', clip_on=False)
for u, k in zip(EMBS, BAR): ax.plot([BAR[k], BAR[k]], [sp_[u] + 1.0, ST], color='#555555', lw=0.6, ls=(0, (3, 2)), zorder=0)
for spn in ax.spines.values(): spn.set_visible(False)
ax.set_xticks([mp[m] + 0.5 for m in MSO]); ax.set_xticklabels([f"{m[1:]}  {ABBR[m]}" for m in MSO], rotation=90); ax.xaxis.tick_top(); ax.tick_params(length=0, pad=14)
for lab_, m in zip(ax.get_xticklabels(), MSO):
    if meta.milestone_set[m] == 'unused': lab_.set_color('#888888')
for k in SO:
    c_ = '#555555' if k != 'unused' else '#AAAAAA'
    ax.plot([sl[k] + 0.1, sr[k] - 0.1], [-0.18, -0.18], color=c_, lw=0.6, clip_on=False)
    ax.text((sl[k] + sr[k]) / 2, -0.3, SETL[k], ha='center', va='bottom', fontsize=5, color='#333333' if k != 'unused' else '#888888', clip_on=False)
ax.text(-0.4, -0.3, 'Reached in CosMx embryo', ha='right', va='bottom', fontsize=5, color='#333333', clip_on=False)
ax.set_yticks([sp_[u] + 0.5 for u, d in rows]); ax.set_yticklabels(['CS7 (CosMx)', 'CS8 (CosMx)'] + [SL[g] for g in UNITS]); xl = -(x0 - 0.08) / cw
ax.text(xl, (sp_[EMBS[0]] + sp_[EMBS[1]] + 1) / 2, 'Human\nembryos', ha='left', va='center', fontsize=6, clip_on=False, linespacing=1.0)
for d in DS:
    gs = [g for g in UNITS if INFO.dataset[g] == d]; ax.text(xl, (sp_[gs[0]] + sp_[gs[-1]] + 1) / 2, SHORT[d].split(' ')[0], ha='left', va='center', fontsize=6, clip_on=False)
xs_ = MT + 0.6
for u, d in rows:
    c = R.stage[u]; ax.add_patch(Rectangle((xs_, sp_[u] + 0.12), 0.76, 0.76, fc=SCOL[c], ec='none', clip_on=False)); ax.text(xs_ + 1.05, sp_[u] + 0.52, SLAB.get(c, c), ha='left', va='center', fontsize=6, clip_on=False)
ax.text(xs_, -0.5, 'Stage', ha='left', va='bottom', fontsize=6, clip_on=False)
kw = dict(frameon=False, fontsize=6, handlelength=1.0, handleheight=1.0, labelspacing=0.4, borderaxespad=0.0, borderpad=0.0)
fig.legend(handles=HS[:4], loc='upper left', bbox_to_anchor=(x0 / W, (bot - 0.08) / H), ncol=1, **kw)
fig.legend(handles=HS[4:], loc='upper left', bbox_to_anchor=((x0 + sl['unused'] * cw - 0.45) / W, (bot - 0.08) / H), ncol=1, **kw)
name = 'SuppFig_gastruloid_staging_A_human_only'
for ext in ('png', 'pdf', 'svg'): fig.savefig(OUT + name + '.' + ext, dpi=300)
shutil.copy(OUT + name + '.pdf', OUT + name + '.ai')
fig.canvas.draw(); r = fig.canvas.get_renderer(); texts = [(t, t.get_window_extent(r)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
ov = [(a.get_text()[:25], b.get_text()[:25]) for i, (a, ba) in enumerate(texts) for b, bb in texts[i + 1:] if ba.overlaps(bb)]
outb = [t.get_text()[:30] for t, bb in texts if not (bb.x0 >= 0 and bb.y0 >= 0 and bb.x1 <= fig.bbox.x1 and bb.y1 <= fig.bbox.y1)]
print(round(W, 2), round(H, 2), 'overlaps', ov[:8], 'outside', outb[:8])
print('kept', len(UNITS), R.loc[UNITS].stage.value_counts().to_dict()); print('datasets', INFO.dataset[UNITS].value_counts().to_dict()); print('removed', REMOVED)
tab = R.loc[UNITS, ['dataset', 'label', 'stage', 'most_advanced_set']].copy(); tab.to_csv(OUT + name + '_samples.csv')
