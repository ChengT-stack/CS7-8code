# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/cs7_cs8_matching/figure1_L_heatmap_by_stage/SuppFig2A/scheme39.py (= artifact 77f0af3f)
# sha256 of original: e9a50acf928f5f4e4a2dff92496181dbe6c9f8058bac9e6e5894b99a60e96171
# Methods paragraphs: P349
# Produces: SCHEME constant (38 labels, Type39_scheme order and colours); exec-ed by
#     build_SuppFig3_heatmap_v2.py
# Edits/notes: palette constant, unchanged

SCHEME = [  # (full 39Type label, colour) in the object's own Type39_scheme order (1-38)
 ("Epiblast (EPI)", "#4C4FA3"), ("Ectoderm (ECT)", "#2F80ED"), ("Anterior ectoderm (aECT)", "#0057B8"),
 ("Posterior ectoderm (pECT)", "#00A6D6"), ("Primitive streak (PS)", "#9ACD32"),
 ("Anterior primitive streak (APS)", "#2E8B57"), ("Node", "#00441B"), ("Notochord", "#008B8B"),
 ("Prechordal plate", "#00C49A"), ("Caudal lateral epiblast (CLE)", "#6A5ACD"),
 ("Primordial germ cell (PGC)", "#FF1493"), ("Non-neural ectoderm (NNE)", "#40C4FF"),
 ("Amniotic epithelium progenitor (Am.Epi progenitor)", "#8C6FF7"), ("Amniotic epithelium (Am.Epi)", "#AFCBFF"),
 ("Nascent mesoderm (Nas.Meso)", "#F4A261"), ("Lateral plate mesoderm (LP.Meso)", "#E76F51"),
 ("Heart mesoderm", "#E31A1C"), ("Extraembryonic mesoderm progenitor (Exe.Meso progenitor)", "#F7B6D2"),
 ("Amniotic mesenchyme (Am.Mes)", "#E75480"), ("Allantois mesenchyme (Al.Mes)", "#F768A1"),
 ("Chorion-allantois mesenchyme (ChA.Mes)", "#C51B8A"), ("Yolk sac mesoderm (ys.Meso)", "#8E3A9C"),
 ("Paraxial mesoderm (Para.Meso)", "#D97706"), ("Rostral mesoderm (Rostral.Meso)", "#F43F5E"),
 ("Definitive endoderm (DE)", "#FF5A1F"), ("Visceral endoderm 1 (VE1)", "#FF8C00"),
 ("Visceral endoderm 2 (VE2)", "#FFCA3A"), ("Parietal yolk sac endoderm (Pari.Endo)", "#D4A017"),
 ("Proximal yolk sac endoderm (Prox.ys.Endo)", "#FFE08A"), ("Distal yolk sac endoderm (Dist.ys.Endo)", "#FFF1B8"),
 ("Allantois endoderm (Al.Endo)", "#8F6B00"), ("Anterior visceral endoderm (AVE)", "#C2410C"),
 ("Hematopoietic progenitor (Hema)", "#C4A1FF"), ("Endothelium", "#3B82A0"), ("Macrophage", "#3C1361"),
 ("Megakaryocyte", "#7B2CBF"), ("Primitive erythroblast", "#D65DB1"), ("Trophoblast", "#7A4A00")]
