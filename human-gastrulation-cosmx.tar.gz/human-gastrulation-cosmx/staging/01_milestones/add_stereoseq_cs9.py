# staging/01_milestones/add_stereoseq_cs9.py
# Source: reconstructed from transcript 824ef1ce (messages 8498-8527, 2026-11-17)
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Stereo-seq CS9 milestone evidence and calls added to the audited call table and windows (Figure 6A/B; Table S2, sheet Stereo-seq CS9 evidence).
# Reconstructed verbatim from session transcript 824ef1ce (code was run cell-by-cell in a
# persistent kernel and never saved as a file). Cells are concatenated in execution order;
# inspection-only and figure-polishing cells are omitted, and cells that stopped with an error are
# truncated at the failing line (marked). See PROVENANCE.md.


# ---- cell [frame 824ef1ce, message 8498] Loading CS9 Stereo-seq marker table and labels
import pandas as pd, numpy as np, os
B=(str(HGC_DATA) + '/milestone_evidence/')
c9=pd.read_csv(B+'out_stereo/work/CS9_markers.csv'); print(c9.shape, list(c9.columns))
c9['batch']=c9.cell.str.extract(r'^(CS9-\d)')[0]; print(c9.cell.head(3).tolist(), c9.batch.value_counts(dropna=False).to_dict())
pd.set_option('display.width',250); pd.set_option('display.max_rows',200)
print(c9.groupby(['Type2','batch']).size().unstack(fill_value=0).to_string())
print(c9.Type3.value_counts().head(70).to_string())
L=(str(HGC_DATA) + '/external/human_stereoseq/')
print(os.listdir(L))
lab=pd.read_csv(L+'stereoseq_cell_labels.csv', nrows=5); print(lab.columns.tolist()); 
print(pd.read_csv(L+'stereoseq_label_mapping.csv').head(60).to_string())


# ---- cell [frame 824ef1ce, message 8509] Computing CS9 Stereo-seq milestone evidence
d9=c9.merge(l9[['cell','section','our_group_fine','in_disc_fine']], on='cell', validate='1:1')
G=[c for c in c9.columns if c not in ('cell','nCount_RNA','Types','Type2','Type3','batch')]
det=(d9[G]>0)
rows=[]
def ev9(mid, name, tmask, genes, bg='disc', sub=None):
    base=np.ones(len(d9),bool) if sub is None else sub.values
    t=tmask.values & base
    if bg=='disc': b=d9.in_disc_fine.values & ~tmask.values & base
    elif bg=='all': b=~tmask.values & base
    else: b=bg.values & ~tmask.values & base
    for g in genes:
        if '+' in g: m=np.logical_and.reduce([det[x].values for x in g.split('+')])
        else: m=det[g].values
        nt=t.sum(); nb=b.sum()
        rows.append(dict(milestone_id=mid, population=name, n=nt, marker=g, n_pos=int(m[t].sum()), pct=round(100*m[t].mean(),2) if nt else np.nan,
                         n_bg=nb, pct_bg=round(100*m[b].mean(),2), background={'disc':'other in-disc spots','all':'all other spots'}.get(bg if isinstance(bg,str) else '', 'custom')))
og=d9.our_group_fine; T2=d9.Type2.str.replace(r'^\d+\s+','',regex=True); T3=d9.Type3.str.replace(r'^\d+\s+','',regex=True)
print(sorted(T2.unique())); print(d9.Types.value_counts().index.tolist()[:80])
meso=og.isin(['Nas.Meso','Para.Meso','LP.Meso','Rostral.Meso','Adv.Meso','Other.Meso','Heart mesoderm'])
def run(sub=None):
    ev9('m01','Nas.Meso',og=='Nas.Meso',['MESP1','TBX6'],sub=sub)
    ev9('m02','APS',og=='APS',['GSC','FOXA2','GSC+FOXA2'],sub=sub); ev9('m02','Node/axial',og=='Node',['GSC','FOXA2','GSC+FOXA2'],sub=sub)
    ev9('m03','Node',og=='Node',['FOXJ1','CHRD','FOXJ1+CHRD'],sub=sub)
    ev9('m04','DE',og=='DE',['FOXA2','SOX17','FOXA2+SOX17'],sub=sub); ev9('m04','DE+Gut',og.isin(['DE','Gut']),['FOXA2','SOX17','FOXA2+SOX17'],sub=sub)
    ev9('m05/m06','DE',og=='DE',['GSC','CER1','GSC+CER1'],sub=sub); ev9('m05/m06','DE+Gut',og.isin(['DE','Gut']),['GSC','CER1','GSC+CER1'],sub=sub)
    ev9('m07','Node/axial',og=='Node',['NOTO','SHH','NOTO+FOXA2','SHH+FOXA2','TBXT','TBXT+FOXA2','TBXT+SHH'],sub=sub)
    ev9('m07','Node (Type3 63)',T3=='Node',['NOTO','SHH','TBXT','FOXA2'],sub=sub); ev9('m07','Prechordal plate (Type3 62)',T3=='Prechordal plate',['NOTO','SHH','TBXT','FOXA2','GSC'],sub=sub)
    ev9('m07','Floor plate (Type3 24)',T3.str.contains('floor plate'),['NOTO','SHH','FOXA2'],sub=sub)
    ev9('m08','APS (PS label empty)',og=='APS',['HOXA1','HOXB1'],sub=sub); ev9('m08','PS (Type2 15)',T2=='PS',['HOXA1','HOXB1'],sub=sub); ev9('m08','CLE/NMP',og=='CLE',['HOXA1','HOXB1'],sub=sub)
    ev9('m08','TBXT+ CLE/NMP+APS',og.isin(['CLE','APS'])&det.TBXT,['HOXA1','HOXB1'],sub=sub)
    ev9('m09','CLE/NMP',og=='CLE',['NKX1-2','CDX2','NKX1-2+CDX2'],sub=sub)
    ev9('m10','aECT (neural ectoderm+forebrain)',og=='aECT',['HESX1','SIX3','HESX1+SIX3','OTX2','SOX2','LHX2'],sub=sub)
    ev9('m10','neural (aECT+pECT spinal cord)',og.isin(['aECT','pECT']),['SOX2'],sub=sub)
    ev9('m11','Para.Meso',og=='Para.Meso',['MEOX1','TCF15','MEOX1+TCF15'],sub=sub); ev9('m11','embryonic mesoderm',meso,['MEOX1','TCF15','MEOX1+TCF15'],sub=sub)
    ev9('m12','APS',og=='APS',['EOMES','TBXT'],sub=sub); ev9('m12','PS (Type2 15)',T2=='PS',['EOMES','TBXT'],sub=sub); ev9('m12','CLE/NMP+APS',og.isin(['CLE','APS']),['EOMES','TBXT'],sub=sub)
    ev9('m12','TBXT+ CLE/NMP+APS',og.isin(['CLE','APS'])&det.TBXT,['EOMES'],sub=sub)
    ev9('m13','CLE/NMP',og=='CLE',['HOXB8'],sub=sub); ev9('m13','NKX1-2+CDX2+ CLE/NMP',(og=='CLE')&det['NKX1-2']&det.CDX2,['HOXB8'],sub=sub)
    ev9('m14','Cardiomyocyte (Type2)',T2=='Cardiomyocyte',['NKX2-5','TNNT2','MYL7','NKX2-5+TNNT2'],bg='all',sub=sub)
    ev9('m15','all spots',pd.Series(np.ones(len(d9),bool)),['NANOS3','DPPA3','NANOS3+TFAP2C','NANOS3+DPPA3','NANOS3+PRDM1'],bg='all',sub=sub)
    ev9('m16','Endothelial + Blood progenitor (Type2)',T2.isin(['Endothelial cell','Blood progenitor']),['ETV2','KDR','TAL1','ETV2+KDR'],bg='all',sub=sub)
    ev9('m17','EXM + YS.Meso (Type2)',T2.isin(['EXM','YS.Meso']),['HAND1'],bg='all',sub=sub)
    ev9('m18','Allantois (Type3 117)',T3=='Allantois',['TBX4','HOXA10','TBX4+HOXA10'],bg='all',sub=sub)
    ery=T3.isin(['Erythrocyte']); blood=T2.isin(['Erythrocyte','Blood progenitor','Endothelial cell'])
    ev9('m19','Erythrocyte (Type2)',T2=='Erythrocyte',['HBZ','HBE1','GATA1','HBZ+GATA1'],bg=~blood,sub=sub)
    ev9('m19','Megakaryocyte/haem. progenitor (Type3)',T3.isin(['Megakaryocyte','Hematopoietic progenitor']),['HBZ','HBE1','GATA1','HBZ+GATA1'],bg=~blood,sub=sub)
# [not executed in the original run: the cell stopped with an error at the next line]
# run(); E_all=pd.DataFrame(rows); rows=[]
# run(sub=(d9.batch=='CS9-2')); E_2=pd.DataFrame(rows)
# E=E_all.merge(E_2[['milestone_id','population','marker','n','n_pos','pct','n_bg','pct_bg']],on=['milestone_id','population','marker'],suffixes=('','_CS9-2'))
# E['fold']=(E.pct/E.pct_bg.replace(0,np.nan)).round(1); E['enriched']=(E.pct>=2*E.pct_bg)&(E.pct-E.pct_bg>=5)
# print(E[['milestone_id','population','marker','n','n_pos','pct','pct_bg','fold','enriched','n_CS9-2','pct_CS9-2','pct_bg_CS9-2']].to_string(index=False))


# ---- cell [frame 824ef1ce, message 8511] Recomputing CS9 evidence table with fixed background handling
import warnings; warnings.filterwarnings('ignore')
def ev9(mid, name, tmask, genes, bg='disc', sub=None):
    base=np.ones(len(d9),bool) if sub is None else sub.values
    t=tmask.values & base
    if isinstance(bg,str):
        b=(d9.in_disc_fine.values if bg=='disc' else np.ones(len(d9),bool)) & ~tmask.values & base; bgn={'disc':'other in-disc spots','all':'all other spots'}[bg]
    else: b=bg.values & ~tmask.values & base; bgn='non-blood, non-endothelial spots'
    for g in genes:
        m=np.logical_and.reduce([det[x].values for x in g.split('+')])
        nt=t.sum(); nb=b.sum()
        rows.append(dict(milestone_id=mid, population=name, n=int(nt), marker=g, n_pos=int(m[t].sum()), pct=round(100*m[t].mean(),2) if nt else np.nan, n_bg=int(nb), pct_bg=round(100*m[b].mean(),2) if nb else np.nan, background=bgn))
rows=[]; run(); E_all=pd.DataFrame(rows); rows=[]
run(sub=(d9.batch=='CS9-2')); E_2=pd.DataFrame(rows)
E=E_all.merge(E_2[['milestone_id','population','marker','n','n_pos','pct','n_bg','pct_bg']],on=['milestone_id','population','marker'],suffixes=('','_CS9-2'))
E['fold']=(E.pct/E.pct_bg.replace(0,np.nan)).round(1); E['enriched']=(E.pct>=2*E.pct_bg)&(E.pct-E.pct_bg>=5)
print(E[['milestone_id','population','marker','n','n_pos','pct','pct_bg','fold','enriched','n_CS9-2','pct_CS9-2','pct_bg_CS9-2']].to_string(index=False))


# ---- cell [frame 824ef1ce, message 8519] Building CS9 calls, windows and redrawing panels A–B
import shutil, importlib, sys, matplotlib as mpl
SRC=(str(HGC_OUT) + '/figure6/'); OUTD=str(HGC_OUT)+'/figure6_cs9/'; os.makedirs(OUTD,exist_ok=True)
K='CS9 (Stereo-seq)'
def e(mid,pop,mk):
    r=E[(E.milestone_id==mid)&(E.population==pop)&(E.marker==mk)].iloc[0]; return r
def pv(mid,pop,mk,bg=True):
    r=e(mid,pop,mk); s=f"{mk} {r.pct:.1f}% ({r.n_pos}/{r.n})"; return s+(f" vs {r.pct_bg:.1f}%" if bg else '')
n=lambda mid,pop,mk: int(e(mid,pop,mk).n)
CALL={
 'm01':('reached', f"Nas.Meso {n('m01','Nas.Meso','MESP1')} spots; {pv('m01','Nas.Meso','MESP1')}"),
 'm02':('reached', f"APS {n('m02','APS','GSC')} spots annotated; axial (Node) {pv('m02','Node/axial','FOXA2')}; GSC not detected in APS or Node (transient programme passed)"),
 'm03':('reached', f"Node {n('m03','Node','FOXJ1')} spots; {pv('m03','Node','FOXJ1')}; {pv('m03','Node','CHRD')}; {pv('m03','Node','FOXJ1+CHRD')}"),
 'm04':('reached', f"DE {n('m04','DE','FOXA2')} + gut {n('m04','DE+Gut','FOXA2')-n('m04','DE','FOXA2')} spots; DE+gut {pv('m04','DE+Gut','FOXA2')}; {pv('m04','DE+Gut','SOX17')}"),
 'm05':('not assessable', f"ADE programme already regressed (GSC+CER1+ {e('m05/m06','DE','GSC+CER1').n_pos}/{n('m05/m06','DE','GSC')} DE spots, {e('m05/m06','DE+Gut','GSC+CER1').n_pos}/{n('m05/m06','DE+Gut','GSC')} DE+gut spots)"),
 'm06':('reached', f"DE {pv('m05/m06','DE','GSC')}; DE+gut {pv('m05/m06','DE+Gut','GSC')} (same-platform CS8 DE GSC 46.9%)"),
 'm07':('reached', f"axial (Node) {n('m07','Node/axial','SHH')} spots: {pv('m07','Node/axial','SHH')}; {pv('m07','Node/axial','TBXT+SHH')}; NOTO {e('m07','Node/axial','NOTO').n_pos}/{n('m07','Node/axial','NOTO')} (not detected; call rests on SHH/TBXT) - provisional"),
 'm08':('reached', f"PS (Type2) {pv('m08','PS (Type2 15)','HOXA1')} (13 spots, provisional); CLE/NMP {pv('m08','CLE/NMP','HOXA1')}; {pv('m08','CLE/NMP','HOXB1')}"),
 'm09':('reached', f"CLE/NMP {n('m09','CLE/NMP','NKX1-2')} spots; {pv('m09','CLE/NMP','NKX1-2+CDX2')}"),
 'm10':('reached', f"neural ectoderm + forebrain {n('m10','aECT (neural ectoderm+forebrain)','SOX2')} spots annotated ({pv('m10','aECT (neural ectoderm+forebrain)','SOX2')}); HESX1 and SIX3 not detectable on this platform ({e('m10','aECT (neural ectoderm+forebrain)','HESX1').pct:.1f}% / {e('m10','aECT (neural ectoderm+forebrain)','SIX3').pct:.1f}%) - annotation-based"),
 'm11':('reached', f"Para.Meso (PSM, somitomere, somite, sclerotome) {n('m11','Para.Meso','MEOX1')} spots; {pv('m11','Para.Meso','MEOX1')}; {pv('m11','Para.Meso','MEOX1+TCF15')}"),
 'm12':('reached', f"{pv('m12','PS (Type2 15)','EOMES',False)} PS; {pv('m12','CLE/NMP+APS','EOMES',False)} CLE/NMP+APS (same-platform CS8 PS 42.0%); few PS spots"),
 'm13':('reached', f"CLE/NMP {pv('m13','CLE/NMP','HOXB8')}"),
 'm14':('reached', f"Cardiomyocyte {n('m14','Cardiomyocyte (Type2)','NKX2-5')} spots; {pv('m14','Cardiomyocyte (Type2)','NKX2-5+TNNT2')}"),
 'm15':('not assessable', f"no annotated PGC spots; NANOS3+DPPA3+ {e('m15','all spots','NANOS3+DPPA3').n_pos} spot; PGC not resolved at spot level"),
 'm16':('reached', f"Endothelial + blood progenitor {n('m16','Endothelial + Blood progenitor (Type2)','KDR')} spots; {pv('m16','Endothelial + Blood progenitor (Type2)','KDR')}; {pv('m16','Endothelial + Blood progenitor (Type2)','TAL1')}"),
 'm17':('reached', f"EXM + YS.Meso {n('m17','EXM + YS.Meso (Type2)','HAND1')} spots; {pv('m17','EXM + YS.Meso (Type2)','HAND1')}"),
 'm18':('reached', f"Allantois {n('m18','Allantois (Type3 117)','TBX4')} spots; {pv('m18','Allantois (Type3 117)','TBX4')}; {pv('m18','Allantois (Type3 117)','HOXA10')} (fold-enriched, below the 5-point rule)"),
 'm19':('reached', f"Erythrocyte {n('m19','Erythrocyte (Type2)','HBZ')} spots (HBZ ambient, {e('m19','Erythrocyte (Type2)','HBZ').pct_bg:.0f}% of non-blood spots); megakaryocyte/haematopoietic progenitor spots {pv('m19','Megakaryocyte/haem. progenitor (Type3)','HBZ+GATA1')}"),
}
A=pd.read_csv(SRC+'audited_calls.csv')
i=list(A.columns).index('Cui CS7 (Stereo-seq) | evidence')  # insert after the two Stereo-seq embryos
j=max(i, list(A.columns).index('Xiao CS8 (Stereo-seq) | evidence'))+1
A.insert(j, K, [CALL[m][0] for m in A.milestone_id]); A.insert(j+1, K+' | evidence', [CALL[m][1] for m in A.milestone_id])
R_,N_='reached','not reached'
def window(TT,k):
    d=TT[(TT.domain=='disc')&TT.mouse_onset.notna()]
    lo=d.loc[d[k]==R_,'mouse_onset'].max(); hi=d.loc[d[k]==N_,'mouse_onset'].min()
    if np.isnan(hi): hi=np.inf
    tied=lo>=hi
    if tied:
        grid=np.array([6.5,6.75,7.0,7.25,7.5,7.75,8.0,8.25,8.5]); jj=np.searchsorted(grid,lo); lo,hi=grid[jj-1],grid[jj]
    return lo,hi,tied
def lab(lo,hi,tied):
    if np.isinf(hi): return f"≥E{lo:g}"
    if hi-lo<=0.25+1e-9 and not tied: return f"≈E{(lo+hi)/2:g}"
    return f"E{lo:g}–{hi:g}"
W0=pd.read_csv(SRC+'windows_audited.csv')
# check the rule reproduces the existing windows
for _,r in W0.iterrows():
    lo,hi,t=window(A,r.dataset); assert lab(lo,hi,t)==r.label, (r.dataset,lab(lo,hi,t),r.label)
lo,hi,t=window(A,K); d=A[A.domain=='disc']
new=dict(dataset=K,window_lo=lo,window_hi=hi,tied=t,label=lab(lo,hi,t),latest_reached_onset=d.loc[d[K]==R_,'mouse_onset'].max(),
         latest_reached=';'.join(d.loc[(d[K]==R_)&(d.mouse_onset==d.loc[d[K]==R_,'mouse_onset'].max()),'milestone_id']),earliest_not_reached_onset=np.nan,earliest_not_reached='')
W=pd.concat([W0.iloc[:4],pd.DataFrame([new]),W0.iloc[4:]],ignore_index=True)
A.to_csv(OUTD+'audited_calls.csv',index=False); W.to_csv(OUTD+'windows_audited.csv',index=False)
print(new); print(A[K].value_counts().to_dict())
for m in A.milestone_id: print(m, CALL[m][0],'|',CALL[m][1])


# ---- cell [frame 824ef1ce, message 8527] Finalising panel files and evidence workbook
# (first part of this cell re-ran the Figure 6A/B plotting script, see plot_fig6AB.py)
# evidence workbook
calls=pd.DataFrame([dict(milestone_id=mm, milestone=A.loc[A.milestone_id==mm,'milestone'].iloc[0], domain=A.loc[A.milestone_id==mm,'domain'].iloc[0],
        mouse_onset_E=A.loc[A.milestone_id==mm,'mouse_onset'].iloc[0], call_StereoSeq_CS9=CALL[mm][0], evidence=CALL[mm][1],
        Stereo_CS7=A.loc[A.milestone_id==mm,'Cui CS7 (Stereo-seq)'].iloc[0], Stereo_CS8=A.loc[A.milestone_id==mm,'Xiao CS8 (Stereo-seq)'].iloc[0]) for mm in A.milestone_id])
Eo=E.rename(columns={'n':'n_target','pct':'pct_target','n_CS9-2':'n_target_CS9-2only','n_pos_CS9-2':'n_pos_CS9-2only','pct_CS9-2':'pct_target_CS9-2only','n_bg_CS9-2':'n_bg_CS9-2only','pct_bg_CS9-2':'pct_bg_CS9-2only','fold':'fold_over_background','enriched':'enriched_2x_and_5pp'})
readme=pd.DataFrame({'item':['data','units','detection','populations','background','enrichment rule','window rule','batches','provenance','judgement calls'],
 'description':[(str(HGC_DATA) + '/CS9-28798-RNA-MapQ.rds (28,793 spots; batch CS9-1 8,873 spots, CS9-2 19,920 spots); per-spot marker counts from milestone_evidence/out_stereo/work/CS9_markers.csv; labels from external/human_stereoseq/stereoseq_cell_labels.csv'),
  'Stereo-seq bin50 spots (not single cells)','>=1 UMI per spot',
  'our_group_fine (from Types) for disc groups; Type2 for cardiomyocyte, endothelial + blood progenitor, EXM + YS.Meso, erythrocyte; Type3 for allantois, node, prechordal plate, floor plate, megakaryocyte / haematopoietic progenitor',
  'disc populations: all other in-disc spots; extra-embryonic and cardiac populations: all other spots; erythroid: non-blood, non-endothelial spots',
  'target >= 2x background and >= 5 percentage points above it (same rule as for the Stereo-seq CS7 and CS8 embryos)',
  'identical to audit.py: lower bound = latest mouse onset among reached disc milestones; upper bound = earliest onset among not-reached disc milestones; no not-reached milestone -> open-ended',
  'all spots used for the calls; columns *_CS9-2only repeat every number in batch CS9-2 alone (CS9-1 is the lower-depth batch)',
  'the source publication of this CS9 object is not recorded in the analysis files; confirm before citing',
  'm07 rests on SHH/TBXT (NOTO 0/58); m08 and m12 use 13 PS spots plus CLE/NMP; m10 is annotation-based (HESX1/SIX3 not detectable on the platform); m18 markers are fold-enriched but below the 5-point rule; none of these changes the window']})
with pd.ExcelWriter(OUTD+'Fig6AB_StereoSeq_CS9_calls_evidence.xlsx') as xw:
    readme.to_excel(xw,'README',index=False); calls.to_excel(xw,'CS9_calls',index=False); Eo.to_excel(xw,'CS9_evidence',index=False)
    A.to_excel(xw,'6A_calls_all_datasets',index=False); W.to_excel(xw,'6B_windows_all_datasets',index=False)
# (remaining lines of this cell: a CS9-2-only sensitivity print and copies to the shared drive)
