# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/cs7_seven_pop_trends/seven_pop_trends.py (2026-09-28; artifact a10d757c, session
#     0b0712b4)
# sha256 of original: d068401366540d1e9a4e67c513fd173e76a617a91e198452f5e1ed6da4fe4d42
# Methods paragraphs: P352 (CS7 landmark frame), P358, P361
# Produces: cs7_seven_pop_ap_trends.{png,pdf,svg,csv}, cs7_seven_pop_ap_curves.csv (CS7 set-level pathway
#     curves; same specification as the five-population Figure 4A run) and cs7_pathway_gene_sets.json
# Edits/notes: Gene-set source "recover3/complete_sets.json" (not in any shared folder) replaced by the COMPLETE
#     sets of common/pathway_gene_sets.py, which this script itself had written out (idempotent). Whether Figure
#     4B was drawn from this 7-population run or a 4-population (DE/AVE/VE1/VE2) variant is uncertain (see
#     PROVENANCE).
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

"""AP trends of five signalling pathways (ligand / receptor / target / inhibitor sets) restricted to seven CS7
populations: DE, AVE, VE1, VE2, Node, APS, PS. Same specification as cs7_five_pop_ap_trends (EPI/ECT/Node/APS/PS):
frame = landmark-anchored CS7 frame (AP sign from PS vs anterior landmarks, view axis from extraembryonic side),
AP band = 1-99th pct of these cells; set CP10K summed / set size, depth-adjusted, Gaussian kernel h = 0.06 x span;
slopes = OLS with log depth + population fixed effects; BH over the 20 sets of each version; 200 detection-matched
random sets; leave-one-out of the strongest genes."""
import os, re, json, sys
for k,v in [("KMP_AFFINITY","disabled"),("OMP_NUM_THREADS","8"),("KMP_INIT_AT_FORK","FALSE")]: os.environ.setdefault(k,v)
import numpy as np, pandas as pd, scipy.sparse as ssp
from scipy.io import mmread
from scipy.stats import binomtest
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
import matplotlib as mpl; mpl.use("Agg"); import matplotlib.pyplot as plt
sys.path.insert(0,os.getcwd())
from figure_style import apply_figure_style, panel_letter
META_GREY="#8A8A8A"

# ---------------- frame (identical to the five-population run) ----------------
E7=pd.read_csv(sys.argv[1] if len(sys.argv)>1 else "handoff/cs7_proj_curves_export.csv")
E7["curated_kept"]=E7.curated_kept.astype(str).isin(["True","TRUE","true"])
X7=E7[["x","y","z"]].to_numpy(float); fin7=np.isfinite(X7).all(1)
lab7=E7.label.to_numpy(); kept7=E7.curated_kept.to_numpy(); present=set(lab7)
ANT=[t for t in ["Anterior ectoderm (aECT)","Rostral mesoderm (Rostral.Meso)","Anterior visceral endoderm (AVE)"] if t in present]
POST=[t for t in ["Primitive streak (PS)","Caudal lateral epiblast (CLE)","Nascent mesoderm (Nas.Meso)"] if t in present]
EXE=[t for t in ["Trophoblast","Distal yolk sac endoderm (Dist.ys.Endo)","Proximal yolk sac endoderm (Prox.ys.Endo)",
                 "Parietal yolk sac endoderm (Pari.Endo)","Yolk sac mesoderm (ys.Meso)","Chorion-allantois mesenchyme (ChA.Mes)"] if t in present]
an,po,ex=np.isin(lab7,ANT)&fin7, np.isin(lab7,POST)&fin7, np.isin(lab7,EXE)&fin7
sa2=1.0 if np.median(X7[po,0])>np.median(X7[an,0]) else -1.0
sp2=1.0 if np.median(X7[ex,1])>np.median(X7[~ex&fin7,1]) else -1.0
C_fig=np.c_[sa2*X7[:,0], X7[:,2], sp2*X7[:,1]]; C_fig=C_fig-np.nanmedian(C_fig,axis=0)
assert np.median(C_fig[po,0])>np.median(C_fig[an,0]) and np.median(C_fig[ex,2])>0
# reproduce the earlier band check as a frame-fidelity assertion
TARG={"EPI":"Epiblast (EPI)","APS":"Anterior primitive streak (APS)","PS":"Primitive streak (PS)","Node":"Node"}
CUT={"PS":600.0,"APS":900.0,"EPI":720.0,"Node":760.0}; ci=[]
for s_,f_ in TARG.items():
    m=(lab7==f_)&kept7&fin7; d=np.hypot(C_fig[m,0]-np.median(C_fig[m,0]), C_fig[m,1]-np.median(C_fig[m,1])); ci.append(np.where(m)[0][d<=CUT[s_]])
ap_lo,ap_hi=np.percentile(C_fig[np.unique(np.concatenate(ci)),0],[1,99])
print(f"frame: AP = {sa2:+.0f}*x | earlier all-cell band reproduced [-482, 440]: {abs(ap_lo+482)<1 and abs(ap_hi-440)<1} ([{ap_lo:.0f}, {ap_hi:.0f}])",flush=True)

def kernel_curve(ap,val,h=None,n_grid=80,min_h=20):
    ap=np.asarray(ap,float); val=np.asarray(val,float)
    if h is None: h=max(min_h, 0.06*(ap.max()-ap.min()))
    grid=np.linspace(ap.min(),ap.max(),n_grid)
    w=np.exp(-0.5*((grid[:,None]-ap[None,:])/h)**2); wsum=w.sum(1)
    mean=(w*val[None,:]).sum(1)/np.where(wsum>1e-9,wsum,1)
    eff=wsum**2/(w**2).sum(1)
    var=(w*(val[None,:]-mean[:,None])**2).sum(1)/np.where(wsum>1e-9,wsum,1)
    return grid, mean, np.sqrt(var/np.where(eff>1,eff,1)), h

# ---------------- the seven populations ----------------
WANT=["DE","AVE","VE1","VE2","Node","APS","PS"]
PCOL={"DE":"#D95F02","AVE":"#1F6FB2","VE1":"#E6AB02","VE2":"#7E7E1F","Node":"#2E8B57","APS":"#7B4FA3","PS":"#C2401A"}
FULL7={k:[t for t in present if t==k or t.endswith(f"({k})")][0] for k in WANT}
M7=ssp.csr_matrix(mmread("handoff/seven_counts.mtx"))
G7=pd.read_csv("handoff/seven_genes.csv"); C7=pd.read_csv("handoff/seven_cells.csv")
gi7={g:i for i,g in enumerate(G7.gene)}; det7=G7.n_det.to_numpy()
pos={c:i for i,c in enumerate(E7.cell)}
ordr=np.array([pos[c] for c in C7.cell]); assert (lab7[ordr]==C7.label.to_numpy()).all()
ap7=C_fig[ordr,0]; lab5=C7.label.to_numpy(); dep5=C7.nCount.to_numpy(float); ld5=np.log(dep5)
sel=np.isfinite(ap7)
lo5,hi5=np.percentile(ap7[sel],[1,99])
inb=sel&(ap7>=lo5)&(ap7<=hi5)
print(f"seven populations: {len(C7):,} cells | AP band 1-99 pct [{lo5:.0f}, {hi5:.0f}] (span {hi5-lo5:.0f}) -> {int(inb.sum()):,} inside",flush=True)
for k in WANT:
    m=inb&(lab5==FULL7[k]); print(f"  {k:5s} n={int(m.sum()):5d}  AP median {np.median(ap7[m]):+6.0f}  IQR {np.percentile(ap7[m],25):+.0f}..{np.percentile(ap7[m],75):+.0f}")
POP=np.column_stack([(lab5==FULL7[k]).astype(float) for k in WANT[1:]])

# ---------------- gene sets (recovered from the project's curve tables; identical to the earlier figures) ----------------
from pathway_gene_sets import PATHWAY_GENE_SETS; COMPLETE=json.loads(json.dumps(PATHWAY_GENE_SETS["COMPLETE"])); COMPLETE.pop("FGF_FGF_FHF_excluded",None)
CONCISE=dict(COMPLETE)
CONCISE.update({"WNT_ligand":["WNT1","WNT2B","WNT3","WNT3A","WNT4","WNT5A","WNT5B","WNT6","WNT7A","WNT7B","WNT8A","WNT9A","WNT11","RSPO1","RSPO2","RSPO3"],
 "FGF_ligand":["FGF2","FGF3","FGF4","FGF5","FGF8","FGF9","FGF10","FGF17","FGF18"],
 "WNT_receptor":["FZD1","FZD2","FZD3","FZD4","FZD5","FZD6","FZD7","FZD8","FZD10","LRP5","LRP6"],
 "NODAL_receptor":["ACVR1B","ACVR2A","ACVR2B","SMAD2","SMAD3"],"NOTCH_receptor":["NOTCH1","NOTCH2","NOTCH3","NOTCH4"],
 "SHH_receptor":["PTCH1","SMO","GAS1","CDON","BOC"],"FGF_receptor":["FGFR1","FGFR2","FGFR3","FGFR4"],
 "NODAL_ligand":["NODAL","GDF3","CFC1","LEFTY1"],"NOTCH_ligand":["DLL1","DLL3","DLL4","JAG1","JAG2"],"SHH_ligand":["SHH","IHH","DHH"]})
PWS=["WNT","NODAL","NOTCH","SHH","FGF"]; KINDS4=["ligand","receptor","target","inhibitor"]
assert set(COMPLETE)=={f"{p}_{k}" for p in PWS for k in KINDS4}
diff={k for k in COMPLETE if sorted(COMPLETE[k])!=sorted(CONCISE[k])}
missing={k:[g for g in COMPLETE[k]+CONCISE[k] if g not in gi7] for k in COMPLETE}
print("genes absent from the export:",{k:v for k,v in missing.items() if v} or "none")

def slope(y,m):
    X=np.column_stack([np.ones(m.sum()), ap7[m]/100.0, ld5[m]]+[POP[m,j] for j in range(POP.shape[1])])
    f=sm.OLS(y[m],X).fit(); return float(f.params[1]), float(f.bse[1]), float(f.pvalues[1])
def sc(genes):
    ii=[gi7[g] for g in genes if g in gi7]; return np.log1p(np.asarray(M7[ii,:].sum(0)).ravel()/dep5*1e4)
rng=np.random.default_rng(23)
def null(genes,n_null=200,tol=0.25):
    ii=[gi7[g] for g in genes if g in gi7]
    pools=[np.where((det7>det7[j]*(1-tol))&(det7<det7[j]*(1+tol)))[0] for j in ii]
    return [np.log1p(np.asarray(M7[[int(rng.choice(p)) for p in pools if len(p)],:].sum(0)).ravel()/dep5*1e4) for _ in range(n_null)]
rows=[]
for ver,DEF in [("concise",CONCISE),("complete",COMPLETE)]:
    for k in sorted(DEF):
        gs=[g for g in DEF[k] if g in gi7]; y=sc(gs); b,se,p=slope(y,inb)
        nb=np.array([slope(z,inb)[0] for z in null(gs)])
        rows.append(dict(version=ver,set=k,pathway=k.split("_")[0],kind=k.split("_")[1],n_genes=len(gs),
                         slope_per_100um=round(b,4),se=round(se,4),p=p,z_vs_null=round(float((b-nb.mean())/nb.std()),2),mde=round(2.80*se,4)))
F5=pd.DataFrame(rows)
for ver in ["concise","complete"]:
    m=F5.version==ver; F5.loc[m,"FDR"]=multipletests(F5.loc[m,"p"],method="fdr_bh")[1]
print(f"\nBH<0.05: concise {int((F5[F5.version=='concise'].FDR<0.05).sum())}/20 | complete {int((F5[F5.version=='complete'].FDR<0.05).sum())}/20")
print(F5[F5.version=="complete"].sort_values("slope_per_100um")[["set","n_genes","slope_per_100um","se","FDR","z_vs_null"]].to_string(index=False),flush=True)

# leave-one-out for the hits
L5=[]
for ver,DEF in [("concise",CONCISE),("complete",COMPLETE)]:
    for k in F5[(F5.version==ver)&(F5.FDR<0.05)].set.tolist():
        gs=[g for g in DEF[k] if g in gi7]; b_all=slope(sc(gs),inb)[0]
        per={g:slope(sc([g]),inb)[0] for g in gs}; order=sorted(gs,key=lambda g:-abs(per[g]))
        res={n:slope(sc([g for g in gs if g not in order[:n]]),inb)[::2] for n in [1,3]}
        signs=sum(1 for g in gs if np.sign(per[g])==np.sign(b_all))
        L5.append(dict(version=ver,set=k,n_genes=len(gs),slope_full=round(b_all,4),sign_share=f"{signs}/{len(gs)}",
                       sign_test_p=round(binomtest(signs,len(gs),0.5).pvalue,4),top3=",".join(order[:3]),
                       slope_wo1=round(res[1][0],4),p_wo1=round(res[1][1],4),slope_wo3=round(res[3][0],4),p_wo3=round(res[3][1],4),
                       survives_wo3="YES" if res[3][1]<0.05 else "no"))
L5D=pd.DataFrame(L5)
L5D.to_csv("cs7_seven_pop_ap_leave_one_out.csv",index=False); F5.to_csv("cs7_seven_pop_ap_trends.csv",index=False)
cc=L5D[L5D.version=="complete"]
print(f"\nleave-one-out, complete version ({len(cc)} hits):"); print(cc.to_string(index=False),flush=True)

# ---------------- figure ----------------
plt.close("all"); apply_figure_style()
KCOL={"ligand":"#1F6FB2","receptor":"#7B4FA3","target":"#C2401A","inhibitor":"#2E8B57"}
SETCUR={}
for ver,DEF in [("concise",CONCISE),("complete",COMPLETE)]:
    for k in DEF:
        gs=[g for g in DEF[k] if g in gi7]
        v=np.asarray(M7[[gi7[g] for g in gs],:].sum(0)).ravel()/dep5*1e4
        be=np.polyfit(ld5[inb],v[inb],1); resid=v[inb]-(be[0]*ld5[inb]+be[1])+v[inb].mean()
        SETCUR[(ver,k)]=kernel_curve(ap7[inb],resid/max(len(gs),1))[:3]
fig=plt.figure(figsize=(15.6,14.6))
L0,R0=0.048,0.988; T0=0.885; ah=0.050
ax_a=fig.add_axes([L0,T0-ah,R0-L0,ah])
xs=np.linspace(lo5,hi5,200)
for n_,k in enumerate(WANT):
    m=inb&(lab5==FULL7[k]); cc_=PCOL[k]
    d=np.exp(-0.5*((xs[:,None]-ap7[m][None,:])/28.0)**2).sum(1); d=d/d.max()
    ax_a.fill_between(xs,0,d,color=cc_,alpha=.40,lw=0); ax_a.plot(xs,d,color=cc_,lw=1.0)
# labels as one evenly spaced coloured row: seven medians are too close for median-anchored labels
for n_,k in enumerate(WANT):
    m=inb&(lab5==FULL7[k])
    ax_a.text(0.04+n_*0.92/6,1.08,f"{k} ({int(m.sum()):,})  median AP {np.median(ap7[m]):+.0f}",transform=ax_a.transAxes,ha="center",fontsize=6.0,color=PCOL[k])
ax_a.set_xlim(lo5,hi5); ax_a.set_ylim(0,1.28); ax_a.set_yticks([])
ax_a.spines[["top","right","left"]].set_visible(False); ax_a.tick_params(labelbottom=False); ax_a.set_ylabel("cell\ndensity",fontsize=6.4)
GT=T0-ah-0.022; GB=0.245; gh=(GT-GB-0.013*4)/5; gw=(R0-L0-0.030*3)/4
AXG={}
for i,pw in enumerate(PWS):
    for j,kd in enumerate(KINDS4):
        AXG[(pw,kd)]=fig.add_axes([L0+j*(gw+0.030), GT-gh-i*(gh+0.013), gw, gh])
for pw in PWS:
    for kd in KINDS4:
        ax=AXG[(pw,kd)]; k=f"{pw}_{kd}"; gc,gm,gs_=SETCUR[("complete",k)]
        ax.fill_between(gc,gm-gs_,gm+gs_,color=KCOL[kd],alpha=.16,lw=0); ax.plot(gc,gm,color=KCOL[kd],lw=1.9,zorder=5)
        r=F5[(F5.version=="complete")&(F5.set==k)].iloc[0]; star="\u2605" if r.FDR<0.05 else ""
        ax.text(.03,.93,f"{pw} {kd}s",transform=ax.transAxes,fontsize=6.2,va="top",color=KCOL[kd])
        ax.text(.97,.93,f"{r.slope_per_100um:+.3f}{star}",transform=ax.transAxes,fontsize=6.0,ha="right",va="top",color="#C2401A" if r.FDR<0.05 else "#999999")
        ax.set_xlim(lo5,hi5); ax.spines[["top","right"]].set_visible(False); ax.margins(y=0.18); ax.tick_params(labelsize=5.6)
for pw in PWS[:-1]:
    for kd in KINDS4: AXG[(pw,kd)].tick_params(labelbottom=False)
for kd in KINDS4: AXG[(PWS[-1],kd)].set_xlabel("anterior \u2192 posterior (\u00b5m)",fontsize=7.0)
for pw in PWS: AXG[(pw,"ligand")].set_ylabel("set mean\nper gene (CP10K)",fontsize=6.2)
ax_c=fig.add_axes([L0,0.025,0.44,0.152]); ax_d=fig.add_axes([0.590,0.025,0.398,0.152])
ordset=F5[F5.version=="complete"].sort_values("slope_per_100um").set.tolist()
for i,k in enumerate(ordset):
    rc=F5[(F5.version=="concise")&(F5.set==k)].iloc[0]; rp=F5[(F5.version=="complete")&(F5.set==k)].iloc[0]
    ax_c.plot([rp.slope_per_100um-1.96*rp.se, rp.slope_per_100um+1.96*rp.se],[i,i],color="#BBBBBB",lw=1.1,zorder=2)
    ax_c.plot([rp.slope_per_100um],[i],"o",ms=4.6,color=KCOL[k.split("_")[1]],mec="black" if rp.FDR<0.05 else "none",mew=.7,zorder=5)
ax_c.axvline(0,color="#999999",lw=.8,ls=(0,(3,3)))
ax_c.set_yticks(range(len(ordset))); ax_c.set_yticklabels([k.replace("_"," ") for k in ordset],fontsize=5.4)
for i,k in enumerate(ordset): ax_c.get_yticklabels()[i].set_color(KCOL[k.split("_")[1]])
ax_c.set_xlabel("AP slope per 100 \u00b5m (within-population, depth-adjusted)",fontsize=7.0)
nsig=int((F5[F5.version=="complete"].FDR<0.05).sum())
ax_c.set_title(f"All 20 sets (complete gene lists), {nsig} reach BH < 0.05 (ringed)",loc="left",fontsize=7.6)
ax_c.spines[["top","right"]].set_visible(False); ax_c.tick_params(axis="y",length=0)
if len(cc):
    cc=cc.sort_values("slope_full"); xx=np.arange(len(cc))
    ax_d.bar(xx-0.24,cc.slope_full.abs(),width=.22,color="#8FA8BF",label="full set")
    ax_d.bar(xx,cc.slope_wo1.abs(),width=.22,color="#E8A33D",label="top gene removed")
    ax_d.bar(xx+0.24,cc.slope_wo3.abs(),width=.22,color="#C2401A",label="top 3 removed")
    for i,r in enumerate(cc.itertuples()):
        if r.survives_wo3=="YES": ax_d.annotate("\u2713",(i+0.24,abs(r.slope_wo3)),textcoords="offset points",xytext=(0,2),ha="center",fontsize=7.0,color="#C2401A")
    ax_d.set_xticks(xx); ax_d.set_xticklabels([s.replace("_","\n") for s in cc.set],fontsize=5.2,linespacing=1.3)
    ax_d.set_title(f"{int((cc.survives_wo3=='YES').sum())} of the {len(cc)} hits survive removing their 3 strongest genes (\u2713)",loc="left",fontsize=7.6)
    ax_d.legend(fontsize=5.6,frameon=False,loc="upper left")
else:
    ax_d.text(.5,.5,"no set reaches BH < 0.05",ha="center",va="center",transform=ax_d.transAxes,fontsize=7,color="#777777"); ax_d.set_xticks([])
ax_d.set_ylabel("|AP slope| per 100 \u00b5m",fontsize=7.0); ax_d.spines[["top","right"]].set_visible(False)
panel_letter(ax_a,"a"); panel_letter(AXG[(PWS[0],"ligand")],"b"); panel_letter(ax_c,"c"); panel_letter(ax_d,"d")
NP=" \u00b7 ".join(f"{k} {int((inb&(lab5==FULL7[k])).sum()):,}" for k in WANT)
fig.text(.006,.985,"AP trends of five signalling pathways restricted to DE, AVE, VE1, VE2, Node, APS and PS, CS7",fontsize=10.6)
fig.text(.006,.962,
 f"obj6_obj7_merged_curated_final.rds, 39Type, CS7 (obj6), curation-kept, restricted to seven populations: {NP} = {int(inb.sum()):,} cells inside the AP band [{lo5:.0f}, {hi5:.0f}] \u00b5m (the 1\u201399th percentile\n"
 "of these cells). Identical specification to the EPI/ECT/Node/APS/PS figure: set CP10K summed then divided by set size, depth-adjusted by regressing on log total counts and taking residuals about the mean, Gaussian-kernel smoothed along AP\n"
 "(h = 0.06 \u00d7 AP span); band = SEM from the effective sample size. Slopes are OLS with log depth AND population fixed effects (six dummies), so they are gradients WITHIN each population, not the consequence of where the populations sit \u2014\n"
 "panel (a) shows the endoderm populations spread over the whole axis while Node/APS/PS are localised (each density scaled to its own peak). \u2605 and a ringed dot mark BH < 0.05 across the 20 sets of that version; each is also compared against 200 detection-matched random gene sets.\n"
 "Curves and slopes use the COMPLETE gene lists (all human family members present in the data); the concise-list results are in the CSV. Panel (d): a set-level trend that disappears when its three strongest genes are removed is one gene's trend, not the family's.",
 fontsize=6.1,color=META_GREY,linespacing=1.5,va="top")
for e in ["png","pdf","svg"]: fig.savefig(f"cs7_seven_pop_ap_trends.{e}", **({"dpi":185} if e=="png" else {}), bbox_inches="tight")
fig.canvas.draw(); r_=fig.canvas.get_renderer()
tx=[(t,t.get_window_extent(r_)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
axlab={a_.xaxis.label for a_ in fig.axes}|{a_.yaxis.label for a_ in fig.axes}
ov=[(a.get_text()[:16],b.get_text()[:16]) for i_,(a,ba) in enumerate(tx) for b,bb in tx[i_+1:]
    if ba.overlaps(bb) and a is not b and a not in axlab and b not in axlab and not (a.axes is not None and b.axes is not None and a.axes is not b.axes)]
print("\nwithin-panel overlaps:",len(ov),ov[:5])
bf=open("cs7_seven_pop_ap_trends.pdf","rb").read()
print(f"PDF rasters {bf.count(b'/Subtype /Image')+bf.count(b'/Subtype/Image')} | Type3 {bf.count(b'/Type3')}")
CVX=[]
for ver in ["concise","complete"]:
    for k in sorted(COMPLETE):
        gc,gm,gs_=SETCUR[(ver,k)]
        CVX.append(pd.DataFrame(dict(version=ver,pathway=k.split("_")[0],kind=k.split("_")[1],n_genes=len((CONCISE if ver=="concise" else COMPLETE)[k]),
                                     AP_um=np.round(gc,2),set_mean_per_gene_CP10K=np.round(gm,4),sem=np.round(gs_,4))))
pd.concat(CVX,ignore_index=True).to_csv("cs7_seven_pop_ap_curves.csv",index=False)
pd.DataFrame(dict(cell=C7.cell,label=lab5,AP_um=np.round(ap7,2),in_band=inb)).to_csv("cs7_seven_pop_cells.csv",index=False)
json.dump(dict(COMPLETE=COMPLETE,CONCISE=CONCISE),open("cs7_pathway_gene_sets.json","w"),indent=1)
print("done")
