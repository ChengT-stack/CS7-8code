# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: artifact 803757dc build_cs7_3dview_gene.py (session 824ef1ce, 2026-11-16)
# sha256 of original: 5dc90c23ecd7d93bac6bf05daff439beb56940825e361b9f1551d0bad3793316
# Methods paragraphs: P352 (dorsal views, per-cell log1p CP10K)
# Produces: additional gene panels in the style of Supplementary Figure 4B (CS7 dorsal 3D view of
#     EPI/ECT/node/APS/PS; usage: python build_cs7_3dview_gene.py GENE ...)
# Edits/notes: dataprep path -> HGC_DATA; font folder -> HGC_FONTS. The original Supplementary Figure 4B/5B
#     panels were drawn earlier (code not found); this script reproduces their geometry for added genes.
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

"""Dorsal 3D-view expression panel for the CS7 embryo (EPI, ECT, primitive node, APS, PS),
drawn to match the existing panels of the CS7 supplementary figure (panel B).
Usage: python build_cs7_3dview_gene.py FN1 [GENE2 ...]
Geometry and colour settings were fitted to the existing MSX2 / HAND1 / CDH2 panels:
x = section axis (z, 15-um steps, mirrored), y = A-P (posterior at the bottom).
"""
import sys, glob, shutil
import numpy as np, pandas as pd, scipy.io
import matplotlib; matplotlib.use("Agg")
import matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib import font_manager as fm

DD = (str(DATA) + "/dataprep/")
TYPES = ["EPI", "ECT", "Node", "APS", "PS"]
PX, PY = 0.555 * 595.276 / 4500, 0.51 * 595.276 / 4500   # pt per um (as in the existing panels)
T0, T1, VQ = 0.20, 0.704, 0.99                              # magma range; cap = 99th pct of expressing cells
S_POS, S_ZERO, GREY, FS = 0.34, 0.22, "#D9D9D9", 5.0

for f in glob.glob(os.path.join(FONT_DIR, "arial*.ttf")):
    fm.fontManager.addfont(f)
mpl.rcParams.update({"font.family": "Arial", "pdf.fonttype": 42, "svg.fonttype": "none"})

cells = pd.read_csv(DD + "export/CS7_cells.csv")
fr = pd.read_csv(DD + "frames/CS7_frames.csv")[["cell", "AP_um"]]
df = cells.merge(fr, on="cell", validate="1:1")
assert (df.cell.values == cells.cell.values).all()
genes = pd.read_csv(DD + "export/genes.csv")["gene"].astype(str).values
M = scipy.io.mmread(DD + "export/CS7_counts.mtx").tocsr()
if M.shape[0] == len(genes): M = M.T.tocsr()
assert M.shape == (len(df), len(genes))
tot = np.asarray(M.sum(1)).ravel()
keep = df.label_short.isin(TYPES).values
x = -df.z_um.values[keep].astype(float); y = df.AP_um.values[keep].astype(float)
cmap = mpl.colors.LinearSegmentedColormap.from_list("m", mpl.colormaps["magma"](np.linspace(T0, T1, 256)))

def draw(gene, stem, pad=2.0, top=7.5):
    c = np.asarray(M[:, np.where(genes == gene)[0][0]].todense()).ravel()
    v = np.log1p(c / tot * 1e4)[keep]; pos = v > 0
    Wd, Hd = (x.max() - x.min()) * PX, (y.max() - y.min()) * PY
    Wf, Hf = (Wd + 2 * pad) / 72, (Hd + 2 * pad + top) / 72
    fig = plt.figure(figsize=(Wf, Hf)); ax = fig.add_axes([pad / 72 / Wf, pad / 72 / Hf, Wd / 72 / Wf, Hd / 72 / Hf])
    ax.scatter(x[~pos], y[~pos], s=S_ZERO, c=GREY, lw=0, clip_on=False)
    o = np.argsort(v[pos]); vmin, vmax = v[pos].min(), np.quantile(v[pos], VQ)
    ax.scatter(x[pos][o], y[pos][o], s=S_POS, c=v[pos][o], cmap=cmap, vmin=vmin, vmax=vmax, lw=0, clip_on=False)
    ax.set_xlim(x.min(), x.max()); ax.set_ylim(y.max(), y.min()); ax.axis("off")
    fig.text(0.5, 1 - 0.3 / 72 / Hf, gene, fontsize=FS, style="italic", ha="center", va="top")
    fig.savefig(stem + ".pdf", transparent=True); fig.savefig(stem + ".png", dpi=1200); plt.close(fig)
    shutil.copy(stem + ".pdf", stem + ".ai")
    lab = df.label_short.values
    tab = (pd.DataFrame({"type": lab, "pos": c > 0, "cp10k": c / tot * 1e4}).groupby("type")
           .agg(n=("pos", "size"), pct_detected=("pos", lambda s: round(100 * s.mean(), 1)), mean_CP10K=("cp10k", lambda s: round(s.mean(), 2))))
    tab.loc[[t for t in TYPES + ["DE", "AVE", "VE1", "VE2"] if t in tab.index]].to_csv(stem + "_detection_by_type.csv")
    return dict(gene=gene, cells=int(keep.sum()), detected=int(pos.sum()), pct=round(100 * float(pos.mean()), 1), cap_log1p_CP10K=round(float(vmax), 3))

if __name__ == "__main__":
    for g in (sys.argv[1:] or ["FN1"]):
        assert g in genes, f"{g} not in panel"
        print(draw(g, f"SuppFig_CS7_3Dview_{g}"))
