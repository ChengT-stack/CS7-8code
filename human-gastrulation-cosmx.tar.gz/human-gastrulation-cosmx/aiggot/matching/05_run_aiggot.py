# Re-run GG-OT (final settings) and variants; save couplings.
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import os, sys, json, numpy as np, pandas as pd, scipy.sparse as sp, anndata as ad, scipy.io, time
os.environ.update(KMP_AFFINITY="disabled", OMP_NUM_THREADS="8")
B=DATA + "/cs7_cs8_matching/"; O=os.path.join(os.environ.get('HGC_OUT', 'results'), 'aiggot', 'couplings') + '/'; os.makedirs(O, exist_ok=True)
sys.path.insert(0,os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lib"))   # repo copy of ggot_proposal/final + starmatch.py
import ggot_match as GM, ggot
A=ad.read_h5ad(B+"dataprep/embedding/cs7_cs8_germlayers_harmony.h5ad",backed="r")
obs=A.obs.copy(); g_all=obs.label_short.astype(str).to_numpy(); emb=obs.embryo.astype(str).to_numpy()
i7=np.where(emb=="CS7")[0]; i8=np.where(emb=="CS8")[0]; g7=g_all[i7]; g8=g_all[i8]
SPC=["AP_arc_frac","LR_frac","DV_gap_units"]
fr7=pd.read_csv(B+"dataprep/frames/CS7_frames.csv").set_index("cell"); fr8=pd.read_csv(B+"dataprep/frames/CS8_frames.csv").set_index("cell")
S7=fr7.reindex(A.obs_names[i7])[SPC].to_numpy(float); S8=fr8.reindex(A.obs_names[i8])[SPC].to_numpy(float)
Hhs=np.load(B+"matching/harmony_smoothed.npy")
TT=json.load(open(B+"matching/transition_table_used.json")); trans={tuple(k.split("->")):v for k,v in TT.items()}
a=obs.z_weight.to_numpy(float)[i7]; b=obs.z_weight.to_numpy(float)[i8]
c7n=np.array(A.obs_names[i7]); c8n=np.array(A.obs_names[i8])
pd.DataFrame({'cell':c7n,'label':g7}).to_csv(O+'h5ad_cs7_cells.csv',index=False); pd.DataFrame({'cell':c8n,'label':g8}).to_csv(O+'h5ad_cs8_cells.csv',index=False)
src_drop=np.load(O+'src_drop.npy') if os.path.exists(O+'src_drop.npy') else np.zeros(len(i7),bool)   # FN1-defined VE (CS7)
tgt_drop=np.load(O+'tgt_drop.npy') if os.path.exists(O+'tgt_drop.npy') else np.zeros(len(i8),bool)   # CS8 VE targets
runs=sys.argv[1].split(',')
for tag in runs:
    prior = 'noprior' not in tag; dropVE = 'noVE' in tag
    s=np.where(~src_drop)[0] if dropVE else np.arange(len(i7)); t=np.where(~tgt_drop)[0] if dropVE else np.arange(len(i8))
    t0=time.time(); res=GM.match(Hhs[i7][s],Hhs[i8][t],S7[s],S8[t],g7[s],g8[t],a[s],b[t],trans,space="gated",prior=prior)
    M=res["M"].tocoo(); Mf=sp.csr_matrix((M.data,(s[M.row],t[M.col])),shape=(len(i7),len(i8)))
    sp.save_npz(O+f'M_{tag}.npz',Mf); print(tag,'nnz',Mf.nnz,'sec',round(time.time()-t0,1),'src',len(s),'tgt',len(t),flush=True)
