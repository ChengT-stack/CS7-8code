"""Star-constrained spatiotemporal matching of CS7 cells to CS8 cells.

cost(i, j) = d_expr(i, j)^2 + lam * d_space(i, j)^2 + penalty(class(group_i, group_j))
  d_expr : Euclidean distance in the joint Harmony embedding, divided by the median 15-NN
           distance of the pooled embedding (dimensionless)
  d_space: Euclidean distance between normalised anatomical coordinates
           (AP_frac, LR_frac, DV_gap_units), divided by its pooled median 15-NN distance
  penalty: 0 direct | p_allowed | p_indirect | p_cross; 'forbidden' pairs get no arc

Steps
 1. candidate graph: for every CS7 cell its k cheapest CS8 cells and for every CS8 cell its
    k cheapest CS7 cells (union), within each non-forbidden group pair
 2. entropic unbalanced OT (Sinkhorn, KL-relaxed marginals, z-sampling weights as marginals)
    -> soft coupling pi; used (a) to decide the star direction of each group / cell and
    (b) as a diagnostic; the hard matching uses the cost directly
 3. star rounding by minimum-cost flow (OR-tools):
      CS7 cell of an EXPANDING group : out-degree 1..K, its children have in-degree 1
      CS7 cell of a CONTRACTING group: out-degree exactly 1, its partner may receive up to K
                                       such cells (and only such cells)
    each CS8 cell is assigned to one direction from the soft coupling (majority of incoming
    mass), so no connected component mixes both directions -> bipartite forest of stars.
    Dummy nodes let a cell stay unmatched at cost c_unmatched.
"""
import numpy as np, pandas as pd, scipy.sparse as ssp
from scipy.spatial import cKDTree

CLASS_PENALTY = {"direct": 0.0, "allowed": 0.5, "indirect": 1.0, "penalised": 2.0}   # in units of the median candidate cost


def knn_scale(X, k=15):
    d, _ = cKDTree(X).query(X, k=k + 1)
    return float(np.median(d[:, -1]))


def _topk_rows(C, k):
    """keep the k smallest entries of every row of a csr matrix"""
    C = C.tocsr(); C.sum_duplicates()
    keep = np.zeros(C.nnz, bool)
    for i in range(C.shape[0]):
        s, e = C.indptr[i], C.indptr[i + 1]
        if e - s <= k:
            keep[s:e] = True
        else:
            keep[s + np.argsort(C.data[s:e])[:k]] = True
    coo = C.tocoo()
    return ssp.csr_matrix((coo.data[keep], (coo.row[keep], coo.col[keep])), shape=C.shape)


K_CAND = {"direct": 40, "allowed": 40, "indirect": 20, "penalised": 10}


def build_candidates(E7, E8, S7, S8, g7, g8, trans, lam=1.0, k_cand=K_CAND,
                     class_penalty=CLASS_PENALTY, lam_by_group=None, scales=None):
    """Sparse cost matrix over candidate pairs plus the scale factors used."""
    if scales is None:
        se = knn_scale(np.vstack([E7, E8])); ss = knn_scale(np.vstack([S7, S8]))
    else:
        se, ss = scales["scale_expr"], scales["scale_space"]
    E7n, E8n, S7n, S8n = E7 / se, E8 / se, S7 / ss, S8 / ss
    rows, cols, vals = [], [], []
    idx8_by = {h: np.where(g8 == h)[0] for h in np.unique(g8)}
    idx7_by = {g: np.where(g7 == g)[0] for g in np.unique(g7)}
    for g, idx7 in idx7_by.items():
        lg = lam * (lam_by_group.get(g, 1.0) if lam_by_group else 1.0)
        X7 = np.hstack([E7n[idx7], np.sqrt(lg) * S7n[idx7]])
        for h, idx8 in idx8_by.items():
            cls = trans.get((g, h), "penalised")
            if cls == "forbidden":
                continue
            pen = class_penalty[cls]
            kc = k_cand[cls] if isinstance(k_cand, dict) else k_cand
            X8 = np.hstack([E8n[idx8], np.sqrt(lg) * S8n[idx8]])
            kk8 = min(kc, len(idx8)); kk7 = min(kc, len(idx7))
            d, j = cKDTree(X8).query(X7, k=kk8); d = np.atleast_2d(d).reshape(len(idx7), kk8); j = np.atleast_2d(j).reshape(len(idx7), kk8)
            rows.append(np.repeat(idx7, kk8)); cols.append(idx8[j.ravel()]); vals.append(d.ravel() ** 2 + pen)
            d, i = cKDTree(X7).query(X8, k=kk7); d = np.atleast_2d(d).reshape(len(idx8), kk7); i = np.atleast_2d(i).reshape(len(idx8), kk7)
            rows.append(idx7[i.ravel()]); cols.append(np.repeat(idx8, kk7)); vals.append(d.ravel() ** 2 + pen)
    C = ssp.coo_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(len(g7), len(g8)))
    C = C.tocsr(); C.sum_duplicates()
    # duplicates were summed: fix by recomputing as min via a second pass
    coo = C.tocoo()
    df = pd.DataFrame(dict(r=np.concatenate(rows), c=np.concatenate(cols), v=np.concatenate(vals)))
    df = df.groupby(["r", "c"], as_index=False).v.min()
    # normalise: raw squared distances (without penalty) are divided by their median over
    # all candidate pairs, so that 1 = a typical candidate distance; penalties are then
    # expressed in these units (added after normalisation)
    pen_arr = np.array([class_penalty[trans.get((g7[i], g8[j]), "penalised")] for i, j in zip(df.r.to_numpy(), df.c.to_numpy())])
    raw = df.v.to_numpy() - pen_arr
    med = float(np.median(raw[pen_arr == 0])) if (pen_arr == 0).any() else float(np.median(raw))   # median DIRECT-pair cost = 1
    C = ssp.csr_matrix((raw / med + pen_arr, (df.r.to_numpy(), df.c.to_numpy())), shape=(len(g7), len(g8)))
    return C, dict(scale_expr=se, scale_space=ss, cost_median=med)


def _grouped_lse(vals, ptr):
    """logsumexp of vals within contiguous groups delimited by ptr (csr-style)"""
    n = len(ptr) - 1; out = np.full(n, -np.inf)
    nz = ptr[1:] > ptr[:-1]
    if not nz.any():
        return out
    starts = ptr[:-1][nz]
    mx = np.maximum.reduceat(vals, starts)
    rep = np.repeat(mx, np.diff(ptr)[nz])
    ssum = np.add.reduceat(np.exp(vals - rep), starts)
    out[nz] = mx + np.log(ssum)
    return out


def sinkhorn_unbalanced_sparse(C, a, b, eps=0.1, tau_a=1.0, tau_b=1.0, n_iter=5000, tol=1e-6):
    """Log-domain entropic unbalanced OT on a sparse cost (absent pairs = infinite cost):
    min <pi,C> - eps H(pi) + tau_a KL(pi1|a) + tau_b KL(pi^T1|b); u = (a/Kv)^(tau/(tau+eps)).
    Validated against ot.unbalanced.sinkhorn_unbalanced (max |diff| 1e-5 on a dense test)."""
    C = C.tocsr(); C.sort_indices(); n, m = C.shape
    coo = C.tocoo(); r, c, Cd = coo.row, coo.col, coo.data           # csr order
    oc = np.argsort(c, kind="stable"); rT, dT = r[oc], Cd[oc]
    rptr = C.indptr; cptr = np.r_[0, np.cumsum(np.bincount(c, minlength=m))]
    a = np.asarray(a, float); b = np.asarray(b, float); la, lb = np.log(a), np.log(b)
    f = np.zeros(n); g = np.zeros(m); fa = tau_a / (tau_a + eps); fb = tau_b / (tau_b + eps)
    for it in range(n_iter):
        fn = fa * eps * (la - _grouped_lse((g[c] - Cd) / eps, rptr))
        gn = fb * eps * (lb - _grouped_lse((fn[rT] - dT) / eps, cptr))
        err = max(np.abs(fn - f).max(), np.abs(gn - g).max()); f, g = fn, gn
        if err < tol:
            break
    pi = ssp.csr_matrix((np.exp((f[r] + g[c] - Cd) / eps), (r, c)), shape=(n, m))
    return pi, dict(iterations=it + 1, err=float(err), mass=float(pi.sum()), mass_in=float(a.sum()), mass_out=float(b.sum()))


def group_directions(pi, a, g7, b=None):
    """Allocate each CS8 cell's weight b_j to CS7 groups in proportion to its incoming soft
    mass; a CS7 group is 'expanding' if the weight allocated to it >= its own weight a_g."""
    pi = pi.tocsr(); m = pi.shape[1]
    if b is None:
        b = np.ones(m)
    colsum = np.asarray(pi.sum(0)).ravel(); colsum[colsum == 0] = 1.0
    coo = pi.tocoo(); share = coo.data / colsum[coo.col] * b[coo.col]
    out = {}
    for g in np.unique(g7):
        alloc = share[g7[coo.row] == g].sum()
        out[g] = "expanding" if alloc >= a[g7 == g].sum() else "contracting"
    return out


def cell_directions(pi, g7, gdir):
    """per CS8 cell: direction of the majority of its incoming soft mass"""
    coo = pi.tocoo(); exp7 = np.array([gdir[g] == "expanding" for g in g7])
    m_exp = np.bincount(coo.col, weights=coo.data * exp7[coo.row], minlength=pi.shape[1])
    m_con = np.bincount(coo.col, weights=coo.data * (~exp7[coo.row]), minlength=pi.shape[1])
    return np.where(m_exp >= m_con, "expanding", "contracting")


def star_round(C, g7, gdir, dir8, K=4, c_unmatched=None, scale=1e3, pi=None, delta=0.5):
    """Min-cost-flow rounding to a star forest. C: sparse cost over candidate arcs."""
    from ortools.graph.python import min_cost_flow
    coo = C.tocoo(); n, m = C.shape
    exp7 = np.array([gdir[g] == "expanding" for g in g7]); exp8 = dir8 == "expanding"
    ok = exp7[coo.row] == exp8[coo.col]                       # direction-compatible arcs only
    r, c, w = coo.row[ok], coo.col[ok], coo.data[ok]
    if c_unmatched is None:
        c_unmatched = float(np.percentile(w, 97.5))
    S, T, D7, D8 = 0, 1, 2, 3
    N7 = lambda i: 4 + i
    N8 = lambda j: 4 + n + j
    B = max(m - n, 0) + m + n                                   # bypass supply (generous)
    mcf = min_cost_flow.SimpleMinCostFlow()
    add = lambda u, v, cap, cst: mcf.add_arc_with_capacity_and_unit_cost(int(u), int(v), int(cap), int(round(cst * scale)))
    for i in np.where(exp7)[0]:
        for k in range(1, K):
            add(S, N7(i), 1, delta * k)                         # k-th extra child costs k*delta (convex star-size cost)
    for j in np.where(~exp8)[0]:
        for k in range(1, K):
            add(N8(j), T, 1, delta * k)                         # k-th extra source
    for i, j, cst in zip(r, c, w):
        add(N7(i), N8(j), 1, cst)
    for i in range(n):
        add(N7(i), D8, 1, c_unmatched)                          # CS7 cell left unmatched
    for j in range(m):
        add(D7, N8(j), 1, c_unmatched)                          # CS8 cell left unmatched
    add(S, D7, m, 0); add(D8, T, n, 0); add(S, T, B, 0)
    mcf.set_node_supply(S, int(B)); mcf.set_node_supply(T, -int(B + n - m))
    for i in range(n):
        mcf.set_node_supply(N7(i), 1)
    for j in range(m):
        mcf.set_node_supply(N8(j), -1)
    status = mcf.solve()
    if status != mcf.OPTIMAL:
        raise RuntimeError(f"min-cost flow status {status}")
    rows, cols = [], []
    for k in range(mcf.num_arcs()):
        if mcf.flow(k) > 0:
            u, v = mcf.tail(k), mcf.head(k)
            if 4 <= u < 4 + n and 4 + n <= v < 4 + n + m:
                rows.append(u - 4); cols.append(v - 4 - n)
    M = ssp.csr_matrix((np.ones(len(rows)), (rows, cols)), shape=(n, m))
    return M, c_unmatched


def star_summary(M):
    out = np.asarray(M.sum(1)).ravel(); inn = np.asarray(M.sum(0)).ravel(); coo = M.tocoo()
    return dict(n7=M.shape[0], n8=M.shape[1],
                n7_matched=int((out > 0).sum()), n7_unmatched=int((out == 0).sum()),
                n8_matched=int((inn > 0).sum()), n8_unmatched=int((inn == 0).sum()),
                out_degree_hist=np.bincount(out.astype(int)).tolist(),
                in_degree_hist=np.bincount(inn.astype(int)).tolist(),
                many_to_many_edges=int(((out[coo.row] > 1) & (inn[coo.col] > 1)).sum()))


def flow_table(M, g7, g8):
    coo = M.tocoo()
    return pd.crosstab(pd.Series(g7[coo.row], name="CS7"), pd.Series(g8[coo.col], name="CS8"))


def run_matching(E7, E8, S7, S8, g7, g8, a, b, trans, lam=1.0, k_cand=K_CAND, eps=0.1, tau=3.0, K=4,
                 class_penalty=CLASS_PENALTY, lam_by_group=None, c_unmatched=5.0, delta=0.5, C=None, scales=None):
    if C is None:
        C, scales = build_candidates(E7, E8, S7, S8, g7, g8, trans, lam, k_cand, class_penalty, lam_by_group)
    pi, info = sinkhorn_unbalanced_sparse(C, a, b, eps=eps, tau_a=tau, tau_b=tau)
    gdir = group_directions(pi, a, g7, b); dir8 = cell_directions(pi, g7, gdir)
    M, cu = star_round(C, g7, gdir, dir8, K=K, c_unmatched=c_unmatched, delta=delta)
    return dict(C=C, pi=pi, M=M, scales=scales, sinkhorn=info, group_direction=gdir, dir8=dir8,
                c_unmatched=cu, summary=star_summary(M), flow=flow_table(M, g7, g8))
