# gastruloid/01_preprocess/fix_heemskerk_group.py
# Source: reconstructed from transcript 824ef1ce (messages 7092-7104)
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Rebuild the Heemskerk (GSE271604) 42 h group with rep1 read in the correct orientation (gall/groups_fix/Hee_42.h5ad).
# Reconstructed verbatim from session transcript 824ef1ce (code was run cell-by-cell in a
# persistent kernel and never saved as a file). Cells are concatenated in execution order;
# inspection-only and figure-polishing cells are omitted, and cells that stopped with an error are
# truncated at the failing line (marked). See PROVENANCE.md.
import json, numpy as np, pandas as pd, scipy.sparse as sp, anndata as ad


# ---- cell [frame 824ef1ce, message 7092] Rebuilding Heemskerk group with correctly oriented rep1
import scanpy as sc, os
R=(str(HGC_DATA) + '/gastruloid_sc/GSE271604/')
df=pd.read_csv(R+'GSE271604_42h_rep1_filtered_Counts.csv.gz', index_col=0)
df=df.loc[:, ~df.columns.str.startswith('Unnamed')]
print(df.shape, df.index[:2].tolist(), df.columns[:3].tolist(), float(df.values.max()))
r1=ad.AnnData(sp.csr_matrix(df.values.astype(np.float32)), obs=pd.DataFrame(index=df.index.astype(str)), var=pd.DataFrame(index=df.columns.astype(str))); r1.var_names_make_unique()
mt=r1.var_names.str.startswith('MT-'); r1.obs['n_umi']=np.asarray(r1.X.sum(1)).ravel(); r1.obs['n_genes']=np.asarray((r1.X>0).sum(1)).ravel()
r1.obs['pmt']=np.asarray(r1.X[:,mt].sum(1)).ravel()/r1.obs.n_umi*100
print('rep1 raw', r1.shape, 'MT genes', int(mt.sum()), r1.obs[['n_umi','n_genes','pmt']].median().round(1).to_dict(), 'integer counts', bool(np.allclose(df.values[:200], np.round(df.values[:200]))))
keep=(r1.obs.n_genes>=500)&((r1.obs.pmt<=20)|(mt.sum()==0)); r1=r1[keep.values].copy(); print('rep1 kept', r1.n_obs)
old=ad.read_h5ad('gall/groups/Hee_42.h5ad'); r2=old[old.obs.replicate=='rep2'].copy()
nz=np.asarray((r2.X>0).sum(0)).ravel(); 
# rep2 var: drop barcode-named columns introduced by the transposed rep1
isbc=r2.var_names.str.match(r'^[ACGT]{16}-1$'); print('barcode-named vars', int(isbc.sum()), 'rep2 genes', int((~isbc).sum()))
r2=r2[:, ~isbc].copy()
ann=pd.read_csv(R+'GSM8373031_Cluster_Annotation.csv.gz'); ann.columns=[c.strip() for c in ann.columns]
print(ann.shape, ann.sample_labels.value_counts().to_dict(), ann.annotation.value_counts().to_dict())
r1.obs['replicate']='rep1'; r1.obs['sub']='NA'; r1.obs_names=['rep1:'+x for x in r1.obs_names]
print(r2.obs_names[:2].tolist())
b1=pd.Index(r1.obs_names.str.replace('rep1:','')); b2=pd.Index(r2.obs_names.str.replace('rep2:',''))
for lab in ann.sample_labels.unique():
    s=set(ann.index[ann.sample_labels==lab]) if False else set(ann.loc[ann.sample_labels==lab,'index'])
    print(lab, len(s), 'in rep1', len(s&set(b1)), 'in rep2', len(s&set(b2)))


# ---- cell [frame 824ef1ce, message 7094] Matching author annotation barcodes to rep2
a2=ann[ann.sample_labels=='42h_2']; print(a2['index'].head(3).tolist())
core2=a2['index'].str.replace(r'-\d+$','',regex=True); cb2=pd.Index(b2.str.replace(r'-\d+$','',regex=True))
print('core overlap', len(set(core2)&set(cb2)), 'of', len(core2))
h=pd.read_csv(R+'GSM8373031_42h_rep2_filtered_Counts.csv.gz', index_col=0, nrows=3); print(h.shape, h.index.tolist(), h.columns[:3].tolist())


# ---- cell [frame 824ef1ce, message 7096] Writing corrected Heemskerk group file
amap=dict(zip(ann['index'].str.replace('_BMP4','',regex=False)+'|'+ann.sample_labels, ann.annotation))
r1.obs['author_annotation']=[amap.get(b+'|42h_1','not in author object') for b in b1]
r2.obs['author_annotation']=[amap.get(b+'|42h_2','not in author object') for b in b2]
print(r1.obs.author_annotation.value_counts().to_dict()); print(r2.obs.author_annotation.value_counts().to_dict())
r1.obs=r1.obs[['replicate','n_umi','n_genes','sub','author_annotation']]; r2.obs=r2.obs[['replicate','n_umi','n_genes','sub','author_annotation']]
r2.obs['sub']=r2.obs['sub'].astype(str)
H=ad.concat([r1,r2], join='inner'); print(H.shape, H.obs.replicate.value_counts().to_dict())
os.makedirs('gall/groups_fix', exist_ok=True); H.write_h5ad('gall/groups_fix/Hee_42.h5ad')
json.dump(dict(dataset='Heemskerk 2024', species='human', label='Micropattern 2D gastruloid 42 h', hours=42, cells_kept=int(H.n_obs), note='rep1 re-loaded with correct orientation (4,095 cells x 16,141 genes); rep2 from CellRanger filtered matrix'), open('gall/groups_fix/Hee_42.json','w'))


# ---- cell [frame 824ef1ce, message 7104] Rebuilding Heemskerk file with gene union
H=ad.concat([r1,r2], join='outer', fill_value=0); H.X=sp.csr_matrix(H.X).astype(np.float32)
H.var['in_all_libs']=H.var_names.isin(r1.var_names)&H.var_names.isin(r2.var_names)
print(H.shape, int(H.var.in_all_libs.sum()))
H.write_h5ad('gall/groups_fix/Hee_42.h5ad')
# (the remainder of this cell patched reanno/pipeline.py in place; the patched pipeline.py is the version in 04_denovo_annotation/)
