# staging/01_milestones/evidence_monkey.py
# Source: reconstructed from transcript 6696c2c1
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Milestone evidence review, cynomolgus monkey CS8/CS9/CS11 embryos (input to audit_calls.py).
# Reconstructed verbatim from session transcript 6696c2c1 (code was run cell-by-cell in a
# persistent kernel and never saved as a file). Cells are concatenated in execution order;
# inspection-only and figure-polishing cells are omitted, and cells that stopped with an error are
# truncated at the failing line (marked). See PROVENANCE.md.


# ---- cell [frame 6696c2c1, message 9] Reading workbook rules and monkey sheets
import pandas as pd, os
pd.set_option('display.width',250); pd.set_option('display.max_columns',30); pd.set_option('display.max_colwidth',120)
B=(str(HGC_DATA) + '/milestone_evidence/')
wb=pd.read_excel(B+'20261030-Fig_milestone_axis_human_monkey_data.xlsx',sheet_name=None)
for k,v in wb.items(): print(k,v.shape, list(v.columns)[:15])
print(wb['rules'].to_string())


# ---- cell [frame 6696c2c1, message 11] Printing monkey sheets and definitions
print(wb['milestone_definitions'].to_string())
print(wb['monkey_evidence'].to_string())
print(wb['monkey_recluster_best'].to_string())
print(wb['mouse_TBXTpos_pool'].to_string())
mc=wb['milestone_calls']; print([c for c in mc.columns if 'Monkey' in c])


# ---- cell [frame 6696c2c1, message 25] Loading monkey counts and metadata
import numpy as np, pandas as pd, scipy.sparse as sp, scanpy as sc, os
print(sc.__version__)
D=(str(HGC_DATA) + '/GSE193007/')
z=np.load(D+'counts_recovered_int.npz'); X=sp.csr_matrix((z['data'],z['indices'],z['indptr']),shape=tuple(z['shape']))
g=pd.read_csv(D+'genes.csv').iloc[:,0].astype(str).values; m=pd.read_csv(D+'MFE56636-meta.csv',index_col=0)
m['cell_type']=m.cell_type.astype(str).str.strip()
print(X.shape,len(g),m.shape, m.doublet.value_counts().to_dict())
print(pd.crosstab(m.cell_type,m['sample']).to_string())
print(os.path.exists((str(HGC_DATA) + '/staging/layer_rescue/mouse_milestone_genesets.csv')))
B=pd.read_parquet((str(HGC_DATA) + '/milestone_evidence/mz/monkey/monkey_marker_binary.parquet')); print(B.shape, list(B.columns))


# ---- cell [frame 6696c2c1, message 27] Reproducing TBXT pool and DE/Node metrics
gi={x:i for i,x in enumerate(g)}
print([x for x in ['T','TBXT','NKX1-2','NKX2-5','HOXB1','HBZ','HBE1','HBA1','GATA1','SOX2','ETV2','KDR','DPPA3'] if x in gi])
Xc=X.tocsc()
def det(gene): return (np.asarray(Xc[:,gi[gene]].todense()).ravel()>0)
s=m['sample'].values; ct=m.cell_type.values
T=det('T'); EO=det('EOMES'); HA1=det('HOXA1')
EXE={'AM','VE','ys.Endo1','ys.Endo2','ys.Meso1','ys.Meso2','ExE.Meso','AI','EC','BP','Ery1','Ery2','Mac','PGC'}
EMB=~pd.Series(ct).isin(EXE).values
for name,mask in [('all',np.ones(len(ct),bool)),('emb',EMB),('emb+AI',EMB|(ct=='AI'))]:
    r=[]
    for ss in ['CS8-e1','CS8-e2','CS9-e1','CS9-e2','CS11-e1','CS11-e2']:
        k=mask&T&(s==ss); r.append((ss,k.sum(),round(100*EO[k].mean(),1),round(100*HA1[k].mean(),1)))
    print(name,r)


# ---- cell [frame 6696c2c1, message 29] Tabulating TBXT+ cells by cell type
tb=pd.crosstab(ct[T],s[T]); tb=tb[['CS8-e1','CS8-e2','CS9-e1','CS9-e2','CS11-e1','CS11-e2']]
print(tb[tb.sum(1)>5].to_string())
target=np.array([156,562,673,727,71,391])
import itertools
rows=tb.index[tb.sum(1)>3].tolist()
# greedy test of plausible sets
cands={'streak':['PS','APS','Nas.Meso','Caud.Meso','NMP','PSM','EPI','Node'],
 's2':['PS','APS','Nas.Meso','Caud.Meso','NMP','PSM','Node'],'s3':['PS','APS','Nas.Meso','Caud.Meso','NMP','PSM','EPI'],'s4':['PS','APS','Nas.Meso','Caud.Meso','NMP','PSM']}
for k,v in cands.items(): print(k, tb.reindex(v).fillna(0).sum().values)


# ---- cell [frame 6696c2c1, message 31] Reproducing evidence table numbers
L={**{k:'E' for k in ['EPI','ECT','PS','NMP','SE1','SE2','FB/MB/HB','SC','NC']},**{k:'M' for k in ['APS','Nas.Meso','Caud.Meso','PSM','Para.Meso','LP.Meso','Inter.Meso','Pharyg.Meso','Cardi.Meso','Cardi.','Rostr.Meso','Mes']},
   'Node':'X','DE':'N','Gut':'N',**{k:'Mx' for k in ['ExE.Meso','ys.Meso1','ys.Meso2','AI']}}
lay=pd.Series(ct).map(L).fillna('other').values
GL=['MESP1','TBX6','GSC','FOXA2','FOXJ1','CHRD','NOTO','SHH','SOX17','CER1','HOXA1','HOXB1','NKX1-2','CDX2','SOX2','HOXB8','HESX1','SIX3','MEOX1','TCF15','EOMES','T','NKX2-5','TNNT2','MYL7','NANOS3','DPPA3','TFAP2C','PRDM1','SOX17','ETV2','KDR','HAND1','TBX4','HOXA10','HBZ','HBE1','GATA1','TFAP2A']
GL=list(dict.fromkeys(GL))
Bd=pd.DataFrame({x:det(x) for x in GL}).rename(columns={'T':'TBXT'})
Bd['sample']=s; Bd['ct']=ct; Bd['layer']=lay
SAM=['CS8-e1','CS8-e2','CS9-e1','CS9-e2','CS11-e1','CS11-e2']
def pct(mask,gene): return round(100*Bd.loc[mask,gene].mean(),1) if mask.sum() else np.nan
out={}
for ss in SAM:
    S=Bd['sample']==ss; o={}
    pool=S&Bd.TBXT&Bd.layer.isin(['E','M'])
    o['TBXTpool_n']=pool.sum(); 
    for x in ['HOXA1','HOXB1','EOMES']: o['TBXT_'+x]=pct(pool,x)
    ps=S&(Bd.ct=='PS'); o['n_PS']=ps.sum()
    for x in ['HOXA1','HOXB1','EOMES']: o['PS_'+x]=pct(ps,x)
    de=S&(Bd.ct=='DE'); o['DE_GSC']=pct(de,'GSC'); o['DE_CER1']=pct(de,'CER1'); o['DE_GSCCER1']=round(100*(Bd.loc[de,'GSC']&Bd.loc[de,'CER1']).mean(),1)
    o['CE_n']=(S&Bd['NKX1-2']&Bd.CDX2).sum(); o['CE_n_E']=(S&Bd['NKX1-2']&Bd.CDX2&(Bd.layer=='E')).sum()
    meso=S&(Bd.layer=='M'); o['meso_n']=meso.sum(); o['meso_MT']=(meso&Bd.MEOX1&Bd.TCF15).sum()
    o['card']=(S&Bd['NKX2-5']&Bd.TNNT2).sum()
    o['ECT_HESX1']=pct(S&(Bd.ct=='ECT'),'HESX1'); o['ECT_SIX3']=pct(S&(Bd.ct=='ECT'),'SIX3')
    for x in ['EOMES','GSC','HOXB1','HOXB8']:
        o['bgExE_'+x]=pct(S&(Bd.layer.isin(['other'])),x)
    o['bg_EOMES_nonpool']=pct(S&~pool,'EOMES'); o['bg_GSC_nonDE']=pct(S&~de,'GSC')
    out[ss]=o
print(pd.DataFrame(out).to_string())


# ---- cell [frame 6696c2c1, message 33] Checking NKX2-5, NKX1-2 detection per cell type
print(sorted(set(m.cell_type.unique()))[:50])
raw=pd.read_csv(D+'MFE56636-meta.csv',usecols=['cell_type']).cell_type
print([repr(x) for x in raw.unique() if x!=x.strip()])
print((g=='NKX2-5').sum(), (g=='NKX1-2').sum())
t=Bd.groupby(['ct','sample'])[['NKX2-5','TNNT2','MYL7','NKX1-2','CDX2','HOXB8','HOXB1','SIX3','HESX1']].mean().mul(100).round(1)
print(t.loc[['Cardi.','Cardi.Meso','NMP','PS','Caud.Meso','FB/MB/HB','ECT','LP.Meso','ys.Meso1','Pharyg.Meso']].to_string())
P0=pd.read_csv((str(HGC_DATA) + '/milestone_evidence/mz/monkey/monkey_detection_by_sample_celltype.csv'))
print(P0[P0.ct.str.contains('Card')][['sample','ct','n','NKX2-5','TNNT2','MYL7']])


# ---- cell [frame 6696c2c1, message 35] Identifying original background population definition
tgt={'EOMES':[2.4,5.7,2.6,4.0,0.0,0.0],'GSC':[0.6,1.2,0.7,0.6,0.6,4.2],'HOXB1':[0,0,0,0,0.2,0.3],'HOXB8':[0,0.4,0.4,0.1,2.5,6.9]}
sets={'AM':['AM'],'AM+VE':['AM','VE'],'AM+VE+ysE':['AM','VE','ys.Endo1','ys.Endo2'],'VE+ysE':['VE','ys.Endo1','ys.Endo2'],'ECT/EPI':['ECT','EPI'],'SE':['SE1','SE2'],'AM+SE':['AM','SE1','SE2'],'E layer':[k for k,v in L.items() if v=='E'],
 'blood':['EC','BP','Ery1','Ery2','Mac'],'AM+VE+ys+blood':['AM','VE','ys.Endo1','ys.Endo2','EC','BP','Ery1','Ery2','Mac'], 'ECT':['ECT'],'FB+SC+NC':['FB/MB/HB','SC','NC','ECT']}
for nm,v in sets.items():
    r={x:[pct((Bd['sample']==ss)&Bd.ct.isin(v),x) for ss in SAM] for x in tgt}
    err=sum(np.nansum(np.abs(np.array(r[x],float)-np.array(tgt[x]))) for x in tgt)
    print(nm, round(err,1), r['GSC'], r['HOXB8'])


# ---- cell [frame 6696c2c1, message 39] Extracting monkey figure calls and mouse references
mcols=[c for c in mc.columns if c.startswith('Monkey') and '|' not in c]
print(mc[['milestone']+mcols].to_string())
print(mc[['milestone','Monkey CS11-e1 | evidence']].iloc[[14,18]].to_string())
print(wb['mouse_10x_calibration'].to_string())


# ---- cell [frame 6696c2c1, message 47] Computing gene-level metrics for all milestones
BG=['AM','ys.Endo1','ys.Endo2']; BGN='amnion + yolk-sac endoderm (AM, ys.Endo1, ys.Endo2)'
EMBP=Bd.layer.isin(['E','M','X','N'])
def P(mask,expr):
    n=int(mask.sum()); 
    if n==0: return 0,np.nan
    v=expr[mask] if not isinstance(expr,str) else Bd.loc[mask,expr]
    return n, round(100*float(np.mean(v)),1)
recs=[]
def add(ds,mid,metric,tpop,tmask,expr,bgmask=None,bgexpr=None,count=False,mref='',note=''):
    n,v=P(tmask,expr)
    if count: v=int(np.sum((expr[tmask] if not isinstance(expr,str) else Bd.loc[tmask,expr])))
    bn,bv=(np.nan,np.nan)
    if bgmask is not None:
        bn,bv=P(bgmask,bgexpr if bgexpr is not None else expr)
    recs.append(dict(dataset='Monkey '+ds,milestone_id=mid,metric=metric,target_population=tpop,n_target=n,value_target=v,
                     background_population=(BGN if bgmask is not None else ''),n_background=bn,value_background=bv,mouse_reference=mref,note=note))
both=lambda a,b:(Bd[a]&Bd[b]).values
for ss in SAM:
    S=(Bd['sample']==ss).values; c11=ss.startswith('CS11'); bg=S&Bd.ct.isin(BG).values
    isct=lambda *c: S&Bd.ct.isin(c).values
    # m01
    if not c11:
        t=isct('Nas.Meso'); add(ss,'m01','cells annotated Nas.Meso','Nas.Meso',t,np.ones(len(Bd)),count=True,mref='Mouse nascent mesoderm; Mesp1 98.6% vs 9.3%')
        add(ss,'m01','MESP1 detection %','Nas.Meso',t,'MESP1',bg,mref='Mesp1 98.6% in mouse nascent mesoderm vs 9.3% other')
    else:
        t=S&(Bd.layer=='M').values; add(ss,'m01','MESP1+ cells in mesoderm layer (count)','mesoderm layer (M)',t,'MESP1',count=True,mref='Mesp1 98.6% vs 9.3%')
        t=isct('PSM'); add(ss,'m01','MESP1 detection %','PSM (no Nas.Meso label at CS11)',t,'MESP1',bg,mref='Mesp1 98.6% in mouse nascent mesoderm vs 9.3% other')
    # m02
    t=isct('APS'); add(ss,'m02','GSC detection %','APS',t,'GSC',bg,mref='Gsc 91.7% in mouse APS vs 6.9%')
    add(ss,'m02','FOXA2 detection %','APS',t,'FOXA2',bg,mref='Foxa2 81.7% in mouse APS vs 8.8%')
    add(ss,'m02','GSC+FOXA2+ % of APS','APS',t,both('GSC','FOXA2'),bg,mref='mouse APS Gsc+Foxa2+')
    # m03
    t=isct('Node')
    for x,r in [('FOXJ1','Foxj1 90.9% vs 2.3%'),('CHRD','Chrd 64.2% vs 1.9%')]: add(ss,'m03',f'{x} detection %','Node',t,x,bg,mref=r+' (mouse notochord/node)')
    add(ss,'m03','FOXJ1+CHRD+ % of Node','Node',t,both('FOXJ1','CHRD'),bg,mref='mouse node Foxj1+Chrd+')
    add(ss,'m03','FOXJ1+CHRD+ cells in Node (count)','Node',t,both('FOXJ1','CHRD'),count=True)
    # m04
    t=isct('DE'); add(ss,'m04','FOXA2 detection %','DE',t,'FOXA2',bg,mref='Foxa2 70.8% vs 8.9% (mouse DE)')
    add(ss,'m04','SOX17 detection %','DE',t,'SOX17',bg,mref='Sox17 53.0% vs 12.9% (mouse DE)')
    add(ss,'m04','FOXA2+SOX17+ % of DE','DE',t,both('FOXA2','SOX17'),bg)
    # m05
    add(ss,'m05','GSC+CER1+ % of DE','DE',t,both('GSC','CER1'),bg,mref='mouse DE Gsc 69.7%/Cer1 83.6% at E7.25 peak')
    add(ss,'m05','GSC+CER1+ DE cells, % of embryo-proper cells','embryo-proper cells (E,M,node,endoderm layers)',S&EMBP.values,(Bd.ct=='DE').values&both('GSC','CER1'),mref='mouse Gsc+Cer1+ DE: 0.26% (E7.0), 2.2% (E7.25) of embryo-proper')
    # m06
    add(ss,'m06','GSC detection % in DE','DE',t,'GSC',bg,mref='mouse 10x DE Gsc peak 69.7% (E7.25); loss threshold 52.3% (75% of peak); 22.6% E7.5, 2.3% E7.75')
    # m07
    t=isct('Node'); add(ss,'m07','NOTO detection %','Node (annotated node/notochord)',t,'NOTO',bg,mref='Noto 91.2% vs 0.7% (mouse notochord)')
    add(ss,'m07','SHH detection %','Node (annotated node/notochord)',t,'SHH',bg,mref='Shh 48.5% vs 0.6% (mouse notochord)')
    add(ss,'m07','NOTO+ cells in node+mesoderm+endoderm layers (count)','X,M,N layers',S&Bd.layer.isin(['X','M','N']).values,'NOTO',count=True)
    # m08 / m12
    pool=S&Bd.TBXT.values&Bd.layer.isin(['E','M']).values
    add(ss,'m08','HOXA1 % of TBXT+ cells','TBXT+ cells in ectoderm+mesoderm layers',pool,'HOXA1',bg,mref='mouse TBXT+ pool Hoxa1: 2.6% E7.25, 33.9% E7.5; onset threshold 19.4%')
    add(ss,'m08','HOXB1 % of TBXT+ cells','TBXT+ cells in ectoderm+mesoderm layers',pool,'HOXB1',bg,mref='mouse TBXT+ pool Hoxb1: 13.9% E7.25, 48.6% E7.5')
    add(ss,'m08','HOXA1 % of PS cluster','PS',isct('PS'),'HOXA1',bg,mref='mouse PS Hoxa1 5.2% E7.5, 15.6% E7.75')
    add(ss,'m12','EOMES % of TBXT+ cells','TBXT+ cells in ectoderm+mesoderm layers',pool,'EOMES',bg,mref='mouse TBXT+ pool Eomes: 86.2% E7.25, 39.6% E7.5, 9.3% E7.75 (reached <=9.3, not reached >=39.6)')
    add(ss,'m12','EOMES % of PS cluster','PS',isct('PS'),'EOMES',bg,mref='mouse PS Eomes 75.3% E7.5, 54.7% E7.75 (10x)')
    # m09
    em=S&Bd.layer.isin(['E','M']).values
    add(ss,'m09','NKX1-2+CDX2+ cells in ectoderm+mesoderm layers (count)','E+M layers',em,both('NKX1-2','CDX2'),count=True,mref='mouse caudal epiblast Nkx1-2 89.8%, Cdx2 97.2%')
    ce=isct('NMP') if c11 else isct('PS','Caud.Meso')
    add(ss,'m09','NKX1-2 detection %','NMP' if c11 else 'PS + Caud.Meso',ce,'NKX1-2',bg,mref='Nkx1-2 89.8% vs 8.9% (mouse caudal epiblast)')
    add(ss,'m09','CDX2 detection %','NMP' if c11 else 'PS + Caud.Meso',ce,'CDX2',bg,mref='Cdx2 97.2% vs 31.9%')
    add(ss,'m09','CDX2+SOX2+ % ','NMP' if c11 else 'PS + Caud.Meso',ce,both('CDX2','SOX2'),bg)
    # m10
    ect=isct('FB/MB/HB') if c11 else isct('ECT'); en='FB/MB/HB' if c11 else 'ECT'
    add(ss,'m10','SIX3 detection %',en,ect,'SIX3',bg,mref='Six3 22.8% vs 2.5% (mouse rostral neurectoderm)')
    add(ss,'m10','HESX1 detection %',en,ect,'HESX1',bg,mref='Hesx1 38.9% vs 5.9%')
    add(ss,'m10','HESX1+SIX3+ cells (count)',en,ect,both('HESX1','SIX3'),count=True)
    # m11
    mm=S&(Bd.layer=='M').values
    add(ss,'m11','MEOX1+TCF15+ % of mesoderm layer','mesoderm layer (M)',mm,both('MEOX1','TCF15'),bg,mref='mouse paraxial Meox1 53.0%, Tcf15 72.1%')
    add(ss,'m11','MEOX1+TCF15+ cells (count)','mesoderm layer (M)',mm,both('MEOX1','TCF15'),count=True)
    if c11:
        add(ss,'m11','MEOX1 detection %','Para.Meso',isct('Para.Meso'),'MEOX1',bg,mref='Meox1 53.0% vs 5.1%'); add(ss,'m11','TCF15 detection %','Para.Meso',isct('Para.Meso'),'TCF15',bg,mref='Tcf15 72.1% vs 10.3%')
    # m13
    cd=(isct('PS','NMP') if c11 else isct('PS','Caud.Meso'))&Bd.CDX2.values
    add(ss,'m13','HOXB8 % of CDX2+ caudal cells','CDX2+ cells in '+('PS+NMP' if c11 else 'PS+Caud.Meso'),cd,'HOXB8',bg,mref='mouse caudal epiblast Hoxb8 5.3% E7.5, 52.1% E7.75; onset threshold 22.6%')
    if c11: add(ss,'m13','HOXB8 detection % in NMP','NMP',isct('NMP'),'HOXB8',bg,mref='mouse NMP Hoxb8 83-97% (E7.75-E8.25)')
    # m14
    mmx=S&Bd.layer.isin(['M','Mx']).values
    add(ss,'m14','NKX2-5+TNNT2+ cells in M+Mx layers (count)','mesoderm + extra-embryonic mesoderm layers',mmx,both('NKX2-5','TNNT2'),count=True,mref='mouse cardiomyocytes Nkx2-5 93-97%, Tnnt2 ~100% (10x)')
    add(ss,'m14','NKX2-5 detection % in M+Mx layers','mesoderm + extra-embryonic mesoderm layers',mmx,'NKX2-5',bg)
    if c11:
        t=isct('Cardi.')
        for x,r in [('NKX2-5','Nkx2-5 94.4% vs 2.5%'),('TNNT2','Tnnt2 99.8% vs 4.2%'),('MYL7','Myl7 100% (10x)')]: add(ss,'m14',f'{x} detection %','Cardi. (cardiomyocyte cluster)',t,x,bg,mref=r)
    # m15
    t=isct('PGC'); add(ss,'m15','cells annotated PGC (count)','PGC',t,np.ones(len(Bd)),count=True,mref='mouse PGC Dppa3 56.9%, Nanos3 28.8%')
    add(ss,'m15','NANOS3 detection %','PGC',t,'NANOS3',bg,mref='Nanos3 28.8% vs 0.4%'); add(ss,'m15','DPPA3 detection %','PGC',t,'DPPA3',bg,mref='Dppa3 56.9% vs 1.9%')
    add(ss,'m15','NANOS3+ cells whole embryo (count)','all cells',S,'NANOS3',count=True)
    # m16
    t=isct('EC','BP'); add(ss,'m16','cells annotated EC+BP (count)','EC + BP',t,np.ones(len(Bd)),count=True)
    add(ss,'m16','ETV2 detection %','EC + BP',t,'ETV2',bg,mref='Etv2 88.1% vs 14.8%'); add(ss,'m16','KDR detection %','EC + BP',t,'KDR',bg,mref='Kdr 83.0% vs 6.1%')
    add(ss,'m16','ETV2+KDR+ cells (count)','EC + BP',t,both('ETV2','KDR'),count=True)
    # m17
    t=isct('ExE.Meso','ys.Meso1','ys.Meso2'); add(ss,'m17','cells annotated ExE.Meso+ys.Meso (count)','ExE.Meso + ys.Meso1/2',t,np.ones(len(Bd)),count=True)
    add(ss,'m17','HAND1 detection %','ExE.Meso + ys.Meso1/2',t,'HAND1',bg,mref='Hand1 80.6% vs 25.5%')
    add(ss,'m17','ExE mesoderm, % of all cells','all cells',S,(Bd.ct.isin(['ExE.Meso','ys.Meso1','ys.Meso2'])).values)
    # m18
    t=isct('AI'); add(ss,'m18','cells annotated AI (count)','AI',t,np.ones(len(Bd)),count=True)
    add(ss,'m18','TBX4 detection %','AI',t,'TBX4',bg,mref='Tbx4 31.6% vs 0.4%'); add(ss,'m18','HOXA10 detection %','AI',t,'HOXA10',bg,mref='Hoxa10 79.3% vs 2.3%')
    add(ss,'m18','TBX4+ or HOXA10+ % of AI','AI',t,(Bd.TBX4|Bd.HOXA10).values,bg)
    # m19
    t=isct('Ery1','Ery2'); add(ss,'m19','cells annotated Ery1+Ery2 (count)','Ery1 + Ery2',t,np.ones(len(Bd)),count=True)
    for x,r in [('HBZ','Hba-x 99.6% vs 22.9%'),('HBE1','Hbb-y'),('GATA1','Gata1 92.2% vs 9.1%')]: add(ss,'m19',f'{x} detection %','Ery1 + Ery2',t,x,bg,mref=r)
    add(ss,'m19','HBZ+GATA1+ cells whole embryo (count)','all cells',S,both('HBZ','GATA1'),count=True)
E=pd.DataFrame(recs); print(len(E))
pd.set_option('display.width',250)
piv=E.pivot_table(index=['milestone_id','metric'],columns='dataset',values='value_target',aggfunc='first')[['Monkey '+x for x in SAM]]
print(piv.to_string())


# ---- cell [frame 6696c2c1, message 49] Checking backgrounds and population compositions
pb=E.pivot_table(index=['milestone_id','metric'],columns='dataset',values='value_background',aggfunc='first')[['Monkey '+x for x in SAM]].dropna(how='all')
print(pb.to_string())
pn=E.pivot_table(index=['milestone_id','metric'],columns='dataset',values='n_target',aggfunc='first')[['Monkey '+x for x in SAM]]
print(pn.loc[['m08','m12','m13','m09']].to_string())
# EOMES in pool by ct
for ss in ['CS8-e1','CS8-e2','CS9-e1']:
    pool=(Bd['sample']==ss)&Bd.TBXT&Bd.layer.isin(['E','M'])
    print(ss, Bd[pool].groupby('ct').EOMES.agg(['size','mean']).query('size>=5').round(2).T.to_dict())
nan=Bd.NANOS3&(Bd.SOX17|Bd.TFAP2C|Bd.PRDM1)
print(pd.crosstab(Bd.ct[nan],Bd['sample'][nan]).to_string())


# ---- cell [frame 6696c2c1, message 53] Loading rerun best subclusters with extra markers
W=(str(HGC_DATA) + '/milestone_evidence/out_monkey/work/')
RB=pd.read_csv(W+'recluster_rerun_best.csv'); RA=pd.read_csv(W+'recluster_rerun_all.csv')
O=pd.read_csv((str(HGC_DATA) + '/milestone_evidence/mz/monkey/monkey_recluster_best.csv'))
cmp=RB.merge(O,on=['sample','celltype'],suffixes=('','_o'))
print('max diff', max((cmp[c]-cmp[c+'_o']).abs().max() for c in ['pool_n','best_n','mod_z','m1_best','m2_best']))
print(RB[[c for c in RB.columns if c.endswith('_best') or c in('sample','celltype')]].to_string())
# CS8/9 cardiac: any subcluster with NKX2-5 high?
q=RA[RA.celltype=='Cardiomyocytes'].sort_values('x_NKX2-5',ascending=False).groupby('sample').head(1)
print(q[['sample','sub','n','x_NKX2-5','m1','m2','mod_z','top_labels']].round(3).to_string())
q=RA[RA.celltype=='Notochord'].sort_values('m1',ascending=False).groupby('sample').head(1)
print(q[['sample','sub','n','m1','m2','mod_z','top_labels']].round(3).to_string())


# ---- cell [frame 6696c2c1, message 55] Adding subcluster rows and Wilson CIs
from statsmodels.stats.proportion import proportion_confint as pci
def ci(k,n): 
    lo,hi=pci(k,n,method='wilson'); return f'{100*lo:.1f}-{100*hi:.1f}%'
# max SIX3 in any ectoderm subcluster
for ss in SAM:
    q=RA[(RA['sample']==ss)&(RA.celltype=='Rostral neurectoderm')].sort_values('m2',ascending=False).iloc[0]
    print(ss,'max SIX3 subcluster',q['n'],round(100*q.m2,1),'HESX1',round(100*q.m1,1),q.top_labels)
print('CS8-e1 HOXA1 pool CI',ci(38,156),' CS8-e2 HOXB8 CI', ci(13,73))
RBi=RB.set_index(['sample','celltype'])
SUBDEF={'m07':('Notochord','node+mesoderm+endoderm layers',[('NOTO','m1'),('SHH','m2'),('TBXT','T'),('FOXA2','FOXA2')]),
        'm09':('Caudal epiblast','ectoderm layer',[('CDX2','m1'),('SOX2','m2'),('NKX1-2','NKX1-2'),('HOXB8','HOXB8')]),
        'm10':('Rostral neurectoderm','ectoderm layer',[('HESX1','m1'),('SIX3','m2')]),
        'm11':('Paraxial mesoderm','mesoderm layer',[('MEOX1','m1'),('TCF15','m2')]),
        'm14':('Cardiomyocytes','mesoderm + extra-embryonic mesoderm layers',[('TNNT2','m1'),('MYL7','m2'),('NKX2-5','NKX2-5')])}
MREF={'m07':'mouse notochord Noto 91.2%, Shh 48.5%','m09':'mouse caudal epiblast Nkx1-2 89.8%, Cdx2 97.2%; CS11 NMP-like subcluster CDX2 99%, SOX2 52-93%, module z 2.1-3.2',
      'm10':'mouse rostral neurectoderm Six3 22.8%, Hesx1 38.9%; CS11 forebrain SIX3 47-75%','m11':'mouse paraxial Meox1 53.0%, Tcf15 72.1%','m14':'mouse cardiomyocytes Nkx2-5 93-97%, Tnnt2/Myl7 ~100% (10x)'}
for ss in SAM:
    for mid,(t,pooln,gl) in SUBDEF.items():
        b=RBi.loc[(ss,t)]
        for gname,col in gl:
            v=b[col+'_best'] if col in('m1','m2') else b[col+'_best']
            pv=b[col+'_pool'] if col not in('m1','m2') else b[col+'_pool']
            recs.append(dict(dataset='Monkey '+ss,milestone_id=mid,metric=f'{gname} detection % in best re-clustered subcluster (module z {b.mod_z})',
                target_population=f'best {t} subcluster of {pooln} (Leiden r=2; labels: {b.top_labels})',n_target=int(b.best_n),value_target=v,
                background_population=f'whole {pooln} pool',n_background=int(b.pool_n),value_background=pv,mouse_reference=MREF[mid],note=''))
        recs.append(dict(dataset='Monkey '+ss,milestone_id=mid,metric='mouse-marker module z-score of best subcluster',target_population=f'best {t} subcluster',n_target=int(b.best_n),value_target=b.mod_z,
            background_population=f'whole {pooln} pool (z=0 by definition)',n_background=int(b.pool_n),value_background=0.0,mouse_reference=MREF[mid],note=''))
E=pd.DataFrame(recs); print(len(E))


# ---- cell [frame 6696c2c1, message 62] Exporting figure calls to CSV from python env
mc.to_csv((str(HGC_DATA) + '/milestone_evidence/out_monkey/work/milestone_calls.csv'),index=False); print(mc.shape)


# ---- cell [frame 6696c2c1, message 64] Assigning recomputed calls and support verdicts
mc=pd.read_csv((str(HGC_DATA) + '/milestone_evidence/out_monkey/work/milestone_calls.csv'))
print(len(recs)); recs=recs[:462]
for ss in SAM:
    q=RA[(RA['sample']==ss)&(RA.celltype=='Rostral neurectoderm')].sort_values('m2',ascending=False).iloc[0]
    recs.append(dict(dataset='Monkey '+ss,milestone_id='m10',metric='SIX3 detection % in highest-SIX3 ectoderm subcluster (n>=15)',target_population=f'highest-SIX3 ectoderm subcluster ({q.top_labels})',
        n_target=int(q.n),value_target=round(100*q.m2,1),background_population='whole ectoderm layer pool',n_background=int(RBi.loc[(ss,'Rostral neurectoderm')].pool_n),
        value_background=RBi.loc[(ss,'Rostral neurectoderm')].m2_pool,mouse_reference='mouse rostral neurectoderm Six3 22.8% vs 2.5%',note=f'HESX1 {100*q.m1:.1f}% in this subcluster'))
E=pd.DataFrame(recs)
v=lambda ss,mid,met: E[(E.dataset=='Monkey '+ss)&(E.milestone_id==mid)&(E.metric.str.startswith(met))].value_target.iloc[0]
bgv=lambda ss,met: E[(E.dataset=='Monkey '+ss)&(E.metric==met)].value_background.iloc[0]
MN=dict(zip([f'm{i:02d}' for i in range(1,20)],["Nascent mesoderm forms (Mesp1+)","Anterior primitive streak forms (Gsc+Foxa2+ streak)","Node-like cells appear (Foxj1+Chrd+)","Definitive endoderm appears (Foxa2+Sox17+)","ADE appears (Gsc+Cer1+ DE)","ADE programme regresses (Gsc lost from DE)","Notochord forms (Noto+ axial cells)","3' HOX on in streak (Hoxa1+ or Hoxb1+ PS)","Caudal epiblast forms (Nkx1-2+Cdx2+)","Neural plate forms (Hesx1+Six3+ rostral neurectoderm)","Paraxial mesoderm forms (Meox1+Tcf15+)","EOMES switched off in streak","5' HOX on in caudal epiblast (Hoxb8+)","Cardiomyocytes appear (Nkx2-5+Tnnt2+)","PGCs appear (Dppa3+Nanos3+)","Haemato-endothelial progenitors appear (Etv2+Kdr+)","Extra-embryonic mesoderm expands (Hand1+)","Allantois forms (Tbx4+Hoxa10+)","Primitive erythroid cells appear (Hba-x+Gata1+; human HBZ/HBE1 + GATA1)"]))
FC={}; FE={}
for i in range(19):
    for ss in SAM: FC[(ss,f'm{i+1:02d}')]=mc.loc[i,'Monkey '+ss]; FE[(ss,f'm{i+1:02d}')]=mc.loc[i,'Monkey '+ss+' | evidence']
R_,N_,P_,A_='reached','not reached','partial','not assessable'
V={}
for ss in SAM:
    c11=ss.startswith('CS11')
    V[(ss,'m01')]=(R_,'yes',f"MESP1+ cells in mesoderm layer {int(v(ss,'m01','MESP1+ cells'))} (reproduces 106/129); CS11 PSM itself is MESP1-low ({v(ss,'m01','MESP1 detection')}%); nascent mesoderm is transient - presence of PSM/paraxial derivatives implies milestone passed") if c11 else \
        (R_,'yes',f"Nas.Meso n={int(v(ss,'m01','cells annotated'))}, MESP1 {v(ss,'m01','MESP1 detection')}% vs bkg {bgv(ss,'MESP1 detection %')}%; rule: annotated n>=10, MESP1>=50% and >=5x bkg")
    if c11: V[(ss,'m02')]=(R_+' (inferred)','partly',f"cells labelled APS at CS11 (n={int(E[(E.dataset=='Monkey '+ss)&(E.metric=='GSC detection %')&(E.milestone_id=='m02')].n_target.iloc[0])}) do not express APS markers (GSC {v(ss,'m02','GSC detection')}%, FOXA2 {v(ss,'m02','FOXA2 detection')}%, GSC+FOXA2+ 0%); 'APS annotated' is not direct evidence - call holds only by inference from later axial derivatives")
    else: V[(ss,'m02')]=(R_,'yes',f"APS GSC {v(ss,'m02','GSC detection')}% (rule >=15% and >=10x bkg), FOXA2 {v(ss,'m02','FOXA2 detection')}%; GSC+FOXA2+ {v(ss,'m02','GSC+FOXA2+')}%"+('; only 1 GSC+FOXA2+ cell of 23 APS cells' if ss=='CS9-e1' else ''))
    k=int(v(ss,'m03','FOXJ1+CHRD+ cells')); f=v(ss,'m03','FOXJ1+CHRD+ %')
    V[(ss,'m03')]=(R_,'yes',f'FOXJ1+CHRD+ {k} cells ({f}% of Node); rule: >=10 cells and >=30% of node') if (k>=10 and f>=30) else \
        (R_+' (inferred)','partly',f'only {k} FOXJ1+CHRD+ cells ({f}% of Node; FOXJ1 {v(ss,"m03","FOXJ1")}%, CHRD {v(ss,"m03","CHRD")}%; mouse node Foxj1 91%, Chrd 64%) - node regressing at CS11; reached only by inference')
    f=v(ss,'m04','FOXA2+SOX17+')
    V[(ss,'m04')]=(R_,'yes',f'DE n={int(E[(E.dataset=="Monkey "+ss)&(E.metric=="SOX17 detection %")].n_target.iloc[0])}, FOXA2+SOX17+ {f}% (rule >=30% and >=3x bkg)') if f>=30 else \
        (R_+' (inferred)','partly',f'cells labelled DE at CS11 are SOX17-low (SOX17 {v(ss,"m04","SOX17")}%, FOXA2+SOX17+ {f}%); DE stage passed (Gut annotated) - inference, not direct')
    f=v(ss,'m05','GSC+CER1+ % of DE')
    V[(ss,'m05')]=(A_,'yes',f'GSC+CER1+ {f}% of DE (2-3 cells) - ADE already regressed, appearance not observable') if c11 else (R_,'yes',f'GSC+CER1+ {f}% of DE vs bkg <=0.3%; {v(ss,"m05","GSC+CER1+ DE cells")}% of embryo-proper (mouse 0.26% E7.0, 2.2% E7.25)')
    f=v(ss,'m06','GSC'); b6=bgv(ss,'GSC detection % in DE')
    if f>=52.3: V[(ss,'m06')]=(N_,'yes',f'GSC in DE {f}% >= 52.3% (also >= 75% of monkey peak 73.3%)')
    elif c11: V[(ss,'m06')]=(R_,'yes',f'GSC in DE {f}% (< 52.3%; between mouse E7.5 22.6% and E7.75 2.3%); bkg {b6}%')
    else: V[(ss,'m06')]=(R_,'partly',f'GSC in DE {f}% < 52.3% loss threshold (rule met), but still above mouse E7.5 value 22.6% and ~{f/max(b6,0.1):.0f}x background ({b6}%) - not "fallen to background" as the human criterion states')
    b=RBi.loc[(ss,'Notochord')]
    if ss=='CS11-e1': V[(ss,'m07')]=(A_+' (notochord not sampled)','no',f'best axial subcluster NOTO {b.m1_best}%, TBXT {b.T_best}%, SHH {b.m2_best}%, FOXA2 {b.FOXA2_best}% (SHH+FOXA2+TBXT-: floor-plate/endoderm-like); annotated Node NOTO {v(ss,"m07","NOTO detection")}%; only {int(v(ss,"m07","NOTO+ cells"))} NOTO+ cells in embryo; figure call rests on SHH and on the CS11 exemption in build.py')
    elif b.m1_best>=40: V[(ss,'m07')]=(R_,'yes',f'best subcluster NOTO {b.m1_best}%, TBXT {b.T_best}%, module z {b.mod_z}; rule NOTO>=40% reached')
    else: V[(ss,'m07')]=(P_,'yes',f'best subcluster NOTO {b.m1_best}% (<40%), TBXT {b.T_best}%; annotated Node NOTO {v(ss,"m07","NOTO detection")}% (n=18) - between mouse E7.0 (~25%) and E7.5 (~90%)')
    f=v(ss,'m08','HOXA1 % of TBXT'); V[(ss,'m08')]=(R_,'yes',f'HOXA1 {f}% of TBXT+ cells >= 19.4% (bkg {bgv(ss,"HOXA1 % of TBXT+ cells")}%)'+(f'; borderline: 38/156, 95% CI {ci(38,156)}' if ss=='CS8-e1' else '')+f'; HOXB1 {v(ss,"m08","HOXB1")}% (mouse pool 48.6% at E7.5) - HOXB1 uninformative on this platform')
    b=RBi.loc[(ss,'Caudal epiblast')]
    rc=R_ if (b.m1_best>=90 and b.m2_best>=50) else (P_ if (b.m1_best>=40 and b.m2_best>=20) else N_)
    V[(ss,'m09')]=(rc,'yes' if rc==FC[(ss,'m09')] else 'no',f'best ectoderm subcluster CDX2 {b.m1_best}%, SOX2 {b.m2_best}%, z {b.mod_z}; rule reached CDX2>=90&SOX2>=50, partial CDX2>=40&SOX2>=20; NKX1-2 {v(ss,"m09","NKX1-2 detection")}% in {"NMP" if c11 else "PS+Caud.Meso"} - canonical marker not assessable (CS11 NMP 0.7-1.0% vs mouse 89.8%)')
    b=RBi.loc[(ss,'Rostral neurectoderm')]; mx=E[(E.dataset=='Monkey '+ss)&(E.metric.str.startswith('SIX3 detection % in highest'))].iloc[0]
    if c11: V[(ss,'m10')]=(R_,'yes',f'forebrain subcluster SIX3 {b.m2_best}%, HESX1 {b.m1_best}%')
    elif mx.value_target>=15: V[(ss,'m10')]=(N_+' / borderline partial','partly',f'module-best subcluster SIX3 {b.m2_best}%, but an ECT subcluster (n={mx.n_target}) has SIX3 {mx.value_target}% ({mx.note}) - close to mouse rostral NE Six3 22.8%; comparison threshold in figure (CS11 forebrain 47-75%) is stricter than mouse')
    else: V[(ss,'m10')]=(N_,'yes',f'max SIX3 in any ECT subcluster {mx.value_target}% (< mouse 22.8%); HESX1 high ({b.m1_best}%) but HESX1 alone also marks anterior epiblast')
    b=RBi.loc[(ss,'Paraxial mesoderm')]; k=int(v(ss,'m11','MEOX1+TCF15+ cells'))
    V[(ss,'m11')]=((R_ if (b.m1_best>=20 and b.m2_best>=50) else N_),'yes',f'best subcluster MEOX1 {b.m1_best}%, TCF15 {b.m2_best}%; MEOX1+TCF15+ {k} cells in mesoderm layer (rule MEOX1>=20&TCF15>=50)')
    f=v(ss,'m12','EOMES % of TBXT'); fp=v(ss,'m12','EOMES % of PS'); nps=int(E[(E.dataset=='Monkey '+ss)&(E.metric=='EOMES % of PS cluster')].n_target.iloc[0])
    rc=R_ if f<=9.3 else (N_ if f>=39.6 else P_)
    sup='yes'; nt=f'EOMES {f}% of TBXT+ cells (rule <=9.3 reached, >=39.6 not reached)'
    if rc!=R_ and nps>=50: sup='partly'; nt+=f'; but annotated PS cluster (n={nps}) EOMES only {fp}% (mouse PS 75.3% E7.5, 54.7% E7.75) - a PS-based reading would be "reached"'
    elif rc!=R_: nt+=f'; PS cluster EOMES {fp}% but n={nps} too small'
    V[(ss,'m12')]=(rc,sup,nt)
    r=E[(E.dataset=='Monkey '+ss)&(E.milestone_id=='m13')&(E.metric=='HOXB8 % of CDX2+ caudal cells')].iloc[0]; k=int(round(r.value_target*r.n_target/100))
    rc=R_ if r.value_target>=22.6 else N_
    sup='yes' if rc==FC[(ss,'m13')] else 'no'; nt=f'HOXB8 {r.value_target}% of {r.n_target} CDX2+ caudal cells ({k} cells, 95% CI {ci(k,r.n_target)}); threshold 22.6%'
    if (not c11) and r.value_target>6: sup='partly'; nt+=' - call holds but evidence string "<=6%" is wrong for this embryo; value lies between mouse E7.5 (5.3%) and E7.75 (52.1%) and the CI includes the threshold'
    V[(ss,'m13')]=(rc,sup,nt)
    b=RBi.loc[(ss,'Cardiomyocytes')]
    V[(ss,'m14')]=((R_ if b['NKX2-5_best']>=50 else N_),'yes',f'best cardiac subcluster NKX2-5 {b["NKX2-5_best"]}%, TNNT2 {b.m1_best}%, MYL7 {b.m2_best}%; NKX2-5+TNNT2+ {int(v(ss,"m14","NKX2-5+TNNT2+"))} cells. Evidence text "NKX2-5 not detected in this dataset" is incorrect: NKX2-5 78.9-79.4% in CS11 Cardi. cluster (original layer map missed raw label "Cardi. " with trailing space)')
    k=int(v(ss,'m15','cells annotated PGC'))
    V[(ss,'m15')]=((R_ if k>=10 else P_),'yes',f'PGC {k} cells, NANOS3 {v(ss,"m15","NANOS3 detection")}% vs bkg {bgv(ss,"NANOS3 detection %")}%; DPPA3 uninformative ({v(ss,"m15","DPPA3")}% in PGC); rule n>=10 reached else partial (low n = sampling)')
    V[(ss,'m16')]=(R_,'yes',f'EC+BP {int(v(ss,"m16","cells annotated"))} cells; KDR {v(ss,"m16","KDR")}%, ETV2 {v(ss,"m16","ETV2")}% (mouse Etv2 88%); ETV2+KDR+ {int(v(ss,"m16","ETV2+KDR+"))} cells')
    V[(ss,'m17')]=(R_,'yes',f'ExE/ys mesoderm {int(v(ss,"m17","cells annotated"))} cells ({v(ss,"m17","ExE mesoderm, %")}% of all), HAND1 {v(ss,"m17","HAND1")}% vs bkg {bgv(ss,"HAND1 detection %")}%')
    V[(ss,'m18')]=(R_,'yes',f'AI {int(v(ss,"m18","cells annotated"))} cells; HOXA10 {v(ss,"m18","HOXA10")}%, TBX4 {v(ss,"m18","TBX4")}% (bkg <=1.4%; mouse Tbx4 31.6%, Hoxa10 79.3%)')
    k=int(v(ss,'m19','cells annotated')); kk=int(v(ss,'m19','HBZ+GATA1+'))
    V[(ss,'m19')]=((R_ if k>=10 else N_),'yes',f'Ery1+Ery2 {k} cells; HBZ+GATA1+ {kk} cells in embryo'+('' if k==0 else f'; HBZ {v(ss,"m19","HBZ")}%, GATA1 {v(ss,"m19","GATA1")}% (HBZ bkg {bgv(ss,"HBZ detection %")}% = ambient haemoglobin)'))
calls=pd.DataFrame([dict(dataset='Monkey '+ss,milestone_id=mid,milestone=MN[mid],figure_call=FC[(ss,mid)],figure_evidence=FE[(ss,mid)],recomputed_call=V[(ss,mid)][0],supports_figure_call=V[(ss,mid)][1],call_note=V[(ss,mid)][2]) for ss in SAM for mid in MN])
print(calls.supports_figure_call.value_counts().to_dict())
print(calls[calls.supports_figure_call!='yes'][['dataset','milestone_id','figure_call','recomputed_call','supports_figure_call']].to_string())


# ---- cell [frame 6696c2c1, message 66] Finalising evidence table and writing CSV
i=calls.index[(calls.dataset=='Monkey CS9-e1')&(calls.milestone_id=='m13')][0]
calls.loc[i,'supports_figure_call']='yes'; calls.loc[i,'call_note']=calls.loc[i,'call_note'].split(' - call holds')[0]+' (consistent with "<=6%" after rounding)'
EV=E.merge(calls,on=['dataset','milestone_id'],how='left')
EV['note']=EV.apply(lambda r: (r.note+'; ' if r.note else '')+r.call_note,axis=1)
cols=['dataset','milestone_id','milestone','figure_call','target_population','n_target','metric','value_target','background_population','n_background','value_background','mouse_reference','recomputed_call','supports_figure_call','note','figure_evidence']
EV['_o']=EV.dataset.map({'Monkey '+s:i for i,s in enumerate(SAM)})
EV=EV.sort_values(['milestone_id','_o'],kind='stable')[cols]
OUT=(str(HGC_DATA) + '/milestone_evidence/out_monkey/')
EV.to_csv(OUT+'evidence_monkey.csv',index=False); calls.to_csv(OUT+'work/calls_monkey.csv',index=False)
print(EV.shape, EV.groupby(['dataset','milestone_id']).ngroups, EV.isna().sum()[['n_target','value_target']].to_dict())
print(EV[EV.value_target.isna()][['dataset','milestone_id','metric','n_target']])
