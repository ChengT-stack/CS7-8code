# aiggot/ — anatomy-informed gated-geodesic optimal transport (AIGG-OT) between HuE#1 (CS7) and HuE#2 (CS8)

This module holds the code behind the STAR Methods sections **AIGG-OT** [P399–P400], **Parameter sensitivity**
[P402–P403] and **Benchmarking and replication** [P405–P406]. It also produces the matching-derived tables behind
**Figure 7A–D**, **Supplementary Figure 9A–H** and **Table S3**.

Naming used in the code. The scripts were written before the final nomenclature was fixed, so they use older names:

| in code | in the paper |
|---|---|
| GG-OT, `ggot`, "GG-OT + table" | AIGG-OT (default: transition prior on) |
| CS6 / CS7 (in some old file names), obj6 / obj7 | HuE#1 = CS7, HuE#2 = CS8 |
| CS8 `EPI`, `aECT`, `pECT` | EPI1, ECT, EPI2 |
| CS7 `ADE` / `AVE` | AVE |
| "Figure 6" in comments | Figure 7 |
| `starmatch` | the star-constrained matching that the AIGG-OT solver builds on (cost scaling, candidate graph, min-cost-flow star decomposition) |

## Environment variables

| variable | default | meaning |
|---|---|---|
| `HGC_DATA` | `data` | input root (see the layout below) |
| `HGC_OUT` | `results` | output root of the scripts that originally wrote into shared folders |
| `HGC_FONT_DIR` | `.` | folder with the Liberation Sans `.ttf` files (figure scripts) |

Expected input layout under `$HGC_DATA`. Raw data are not part of the repository; see the Key Resources Table.

```
cs7_cs8_matching/
  dataprep/{export,frames,embedding,transition}/   written by dataprep/01–04 (working directory of the data preparation)
  matching/                                        harmony_smoothed.npy, transition_table_used.json (written by 04)
  figure/final_ggot/                               Figure 7 tables (copy of the outputs of 06)
  benchmark/                                       out/ tables of the benchmark (copied there after aggregate_real.py)
  replication_stereoseq/                           outputs of stereoseq_frames_pipeline.py (frames, embedding, row index, transition table)
artifacts/                                         small session exports referenced by file name (e.g. Mittnenzweig metacell annotation)
figure7_supplementary/FigS2_sensitivity.csv        formatted sensitivity table read by figures/build_SF9.py
{CS7,CS8}-RNA-MapQ.rds                             published Stereo-seq objects (Cui et al. CS7, Xiao et al. CS8)
obj6 / obj7 Seurat objects                         HuE#1 / HuE#2 CosMx objects (see dataprep/01)
```

## Run order

The scripts are listed in execution order. A number in a file name gives its position in the order.

| # | script | Methods | produces | figure / table |
|---|---|---|---|---|
| 1 | `dataprep/01_export_disc_cells.R` | P399 (input cells: 17,663 CS7 / 31,041 CS8 disc cells) | `dataprep/export/` counts, genes, cell tables | — |
| 2 | `dataprep/02_build_frames.py` | P399 (normalised A–P / L–R / D–V frame, germ layers) | `dataprep/frames/{CS7,CS8}_frames.csv` | Fig 7A |
| 3 | `dataprep/03_joint_embedding.py` | P399 (joint Harmony embedding) | `dataprep/embedding/cs7_cs8_germlayers_harmony.h5ad` | — |
| 4 | `dataprep/04_transition_prior_and_smoothing.py` | P399–P400 (transition prior; smoothed expression z) | `dataprep/transition/`, `matching/harmony_smoothed.npy`, `matching/transition_table_used.json` | Fig 7A, SF9E |
| 5 | `matching/05_run_aiggot.py` (tag `ref`) | P400 (default AIGG-OT coupling) | `$HGC_OUT/aiggot/couplings/M_ref.npz` (+ parent vector) | Fig 7B–D |
| 6 | `matching/06_derive_figure7_tables.py` | P400 | `ggot_table_cs7_to_cs8.csv`, `ggot_table_cs8_ancestor.csv`, `ggot_table_t05_pseudocells.csv`, `ggot_cs7_coords.csv` | Fig 7B–D, SM3/SM4 |
| 7 | `matching/07_control_couplings.py` | P415 (control couplings) | `$HGC_OUT/aiggot/control_couplings/M_*.npz` | SF10B |
| 8 | `sensitivity/08_parameter_sensitivity.py` | P402–P403 (21 runs, one parameter at a time) | sensitivity table | SF9A–D, Table S3 |
| 9 | `benchmark/run_benchmark.sh` → `prep_data.py`, `run_real.py`, `bench_common.py`, `bench_moscot.py`, `aggregate_real.py` | P405 (moscot FGW / linear, kNN expression, NN space) | `benchmark/out/flow_table_*.csv`, `benchmark_real.csv`, `moscot_best_configs.json` | SF9G, Table S3 |
| 10 | `benchmark/09_compare_methods.py` | P405 (penalised-flow comparison incl. AIGG-OT ± prior, Euclidean OT) | `ggot_real_comparison_penalised.csv` | SF9G, Table S3 |
| 11 | `stereoseq/00_export_stereoseq.R`, `stereoseq/build_mapping.R`, `stereoseq/stereoseq_frames_pipeline.py` | P406 (Stereo-seq frames, label mapping, embedding, transition table) | `replication_stereoseq/*` | SF9H |
| 12 | `stereoseq/10_aiggot_stereoseq_replication.py` | P406 (AIGG-OT vs Euclidean, ± prior, on Stereo-seq) | `ggot_stereoseq_replication.csv` | SF9H, Table S3 |
| 13 | `figures/build_SF9.py` | — | Supplementary Figure 9 (E: transition prior; F: layer-change costs h from `lib/ggot.py`) | SF9A–H |

The library code is in `lib/`. The scripts import it by putting `lib/` on `sys.path`.
- `lib/ggot.py` builds the layered tissue grid, the geodesic spatial distance with the layer-change cost `h`, and the gating.
- `lib/ggot_match.py` provides `match(...)`, the generic matcher. It takes the cost, the prior, the candidate graph and the min-cost-flow star decomposition.
- `lib/starmatch.py` holds the cost scaling, the transition-class penalties and the min-cost-flow solver used by `ggot_match`.

### Default AIGG-OT call (Figure 7)

```python
GM.match(E7, E8, S7, S8, g7, g8, a, b, trans, space="gated", prior=True)
```

All other arguments are module defaults:

| parameter | default |
|---|---|
| unmatched cost | 4 |
| entropic ε | 0.1 |
| marginal relaxation τ | 3 |
| maximum descendants K | 5 |
| star-size cost δ | 0.25 |
| candidates | k = 100 / 50, keep 40 |
| h scale | 1 |
| mesoderm edge factor | 0.25 |
| reverse penalty | +1,000 µm |
| grid | 20 µm |

`05_run_aiggot.py ref` reproduces 31,127 coupling pairs and 1,473 unmatched CS8 cells, with 0.973 agreement with the published ancestor table. The published ancestor table takes the first-listed argmax. `08_parameter_sensitivity.py` asserts that its default run reproduces the Figure 7 penalised share (0.030617) and 285 unmatched cells.

### Benchmark configurations (Table S3)

The configurations were selected by held-out-gene ρ on the `hhs` embedding and then re-run on the full Harmony embedding (`hs`):
- moscot linear: `moscot_linear_full_eps0.0001_tau0.95`.
- moscot FGW: `moscot_fgw_sub35_eps0.05_tau0.99_clipdv5` (35 % stratified subsample, 50 iterations, D–V clipped at ±5).

`aggregate_real.py` writes `moscot_best_configs.json` as an output. It is not an input.

## Not included / gaps

- **Builders for Figure 7 panels B, C, D, G, H, I and the Figure 7 composite.** These are not included. The final composite was assembled in a separate layout session, and its per-panel plotting code could not be traced to a final, verbatim script. The tables these panels are drawn from are produced by this module (`06`) and by `generative/analysis/`.
- **`FigS2_sensitivity.csv`.** This is the formatted table read by `build_SF9.py`. It was produced from the output of `08` by a formatting cell whose code is only available as a platform-reconstructed lineage, so it is not included.
- **Excluded variants.** These were dropped because they were not used in the paper: the synthetic benchmark, DeST-OT, the streak-gated AIGG-OT variant (τ = 25), the starmatch reference-parameter outputs, and the QC plots.
