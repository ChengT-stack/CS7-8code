# staging/ — Milestone staging, cross-species primitive-streak dynamics and signalling-gene detection

Code for the STAR Methods sections 'External datasets and pre-processing' (P366-P368), 'Milestone definition and staging windows' (P370-P375), 'Cross-species comparison of primitive streak expression dynamics' (P377-P382) of the manuscript on the human CS7 (HuE#1) and CS8 (HuE#2) CosMx embryos. Embryo naming: HuE#1 = CS7 (`obj6`, called CS6 in old files), HuE#2 = CS8 (`obj7`). CS8 groups EPI1/ECT/EPI2 = old EPI/aECT/pECT; AVE = old ADE.

Each script carries a header naming its source; `PROVENANCE.md` documents how the final version was chosen, the sha256 of the original, the edits made (paths, headers and comments only) and which scripts were reconstructed from session transcripts.

## Methods -> script -> figure

| Script | Methods [P#] | Produces (figure / table) |
|---|---|---|
| `common/figure_style.py` | — | Figure style helper used by plot_fig6AB.py, m4ab.py and the reconstructed PS-dynamics drawing cells |
| `00_inputs/export_tenx_tyser.R` | P367 | Exports tenx_* (in-house 10x CS7) and tyser_* (Smart-seq2 CS7) counts/metadata used for Fig 6A calls and Fig 6G pairs |
| `00_inputs/export_inhouse10x_cs8.R` | P367 | Exports in-house 10x CS8 (CS8-16) counts/metadata (hue11/) for Fig 6A, 6G |
| `00_inputs/export_stereoseq_cs9_markers.R` | P367; P372 | CS9_markers.csv (per-spot marker counts of the Stereo-seq CS9 embryo) for Fig 6A/B and Table S2 sheet "Stereo-seq CS9 evidence" |
| `00_inputs/monkey_recover_counts.py` | P367 (monkey integer UMI recovery) | GSE193007/counts_recovered_int.npz + genes.csv used for Fig 6A (monkey calls) and Fig 6G (monkey CS8→CS9 pairs) |
| `00_inputs/mittnenzweig_cells_markers.py` | P367; P375 | mz_cells_markers.csv.gz (per-cell marker counts, author cell type, transcriptional time; 153 embryos) for Supplementary Figure 7 |
| `01_milestones/mouse_reference_curves.py` | P371 | mouse_reference_curves.csv (19 milestone metrics per stage, onsets, thresholds): Fig 6A diamonds, Supplementary Figure 7B, Table S2 metric columns |
| `01_milestones/mouse_marker_detection.py` | P371 | mz/mouse_milestone_genes.csv, mz/mouse_celltype_counts_by_stage.csv (mouse marker detection per stage; reference values quoted in Table S2 and evidence strings) |
| `01_milestones/milestone_definitions.py` | P371 | mz/allstage/definitions.csv (milestone labels, metrics, markers, human criteria; Table S2 definitions) |
| `01_milestones/layer_recluster.py` | P372 (re-clustering of germ layers when a population is not annotated) | mz/rescue/recluster_best_subclusters.csv (Fig 6A calls for Tyser, Stereo-seq; Table S2) |
| `01_milestones/layer_rescue.py` | P372 | mz/rescue/layer_rescue_results.csv (germ-layer marker rescue; evidence for Fig 6A calls) |
| `01_milestones/monkey_markers.py` | P372 | mz/monkey/monkey_marker_binary.parquet, monkey_detection_by_sample_celltype.csv (monkey calls, Fig 6A) |
| `01_milestones/monkey_recluster.py` | P372 | mz/monkey/monkey_recluster_best.csv (read by build_calls.py; monkey calls Fig 6A) |
| `01_milestones/monkey_recluster_rerun.py` | P372 | recluster_rerun_*.csv (monkey evidence review; feeds audit_calls.py change for Monkey CS11-e1 m07) |
| `01_milestones/evidence_cosmx_export.R` | P372 | out_cosmx/_full_object_markers.csv.gz (CosMx marker counts per cell) |
| `01_milestones/evidence_cosmx.py` | P372 | out_cosmx/evidence_cosmx.csv (CosMx evidence behind the audited calls of HuE#1/HuE#2; Fig 6A; Table S2) |
| `01_milestones/evidence_scrna.py` | P372 | out_scrna/evidence_scrna.csv (Tyser CS7, in-house 10x CS7/CS8 evidence; Fig 6A) |
| `01_milestones/evidence_stereoseq.py` | P372 | out_stereo/evidence_stereo.csv, positive_controls_CS9_stereo.csv (Stereo-seq CS7/CS8 evidence with CS9 positive controls; Fig 6A) |
| `01_milestones/evidence_monkey.py` | P372 | out_monkey/evidence_monkey.csv (monkey evidence; Fig 6A) |
| `01_milestones/build_calls.py` | P372; P373 | mz/allstage/calls.csv, windows.csv (calls of all datasets, windows before audit) |
| `01_milestones/audit_calls.py` | P372; P373 | figure4_staging/milestone/audited_calls.csv, call_changes.csv, windows_audited.csv (Fig 6A/B; Table S2) |
| `01_milestones/add_stereoseq_cs9.py` | P372 (Stereo-seq CS9 sentence); P373 | figure6_cs9/audited_calls.csv, windows_audited.csv, Fig6AB_StereoSeq_CS9_calls_evidence.xlsx (Fig 6A/B CS9 column; Table S2 sheet "Stereo-seq CS9 evidence") |
| `01_milestones/plot_fig6AB.py` | P373; legend P494-P495 | Fig6AB_with_StereoSeq_CS9.{png,svg,pdf} = Figure 6A and 6B |
| `02_mittnenzweig_validation/build_sfig7.py` | P375; legend P549-P552 | FigS_Mittnenzweig_milestone_validation.* and SuppFig8A/C/D/E csv = Supplementary Figure 7A-D |
| `03_ps_dynamics/stereo_pb.R` | P368; P381 | stereo_<batch>_Type2/Type3_pb.csv (Stereo-seq CS7/CS8/CS9 pseudobulks) for Fig 6G |
| `03_ps_dynamics/ps_dynamics_pipeline.py` | P368; P374; P378-P381 | Fig4CD_PS_dynamics_source_data.xlsx (sheets 4C_trajectories, 4C_HOX_heatmap, 4D_concordance, 4D_key_gene_log2FC), PS_dynamic_genes_mouseE7.0-E7.75_vs_human.csv, concordance_summary_all_pairs.csv: source data of Figure 6C, 6D, 6E, 6G |
| `03_ps_dynamics/m4ab.py` | P373 | helper imported by build_fig6.py (draws the pre-CS9 6A/B block, superseded by plot_fig6AB.py) |
| `03_ps_dynamics/build_fig6.py` | P374; P378-P381; legends P496-P498, P500 | Figure6.{png,svg,pdf}: panels later placed as Figure 6C (HOX), 6D (scatter), 6E (PS trajectories), 6G (key-gene log2FC heatmap) |
| `04_lefty_fgf/stereo_detection_by_cluster.R` | P382 | hm/stereo_CS7_pct.csv, hm/stereo_CS8_pct.csv |
| `04_lefty_fgf/signalling_detection_tables.py` | P382 | hm/cosmx_*_pct.csv, hm/mouse_pct.csv, hm/mouse_organiser_stage.csv, hm/human_mouse_candidates_table.csv (inputs of Fig 6F) |
| `04_lefty_fgf/tyser_signalling_detection.R` | P382 | out/Tyser_CS7_signalling_detection_by_cluster.csv (Smart-seq2 columns of Fig 6F) |
| `04_lefty_fgf/lefty_fgf_detection.py` | P382 | SuppFig8E_LEFTY_FGF_detection.csv (values of Figure 6F) |
| `04_lefty_fgf/plot_fig6F.py` | P382; legend P499 | SuppFig8E_merged_FGF.{pdf,png} = Figure 6F |

## Run order

1. 00_inputs/export_tenx_tyser.R, export_inhouse10x_cs8.R, export_stereoseq_cs9_markers.R (R/Seurat exports)
2. 00_inputs/monkey_recover_counts.py
3. 00_inputs/mittnenzweig_cells_markers.py
4. 01_milestones/mouse_marker_detection.py, milestone_definitions.py, mouse_reference_curves.py
5. 01_milestones/layer_recluster.py, layer_rescue.py, monkey_markers.py, monkey_recluster.py
6. 01_milestones/build_calls.py (cwd = $HGC_DATA/milestone_evidence)
7. 01_milestones/evidence_cosmx_export.R, evidence_cosmx.py, evidence_scrna.py, evidence_stereoseq.py, monkey_recluster_rerun.py, evidence_monkey.py (evidence reviews)
8. 01_milestones/audit_calls.py
9. 01_milestones/add_stereoseq_cs9.py (needs audited_calls.csv and windows_audited.csv in $HGC_OUT/figure6/)
10. 01_milestones/plot_fig6AB.py  -> Figure 6A, 6B
11. 02_mittnenzweig_validation/build_sfig7.py  -> Supplementary Figure 7
12. 03_ps_dynamics/stereo_pb.R, then ps_dynamics_pipeline.py
13. 03_ps_dynamics/build_fig6.py <Fig4CD_PS_dynamics_source_data.xlsx> <PS_dynamic_genes_mouseE7.0-E7.75_vs_human.csv>  -> Figure 6C, 6D, 6E, 6G
14. 04_lefty_fgf/stereo_detection_by_cluster.R, signalling_detection_tables.py, tyser_signalling_detection.R, lefty_fgf_detection.py, plot_fig6F.py  -> Figure 6F


## Paths and environment

| Variable | Meaning | Default |
|---|---|---|
| `HGC_DATA` | root of the input data (original relative layout kept, e.g. `external/mouse_pijuan_sala/...`, `milestone_evidence/...`, `GSE193007/...`) | `data` |
| `HGC_OUT` | root of the outputs (`figure4_staging/...`, `figure6/...`, `figure6_cs9/...`) | `results` |
| `HGC_FONTS` | folder with Arial TTF files (optional; figures fall back to the default font) | `fonts` |
| `HGC_TABLE_S2` | path of the user-supplied Table S2 xlsx (gastruloid module) | `$HGC_DATA/Table_S2_milestones.xlsx` |

Several upstream scripts write intermediate tables back to the sub-path that the next script reads (as in the original analysis). For a full re-run either set `HGC_OUT` equal to `HGC_DATA`, or copy the intermediates. Scripts that use relative paths (`mz/...`, `gall/...`, `reanno/...`, `hm/...`, `out/...`) must be run from the working directory noted in the table. No data files are included in the repository.

## Expected input files (under `$HGC_DATA`)

- `$HGC_DATA/`
- `$HGC_DATA/20261030-Fig_milestone_axis_human_monkey_data.xlsx`
- `$HGC_DATA/CS7-RNA-MapQ.rds`
- `$HGC_DATA/CS7ref.rds`
- `$HGC_DATA/CS8-RNA-MapQ.rds`
- `$HGC_DATA/CS9-28798-RNA-MapQ.rds`
- `$HGC_DATA/GSE193007/`
- `$HGC_DATA/GSE193007/MFE56636-meta.csv`
- `$HGC_DATA/GSE193007/counts_recovered_int.npz`
- `$HGC_DATA/GSE193007/genes.csv`
- `$HGC_DATA/MGA_full_atlas_116k.h5ad`
- `$HGC_DATA/Tyser_CS7_signalling_detection_by_cluster.csv`
- `$HGC_DATA/calls.csv`
- `$HGC_DATA/dataprep/`
- `$HGC_DATA/dataprep/export/`
- `$HGC_DATA/external/human_stereoseq/`
- `$HGC_DATA/external/mouse_mittnenzweig2021/`
- `$HGC_DATA/external/mouse_pijuan_sala/mouse_atlas_mapped_rawcounts.h5ad`
- `$HGC_DATA/external/mouse_pijuan_sala/mouse_human_orthologs_one2one_Ensembl116.csv`
- `$HGC_DATA/figure/final_ggot/ggot_cs7_coords.csv`
- `$HGC_DATA/figure/final_ggot/ggot_table_cs8_ancestor.csv`
- `$HGC_DATA/hue11-100512.rds`
- `$HGC_DATA/human_mouse_candidates_table.csv`
- `$HGC_DATA/milestone_evidence`
- `$HGC_DATA/milestone_evidence/`
- `$HGC_DATA/milestone_evidence/20261030-Fig_milestone_axis_human_monkey_data.xlsx`
- `$HGC_DATA/milestone_evidence/mz/`
- `$HGC_DATA/milestone_evidence/mz/monkey/monkey_detection_by_sample_celltype.csv`
- `$HGC_DATA/milestone_evidence/mz/monkey/monkey_marker_binary.parquet`
- `$HGC_DATA/milestone_evidence/mz/monkey/monkey_recluster_best.csv`
- `$HGC_DATA/milestone_evidence/out_cosmx`
- `$HGC_DATA/milestone_evidence/out_cosmx/_full_object_markers.csv.gz`
- `$HGC_DATA/milestone_evidence/out_monkey/`
- `$HGC_DATA/milestone_evidence/out_monkey/work/`
- `$HGC_DATA/milestone_evidence/out_monkey/work/milestone_calls.csv`
- `$HGC_DATA/milestone_evidence/out_scrna/`
- `$HGC_DATA/milestone_evidence/out_scrna/work/`
- `$HGC_DATA/milestone_evidence/out_stereo/`
- `$HGC_DATA/milestone_evidence/out_stereo/work/CS9_markers.csv`
- `$HGC_DATA/mittnenzweig_metacell_annotation.csv`
- `$HGC_DATA/mouse_organiser_stage.csv`
- `$HGC_DATA/mouse_reference_curves.csv`
- `$HGC_DATA/mz_cells_markers.csv.gz`
- `$HGC_DATA/obj6_obj7_merged_curated_v3.rds`
- `$HGC_DATA/published_compare/data/`
- `$HGC_DATA/staging/layer_rescue/`
- `$HGC_DATA/staging/layer_rescue/mouse_milestone_genesets.csv`
- `$HGC_DATA/staging/layer_rescue/tyser_CS7_genes.txt`
- `$HGC_DATA/staging/mouse_milestone_marker_specificity.csv`
- `$HGC_DATA/tyser_raw_reads.rds`
- `$HGC_DATA/tyser_umap.rds`

Supplementary tables: the milestone definitions, thresholds and calls reported in Table S2 are produced by `01_milestones/` (not read back by the code). Inputs taken from the original analysis tree are listed above.

Working-directory inputs produced by earlier scripts of this module (relative paths): ./ai/milestone_atlas/mouse, ./ai/milestone_atlas/mouse/mouse_reference_curves.csv, ./ai/mz_milestones, ./ai/mz_milestones/mz_cells_markers.csv.gz, ./hm/human_mouse_candidates_table.csv, ./hm/mouse_organiser_stage.csv, ./hm/mouse_pct.csv, ./hm/screen_hits.csv, ./hm/stereo_%s_pct.csv, ./out/Tyser_CS7_signalling_detection_by_cluster.csv, ./out/s8e_merge, ./out/s8e_merge/SuppFig8E_LEFTY_FGF_detection.csv, ./out/s8e_merge/SuppFig8E_LEFTY_FGF_detection_v1_withCosMxMax.csv

## Dependencies

Python: python 3.11; numpy 2.4; pandas 2.3; scipy 1.17; matplotlib 3.10-3.11; anndata 0.12.19; scanpy 1.11.5; harmonypy 2.x; python-igraph 1.0; leidenalg 0.12; openpyxl 3.1.5; h5py 3.16; pyarrow (parquet); Pillow.
R: R 4.3.3; Seurat 5.3.0; SeuratObject 5.2.0; Matrix 1.6.5; data.table 1.17.8.
Versions are those of the conda environments in which the analyses were run (checked 2026-11-23); exact versions at run time were not recorded.

## Gaps (Methods steps without code in this module)

- Mouse gastrulation atlas pre-processing (removal of doublets, stripped nuclei and unannotated cells -> 116,312 cells; files MGA_full_atlas_116k.h5ad and external/mouse_pijuan_sala/mouse_atlas_mapped_rawcounts.h5ad): no code found in the project folders or session transcripts searched; the h5ad files pre-date the sessions reviewed.
- One-to-one ortholog table (Ensembl Compara release 116; mouse_human_orthologs_one2one_Ensembl116.csv, 16,335 pairs): no download/filtering code found.
- Mittnenzweig metacell author annotation (mittnenzweig_metacell_annotation.csv, input of mittnenzweig_cells_markers.py): built inside an exploratory kernel session (transcript c8bf3521, messages 195 and 213, parsing mmc2.xlsx header rows); not extracted as a script. The platform lineage export of this file is a re-written approximation and was not used.
- Pre-audit call inputs read by build_calls.py: mz/Fig_milestone_axis_CS7_CS8_data.xlsx (CosMx calls), mz/Fig_milestone_axis_4embryos_data.xlsx (Stereo-seq CS7/CS8 calls), mz/monkey/monkey_milestone_evidence.csv; and staging/mouse_milestone_marker_specificity.csv (milestone_definitions.py), 20261030-Fig_milestone_axis_human_monkey_data.xlsx (mouse_reference_curves.py, evidence_scrna.py): produced in kernel cells of session 5113e657 (2026-10-27/30) that were not reconstructed. The in-house 10x calls are hard-coded with their evidence in build_calls.py.
- Layer re-clustering exports in staging/layer_rescue/ (inhouse10x_CS7*.csv, tyser_CS7*.csv, tyser_CS7_genes.txt, mouse_milestone_genesets.csv): no producing script found.
- Stereo-seq spot labels external/human_stereoseq/stereoseq_cell_labels.csv (our_group_fine, in_disc_fine): label mapping defined in external/human_stereoseq/build_mapping.R (AIGG-OT/Stereo-seq replication module); the script that writes the csv was not located in this module.
- CosMx exports (dataprep/export/*_counts.mtx, *_cells.csv, genes.csv), CosMx h5ad (CS7_CS8_feature_plots/data/*.h5ad), curated Seurat object obj6_obj7_merged_curated_v3.rds and AIGG-OT coordinates (figure/final_ggot/*.csv) come from other modules of the repository.
- Fixed 10x thresholds in the TBXT+ pool (HOXA1 19.4%, HOXB1 20.3%, EOMES 67.2%/67.1%; used for in-house 10x, monkey and gastruloid gene milestones): derivation cell not located; values are quoted in build_calls.py, evidence strings and stage_lib.py.
- Final arrangement of Figure 6 (panel order A-H, insertion of 6F and 6H) and of Supplementary Figure 7 panel letters was done manually in Adobe Illustrator; no code.

## Points for the authors to confirm

- Reconstructed scripts (ps_dynamics_pipeline.py, evidence_*.py, add_stereoseq_cs9.py, mouse_reference_curves.py, signalling_detection_tables.py, lefty_fgf_detection.py, monkey_recover_counts.py and the R reconstructions) are concatenations of notebook-style cells run in persistent kernels; they have not been re-executed end-to-end. Cells that stopped with an error are truncated at the failing line and marked.
- lefty_fgf_detection.py part 1 is the platform lineage export of the code behind SuppFig8E_LEFTY_detection.csv; it was executed and verified in session 13ab33ab (message 197) to reproduce the original five rows, but the original cell that produced that file was not itself recovered.
- Supplementary Figure 7: build_sfig7.py labels the agreement panel C and the per-embryo staging panel D; the final legend has C = per-embryo staging and D = agreement (letters swapped during assembly).
- build_fig6.py (2026-11-06) draws the older Figure 6 layout (A/B without CS9, panel letters C-F); the final Figure 6C/D/E/G panels correspond to its HOX, scatter, trajectory and key-gene heatmap panels.
- build_sfig7.py reads calls.csv (onsets/labels) from an artifact version dated 2026-10-29; onsets are identical in later calls.csv versions.


Licence: MIT (see the repository root).
