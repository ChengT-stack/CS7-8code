# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: execution log, session 824ef1ce R kernel cell 2099 (producing cell of add_mean_cp10k_type_stage.csv
#     c1d9bb55 / add_frac_type_stage.csv a95afa69)
# sha256 of original: 332b1f2c81c9c6eac7c31547b418e19a0daafe199b55b133db3854c22d076d29
# Methods paragraphs: P349
# Produces: hm/add_mean_cp10k_type_stage.csv, hm/add_frac_type_stage.csv, hm/add_mean_cp10k_type_pooled.csv,
#     hm/add_n_type_stage.csv (HESX1, SFRP1 added on 2026-11-11)
# Edits/notes: object path -> HGC_DATA.
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

suppressPackageStartupMessages({library(Seurat); library(Matrix)})
obj <- readRDS(file.path(DATA, "obj6_obj7_merged_curated_final.rds"))
G <- c("HESX1","SFRP1","SOX2","TBXT","POU5F1")
print(setdiff(G, rownames(obj)))
k <- which(obj$curated_kept %in% TRUE)
cnt <- LayerData(obj, assay="RNA", layer="counts")[G, k]
cp <- t(t(as.matrix(cnt)) / obj$nCount_RNA[k] * 1e4)
ty <- as.character(obj$`39Type`[k]); st <- as.character(obj$stage[k])
key <- paste(ty, st, sep="|")
idx <- split(seq_along(key), key)
M <- sapply(idx, function(ii) rowMeans(cp[, ii, drop=FALSE]))
Fd <- sapply(idx, function(ii) rowMeans(cnt[, ii, drop=FALSE] > 0))
Mp <- sapply(split(seq_along(ty), ty), function(ii) rowMeans(cp[, ii, drop=FALSE]))
dir.create("hm", showWarnings=FALSE)
write.csv(M, "hm/add_mean_cp10k_type_stage.csv"); write.csv(Fd, "hm/add_frac_type_stage.csv"); write.csv(Mp, "hm/add_mean_cp10k_type_pooled.csv")
write.csv(data.frame(key=names(idx), n=lengths(idx)), "hm/add_n_type_stage.csv", row.names=FALSE)
print(dim(M)); print(length(k))