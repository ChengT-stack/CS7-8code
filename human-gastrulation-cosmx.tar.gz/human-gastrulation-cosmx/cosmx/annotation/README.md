# cosmx/annotation

RCTD (HuE#2), curation feature exports and the verbatim curation/trimming rules.

Inputs, run order, Methods-to-panel table and gaps: see [../README.md](../README.md). Origin and sha256 of every file: [../PROVENANCE.md](../PROVENANCE.md).
