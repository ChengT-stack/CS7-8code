# One rotation: fixed final_v2 config (5 seeds) on TR_rot{r} train -> V1a fine-tune of each seed (fixed out_domain recipe) ->
# single locked evaluation of both + linear / linear+noise(0.4) baselines; sigma re-tuned on this rotation's VAL set as sensitivity.
import sys, os, time; ROTN = int(sys.argv[1])
exec(open('out_gencv/gencv_lib.py').read())
rot = ROTN; t00 = time.time()
assert {k: V1A['config'][k] for k in F2} == F2, 'V1a base config != final_v2 config'
KW = V1A['finetune_kwargs']; assert KW == dict(center_nominal=True, w_end_m=0.0, lam_h=3.0) and V1A['finetune_steps'] == 1500
assert abs(CFG['lr'] * 0.3 - V1A['finetune_lr']) < 1e-12
Es = set_rot(rot); print(f'rot{rot} dev={dev} train/val/locked={len(TR["train"])}/{len(TR["val"])}/{len(TR["locked"])} extra={ROT["n_extra"]}', flush=True)
LK = TR['locked']
meta = pd.DataFrame(dict(trip=range(len(LK)), ea=[t['ea'] for t in LK], em=[t['em'] for t in LK], eb=[t['eb'] for t in LK],
                         ta=[t['ta'] for t in LK], tm=[t['tm'] for t in LK], tb=[t['tb'] for t in LK]))
rows = []
def add(df, model, seed):
    df = df.copy().reset_index(drop=True); assert (df.em.values == meta.em.values).all()
    df = pd.concat([meta.drop(columns=['em']), df], axis=1); df['model'] = model; df['seed'] = seed; rows.append(df)
add(evaluate(('linear', None), dict(pair='emd_cen'), 'locked'), 'linear', 0)
add(evaluate(('linear_noise', None), BCFG, 'locked'), 'linear_noise', 0)
print(f'rot{rot} baselines done {time.time()-t00:.0f}s', flush=True)
# sigma sensitivity: re-tune on this rotation's VAL triplets over the old grid (loop.py tune_sigma criterion, all val triplets)
sg = []
for s in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.8]:
    cfg = dict(pair='emd_cen', sigma0=s); v = []
    for t in TR['val']:
        X = generate(('linear_noise', None), cfg, t); Y = Zt[torch.as_tensor(t['im'], device=dev)]; v.append(float(L.energy(X, Y)))
    sg.append(dict(rotation=rot, sigma=s, val_mean_ED=float(np.mean(v))))
SG = pd.DataFrame(sg); s_best = float(SG.sigma[SG.val_mean_ED.idxmin()]); SG['selected'] = SG.sigma == s_best; SG.to_csv(OG + f'sigma_val_rot{rot}.csv', index=False)
add(evaluate(('linear_noise', None), dict(pair='emd_cen', sigma0=s_best), 'locked'), 'linear_noise_valsigma', 0)
print(f'rot{rot} val-tuned sigma = {s_best}  {time.time()-t00:.0f}s', flush=True)
HLIN2 = knnd(generate(('linear', None), dict(pair=F2['pair']), HD), HREF_ALL)   # run_rot.py / final2.py denominator (== KL_ALL)
hum = []; GV2 = []; GV1 = []
for seed in range(5):
    t0 = time.time(); M = fit(F2, seed); torch.save(M[1].state_dict(), OG + f'weights/rot{rot}_final_v2_seed{seed}.pt')
    add(evaluate(M, F2, 'locked', seed), 'final_v2', seed)
    G2 = generate(M, F2, HD, seed=seed); GV2.append(G2.cpu().numpy())
    V = finetune(M[1], seed, steps=V1A['finetune_steps'], lr_mult=0.3, **KW); torch.save(V.state_dict(), OG + f'weights/rot{rot}_V1a_seed{seed}.pt')
    add(evaluate_net(V, 'locked', seed), 'V1a', seed)
    G1 = gen_human(V, seed); GV1.append(G1.cpu().numpy())
    hum.append(dict(rotation=rot, seed=seed, plaus_final_v2=knnd(G2, HREF_ALL) / HLIN2, plaus_V1a=knnd(G1, HREF_ALL) / KL_ALL,
                    plaus_heldout_final_v2=knnd(G2[HO], HREF_HO) / KL_HO, plaus_heldout_V1a=knnd(G1[HO], HREF_HO) / KL_HO,
                    shift_final_v2=float((G2 - HLIN).norm(dim=1).mean()), shift_V1a=float((G1 - HLIN).norm(dim=1).mean())))
    print(f'rot{rot} seed{seed} done {time.time()-t0:.0f}s  plaus v2 {hum[-1]["plaus_final_v2"]:.3f} V1a {hum[-1]["plaus_V1a"]:.3f}', flush=True)
    pd.concat(rows).to_csv(OG + f'rot{rot}_locked_triplets_long.csv', index=False)
pd.DataFrame(hum).to_csv(OG + f'rot{rot}_human_plaus.csv', index=False)
np.savez_compressed(OG + f'rot{rot}_human_t05_latent.npz', gen_V1a=np.stack(GV1).astype(np.float32), gen_final_v2=np.stack(GV2).astype(np.float32), linear=HLIN.cpu().numpy(), h_a=HUM['ia'])
LO = pd.concat(rows); LO.to_csv(OG + f'rot{rot}_locked_triplets_long.csv', index=False)
# wide per-triplet table, seed-pooled = mean over the 5 seeds per triplet (old evaluation averages seeds after per-mid means; identical for per-mid means)
W = meta.copy(); W['new_mid'] = Es.new_embryo.reindex(W.em).values.astype(bool)
for mdl, col in [('linear', 'ED_linear'), ('linear_noise', 'ED_linear_noise'), ('final_v2', 'ED_final_v2'), ('V1a', 'ED_V1a'), ('linear_noise_valsigma', 'ED_linear_noise_valsigma')]:
    g = LO[LO.model == mdl].groupby('trip'); W[col] = g.ED.mean().reindex(W.trip).values; W[col.replace('ED_', 'terr_')] = g.terr.mean().reindex(W.trip).values
W['rotation'] = rot; W['sigma_valtuned'] = s_best
W.drop(columns=['trip']).to_csv(OG + f'locked_triplets_rot{rot}.csv', index=False)
print(f'finished rotation {rot} in {(time.time()-t00)/60:.1f} min', flush=True)
