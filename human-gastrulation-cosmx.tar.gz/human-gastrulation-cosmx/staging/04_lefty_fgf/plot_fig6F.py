# staging/04_lefty_fgf/plot_fig6F.py
# Source: drive G: file/20261028-figures/SuppFig8-11_panels_ai/scripts/build_SuppFig8E_merged_FGF.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

"""Supplementary Figure 8E with FGF8 and FGF17 added (merge of the former FGF17_FGF8_human_mouse bar chart into the heatmap).
Input : SuppFig8E_LEFTY_FGF_detection.csv  (% cells or spots with >=1 transcript). Columns as in the published panel E, except that
        the 'CosMx max' control column is removed and CosMx CS8 rostral mesoderm (n = 4,102 cells) is added to the CS8 group.
        The TDGF1 row of the published panel is dropped (not on the CosMx panel; not cited in the text).
        The five original rows were regenerated with the code that produced SuppFig8E_LEFTY_detection.csv (gene list extended by
        FGF17 and FGF8) and reproduce that file exactly at one decimal. CosMx columns hold exact fractions from the count matrices;
        mouse-organiser and Smart-seq2 columns hold k/n backed out from the one-decimal source tables and their group sizes.
Output: SuppFig8E_merged_FGF.ai (PDF-compatible, all vector, Arial) and .png.
Geometry (pt) is copied from the published panel: width 219.4, heatmap box x 39.4-211.5, top 32.5, row height 28.37."""
import numpy as np, pandas as pd, matplotlib as mpl, os, shutil
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib import font_manager as fm
FD = os.path.join(os.environ.get("CONDA_PREFIX", ""), "fonts")
for f in ["arial.ttf", "arialbd.ttf", "ariali.ttf", "arialbi.ttf"]:
    if os.path.exists(os.path.join(FD, f)): fm.fontManager.addfont(os.path.join(FD, f))
mpl.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial'], 'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none', 'axes.unicode_minus': False})
PW, X0, X1, Y0, ROWH, BOT = 219.4, 39.4, 211.5, 32.5, 28.37, 58.0   # BOT: space below the heatmap for the column labels
rows = ['LEFTY1', 'LEFTY2', 'NOG', 'SHH', 'FGF8', 'FGF17']
EE = pd.read_csv('SuppFig8E_LEFTY_FGF_detection.csv', header=[0, 1], index_col=0).loc[rows]
Mx = EE.values.astype(float); nR, nC = Mx.shape; H = Y0 + nR * ROWH + BOT
fig = plt.figure(figsize=(PW / 72, H / 72))
ax = fig.add_axes([X0 / PW, 1 - (Y0 + nR * ROWH) / H, (X1 - X0) / PW, nR * ROWH / H])
cmap = plt.get_cmap('Blues')
for i in range(nR):
    for j in range(nC):
        v = Mx[i, j]
        if np.isnan(v):                                   # gene not on the CosMx panel
            ax.add_patch(Rectangle((j - .5, i - .5), 1, 1, fc='#E0E0E0', ec='none', lw=0))
            ax.text(j, i, 'n.p.', ha='center', va='center', fontsize=4.8, color='#444')
        else:
            ax.add_patch(Rectangle((j - .5, i - .5), 1, 1, fc=cmap(v / 100), ec=cmap(v / 100), lw=0.2))
            ax.text(j, i, f'{v:.0f}', ha='center', va='center', fontsize=5, color='white' if v > 55 else 'black')
ax.set_xlim(-.5, nC - .5); ax.set_ylim(nR - .5, -.5)
ax.set_yticks(range(nR)); ax.set_yticklabels(rows, fontstyle='italic', fontsize=6)
ax.set_xticks(range(nC)); ax.set_xticklabels([c for _, c in EE.columns], fontsize=5.2, rotation=90)
ax.tick_params(axis='both', length=0, pad=2)
grp = [g for g, _ in EE.columns]
for b in [k for k in range(1, len(grp)) if grp[k] != grp[k - 1]]:
    same = grp[b].split()[0] == grp[b - 1].split()[0]
    ax.axvline(b - .5, c='white' if same else 'k', lw=1.2 if same else 0.7)
for x in [1.5, 3.5, 7.5]: ax.axvline(x, c='white', lw=1.2)      # dataset boundaries within Human CS7 and CS8 (CosMx | Stereo-seq | Smart-seq2)
ax.axhline(rows.index('FGF8') - .5, c='white', lw=2.2)                        # separates the FGF8 / FGF17 rows
hdr = {}
for k, g in enumerate(grp): hdr.setdefault(g, []).append(k)
short = {'Human CS7': 'Human CS7', 'Human CS8': 'CS8', 'Mouse organiser': 'Mouse organiser', 'Mouse APS': 'Mouse', 'CosMx control': 'Ctrl'}
for g, ks in hdr.items():
    a, b = min(ks), max(ks)
    ax.plot([a - .4, b + .4], [-.66, -.66], c='k', lw=0.6, clip_on=False)
    ax.text((a + b) / 2, -.74, short[g], ha='center', va='bottom', fontsize=5.0 if a == b else 5.2, clip_on=False)
for s in ax.spines.values(): s.set_visible(False)
ax.set_title('LEFTY2 and FGF17 in human, Lefty1 and Fgf8 in mouse\n% cells (spots) with ≥1 transcript', loc='left', pad=16, fontsize=6.3)
ax.text(-0.2, 1 + 0.2 * 5 / nR, 'E', transform=ax.transAxes, fontsize=9, fontweight='bold', va='top', ha='left')
fig.savefig('SuppFig8E_merged_FGF.pdf'); fig.savefig('SuppFig8E_merged_FGF.png', dpi=400)
shutil.copyfile('SuppFig8E_merged_FGF.pdf', 'SuppFig8E_merged_FGF.ai'); os.remove('SuppFig8E_merged_FGF.pdf')
r = fig.canvas.get_renderer(); T = [(t, t.get_window_extent(r)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
print('text overlaps:', [(a.get_text(), b.get_text()) for i, (a, ba) in enumerate(T) for b, bb in T[i + 1:] if ba.overlaps(bb)],
      '| text outside canvas:', [t.get_text() for t, b in T if b.x0 < 0 or b.y0 < 0 or b.x1 > fig.bbox.x1 or b.y1 > fig.bbox.y1],
      '| lowest text bottom (pt):', round(min(b.y0 for _, b in T) * 72 / fig.dpi, 1), '| size pt:', round(PW, 1), round(H, 1))
