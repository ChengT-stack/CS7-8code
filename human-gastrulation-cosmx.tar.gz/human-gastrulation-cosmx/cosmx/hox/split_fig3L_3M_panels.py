# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: execution log, session 824ef1ce python kernel cell 2187 (producing cell of Fig3L_HOX_maps_CS7_CS8.ai
#     c9046a4c and Fig3M_HOX_AP_profiles_CS7_CS8.ai 43307ec0)
# sha256 of original: 0ced727cca075f918b0e97bbfde4af4746a60290e933bb96429334181c7b1f4d
# Methods paragraphs: Figure 3L/3M legends
# Produces: hox/Fig3L_HOX_maps_CS7_CS8.ai (Figure 3L), hox/Fig3M_HOX_AP_profiles_CS7_CS8.ai (Figure 3M), with
#     PNG previews
# Edits/notes: reconstructed from kernel log; fallback to a platform artifact path removed (the combined .ai
#     from build_fig3L_hox_ap.py is required).
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

import pymupdf
hx = pymupdf.open('hox/Fig3L_HOX_AP_CS7_CS8.ai', filetype='pdf')
hp = hx[0]; print(hp.rect)
a1 = hp.search_for('anterior'); a2 = hp.search_for('Profiles along'); print(a1, a2)
yA = a1[0].y1 + 4; yB = a2[0].y0 - 3
def clip_save(rect, fn):
    o = pymupdf.open(); p = o.new_page(width=rect.width, height=rect.height); p.show_pdf_page(p.rect, hx, 0, clip=rect); o.save(fn, garbage=3, deflate=True)
    o[0].get_pixmap(matrix=pymupdf.Matrix(4, 4)).save(fn.replace('.ai', '.png')); return [round(v / 72 * 25.4) for v in rect[2:]]
os.makedirs('hox', exist_ok=True)
print(clip_save(pymupdf.Rect(0, 0, hp.rect.width, yA), 'hox/Fig3L_HOX_maps_CS7_CS8.ai'), clip_save(pymupdf.Rect(0, yB, hp.rect.width, hp.rect.height), 'hox/Fig3M_HOX_AP_profiles_CS7_CS8.ai'))
for f in ['hox/Fig3L_HOX_maps_CS7_CS8.ai', 'hox/Fig3M_HOX_AP_profiles_CS7_CS8.ai']:
    q = pymupdf.open(f, filetype='pdf')[0]; print(f, sorted({x[3] for x in q.get_fonts()}), len(q.get_images()), q.get_text()[:60].replace('\n', ' | '))