# Shared representation (identical recipe to the Mittnenzweig benchmark) + precomputed endpoint pairings for all triplets and pairing schemes.
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import sys, glob, pickle, numpy as np, pandas as pd, anndata as ad, ot, harmonypy, warnings; warnings.filterwarnings('ignore')
from sklearn.decomposition import PCA
sys.path.insert(0,'ai'); import step5_lib as L
O='ai/step7/'; rng=np.random.default_rng(0); B=DATA + '/cs7_cs8_matching/'
H=ad.read_h5ad('ai/integrated_scvi.h5ad'); o=H.obs; n0=H.n_obs; uid=o.index.values
U=np.zeros((n0,1280),np.float32); pos={u:i for i,u in enumerate(uid)}
for f in glob.glob(DATA + '/UCE/out/*_uce_adata.h5ad'):
    if 'Mittnenzweig' in f: continue
    a=ad.read_h5ad(f); U[[pos[x] for x in a.obs_names]]=a.obsm['X_uce']
q=ad.read_h5ad('ai/mz_bench/mz_hvg_counts.h5ad'); qo=q.obs.copy(); nq=q.n_obs
qu=ad.read_h5ad(DATA + '/UCE/out/Mittnenzweig153_uce_adata.h5ad'); qpos={u:i for i,u in enumerate(qo.index)}
keepq=np.array([x in set(qu.obs_names) for x in qo.index]); Uq=np.zeros((nq,1280),np.float32); Uq[[qpos[x] for x in qu.obs_names]]=qu.obsm['X_uce']
Xs=np.vstack([H.obsm['X_scVI'],np.load('ai/mz_bench/mz_scvi30.npy')]).astype(np.float32); Ua=np.vstack([U,Uq])
ds=np.r_[o.dataset.values.astype(str),np.full(nq,'MZ')]; grp=np.r_[o.group.astype(str).values,qo.group.values]; mt=np.r_[o.mouse_time.values.astype(float),np.full(nq,np.nan)]
bat=np.r_[o['batch'].astype(str).values,np.full(nq,'MARS_mouse')]; valid=np.r_[np.ones(n0,bool),keepq]
emb=np.r_[np.full(n0,''),qo.embryo.values.astype(str)]; etime=np.r_[np.full(n0,np.nan),qo.time.values]
sub=np.concatenate([rng.choice(np.where(ds==d)[0],min(3000,int((ds==d).sum())),replace=False) for d in np.unique(ds[:n0])])
P=PCA(64,random_state=0).fit(Ua[sub]); Up=P.transform(Ua).astype(np.float32)
ho=harmonypy.run_harmony(Up,pd.DataFrame({'b':bat}),'b',random_state=0,max_iter_harmony=20); Hm=np.asarray(ho.Z_corr); Hm=(Hm.T if Hm.shape[0]==64 else Hm).astype(np.float32)
zs=lambda X:((X-X[sub].mean(0))/(X[sub].std(0)+1e-6)).astype(np.float32)
Z=np.hstack([zs(Xs),zs(Hm)*np.sqrt(30/64)]).astype(np.float32)
np.savez(O+'rep.npz',Z=Z,ds=ds,grp=grp,mt=mt,emb=emb,etime=etime,valid=valid,n0=n0)
GB=np.array(sorted(set(grp)))
def plan(ia,ib,reg=None):
    M=ot.dist(Z[ia],Z[ib]); M/=M.max(); a=np.ones(len(ia))/len(ia); b=np.ones(len(ib))/len(ib)
    G=ot.emd(a,b,M,numItermax=3000000) if reg is None else ot.sinkhorn(a,b,M,reg,numItermax=2000)
    return G/G.sum(1,keepdims=True)
def partners(ia,ib):
    out={}; r=np.random.default_rng(len(ia)+len(ib))
    for tag,reg in [('emd',None),('ent',0.02)]:
        W=plan(ia,ib,reg); out[f'{tag}_cen']=(W@Z[ib]).astype(np.float32)
        out[f'{tag}_sample']=Z[ib[[r.choice(len(ib),p=w/w.sum()) for w in W]]]
        if tag=='emd':
            out['emd_top']=Z[ib[W.argmax(1)]]; Wg=np.stack([W[:,grp[ib]==g].sum(1) for g in GB],1); out['dom']=GB[Wg.argmax(1)]
    return out
# Pijuan-Sala stage pairs for the flow family (consecutive / 0.5-day spacing), as in step 5
C={}
for i,a in enumerate(L.STG):
    for b in L.STG[i+1:]:
        if round(b-a,2) not in (0.25,0.5,1.0): continue
        ia=np.where((mt==a)&valid)[0]; ib=np.where((mt==b)&valid)[0]; ia=rng.choice(ia,min(1500,len(ia)),replace=False)
        p=partners(ia,ib); k=f'm_{a}_{b}'; C[k+'_a']=ia; C[k+'_cen']=p['emd_cen']; C[k+'_top']=np.array([0]); C[k+'_topZ']=p['emd_top']; C[k+'_dom']=p['dom']
        C[k+'_ent_cen']=p['ent_cen']; C[k+'_emd_sample']=p['emd_sample']; C[k+'_ent_sample']=p['ent_sample']
# Mittnenzweig triplets per split
E=pd.read_csv('ai/mz_bench/embryo_split.csv',index_col=0)
def trip(mset,eset,lo,hi,tol):
    out=[]
    for ea,ra in E[E.split.isin(eset)].iterrows():
        for eb,rb in E[E.split.isin(eset)].iterrows():
            D=rb.t-ra.t
            if not(lo<=D<=hi and ra.t>=6.6): continue
            mm=E[E.split.isin(mset)&(np.abs(E.t-(ra.t+rb.t)/2)<=tol)&~E.index.isin([ea,eb])]
            out+=[(ea,em,eb,ra.t,rm.t,rb.t) for em,rm in mm.iterrows()]
    return out
TR={}
for nm,ms,es,lo,hi,tol in [('train',['T'],['T'],0.25,0.5,0.06),('val',['V'],['T','V'],0.3,0.45,0.05),('locked',['L'],['T','V'],0.3,0.45,0.05)]:
    lst=[]
    for (ea,em,eb,ta,tm,tb) in trip(ms,es,lo,hi,tol):
        ia=np.where((emb==ea)&valid)[0]; ib=np.where((emb==eb)&valid)[0]; im=np.where((emb==em)&valid)[0]
        ia=rng.choice(ia,min(600,len(ia)),replace=False) if len(ia)>600 else ia
        lst.append(dict(ea=ea,em=em,eb=eb,ta=ta,tm=tm,tb=tb,ia=ia,im=im,**partners(ia,ib)))
    TR[nm]=lst; print(nm,len(lst),flush=True)
# human GG-OT pairs (CS7 cell -> its CS8 descendants), in this representation
u7=np.load('ai/step5_u7.npy'); u8=np.load('ai/step5_u8.npy'); t05=pd.read_csv('ai/step5_human_t05_index.csv')
anc=pd.read_csv(B+'figure/final_ggot/ggot_table_cs8_ancestor.csv'); anc=anc[anc.cls!='unmatched']; desc=anc.groupby('ancestor_idx').cs8_idx.apply(np.array).reindex(t05.cs7_idx.values)
CO={**{k:'EPI' for k in ['EPI','ECT','aECT','pECT','NNE','CLE']},'PS':'PS','APS':'PS',**{k:'MESO' for k in ['Nas.Meso','Para.Meso','Rostral.Meso','LP.Meso','Heart.Meso']},**{k:'AXIAL' for k in ['Node','Notochord','PrP']},'DE':'DE','AVE':'DE','ADE':'DE','VE1':'VE','VE2':'VE'}
r=np.random.default_rng(7); hia=u7[t05.cs7_idx.values]
hum=dict(ia=hia,emd_cen=np.stack([Z[u8[d]].mean(0) for d in desc.values]).astype(np.float32),dom=t05.dom_cs8_group.map(CO).values)
hum['ent_cen']=hum['emd_cen']; hum['emd_top']=np.stack([Z[u8[r.choice(d)]] for d in desc.values]); hum['emd_sample']=hum['emd_top']; hum['ent_sample']=np.stack([Z[u8[r.choice(d)]] for d in desc.values])
pickle.dump(dict(C=C,TR=TR,hum=hum,GB=GB),open(O+'pairs.pkl','wb')); print('done')
