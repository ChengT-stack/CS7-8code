# Domain-shift reduction for the final_v2 t0.5 generator: shared library.
# Run with cwd = the generative working directory (original: the 115-embryo root ai_t05). Never writes under ai/.
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import sys, os, json, numpy as np, pandas as pd, torch, torch.nn as nn, scipy.sparse as sp
sys.argv = [sys.argv[0], '0']; sys.path.insert(0, 'ai/step7')
exec(open('ai/step7/loop.py').read().split('# ---------- search space')[0])   # lib7 *, evaluate, score, BASE, BCFG, REF, ET
import lib7
from scipy.stats import wilcoxon
OD = 'out_domain/'; os.makedirs(OD, exist_ok=True)
CFG = json.load(open('ai/step7/final_v2/generator_config.json'))['config']
d = Z.shape[1]
u7 = np.load('ai/step5_u7.npy'); u8 = np.load('ai/step5_u8.npy')
T05 = pd.read_csv('ai/step5_human_t05_index.csv')
HD = dict(HUM); HD['ta'] = 7.25; HD['tb'] = 7.625
HUM_D, HUM_TA = 0.375, 7.25

# ---------------- human split by CS7 ancestor clone (train half for human loss terms, held-out half for evaluation)
_r = np.random.default_rng(2026)
anc = pd.read_csv(DATA + '/cs7_cs8_matching/figure/final_ggot/ggot_table_cs8_ancestor.csv')
tr7 = np.zeros(len(u7), bool)
for g_, idx in T05.groupby('cs7_group').groups.items():      # stratified by CS7 group
    ci = T05.cs7_idx.values[np.asarray(idx)]; tr7[_r.choice(ci, len(ci) // 2, replace=False)] = True
nopc = np.setdiff1d(np.arange(len(u7)), T05.cs7_idx.values); tr7[_r.choice(nopc, len(nopc) // 2, replace=False)] = True
matched = anc.cls.values != 'unmatched'
tr8 = np.where(matched, tr7[anc.ancestor_idx.values], _r.random(len(anc)) < 0.5)
HTR = tr7[T05.cs7_idx.values]                                 # pseudo-cell mask, train half
HREF_ALL = Zt[torch.as_tensor(np.r_[u7, u8], device=dev)]
HREF_HO = Zt[torch.as_tensor(np.r_[u7[~tr7], u8[~tr8]], device=dev)]
U7TR = torch.as_tensor(u7[tr7], device=dev); U8TR = torch.as_tensor(u8[tr8], device=dev)
HUMREAL_TR = torch.cat([U7TR, U8TR])

# ---------------- fraction-conditioned network (identical to final_v2 Net at initialisation)
class NetF(nn.Module):
    def __init__(s, d, h, Ly, drop, sig_init):
        super().__init__(); s.f = L.mlp(2 * d + 3, 2 * d, h, Ly, drop); s.d = d
    def forward(s, lin, dlt, D, ta, fr):
        o = s.f(torch.cat([lin, dlt, D[:, None], ta[:, None] - 7.5, fr[:, None] - 0.5], 1)); return o[:, :s.d], o[:, s.d:].clamp(-6, 2)
    @staticmethod
    def from_net(net):
        m = NetF(net.d, net.f[0].out_features, CFG['L'], CFG['drop'], CFG['sig_init']).to(dev)
        sd = net.state_dict(); w = sd['f.0.weight']; sd['f.0.weight'] = torch.cat([w, torch.zeros(w.shape[0], 1, device=w.device)], 1)
        m.load_state_dict(sd); return m

def load_v2(seed):
    n = Net(d, CFG['h'], CFG['L'], CFG['drop'], CFG['sig_init']).to(dev)
    n.load_state_dict(torch.load(f'ai/step7/final_v2/generator_seed{seed}.pt', map_location=dev)); n.eval(); return n

def _full(n, v): return torch.full((n,), float(v), device=dev)
def gnet(net, A, Bp, D, ta, fr, cfg=CFG, scale=True, eps=None):
    """state at fraction fr between A and partner Bp. scale=True applies deployed ds/ns."""
    lin = (1 - fr) * A + fr * Bp; n = len(A)
    if isinstance(net, NetF): mu, ls = net(lin, Bp - A, _full(n, D), _full(n, ta), _full(n, fr))
    else: mu, ls = net(lin, Bp - A, _full(n, D), _full(n, ta))
    eps = torch.randn_like(lin) if eps is None else eps
    ds, ns = (cfg['ds'], cfg['ns']) if scale else (1.0, 1.0)
    env = 4 * fr * (1 - fr) if getattr(net, 'env', False) else 1.0   # V1b: endpoints exact by construction
    return lin + env * (ds * mu + ns * torch.exp(ls) * eps), mu

# ---------------- extra mouse triplets at off-centre fractions (train embryos only; partners re-used from TR['train'])
E = pd.read_csv('ai/mz_bench/embryo_split.csv', index_col=0); ET_ = E[E.split == 'T']
_seen = {}
for t in TR['train']: _seen[(t['ea'], t['eb'])] = t
EXTRA = []
for (ea, eb), t in _seen.items():
    Dd = t['tb'] - t['ta']
    for em, r in ET_.iterrows():
        if em in (ea, eb): continue
        fr = (r.t - t['ta']) / Dd
        if 0.1 <= fr <= 0.35 or 0.65 <= fr <= 0.9:
            EXTRA.append(dict(t, em=em, tm=r.t, im=np.where((emb == em) & valid)[0]))
def _prep(t):
    pair = CFG['pair']
    return dict(ia=torch.as_tensor(t['ia'], device=dev), bp=tt(t[pair]), im=torch.as_tensor(t['im'], device=dev),
                D=t['tb'] - t['ta'], ta=t['ta'], fr=(t['tm'] - t['ta']) / (t['tb'] - t['ta']),
                ea=torch.as_tensor(np.where((emb == t['ea']) & valid)[0], device=dev), eb=torch.as_tensor(np.where((emb == t['eb']) & valid)[0], device=dev))
PTR = [_prep(t) for t in TR['train']]; PEX = [_prep(t) for t in EXTRA]
HIA = torch.as_tensor(HUM['ia'], device=dev); HBP = tt(HUM[CFG['pair']]); HTRi = torch.as_tensor(np.where(HTR)[0], device=dev)

def _samp(idx, n): return idx[torch.randint(len(idx), (n,), device=dev)]
def wgan_gp(C, real, fake):
    a = torch.rand(len(real), 1, device=dev); x = (a * real + (1 - a) * fake).requires_grad_(True)
    g = torch.autograd.grad(C(x).sum(), x, create_graph=True)[0]; return ((g.norm(dim=1) - 1) ** 2).mean()

def finetune(seed, lam_h=0.0, lam_adv=0.0, steps=1500, lr_mult=0.3, p_off=0.3, w_end_m=0.2, use_frac=True, ncrit=2, log=None, center_nominal=False, envelope=False, hum_end=True):
    """Fine-tune final_v2 seed `seed`. Mouse loss always on; human endpoint + self-consistency weighted lam_h; WGAN-GP adversary lam_adv."""
    torch.manual_seed(1000 + seed); rng = np.random.default_rng(1000 + seed); bs = CFG['bs']
    net = NetF.from_net(load_v2(seed)); net.env = envelope; net.train()
    opt = torch.optim.AdamW(net.parameters(), lr=CFG['lr'] * lr_mult, weight_decay=CFG['wd'])
    sch = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=CFG['lr'] * lr_mult, total_steps=steps, pct_start=0.1)
    if lam_adv > 0:
        crit = L.mlp(d, 1, 256, 2, 0.0).to(dev); optc = torch.optim.Adam(crit.parameters(), lr=2e-4, betas=(0.5, 0.9))
    hist = []
    for it in range(steps):
        off = use_frac and rng.random() < p_off; P = PEX[rng.integers(len(PEX))] if off else PTR[rng.integers(len(PTR))]
        fr = P['fr'] if use_frac else 0.5
        if center_nominal and not off: fr = 0.5
        j = torch.randint(len(P['ia']), (bs,), device=dev); A = Zt[P['ia'][j]]; Bp = P['bp'][j]
        gen, mu = gnet(net, A, Bp, P['D'], P['ta'], fr, scale=False)
        loss = L.energy(gen, Zt[_samp(P['im'], bs)]) + CFG['lam'] * (mu ** 2).mean(); rec = dict(mouse=float(loss))
        if use_frac and w_end_m > 0:                                   # mouse endpoints: f=0 -> embryo A, f=1 -> embryo B
            g0, _ = gnet(net, A, Bp, P['D'], P['ta'], 0.0, scale=False); g1, _ = gnet(net, A, Bp, P['D'], P['ta'], 1.0, scale=False)
            le = L.energy(g0, Zt[_samp(P['ea'], bs)]) + L.energy(g1, Zt[_samp(P['eb'], bs)]); loss = loss + w_end_m * le
        if lam_h > 0 or lam_adv > 0:
            k = _samp(HTRi, bs); HA = Zt[HIA[k]]; HB = HBP[k]
        if lam_h > 0:
            h0, _ = gnet(net, HA, HB, HUM_D, HUM_TA, 0.0); h1, _ = gnet(net, HA, HB, HUM_D, HUM_TA, 1.0)
            l_end = L.energy(h0, Zt[_samp(U7TR, bs)]) + L.energy(h1, Zt[_samp(U8TR, bs)])
            hm, _ = gnet(net, HA, HB, HUM_D, HUM_TA, 0.5)                                  # t0.5
            hq_c, _ = gnet(net, HA, hm, HUM_D / 2, HUM_TA, 0.5)                             # midpoint(CS7, G(CS7,CS8)) -> t0.25
            hq_d, _ = gnet(net, HA, HB, HUM_D, HUM_TA, 0.25)                                # direct t0.25
            l_end = l_end if hum_end else 0.0 * l_end
            l_con = L.energy(hq_c, hq_d); loss = loss + lam_h * (l_end + l_con); rec.update(h_end=float(l_end), h_con=float(l_con))
        if lam_adv > 0:
            for _ in range(ncrit):
                with torch.no_grad(): fk, _ = gnet(net, HA, HB, HUM_D, HUM_TA, 0.5)
                rl = Zt[_samp(HUMREAL_TR, bs)]
                lc = crit(fk).mean() - crit(rl).mean() + 10 * wgan_gp(crit, rl, fk)
                optc.zero_grad(); lc.backward(); optc.step()
            fk, _ = gnet(net, HA, HB, HUM_D, HUM_TA, 0.5); la = -crit(fk).mean(); loss = loss + lam_adv * la; rec.update(adv=float(la), crit=float(lc))
        opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(net.parameters(), 1.0); opt.step(); sch.step()
        if it % 100 == 0: hist.append(dict(it=it, **rec))
    net.eval(); return net, pd.DataFrame(hist)

# ---------------- evaluation (final2 protocol; generation at fraction 0.5 for every model)
@torch.no_grad()
def gen_trip(net, t, seed):
    torch.manual_seed(seed); A = Zt[torch.as_tensor(t['ia'], device=dev)]; Bp = tt(t[CFG['pair']])
    eps = torch.randn_like(A); return gnet(net, A, Bp, t['tb'] - t['ta'], t['ta'], 0.5, eps=eps)[0]
def evaluate_net(net, split, seed):
    rows = []; g = torch.Generator(device=dev)
    with torch.no_grad():
        for i, t in enumerate(TR[split]):
            X = gen_trip(net, t, seed); Y = Zt[torch.as_tensor(t['im'], device=dev)]; g.manual_seed(123)
            rows.append(dict(em=t['em'], ta=t['ta'], ED=float(L.energy(X, Y, gen=g)), terr=24 * (knn_time(X, REF[split][i]) - t['tm']), disp=disp(X, Y)))
    return pd.DataFrame(rows)
def per_mid(df): return df.groupby('em').agg(ta=('ta', 'mean'), ED=('ED', 'mean'), terr=('terr', 'mean'))
BL = evaluate(('linear_noise', None), BCFG, 'locked'); LL = evaluate(('linear', None), dict(pair='emd_cen'), 'locked')
bl, ll = per_mid(BL), per_mid(LL)
@torch.no_grad()
def knnd(X, ref, k=10): return float(torch.cat([torch.cdist(X[i:i + 2048], ref).topk(k, largest=False).values.mean(1) for i in range(0, len(X), 2048)]).mean())
HLIN = (0.5 * (Zt[HIA] + HBP))
KL_ALL = knnd(HLIN, HREF_ALL); HO = torch.as_tensor(~HTR, device=dev); KL_HO = knnd(HLIN[HO], HREF_HO)
@torch.no_grad()
def gen_human(net, seed, fr=0.5):
    torch.manual_seed(seed); A = Zt[HIA]; eps = torch.randn_like(A); return gnet(net, A, HBP, HUM_D, HUM_TA, fr, eps=eps)[0]

def full_eval(nets, name, save_latent=True):
    """nets: list of 5 seed models. Returns summary dict + per-mid table; saves human latent."""
    vs, eds, ters, gens, hp, hph, sh = [], [], [], [], [], [], []
    for s, net in enumerate(nets):
        vs.append(score(evaluate_net(net, 'val', s), BASE)[0])
        df = per_mid(evaluate_net(net, 'locked', s)); eds.append(df.ED); ters.append(df.terr)
        G = gen_human(net, s); gens.append(G.cpu().numpy()); hp.append(knnd(G, HREF_ALL) / KL_ALL); hph.append(knnd(G[HO], HREF_HO) / KL_HO)
        sh.append(float((G - HLIN).norm(dim=1).mean()))
    ed = pd.concat(eds, axis=1).mean(1); te = pd.concat(ters, axis=1).mean(1); out = dict(variant=name, n_seeds=len(nets), val_score=float(np.mean(vs)), val_score_sd=float(np.std(vs)))
    for nm, ref in [('linear', ll), ('linear_noise', bl)]:
        v = np.log(ed / ref.ED); out.update({f'locked_median_pct_vs_{nm}': 100 * (np.exp(v.median()) - 1), f'locked_frac_better_vs_{nm}': float((v < 0).mean()),
                                             f'locked_p_vs_{nm}': float(wilcoxon(v).pvalue)})
    out.update(n_mid=len(ed), abs_terr_h=float(te.abs().median()), human_plaus=float(np.mean(hp)), human_plaus_sd=float(np.std(hp)), human_plaus_heldout=float(np.mean(hph)),
               shift_from_linear_seedmean=float(np.linalg.norm(np.stack(gens).mean(0) - HLIN.cpu().numpy(), axis=1).mean()), shift_from_linear_perseed=float(np.mean(sh)))
    pm = pd.DataFrame({'ED_model': ed, 'terr_model': te, 'ED_linear': ll.ED, 'ED_linear_noise': bl.ED, 'ta': ll.ta})
    if save_latent: np.savez_compressed(OD + f'latent/{name}_human_t05_latent.npz', gen=np.stack(gens).astype(np.float32), linear=HLIN.cpu().numpy(), h_a=HUM['ia'])
    return out, pm, np.stack(gens)

# ---------------- marker decoding with the final_v2 decoder (pools as in ai/step5_milestones.py)
class Dec(nn.Module):
    def __init__(s, d, G, h, Ly, drop):
        super().__init__(); s.net = L.mlp(d, G, h, Ly, drop); s.logth = nn.Parameter(torch.zeros(G))
    def forward(s, z, loglib): return torch.softmax(s.net(z), 1) * torch.exp(loglib)[:, None], torch.exp(s.logth)
GENES = ['NOTO', 'TBXT', 'HOXA1', 'HOXB1', 'EOMES', 'GSC', 'NKX1-2', 'CDX2', 'HOXB8', 'MEOX1']
POOLS = {'NOTO': 'axial', 'TBXT': 'PS', 'HOXA1': 'PS', 'HOXB1': 'PS', 'EOMES': 'PS', 'GSC': 'DE', 'NKX1-2': 'CLE', 'CDX2': 'CLE', 'HOXB8': 'CLE', 'MEOX1': 'Para'}
KIND = {'EOMES': 'loss', 'GSC': 'loss', 'TBXT': 'ref'}
PM = {'axial': T05.cs7_group.values == 'Node', 'PS': T05.cs7_group.values == 'PS', 'DE': np.isin(T05.cs7_group.values, ['DE', 'AVE']),
      'CLE': T05.dom_cs8_group.values == 'CLE', 'Para': T05.dom_cs8_group.values == 'Para.Meso', 'bg': T05.cs7_group.values == 'VE2'}
_dec = None
def decoder():
    global _dec
    if _dec is None:
        D_ = torch.load('ai/step7/final_v2/decoder.pt', map_location=dev, weights_only=False); p = D_['params']
        m = Dec(94, len(D_['genes']), p['h'], p['L'], p['drop']).to(dev); m.load_state_dict(D_['state']); m.eval()
        gi = [D_['genes'].index(g) for g in GENES]; lib05 = np.load(OD + 'cache_lib05.npy'); _dec = (m, gi, lib05)
    return _dec
@torch.no_grad()
def markers(latents, sample_seed0=10):
    """latents: (S, N, 94). Returns per-seed analytic and sampled detection % per gene in its pool and in background."""
    m, gi, lib05 = decoder(); out = []
    for s, Zs in enumerate(latents):
        P = []; Smp = []; torch.manual_seed(sample_seed0 + s)
        for k in range(0, len(Zs), 2048):
            mu, th = m(torch.tensor(Zs[k:k + 2048], device=dev, dtype=torch.float32), torch.tensor(np.log(lib05[k:k + 2048]), device=dev, dtype=torch.float32))
            mu = mu[:, gi]; th = th[gi].expand_as(mu)
            P.append((1 - torch.exp(th * torch.log(th / (th + mu)))).cpu().numpy())
            r = torch.distributions.Gamma(th, th / mu.clamp_min(1e-8)).sample(); Smp.append((torch.poisson(r) > 0).float().cpu().numpy())
        P = np.vstack(P); Smp = np.vstack(Smp)
        for j, g in enumerate(GENES):
            pm, bg = PM[POOLS[g]], PM['bg']
            out.append(dict(seed=s, gene=g, pool=POOLS[g], det_expected=100 * P[pm, j].mean(), det_sampled=100 * Smp[pm, j].mean(), bg_expected=100 * P[bg, j].mean(), bg_sampled=100 * Smp[bg, j].mean()))
    return pd.DataFrame(out)
def call(g, x, bg):
    k = KIND.get(g, 'onset')
    if k == 'onset': return 'reached' if (x - bg >= 5 and x >= 2 * bg) else ('not reached' if x - bg < 2 else 'partial')
    if k == 'loss': return 'reached (fallen to background)' if x - bg <= 3 else 'not reached (still on)'
    return ''
def marker_summary(df, name):
    a = df.groupby('gene').agg(det_expected=('det_expected', 'mean'), det_expected_sd=('det_expected', 'std'), det_sampled=('det_sampled', 'mean'),
                               bg_expected=('bg_expected', 'mean'), bg_sampled=('bg_sampled', 'mean')).reindex(GENES)
    a['call_sampled'] = [call(g, r.det_sampled, r.bg_sampled) for g, r in a.iterrows()]; a['variant'] = name; a['pool'] = [POOLS[g] for g in GENES]
    return a.reset_index()
os.makedirs(OD + 'latent', exist_ok=True); os.makedirs(OD + 'weights', exist_ok=True)
