# Generator nested-CV re-evaluation on the 153-embryo rebuild (track out_gencv).
# Shared library: loop.py header (evaluate/knn_time/score; lib7 globals) + out_domain/dom.py pieces (NetF, finetune, gnet,
# human split, knnd, markers), with every rotation-dependent object (TR, REF, train embryos for EXTRA) swapped by set_rot(r).
# Run with cwd = the generative working directory (original: ai_t05_v153). Never writes under ai/.
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import os, sys, json, pickle, numpy as np, pandas as pd, torch, torch.nn as nn
torch.set_num_threads(int(os.environ.get('NTHR', '4')))
sys.path.insert(0, 'out_gencv/lib7dev'); import lib7          # device-patched copy (DEV env, default cuda)
sys.argv = [sys.argv[0], '0']
_src = open('ai/step7/loop.py').read().split('# ---------- search space')[0]
_cut = "BCFG=dict(pair='emd_cen',sigma0=SIG); BASE="
assert _cut in _src
_src = _src[:_src.index(_cut)] + "BCFG=dict(pair='emd_cen',sigma0=SIG)\n"   # skip rot-0 val baseline evaluation (not needed here)
exec(_src)                                                       # lib7 *, E, TV, mzc, REF, ET, knn_time, disp, evaluate, score, tune_sigma, SIG
assert SIG == 0.4
import step5_lib as L
OG = 'out_gencv/'
F2 = json.load(open('ai/step7/final_v2_orig/generator_config.json'))['config']; F2 = {k: v for k, v in F2.items() if k != 'rep'}
CFG = F2
V1A = json.load(open(OG + 'V1a_config_ref.json'))
d = Z.shape[1]

# ---------------- rotation swap (as out_robustness/run_rot.py)
ROT = {}
def set_rot(rot):
    TRr = pickle.load(open(f'ai/rot/TR_rot{rot}.pkl', 'rb')); TR.clear(); TR.update(TRr)
    Es = pd.read_csv(f'ai/mz_bench/rot/split_rot{rot}.csv', index_col=0); TVr = set(Es.index[Es.split.isin(['T', 'V'])])
    def ref_idx_r(t): return mzc[np.isin(emb[mzc], list(TVr - {t['ea'], t['em'], t['eb']}))]
    REF.clear(); REF.update({s: [torch.as_tensor(ref_idx_r(t), device=dev) for t in TR[s]] for s in ['val', 'locked']})
    assert not set(t['em'] for t in TR['locked']) & TVr and all(t['ea'] in TVr and t['eb'] in TVr for t in TR['locked'])
    # dom.py: extra off-centre mouse triplets from THIS rotation's train embryos (partners re-used from TR['train'])
    ET_ = Es[Es.split == 'T']; seen = {}
    for t in TR['train']: seen[(t['ea'], t['eb'])] = t
    EXTRA = []
    for (ea, eb), t in seen.items():
        Dd = t['tb'] - t['ta']
        for em, r in ET_.iterrows():
            if em in (ea, eb): continue
            fr = (r.t - t['ta']) / Dd
            if 0.1 <= fr <= 0.35 or 0.65 <= fr <= 0.9:
                EXTRA.append(dict(t, em=em, tm=r.t, im=np.where((emb == em) & valid)[0]))
    ROT.clear(); ROT.update(rot=rot, split=Es, PTR=[_prep(t) for t in TR['train']], PEX=[_prep(t) for t in EXTRA], n_extra=len(EXTRA))
    return Es

# ---------------- human split by CS7 ancestor clone (dom.py, unchanged)
u7 = np.load('ai/step5_u7.npy'); u8 = np.load('ai/step5_u8.npy')
T05 = pd.read_csv('ai/step5_human_t05_index.csv')
HD = dict(HUM); HD['ta'] = 7.25; HD['tb'] = 7.625
HUM_D, HUM_TA = 0.375, 7.25
_r = np.random.default_rng(2026)
anc = pd.read_csv(DATA + '/cs7_cs8_matching/figure/final_ggot/ggot_table_cs8_ancestor.csv')
tr7 = np.zeros(len(u7), bool)
for g_, idx in T05.groupby('cs7_group').groups.items():
    ci = T05.cs7_idx.values[np.asarray(idx)]; tr7[_r.choice(ci, len(ci) // 2, replace=False)] = True
nopc = np.setdiff1d(np.arange(len(u7)), T05.cs7_idx.values); tr7[_r.choice(nopc, len(nopc) // 2, replace=False)] = True
matched = anc.cls.values != 'unmatched'
tr8 = np.where(matched, tr7[anc.ancestor_idx.values], _r.random(len(anc)) < 0.5)
HTR = tr7[T05.cs7_idx.values]
HREF_ALL = Zt[torch.as_tensor(np.r_[u7, u8], device=dev)]
HREF_HO = Zt[torch.as_tensor(np.r_[u7[~tr7], u8[~tr8]], device=dev)]
U7TR = torch.as_tensor(u7[tr7], device=dev); U8TR = torch.as_tensor(u8[tr8], device=dev)

class NetF(nn.Module):
    def __init__(s, d, h, Ly, drop, sig_init):
        super().__init__(); s.f = L.mlp(2 * d + 3, 2 * d, h, Ly, drop); s.d = d
    def forward(s, lin, dlt, D, ta, fr):
        o = s.f(torch.cat([lin, dlt, D[:, None], ta[:, None] - 7.5, fr[:, None] - 0.5], 1)); return o[:, :s.d], o[:, s.d:].clamp(-6, 2)
    @staticmethod
    def from_net(net):
        m = NetF(net.d, net.f[0].out_features, CFG['L'], CFG['drop'], CFG['sig_init']).to(dev)
        sd = {k: v.clone() for k, v in net.state_dict().items()}; w = sd['f.0.weight']; sd['f.0.weight'] = torch.cat([w, torch.zeros(w.shape[0], 1, device=w.device)], 1)
        m.load_state_dict(sd); return m

def _full(n, v): return torch.full((n,), float(v), device=dev)
def gnet(net, A, Bp, D, ta, fr, cfg=CFG, scale=True, eps=None):
    lin = (1 - fr) * A + fr * Bp; n = len(A)
    if isinstance(net, NetF): mu, ls = net(lin, Bp - A, _full(n, D), _full(n, ta), _full(n, fr))
    else: mu, ls = net(lin, Bp - A, _full(n, D), _full(n, ta))
    eps = torch.randn_like(lin) if eps is None else eps
    ds, ns = (cfg['ds'], cfg['ns']) if scale else (1.0, 1.0)
    env = 4 * fr * (1 - fr) if getattr(net, 'env', False) else 1.0
    return lin + env * (ds * mu + ns * torch.exp(ls) * eps), mu

def _prep(t):
    pair = CFG['pair']
    return dict(ia=torch.as_tensor(t['ia'], device=dev), bp=tt(t[pair]), im=torch.as_tensor(t['im'], device=dev),
                D=t['tb'] - t['ta'], ta=t['ta'], fr=(t['tm'] - t['ta']) / (t['tb'] - t['ta']),
                ea=torch.as_tensor(np.where((emb == t['ea']) & valid)[0], device=dev), eb=torch.as_tensor(np.where((emb == t['eb']) & valid)[0], device=dev))
HIA = torch.as_tensor(HUM['ia'], device=dev); HBP = tt(HUM[CFG['pair']]); HTRi = torch.as_tensor(np.where(HTR)[0], device=dev)
def _samp(idx, n): return idx[torch.randint(len(idx), (n,), device=dev)]

def finetune(base_net, seed, lam_h=0.0, steps=1500, lr_mult=0.3, p_off=0.3, w_end_m=0.2, use_frac=True, center_nominal=False, envelope=False, hum_end=True):
    """dom.py finetune (lam_adv=0 branch), initialised from the in-memory final_v2 net of the same seed fitted on this rotation."""
    PTR, PEX = ROT['PTR'], ROT['PEX']
    torch.manual_seed(1000 + seed); rng = np.random.default_rng(1000 + seed); bs = CFG['bs']
    net = NetF.from_net(base_net); net.env = envelope; net.train()
    opt = torch.optim.AdamW(net.parameters(), lr=CFG['lr'] * lr_mult, weight_decay=CFG['wd'])
    sch = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=CFG['lr'] * lr_mult, total_steps=steps, pct_start=0.1)
    for it in range(steps):
        off = use_frac and rng.random() < p_off; P = PEX[rng.integers(len(PEX))] if off else PTR[rng.integers(len(PTR))]
        fr = P['fr'] if use_frac else 0.5
        if center_nominal and not off: fr = 0.5
        j = torch.randint(len(P['ia']), (bs,), device=dev); A = Zt[P['ia'][j]]; Bp = P['bp'][j]
        gen, mu = gnet(net, A, Bp, P['D'], P['ta'], fr, scale=False)
        loss = L.energy(gen, Zt[_samp(P['im'], bs)]) + CFG['lam'] * (mu ** 2).mean()
        if use_frac and w_end_m > 0:
            g0, _ = gnet(net, A, Bp, P['D'], P['ta'], 0.0, scale=False); g1, _ = gnet(net, A, Bp, P['D'], P['ta'], 1.0, scale=False)
            loss = loss + w_end_m * (L.energy(g0, Zt[_samp(P['ea'], bs)]) + L.energy(g1, Zt[_samp(P['eb'], bs)]))
        if lam_h > 0:
            k = _samp(HTRi, bs); HA = Zt[HIA[k]]; HB = HBP[k]
            h0, _ = gnet(net, HA, HB, HUM_D, HUM_TA, 0.0); h1, _ = gnet(net, HA, HB, HUM_D, HUM_TA, 1.0)
            l_end = L.energy(h0, Zt[_samp(U7TR, bs)]) + L.energy(h1, Zt[_samp(U8TR, bs)])
            hm, _ = gnet(net, HA, HB, HUM_D, HUM_TA, 0.5)
            hq_c, _ = gnet(net, HA, hm, HUM_D / 2, HUM_TA, 0.5)
            hq_d, _ = gnet(net, HA, HB, HUM_D, HUM_TA, 0.25)
            l_end = l_end if hum_end else 0.0 * l_end
            loss = loss + lam_h * (l_end + L.energy(hq_c, hq_d))
        opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(net.parameters(), 1.0); opt.step(); sch.step()
    net.eval(); return net

@torch.no_grad()
def gen_trip(net, t, seed):
    torch.manual_seed(seed); A = Zt[torch.as_tensor(t['ia'], device=dev)]; Bp = tt(t[CFG['pair']])
    eps = torch.randn_like(A); return gnet(net, A, Bp, t['tb'] - t['ta'], t['ta'], 0.5, eps=eps)[0]
def evaluate_net(net, split, seed):
    rows = []; g = torch.Generator(device=dev)
    with torch.no_grad():
        for i, t in enumerate(TR[split]):
            X = gen_trip(net, t, seed); Y = Zt[torch.as_tensor(t['im'], device=dev)]; g.manual_seed(123)
            rows.append(dict(em=t['em'], ta=t['ta'], ED=float(L.energy(X, Y, gen=g)), terr=24 * (knn_time(X, REF[split][i]) - t['tm']), disp=disp(X, Y)))
    return pd.DataFrame(rows)

@torch.no_grad()
def knnd(X, ref, k=10): return float(torch.cat([torch.cdist(X[i:i + 2048], ref).topk(k, largest=False).values.mean(1) for i in range(0, len(X), 2048)]).mean())
HLIN = (0.5 * (Zt[HIA] + HBP)); HO = torch.as_tensor(~HTR, device=dev)
KL_ALL = knnd(HLIN, HREF_ALL); KL_HO = knnd(HLIN[HO], HREF_HO)
@torch.no_grad()
def gen_human(net, seed, fr=0.5):
    torch.manual_seed(seed); A = Zt[HIA]; eps = torch.randn_like(A); return gnet(net, A, HBP, HUM_D, HUM_TA, fr, eps=eps)[0]

# ---------------- marker decoding (dom.py markers(); decoder path configurable -> retrained decoder on the NEW Z)
class Dec(nn.Module):
    def __init__(s, d, G, h, Ly, drop):
        super().__init__(); s.net = L.mlp(d, G, h, Ly, drop); s.logth = nn.Parameter(torch.zeros(G))
    def forward(s, z, loglib): return torch.softmax(s.net(z), 1) * torch.exp(loglib)[:, None], torch.exp(s.logth)
GENES = ['NOTO', 'TBXT', 'HOXA1', 'HOXB1', 'EOMES', 'GSC', 'NKX1-2', 'CDX2', 'HOXB8', 'MEOX1']
POOLS = {'NOTO': 'axial', 'TBXT': 'PS', 'HOXA1': 'PS', 'HOXB1': 'PS', 'EOMES': 'PS', 'GSC': 'DE', 'NKX1-2': 'CLE', 'CDX2': 'CLE', 'HOXB8': 'CLE', 'MEOX1': 'Para'}
PM = {'axial': T05.cs7_group.values == 'Node', 'PS': T05.cs7_group.values == 'PS', 'DE': np.isin(T05.cs7_group.values, ['DE', 'AVE']),
      'CLE': T05.dom_cs8_group.values == 'CLE', 'Para': T05.dom_cs8_group.values == 'Para.Meso', 'bg': T05.cs7_group.values == 'VE2'}
def load_decoder(path):
    D_ = torch.load(path, map_location=dev, weights_only=False); p = D_['params']
    m = Dec(d, len(D_['genes']), p['h'], p['L'], p['drop']).to(dev); m.load_state_dict(D_['state']); m.eval()
    return m, [D_['genes'].index(g) for g in GENES], np.load(OG + 'cache_lib05.npy'), D_['genes']
@torch.no_grad()
def markers(latents, dec, sample_seed0=10):
    m, gi, lib05, _ = dec; out = []
    for s, Zs in enumerate(latents):
        P = []; Smp = []; torch.manual_seed(sample_seed0 + s)
        for k in range(0, len(Zs), 2048):
            mu, th = m(torch.tensor(Zs[k:k + 2048], device=dev, dtype=torch.float32), torch.tensor(np.log(lib05[k:k + 2048]), device=dev, dtype=torch.float32))
            mu = mu[:, gi]; th = th[gi].expand_as(mu)
            P.append((1 - torch.exp(th * torch.log(th / (th + mu)))).cpu().numpy())
            r = torch.distributions.Gamma(th, th / mu.clamp_min(1e-8)).sample(); Smp.append((torch.poisson(r) > 0).float().cpu().numpy())
        P = np.vstack(P); Smp = np.vstack(Smp)
        for j, g in enumerate(GENES):
            pm, bg = PM[POOLS[g]], PM['bg']
            out.append(dict(seed=s, gene=g, pool=POOLS[g], det_expected=100 * P[pm, j].mean(), det_sampled=100 * Smp[pm, j].mean(), bg_expected=100 * P[bg, j].mean(), bg_sampled=100 * Smp[bg, j].mean()))
    return pd.DataFrame(out)
