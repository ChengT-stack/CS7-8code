import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import numpy as np, pandas as pd, tarfile, gzip, io, scipy.sparse as sp, anndata as ad
B=DATA + '/cs7_cs8_matching/'; MZ=B+'external/mouse_mittnenzweig2021/'
ANN=DATA + '/artifacts/mittnenzweig_metacell_annotation.csv'
md=pd.concat([pd.read_csv(MZ+f,sep='\t') for f in ['GSE169210_wt_bl6_single_cell_metadata.txt.gz','GSE169210_wt_icr_single_cell_metadata.txt.gz']])
md=md.dropna(subset=['developmental_time','metacell_id']).merge(pd.read_csv(ANN)[['metacell_id','author_cell_type']],on='metacell_id',how='left')
CO={**{k:'EPI' for k in ['Epiblast','Caudal epiblast','Definitive Ectoderm','Rostral neural plate','Caudal neural plate','Surface ectoderm']},
    **{k:'PS' for k in ['Primitive streak','Anterior Primitive Streak']},
    **{k:'MESO' for k in ['Early nascent mesoderm','Late nascent mesoderm','Rostral mesoderm','Caudal mesoderm','Lateral & intermediate mesoderm','Cardiac Mesoderm','Paraxial mesoderm','Cardiomyocytes']},
    'Node/Notochord':'AXIAL','Definitive endoderm':'DE','Foregut':'DE','Visceral endoderm':'VE','ExE endoderm':'VE'}
md['group']=md.author_cell_type.map(CO); md=md[md.group.notna()].copy(); md['well']=[c[len(p)+1:] for c,p in zip(md.cell_id,md.plate)]
need=set(md.plate); tf=tarfile.open(MZ+'GSE169210_RAW.tar'); mats=[]; wells=[]; rows=None
for m in tf.getmembers():
    pl=m.name.split('_',1)[1].replace('.txt.gz','')
    if pl not in need: continue
    df=pd.read_csv(io.BytesIO(gzip.decompress(tf.extractfile(m).read())),sep='\t',index_col=0); df=df[~df.index.str.startswith('ERCC')]
    if rows is None: rows=df.index
    assert (df.index==rows).all()
    keep=[c for c in df.columns if c in set(md.well[md.plate==pl])]; mats.append(sp.csr_matrix(df[keep].values.T.astype(np.float32))); wells+=[(pl,c) for c in keep]
X=sp.vstack(mats).tocsr(); W=pd.MultiIndex.from_tuples(wells)
md=md.set_index(['plate','well']).loc[W].reset_index()
sym=np.array([s.split(';')[0] for s in rows])
# mouse-symbol matrix (sum duplicate symbols)
u,inv=np.unique(sym,return_inverse=True); M=sp.csr_matrix((np.ones(len(sym)),(np.arange(len(sym)),inv)),shape=(len(sym),len(u)))
Xm=(X@M).tocsr()
obs=pd.DataFrame({'embryo':md.embryo_id.values,'time':md.developmental_time.values,'cell_type':md.author_cell_type.values,'group':md.group.values},index=[f'mz{i}' for i in range(len(md))])
a=ad.AnnData(Xm,obs=obs,var=pd.DataFrame(index=pd.Index(u).str.upper())); a.var_names_make_unique(); a.write_h5ad(DATA + '/UCE/inputs/Mittnenzweig153.h5ad')
# human-ortholog matrix on the integrated scVI HVGs
orth=pd.read_csv(B+'external/mouse_pijuan_sala/mouse_human_orthologs_one2one_Ensembl116.csv'); orth=orth[orth.homology_type=='ortholog_one2one']
mp=dict(zip(orth.mouse_symbol,orth.human_symbol)); hv=ad.read_h5ad('ai/integrated_scvi.h5ad',backed='r').var_names
hs=np.array([mp.get(s,'') for s in u]); col={g:i for i,g in enumerate(hv)}
r=[j for j,h in enumerate(hs) if h in col]; c=[col[hs[j]] for j in r]
P=sp.csr_matrix((np.ones(len(r)),(r,c)),shape=(len(u),len(hv))); Xh=(Xm@P).tocsr()
b=ad.AnnData(Xh,obs=obs.copy(),var=pd.DataFrame(index=hv)); b.write_h5ad('ai/mz_bench/mz_hvg_counts.h5ad')
print(a.shape, 'HVG covered',len(set(c)),'/',len(hv)); print('UMI/cell median',float(np.median(np.asarray(X.sum(1)).ravel())))
print(obs.group.value_counts().to_dict()); print('embryos',obs.embryo.nunique())
