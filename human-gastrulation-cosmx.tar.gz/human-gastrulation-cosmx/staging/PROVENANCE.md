# Provenance — staging/

All scripts are the final versions used for the manuscript figures and tables. Edits relative to the originals: absolute paths replaced by `$HGC_DATA` / `$HGC_OUT` roots (relative sub-paths kept), a provenance header added, analysis-platform calls and artifact markers removed, imports of sibling scripts pointed at their repository folder, and Table S2 read from the xlsx. No algorithm, parameter, threshold, random seed or output definition was changed. Original paths below refer to the authors' project drives F: and G:.

Reconstructed scripts: code that existed only as cells of persistent kernel sessions was copied verbatim from the session transcripts (frame id and message numbers in the header of every cell); inspection-only and figure-polishing cells were left out, and cells that stopped with an error are truncated at the failing line and marked. sha256 values of reconstructed scripts refer to the extracted transcript text.

| Repository file | Original source | sha256 of original | Notes |
|---|---|---|---|
| `common/figure_style.py` | [F:]/CS6-CS7/cs7_cs8_matching/figure/figure_style.py | `8d16286025719a39…` | support module (copied unchanged except a docstring) |
| `00_inputs/export_tenx_tyser.R` | [G:]/data/milestone_evidence/out_scrna/work/export.R | `06f32d8fffc70e01…` | run with cwd = $HGC_DATA/milestone_evidence/out_scrna/work |
| `00_inputs/export_inhouse10x_cs8.R` | [G:]/data/milestone_evidence/hue11/export.R | `77a15d723c03cfe4…` | run with cwd = $HGC_DATA/milestone_evidence/hue11 |
| `00_inputs/export_stereoseq_cs9_markers.R` | [G:]/data/milestone_evidence/out_stereo/work/cs9_export.R | `ead71a3255829c97…` | run with cwd = $HGC_DATA/milestone_evidence/out_stereo/work |
| `00_inputs/monkey_recover_counts.py` | reconstructed from transcript c88279b5 (messages 86, 88, 102) | `9d64d7a3c2f1ce29…` | writes back into $HGC_DATA/GSE193007/ as in the original |
| `00_inputs/mittnenzweig_cells_markers.py` | script prep.py from transcript 5113e657 (messages 3275, 3277) | `54292eaad69dce02…` | needs mittnenzweig_metacell_annotation.csv (GAP) and mmc1.xlsx |
| `01_milestones/mouse_reference_curves.py` | reconstructed from transcript 5113e657 (messages 3156-3191) | `3a547e66bfe7a9e8…` | reconstructed; reads milestone workbook 20261030-Fig_milestone_axis_human_monkey_data.xlsx for labels and figure onsets |
| `01_milestones/mouse_marker_detection.py` | [G:]/data/milestone_evidence/mz/milestones_mouse.py | `cdd77c655cd0f29c…` | run with cwd = $HGC_DATA/milestone_evidence |
| `01_milestones/milestone_definitions.py` | [G:]/data/milestone_evidence/mz/allstage/definitions.py | `c4de263ff422fccd…` | run with cwd = $HGC_DATA/milestone_evidence |
| `01_milestones/layer_recluster.py` | [G:]/data/milestone_evidence/mz/rescue/recluster.py | `e13a9d2e6cc492fa…` | run with cwd = $HGC_DATA/milestone_evidence |
| `01_milestones/layer_rescue.py` | [G:]/data/milestone_evidence/mz/rescue/rescue.py | `d50be5fe69b6897f…` | run with cwd = $HGC_DATA/milestone_evidence |
| `01_milestones/monkey_markers.py` | [G:]/data/milestone_evidence/mz/monkey/markers.py | `916e41ffb129e16f…` |  |
| `01_milestones/monkey_recluster.py` | [G:]/data/milestone_evidence/mz/monkey/recluster_monkey.py | `296e54dc6d2c5018…` |  |
| `01_milestones/monkey_recluster_rerun.py` | [G:]/data/milestone_evidence/out_monkey/work/recluster_rerun.py | `68c60a79baae3b87…` | run with cwd = $HGC_DATA/milestone_evidence/out_monkey/work |
| `01_milestones/evidence_cosmx_export.R` | reconstructed from transcript ce4e1bd4 (messages 37, 39) | `89cd7bd52136af8e…` |  |
| `01_milestones/evidence_cosmx.py` | reconstructed from transcript ce4e1bd4 | `936e45302a444cc4…` | reconstructed; evidence-figure cells omitted |
| `01_milestones/evidence_scrna.py` | reconstructed from transcript 31f871e7 | `83ceec09305dd9f5…` | reconstructed; evidence-figure cells omitted |
| `01_milestones/evidence_stereoseq.py` | reconstructed from transcript 18ae5ceb | `5a26370aedf14348…` | reconstructed; evidence-figure cells omitted |
| `01_milestones/evidence_monkey.py` | reconstructed from transcript 6696c2c1 | `a8b23822850aaaeb…` | reconstructed; evidence-figure cells omitted |
| `01_milestones/build_calls.py` | [G:]/data/milestone_evidence/mz/allstage/build.py | `ccc1448b47905ede…` | calls are hard-coded with evidence strings (curated); run with cwd = $HGC_DATA/milestone_evidence |
| `01_milestones/audit_calls.py` | [F:]/CS6-CS7/cs7_cs8_matching/figure4_staging/milestone/audit.py | `f8b8c9cde9717a48…` | 18 call changes hard-coded with evidence (from the evidence_* reviews) |
| `01_milestones/add_stereoseq_cs9.py` | reconstructed from transcript 824ef1ce (messages 8498-8527, 2026-11-17) | `811888e61e01dd90…` | reconstructed; final version (2026-11-17) |
| `01_milestones/plot_fig6AB.py` | [F:]/CS6-CS7/cs7_cs8_matching/figure6_cs9/m4ab_cs9.py | `ec89a372b92570fe…` | final script (m4ab_cs9.py) |
| `02_mittnenzweig_validation/build_sfig7.py` | [F:]/CS6-CS7/cs7_cs8_matching/figure6/SuppFig8/build_supp8.py | `0376498d3ec799d3…` | script panel letters A, B (curves), C (agreement), D (per-embryo staging); final figure shows C = per-embryo staging and D = agreement |
| `03_ps_dynamics/stereo_pb.R` | [F:]/CS6-CS7/cs7_cs8_matching/figure4_staging/ps_dynamics/work/stereo_pb.R | `43aebb3145fab1d4…` | writes to cwd (originally figure4_staging/ps_dynamics/work) |
| `03_ps_dynamics/ps_dynamics_pipeline.py` | reconstructed from transcript 1c2d1a43 | `13f745a4687673c7…` | reconstructed; also writes draft figures (superseded by build_fig6.py) |
| `03_ps_dynamics/m4ab.py` | [F:]/CS6-CS7/cs7_cs8_matching/figure6/m4ab.py | `4ddf88c01867e612…` | needs audited_calls.csv/windows_audited.csv copied into $HGC_OUT/figure6/ |
| `03_ps_dynamics/build_fig6.py` | [F:]/CS6-CS7/cs7_cs8_matching/figure6/build_fig6.py | `89b49b61c9267715…` | usage: python build_fig6.py Fig4CD_PS_dynamics_source_data.xlsx PS_dynamic_genes_mouseE7.0-E7.75_vs_human.csv; final panel arrangement done manually |
| `04_lefty_fgf/stereo_detection_by_cluster.R` | reconstructed from transcript 5113e657 (messages 1086, 1116) | `9d6a78b8834cb5f4…` | reconstructed |
| `04_lefty_fgf/signalling_detection_tables.py` | reconstructed from transcript 5113e657 (messages 880-1142) | `e4f7f575cba1fd6a…` | reconstructed |
| `04_lefty_fgf/tyser_signalling_detection.R` | reconstructed from transcript 723f1529 (messages 202, 205) | `fdd4db222af5a93e…` | reconstructed |
| `04_lefty_fgf/lefty_fgf_detection.py` | lineage export s8e_csv_code.py as executed in transcript 13ab33ab (messages 197, 210) | `5658fbd64d719b06…` | reconstructed from executed lineage export |
| `04_lefty_fgf/plot_fig6F.py` | [G:]/file/20261028-figures/SuppFig8-11_panels_ai/scripts/build_SuppFig8E_merged_FGF.py | `bdb92dc1d213ee30…` | reads SuppFig8E_LEFTY_FGF_detection.csv from cwd; TDGF1 row dropped (as in final) |

## Version choices

- Figure 6A/B: `figure6_cs9/m4ab_cs9.py` (2026-11-17, adds Stereo-seq CS9) supersedes `figure6/m4ab.py` (2026-11-06) and `figure4_staging/final_v2/m4ab.py` / `final/m4ab.py` (2026-11-03/04). The CS9 calls were added in session 824ef1ce (messages 8498-8527); the platform lineage export of those files is a rewritten approximation (it writes to different paths) and was not used.
- Audited calls: `figure4_staging/milestone/audit.py` (2026-11-03) on top of `milestone_evidence/mz/allstage/build.py` (2026-11-02).
- Supplementary Figure 7: `figure6/SuppFig8/build_supp8.py` (2026-11-06; aligned to the audited onsets of Figure 6A) supersedes `figure4_staging/final_v2/build_supp_mittnenzweig.py` (2026-11-04) and `final/build_supp.py`. The figure was renumbered from Supplementary Figure 8 to 7 later.
- Figure 6C/D/E/G: `figure6/build_fig6.py` version 5 (2026-11-06, artifact cd6502dc, 13,746 bytes) with source data from the PS-dynamics sub-session 1c2d1a43 (2026-11-03).
- Figure 6F: `build_SuppFig8E_merged_FGF.py` (session 13ab33ab, 2026-11-13; LEFTY1/2, NOG, SHH, FGF8, FGF17; CosMx CS8 Rostral.Meso added; TDGF1 row and CosMx max column dropped) supersedes the LEFTY-only heatmap (former Supplementary Figure 8E).
- Not included (superseded or exploratory): `mz_interval*.py`, `lower_bound.py`, `axis/` (interval-matching analyses), `figure4_staging/final/`, `hox_AP/` (Figure 3L/M, other module), `t05_*`, `endoderm_markers/`, `external/monkey_early/` (early primate replication, not in the manuscript).
