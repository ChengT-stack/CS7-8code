# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/cs7_cs8_matching/figure1_L_heatmap_by_stage/v2_HESX1_SFRP1/build_SuppFig3_heatmap_v2.py
#     (2026-11-11; artifact 39f048e3)
# sha256 of original: 483938f007089e08329632d43d14fc57b8485a45916a226374c531998317c107
# Methods paragraphs: P349
# Produces: Supplementary Figure 3A (row z-score heatmap, clipped ±2.5; SuppFig3A_marker_heatmap_rowZ.*,
#     artifact c4f1d0f5)
# Edits/notes: font folder -> HGC_FONTS; scheme39.py read from this folder.
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

import os
import numpy as np, pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm

FD = os.path.join(FONT_DIR, "")
for f in ["arial.ttf", "arialbd.ttf", "ariali.ttf", "arialbi.ttf"]:
    if os.path.exists(FD + f):
        fm.fontManager.addfont(FD + f)
mpl.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
                     "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
                     "axes.unicode_minus": False, "savefig.facecolor": "white"})

# mean CP10K per 39Type x stage, curated_kept cells (identical to the original S2A input, max |diff| 1e-12)
CM = pd.read_csv("hm/S2A_mean_cp10k_type_stage_v2.csv", index_col=0)

exec(open(SCRIPT_DIR / "scheme39.py").read())          # SCHEME list (label, colour), Type39_scheme order
ORDER = [t for t, _ in SCHEME]
COL = dict(SCHEME)
ABBR = {"Exe.Meso progenitor": "Exe.Meso prog.", "Am.Epi progenitor": "Am.Epi prog.", "Heart mesoderm": "Heart meso.",
        "Primitive erythroblast": "Prim.eryth.", "Prechordal plate": "Prechordal pl.", "AVE": "ADE", "Pari.Endo": "Pari.ys.Endo"}
def short(t):
    s = t[t.index("(") + 1:t.rindex(")")] if "(" in t else t
    return ABBR.get(s, s)
LAB = lambda t, s: "Primitive node" if (t == "Node" and s == "CS7") else short(t)
COLS = [(t, s, f"{t}||{s}") for t in ORDER for s in ("CS7", "CS8") if f"{t}||{s}" in CM.columns]
NUM = {t: i + 1 for i, t in enumerate(ORDER)}
NC = len(COLS)
cb_e = [0]
for j in range(1, NC):
    if COLS[j][0] != COLS[j - 1][0]:
        cb_e.append(j)
cb_e.append(NC)

SEG_A = ("POU5F1 NANOG DNMT3B SALL3 USP44 THY1 DPPA3 DPPA5 TFCP2L1 DNMT3L SUSD2 LIN28A SOX2 HESX1 SFRP1 CYP26A1 FST FGFR1 "
         "EOMES MIXL1 MESP1 TBXT FGFR4 WNT3A WNT8A CHRD LHX1 NODAL NOTO FOXA2 FOXF1 NOG NKX1-2 NANOS3 TFAP2C RPL38 "
         "PRDM14 ANXA2 TFAP2A CER1 WNT5A HAND1 COL2A1 HAND2 GATA6 NKX2-5 MESP2 ISL1 POSTN PITX1 COL1A1 ALDH1A2 TBXT "
         "HOXA1 LEFTY2 FOXC2 TCF15 FOXC1 SOX17 GATA4 HNF4A").split()
SEG_B = ("PITX2 AFP TTR APOA1 APOE IHH SHH GATA3 DKK1 OTX2 PTPN13 SIX3 RUNX1 PECAM1 FLI1 TAL1 KDR CDH5 SPP1 CD36 "
         "PPBP GP1BB GP9 HBZ HBG2 GCM1 KRT7").split()
NEW = ["SALL3", "USP44", "THY1", "DPPA3", "DPPA5", "TFCP2L1", "DNMT3L", "SUSD2"]
GENES = SEG_A + SEG_B
SEG1, NR = len(SEG_A), len(GENES)
Hm = CM.loc[GENES, [c[2] for c in COLS]].to_numpy(float)
Hz = (Hm - Hm.mean(1, keepdims=True)) / (Hm.std(1, keepdims=True) + 1e-9)

MM = 1 / 25.4
tw, th = 2.30, 1.95                    # tile width / height (mm)
L, B = 6.0, 6.0
Wf = L + NC * tw + 20
Hf = B + NR * th + 35
VM = 2.5
SCOL = {"CS7": "#BFD9EE", "CS8": "#2C5F8A"}
fig = plt.figure(figsize=(Wf * MM, Hf * MM))
ax = fig.add_axes([L / Wf, B / Hf, NC * tw / Wf, NR * th / Hf])
qm = ax.pcolormesh(np.arange(NC + 1), np.arange(NR + 1), Hz, cmap="RdBu_r", vmin=-VM, vmax=VM,
                   edgecolors="white", linewidth=0.35)
ax.set_ylim(NR, 0); ax.set_xlim(0, NC); ax.set_xticks([]); ax.set_yticks([])
for sp in ax.spines.values():
    sp.set_visible(False)
for x_ in cb_e:
    ax.plot([x_, x_], [0, NR], color="white", lw=1.4, zorder=4)
for y_ in [0, SEG1, NR]:
    ax.plot([0, NC], [y_, y_], color="white", lw=2.4, zorder=5)
top = B + NR * th
axS = fig.add_axes([L / Wf, (top + 0.8) / Hf, NC * tw / Wf, 1.6 / Hf]); axS.set_axis_off()
axC = fig.add_axes([L / Wf, (top + 2.8) / Hf, NC * tw / Wf, 1.6 / Hf]); axC.set_axis_off()
for j, (t, s, k) in enumerate(COLS):
    axS.add_patch(mpl.patches.Rectangle((j / NC, 0), 1 / NC, 1, transform=axS.transAxes,
                                        facecolor=SCOL[s], edgecolor="white", lw=0.3))
    axC.add_patch(mpl.patches.Rectangle((j / NC, 0), 1 / NC, 1, transform=axC.transAxes,
                                        facecolor=COL[t], edgecolor="white", lw=0.3))
    fig.text((L + (j + 0.5) * tw) / Wf, (top + 5.0) / Hf, f"{NUM[t]} {LAB(t, s)}", rotation=90,
             ha="center", va="bottom", fontsize=5, color="#2A2A2A")
for i, g in enumerate(GENES):
    ax.text(NC + 0.4, i + 0.5, g, ha="left", va="center", fontsize=5, style="italic",
            color="#2A2A2A")
# legends
cax = fig.add_axes([L / Wf, (Hf - 9.0) / Hf, 9 / Wf, 1.5 / Hf])
cb = fig.colorbar(qm, cax=cax, orientation="horizontal", ticks=[-VM, VM])
cb.ax.set_xticklabels(["Low", "High"], fontsize=5); cb.ax.tick_params(length=0, pad=1)
cb.outline.set_linewidth(0.35)
fig.text(L / Wf, (Hf - 7.0) / Hf, "Row Z-score", fontsize=5, va="bottom")
for i, (nm, s) in enumerate([("CS7  (HuE#1)", "CS7"), ("CS8  (HuE#2)", "CS8")]):
    fig.add_artist(mpl.patches.Rectangle(((L + 14) / Wf, (Hf - 7.2 - i * 2.4) / Hf), 2.2 / Wf, 1.6 / Hf,
                                         facecolor=SCOL[s], edgecolor="#999999", lw=0.3,
                                         transform=fig.transFigure))
    fig.text((L + 17) / Wf, (Hf - 6.4 - i * 2.4) / Hf, nm, fontsize=5, va="center")
fig.text(1.0 / Wf, (Hf - 3.0) / Hf, "A", fontsize=8, fontweight="bold", va="center")

os.makedirs("hm/out", exist_ok=True)
base = "hm/out/SuppFig3A_marker_heatmap_rowZ"
fig.savefig(base + ".png", dpi=600); fig.savefig(base + ".pdf"); fig.savefig(base + ".svg")
fig.savefig(base + ".ai", format="pdf")
pd.DataFrame(Hz, index=[f"{i+1:02d}_{g}" for i, g in enumerate(GENES)],
             columns=[f"{NUM[t]} {LAB(t, s)} | {s}" for t, s, _ in COLS]).round(3).to_csv(base + "_rowZ.csv")
CM.loc[list(dict.fromkeys(GENES)), [c[2] for c in COLS]].to_csv(base + "_mean_cp10k.csv")
print(NC, NR, round(Wf), round(Hf))
