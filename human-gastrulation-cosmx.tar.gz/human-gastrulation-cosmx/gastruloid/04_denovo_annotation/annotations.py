# gastruloid/04_denovo_annotation/annotations.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/reannotation_denovo/code/annotations.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

"""Curated de novo annotation of every Leiden cluster (resolution 1.0) of every dataset.
Each entry: cluster -> (label, class, confidence H/M/L, marker evidence read from the cluster's own marker list).
Assigned from marker genes only; author labels and reference-atlas calls were not consulted.
OVR: finer (resolution 2.0) clusters that carry a different identity from their parent cluster."""
PL, PS, EN, HY, AX, NM, PX, LP, CA, EB, NMP, NE, NC, SE, AM, PGC, ST, XX = (
 'Pluripotent/epiblast', 'Primitive streak', 'Endoderm', 'Hypoblast/yolk-sac endoderm', 'Axial (node/notochord)', 'Nascent mesoderm',
 'Paraxial (PSM/somite)', 'Lateral/intermediate/ExE mesoderm', 'Cardiomyocyte', 'Endothelium/blood', 'NMP/caudal progenitor', 'Neural',
 'Neural crest', 'Surface ectoderm', 'Amnion-like', 'PGC-like', 'Stressed', 'Excluded')
LQ = ('Low-quality (low UMI)', XX, 'H', 'median UMI far below the dataset median; no lineage markers above background')
def DB(t): return ('Doublet-like', XX, 'M', t)
ANN, OVR = {}, {}

ANN['Heemskerk'] = {
 0: ('Amnion-like', AM, 'H', 'ISL1 GATA3 TFAP2A HAND1 BAMBI MSX2 HAPLN1; GABRP 27%'),
 1: ('Primitive streak-like', PS, 'H', 'TBXT MIXL1 SP5 EOMES MESP1; S phase'),
 2: ('Primitive streak-like', PS, 'H', 'EOMES FGF4 MIXL1 TBXT NODAL; G2/M'),
 3: ('Epiblast-like, streak-primed', PL, 'H', 'POU5F1 NANOG SOX2 GDF3 with MIXL1/EOMES/TBXT onset'),
 4: ('Epiblast-like (pluripotent)', PL, 'H', 'SOX2 NANOG USP44 LEFTY1/2 POU5F1'),
 5: ('Nascent mesoderm', NM, 'H', 'MESP1 LHX1 GATA6 APLNR PDGFRA TBX6 FOXC1 CER1'),
 6: ('Primitive streak-like', PS, 'M', 'NODAL MIXL1 TBXT EOMES with NANOG retained (epiblast-to-streak transition)'),
 7: ('PGC-like', PGC, 'H', 'SOX17 PRDM1 TFAP2C NANOS3 NANOG'),
 8: LQ, 9: LQ, 10: LQ}
OVR['Heemskerk'] = {18: ('Definitive endoderm', EN, 'L', 'SOX17 100% with EOMES CER1 GATA6 PRDM1; FOXA2 38%, CXCR4 9%, NANOS3 29% (early SOX17+ progenitor; endoderm versus PGC precursor not fully resolved)'),
                    4: ('Anterior PS/mesendoderm', PS, 'M', 'CER1 GSC EOMES NODAL OTX2 FGF4; SOX17 69%')}

ANN['Minn'] = {
 0: ('Anterior neuroectoderm-like', NE, 'M', 'SOX2 FRZB PTN FABP7 TTYH1; SIX3 19%; pluripotency genes declining'),
 1: ('Epiblast-like, anterior-biased', PL, 'M', 'POU5F1 SOX2 OTX2 HESX1 SFRP1 USP44'),
 2: DB('2.6x median UMI, doublet score 0.15; streak + PGC + amnion markers together'),
 3: ('Primitive streak-like', PS, 'H', 'TBXT MIXL1 EOMES NODAL'),
 4: LQ,
 5: ('Anterior PS/mesendoderm', PS, 'H', 'CER1 HHEX DKK1 GSC EOMES LHX1; FOXA2 24%'),
 6: ('Nascent mesoderm', NM, 'H', 'MESP1 APLNR HAS2 LHX1 TBX6 RSPO3'),
 7: ('Amnion-like', AM, 'H', 'ISL1 HAND1 GATA3 TFAP2A GABRP 80% VTCN1 22%'),
 8: ('ExE/lateral mesenchyme', LP, 'L', 'HAND1 ISL1 GATA3 TFAP2A with PRRX1 CDH11 HAND2 VIM; GABRP 23%, KRT7 11% (between amnion-like and mesenchymal states)'),
 9: ('Epiblast-like (pluripotent)', PL, 'H', 'POU5F1 SOX2 NANOG TDGF1 USP44'),
 10: ('Definitive endoderm', EN, 'H', 'SOX17 FOXA2 CXCR4 PRDM1 HNF1B'),
 11: ('PGC-like', PGC, 'H', 'TFAP2C SOX17 NANOS3 PRDM1 NANOG'),
 12: ('Lateral plate/cardiogenic mesoderm', LP, 'H', 'HAND1 KDR PRRX1 NKX2-5 67% ETV2 45% MYL7 TMEM88 (48 h re-plated sample only)'),
 13: DB('2.2x median UMI, doublet score 0.16; amnion + epiblast markers')}

ANN['Olmsted'] = {
 0: ('Mesothelium/epicardium-like', LP, 'M', 'WT1 KRT8/18 PODXL BNC1 WNT2B TMEM88 GATA6 ALDH1A2'),
 1: ('Mesothelium/epicardium-like', LP, 'M', 'WT1 KRT8/18 COL1A1 TNNT1 GATA6; G1'),
 2: ('Splanchnic mesenchyme', LP, 'M', 'COL3A1 PDGFRA FOXF1 TWIST1 CDH11'),
 3: ('Foregut endoderm', EN, 'H', 'FOXA2 SHH NKX2-1 56% SFTA3 CPM FOXA1; APOA1/TTR subset'),
 4: ('Splanchnic mesenchyme', LP, 'M', 'FOXF1 PDGFRA TBX2 PRRX2 LIX1 CXCL12'),
 5: ('Neural tube progenitor', NE, 'H', 'SOX2 RFX4 POU3F2 PAX3 HES5; NKX6-1 25% OLIG2 18%'),
 6: ('Coelomic/septum-transversum mesenchyme', LP, 'M', 'WT1 92% LHX9 GATA4 HAND2 TWIST1 LHX2'),
 7: ('Mixed epithelial (unresolved)', XX, 'L', 'housekeeping-type markers only; FOXA2, PAX2/8 and SOX2 cells mixed'),
 8: ('Dorsal neural tube/roof plate', NE, 'H', 'WNT1 LMX1A MSX1 ZIC2 WNT3A'),
 9: ('Nephric duct-like', LP, 'H', 'PAX2 PAX8 LHX1 EMX2 GATA3 HNF1B EPCAM'),
 10: ('Intermediate mesoderm-like', LP, 'M', 'PAX8 PAX2 EMX2 LHX1 WT1 55% SIX1 CDH6 (nephron-progenitor-like)'),
 11: ('Neuron', NE, 'H', 'STMN2 ELAVL3/4 TUBB3 TAGLN3'),
 12: ('Coelomic/septum-transversum mesenchyme', LP, 'M', 'WT1 LHX2 GATA4 TWIST1 HAND2; G1'),
 13: ('Floor plate', NE, 'H', 'SHH FOXA2 NTN1 SLIT1 SOX2 NKX6-1'),
 14: ('Neural crest', NC, 'H', 'SOX10 PLP1 MPZ S100B TFAP2B (Schwann-cell-precursor-like)'),
 15: ('Endothelium', EB, 'H', 'CDH5 PECAM1 KDR ESAM SOX17'),
 16: ('Cardiomyocyte', CA, 'H', 'TNNT2 MYL7 TTN ACTC1 NKX2-5')}
OVR['Olmsted'] = {7: ('Foregut endoderm', EN, 'M', 'FOXA2 SHH SOX2 GATA6'), 26: ('Nephric duct-like', LP, 'M', 'PAX2 PAX8 EMX2 GATA3')}

ANN['Gribaudo'] = {
 0: ('Lateral plate mesoderm', LP, 'H', 'HAND1 HAND2 FOXF1 GATA4/6 TMEM88 PDGFRA KRT8/19'),
 1: ('Intermediate mesoderm-like', LP, 'M', 'OSR1 PAX8 43% LHX1 ALDH1A2 H19/IGF2; WT1 17%'),
 2: ('Somite, sclerotome-biased', PX, 'H', 'MEOX1 TCF15 FOXC1/2 TWIST1 SOX9; PAX1 19% RIPPLY1'),
 3: ('Somite, sclerotome-biased', PX, 'H', 'MEOX1 TCF15 FOXC1/2 TWIST1 PAX9 35% PAX1 29% NKX3-2 28%'),
 4: DB('doublet score 0.23; somite (MEOX1 TCF15) and neural (SOX2 PAX6 HES5) markers together'),
 5: ('Neural tube progenitor', NE, 'H', 'SOX2 HES5 PAX6 NKX6-1 62% OLIG2 43% CDX1/2 (caudal, ventral)'),
 6: ('NMP/caudal epiblast-like', NMP, 'H', 'SOX2 CDX2 NKX1-2 FGF8 SP5 WNT5A; TBXT 30%'),
 7: ('NMP/caudal epiblast-like', NMP, 'H', 'SOX2 CDX2 CDX1 NKX1-2 FGF8; S phase'),
 8: ('Neural tube progenitor', NE, 'H', 'SOX2 HES5 PAX6 IRX3 SOX3; OLIG2 32%'),
 9: ('Neural tube progenitor', NE, 'H', 'SOX2 HES5 PAX6 IRX3; S phase'),
 10: ('Neural tube progenitor, pMN (OLIG2+)', NE, 'H', 'OLIG2 74% NKX6-1 73% NEUROG2; G2/M'),
 11: ('Neural tube progenitor', NE, 'H', 'SOX2 HES5 PAX6 IRX3; G2/M'),
 12: ('Neural tube progenitor', NE, 'H', 'SOX2 HES5 PAX6 NEUROG2 49%'),
 13: ('Neuron', NE, 'H', 'ELAVL4 NHLH1 ONECUT1/2 DLL3 NEUROG2 STMN2'),
 14: ('Neural crest', NC, 'M', 'PAX3 FOXD3 TFAP2A/B SOX10 28% (premigratory)'),
 15: ('Stress response (p53)', ST, 'H', 'CDKN1A FDXR PHLDA3 MDM2 ZMAT3 on a neural-progenitor background'),
 16: ('Endothelium', EB, 'H', 'KDR ETV2 TAL1 LMO2 CDH5 (haemato-endothelial progenitor)'),
 17: ('Hindgut-like endoderm', EN, 'M', 'FOXA2 FOXA1 CDX2 EPCAM MNX1 TBXT APOA1; n = 30; NOTO and SHH not detected in this dataset'),
 18: ('Posterior PSM', PX, 'H', 'TBX6 MSGN1 HES7 DLL3 FGF17')}

ANN['Weatherbee'] = {
 0: ('Lateral plate mesoderm', LP, 'M', 'HAND1 GATA4/6 FOXF1 BMP4 TBX20 PDGFRA MYL7'),
 1: ('Nascent mesoderm', NM, 'H', 'MESP1 MIXL1 APLNR HAND1 GATA6 LGR5'),
 2: ('Epiblast-like (pluripotent)', PL, 'H', 'POU5F1 SOX2 NANOG TDGF1 DPPA4'),
 3: ('Nascent mesoderm', NM, 'M', 'HAND1 GATA6 KDR APLNR LGR5 with MIXL1 68% (lateral/extra-embryonic-biased)'),
 4: ('Amnion-like (early)', AM, 'M', 'TFAP2A 96% TFAP2C 83% GATA3 65% ISL1 47% ID1/ID4 with POU5F1 retained'),
 5: ('Hypoblast/visceral endoderm-like', HY, 'H', 'GATA4/6 SOX17 FOXA2 HNF1B PDGFRA RSPO3 LAMA1; CXCR4 24%'),
 6: ('PGC-like', PGC, 'M', 'TFAP2C PRDM1 SOX17 NANOS3 39% NANOG; n = 28'),
 7: ('Hypoblast/visceral endoderm-like', HY, 'H', 'APOA1 APOB CUBN HNF4A PDGFRA RSPO3 TTR 71%'),
 8: ('Endothelium', EB, 'H', 'PECAM1 CDH5 KDR TAL1 LMO2 MECOM'),
 9: ('Amnion-like', AM, 'H', 'ISL1 GATA3 TFAP2A GRHL2 CDH1 GABRP 45% VTCN1 34%'),
 10: ('Amnion-like (late)', AM, 'M', 'GATA3 VTCN1 69% GABRP 64% TP63 45% GRHL1 CLDN4'),
 11: ('Amnion-like (late)', AM, 'H', 'GABRP 96% VTCN1 83% GATA3 TFAP2A/B IGFBP7 WFDC2'),
 12: ('ExE/lateral mesenchyme', LP, 'H', 'HAND1 COL3A1 GATA6 BMP4 KDR TBX20 FOXF1'),
 13: ('ExE/lateral mesenchyme', LP, 'H', 'HAND1 COL3A1 TBX20 IGF2 POSTN'),
 14: ('ExE/lateral mesenchyme', LP, 'M', 'HAND1 COL3A1 POSTN with BNC1 PODXL AQP1 (mesothelial-like)'),
 15: ('ExE/lateral mesenchyme', LP, 'H', 'HAND1 COL3A1 GATA6 TMEM88 CYP26A1 TBX20'),
 16: ('ExE/lateral mesenchyme', LP, 'H', 'HAND1 COL3A1 POSTN DCN LUM'),
 17: ('ExE/lateral mesenchyme', LP, 'H', 'COL1A1 COL3A1 COL6A1-3 POSTN HAND1/2; HOX10-13 44%'),
 18: ('Primitive streak-like', PS, 'M', 'TBXT CDX2 MSGN1 MESP1 NODAL WNT3 (posterior)'),
 19: ('Yolk-sac endoderm-like', HY, 'H', 'AFP TTR APOB FGA FGB MTTP HNF4A'),
 20: ('ExE/lateral mesenchyme', LP, 'H', 'COL1A1 COL3A1 POSTN DCN HAND1')}

ANN['Liu'] = {
 0: ('Nascent mesoderm', NM, 'H', 'MIXL1 EOMES MESP1 HAND1 GATA6 CER1 LGR5'),
 1: ('Nascent mesoderm', NM, 'H', 'MESP1 APLNR HAND1 GATA6 MIXL1'),
 2: ('Primitive streak-like', PS, 'M', 'POU5F1 SP5 CDX1/2 TBXT 38% NODAL (posterior epiblast)'),
 3: ('Epiblast-like (pluripotent)', PL, 'H', 'POU5F1 SOX2 NANOG TDGF1 DPPA4'),
 4: ('Epiblast-like (pluripotent)', PL, 'H', 'POU5F1 SOX2 NANOG DPPA4'),
 5: ('Anterior neuroectoderm-like', NE, 'M', 'SOX2 ZIC2 OTX2 HESX1 47% SFRP1 CYP26A1 with POU5F1 retained; n = 49 (anterior epiblast)'),
 6: ('Lateral plate mesoderm', LP, 'M', 'HAND1 BMP4 HAPLN1 TMEM88 CDH11 GATA6'),
 7: ('ExE/lateral mesenchyme', LP, 'M', 'HAND1 BMP4 MYL7 GATA6 COL3A1 LEF1'),
 8: LQ,
 9: ('ExE/lateral mesenchyme', LP, 'H', 'HAND1 COL3A1 BMP4 TBX20 HAND2; MYL7/TNNT2 without NKX2-5'),
 10: ('ExE/lateral mesenchyme', LP, 'H', 'HAND1 COL3A1 ACTC1 TMEM88 MYL7'),
 11: ('Amnion-like (early)', AM, 'M', 'TFAP2A 78% GATA3 60% ISL1 59% GRHL2 CDH1 with POU5F1 retained'),
 12: ('ExE/lateral mesenchyme', LP, 'H', 'HAND1 COL3A1 LUM COL1A1 POSTN IGFBP3'),
 13: ('Epiblast-like, TFAP2A+ (amnion-primed)', PL, 'M', 'POU5F1 SOX2 with ID1 and TFAP2A 54%'),
 14: ('Hypoblast/visceral endoderm-like', HY, 'H', 'GATA4/6 HNF1B PDGFRA RSPO3 LAMA1 CST1; CXCR4 4%'),
 15: LQ,
 16: ('Yolk-sac endoderm-like', HY, 'H', 'APOA1/2 APOB TTR 80% AFP 67% HNF4A PDGFRA RSPO3'),
 17: ('Anterior neuroectoderm-like', NE, 'L', 'SOX2 PAX6 24% SIX3 22% NR2F2 DLK1; low depth (0.6x)'),
 18: ('Endothelium', EB, 'H', 'KDR PECAM1 TAL1 LMO2 FLI1; GATA1 22% (haemato-endothelial)')}

ANN['Pedroza'] = {
 0: ('Epiblast-like (pluripotent)', PL, 'H', 'POU5F1 SOX2 NANOG TDGF1 DPPA4'),
 1: ('Epiblast-like, anterior-biased', PL, 'M', 'POU5F1 SOX2 with OTX2 75% HESX1 50% CYP26A1 89%'),
 2: ('Epiblast-like (pluripotent)', PL, 'H', 'POU5F1 SOX2 NANOG; S phase'),
 3: ('Epiblast-like (pluripotent)', PL, 'H', 'POU5F1 SOX2 NANOG'),
 4: ('Epiblast-like (pluripotent)', PL, 'H', 'POU5F1 SOX2 NANOG; G2/M'),
 5: ('Epiblast-like (pluripotent)', PL, 'H', 'POU5F1 SOX2 NANOG; S phase'),
 6: ('Anterior definitive endoderm', EN, 'M', 'CER1 LEFTY1 HHEX GSC EOMES CXCR4 FOXA2 SOX17; PDGFRA 6% (definitive-endoderm-like rather than hypoblast-like)'),
 7: ('Definitive endoderm', EN, 'M', 'SOX17 FOXA2 EOMES CXCR4 GATA3 CDH2; PDGFRA 6%, HNF4A 20%'),
 8: ('Epiblast-like (pluripotent)', PL, 'H', 'POU5F1 SOX2 NANOG LEFTY1/2'),
 9: ('Nascent mesoderm', NM, 'M', 'HAND1 MIXL1 MESP1 LHX1 EOMES; n = 215'),
 10: ('Hypoblast/visceral endoderm-like', HY, 'M', 'APOA1 PDGFRA RSPO3 APOA4 HNF4A HNF1B GATA4/6; CXCR4 43%'),
 11: ('Endoderm with visceral features', EN, 'M', 'GATA6 SOX17 FOXA2 with PDGFRA RSPO3 APOA4 gained but CXCR4 84% EOMES 82% retained'),
 12: ('Epiblast-like, TFAP2A+ (amnion-primed)', PL, 'M', 'POU5F1 SOX2 with ID1 and TFAP2A 66%'),
 13: LQ,
 14: DB('2.0x median UMI, doublet score 0.14; epiblast and endoderm markers together'),
 15: ('Fibroblast-like (low depth)', XX, 'L', 'PRRX1 COL1A2 COL3A1 S100A6; 0.27x median UMI; n = 72'),
 16: LQ}

ANN['Makwana'] = {
 0: ('NMP/caudal epiblast-like', NMP, 'H', 'SOX2 NKX1-2 CDX1/2 FGF8 FGF17; TBXT 32%'),
 1: ('NMP/caudal epiblast-like', NMP, 'H', 'TBXT 81% SOX2 70% MIXL1 WNT3A TBX6 51% CDX2 (mesoderm-primed)'),
 2: LQ,
 3: ('NMP/caudal epiblast-like', NMP, 'H', 'SOX2 CDX1/2 NKX1-2 FGF8 CYP26A1; TBXT 39%'),
 4: ('NMP/caudal epiblast-like', NMP, 'H', 'SOX2 NKX1-2 CDX1/2 FGF8; TBXT 45%'),
 5: ('NMP/caudal epiblast-like', NMP, 'H', 'SOX2 TBXT 68% CDX1/2 NKX1-2; G2/M'),
 6: ('Posterior PSM', PX, 'H', 'TBX6 MSGN1 HES7 DLL3 RSPO3'),
 7: ('Posterior PSM', PX, 'H', 'TBX6 MSGN1 HES7 DLL3; G2/M'),
 8: ('Anterior PSM/nascent somite', PX, 'H', 'TBX6 with MESP2 33% RIPPLY2 28% MEOX1 34% DLL1 FGF18'),
 9: DB('2.3x median UMI, doublet score 0.16; PSM and NMP markers together'),
 10: ('Somite', PX, 'H', 'TCF15 MEOX1 RIPPLY1 FOXC2 PAX3 UNCX 31%'),
 11: DB('2.3x median UMI, doublet score 0.13; somite and neural markers together'),
 12: ('Neural tube progenitor', NE, 'H', 'SOX2 PAX6 71% HES5 IRX3 with CDX1/2 (caudal, early)'),
 13: ('NMP/caudal epiblast-like', NMP, 'M', 'SOX2 CDX2 NKX1-2 85% CYP26A1 FGF8; TBXT 28% (pre-neural)'),
 14: ('Stress response (p53)', ST, 'H', 'CDKN1A GADD45A FDXR PHLDA3 ZMAT3 on a caudal-progenitor background'),
 15: ('Neural tube progenitor', NE, 'H', 'SOX2 PAX6 HES5 IRX3 PAX3'),
 16: ('Somite', PX, 'H', 'PAX3 TCF15 MEOX1 UNCX 45% SIX1 NR2F2'),
 17: DB('2.3x the 120 h median UMI, doublet score 0.15; somite and neural markers together'),
 18: ('NMP/caudal epiblast-like', NMP, 'M', 'SOX2 CDX2 NKX1-2 FGF8; HOX10-13 13%; TBXT low'),
 19: ('Neuron', NE, 'H', 'ELAVL4 ONECUT1/2 NEUROG2 DLL3; n = 43'),
 20: ('Neural tube progenitor', NE, 'H', 'SOX2 PAX6 85% IRX3 HES5 PAX3 (dorsal-intermediate)'),
 21: ('NMP/caudal epiblast-like', NMP, 'M', 'SOX2 CDX2 NKX1-2 FGF8; HOX10-13 19%')}

ANN['Budjan'] = {
 0: ('Primitive streak-like', PS, 'H', 'MIXL1 NODAL TBXT EOMES GSC FOXA2 41% with POU5F1'),
 1: LQ,
 2: ('Primitive streak-like', PS, 'H', 'MIXL1 NODAL TBXT 87% EOMES GSC FOXA2 61%'),
 3: ('Primitive streak-like', PS, 'M', 'MIXL1 TBXT NODAL EOMES; 0.35x median UMI'),
 4: LQ,
 5: ('Nascent mesoderm', NM, 'M', 'TBXT 84% MIXL1 TBX6 66% HES7 CDX2 WNT5B (posterior)'),
 6: ('Anterior PS/mesendoderm', PS, 'M', 'TBXT FOXA2 61% MIXL1 GSC 41% GATA6 DKK1 MNX1'),
 7: ('Posterior PSM', PX, 'H', 'TBX6 DLL3 RSPO3 HES7 MSGN1 31% with MIXL1/POU5F1 retained'),
 8: ('Posterior PSM', PX, 'H', 'TBX6 HES7 DLL3 FGF17 CDX1/2'),
 9: ('Posterior PSM', PX, 'H', 'TBX6 DLL3 HES7 MSGN1 32%; S phase'),
 10: LQ,
 11: ('Posterior PSM', PX, 'M', 'TBX6 78% HES7 FOXC1 with BMP4 88% MSX1 TAGLN KRT8/18 MYL7 51% ETV2 27%; lateral-plate markers absent (HAND1 2%, FOXF1 1%, KDR 0%)'),
 12: ('Posterior PSM', PX, 'H', 'TBX6 HES7 DLL3 FGF17; G2/M'),
 13: LQ,
 14: ('Posterior PSM', PX, 'H', 'TBX6 HES7 DLL3 FGF17; S phase'),
 15: ('Somite', PX, 'H', 'TCF15 PAX3 RIPPLY1 MEOX1 ALDH1A2 FGF18 SIX1 UNCX 35%'),
 16: ('Somite', PX, 'M', 'TCF15 RIPPLY1 PAX3 MEOX1; ribosomal/mitochondrial transcripts high'),
 17: ('Somite', PX, 'H', 'TCF15 RIPPLY1 PAX3 MEOX1; G1'),
 18: ('Somitic mesenchyme', PX, 'M', 'TWIST1 COL1A1 BGN TAGLN IGF2 with TCF15 MEOX1; PAX1 not detected (not sclerotome)')}

ANN['Chen_polyA'] = {
 0: ('Nascent mesoderm', NM, 'H', 'MIXL1 MESP1 EOMES GATA6 LHX1 CER1 TBX6'),
 1: ('Epiblast-like, streak-primed', PL, 'H', 'POU5F1 NANOG SOX2 with TBXT 62% MIXL1 63%'),
 2: ('Posterior nascent mesoderm', NM, 'H', 'TBXT MESP1 TBX6 78% MSGN1 57% WNT8A HES7'),
 3: ('PGC-like', PGC, 'H', 'SOX17 PRDM1 TFAP2C NANOS3 64% NANOG'),
 4: ('Definitive endoderm', EN, 'H', 'SOX17 FOXA2 71% GATA6 EOMES CXCR4 HNF1B CER1'),
 5: ('Primitive streak-like', PS, 'H', 'TBXT MIXL1 NODAL EOMES WNT3'),
 6: ('Amnion-like', AM, 'H', 'TFAP2A GATA3 ISL1 HAND1 WNT6 GABRP 57% VTCN1 40%'),
 7: ('Epiblast-like, streak-primed', PL, 'H', 'POU5F1 NANOG SOX2 with TBXT 66% MIXL1 69%'),
 8: ('Epiblast-like (pluripotent)', PL, 'H', 'SOX2 NANOG POU5F1 USP44 TDGF1'),
 9: ('Epiblast-like, streak-primed', PL, 'H', 'POU5F1 NANOG SOX2 with TBXT/EOMES/MIXL1 ~60%; G2/M'),
 10: ('Epiblast-like, TFAP2A+ (amnion-primed)', PL, 'M', 'POU5F1 DPPA4 with ID1, TFAP2A 69% GATA3 57%'),
 11: ('Nascent mesoderm', NM, 'H', 'MESP1 MESP2 RIPPLY2 43% DLL3 LHX1 FOXC1'),
 12: ('Lateral plate/cardiogenic mesoderm', LP, 'H', 'HAND1 KDR GATA4/6 NKX2-5 64% TBX20 ISL1 FOXF1; ETV2 32%'),
 13: ('Nascent mesoderm', NM, 'H', 'MESP1 MESP2 LHX1 IRX3 FOXC1 APLNR RIPPLY2 51%'),
 14: ('Amnion-like (late)', AM, 'H', 'GABRP 93% VTCN1 63% IGFBP3 ISL1 GATA3 TFAP2A HAND1'),
 15: DB('2.2x median UMI, doublet score 0.21; epiblast and mesoderm markers together'),
 16: ('Lateral plate mesoderm', LP, 'M', 'HAND1 MESP1 BMP4 GATA6 LHX1 TTN ALPK2 ISL1 53% (early, cardiac-primed)'),
 17: LQ, 18: LQ}

ANN['Chen_probe'] = {
 0: LQ,
 1: ('Primitive streak-like', PS, 'H', 'TBXT MIXL1 EOMES NODAL FGF4 FGF8'),
 2: ('Primitive streak-like', PS, 'M', 'TBXT 84% MIXL1 77% WNT3 with TFAP2A 62% GATA3 52% (late, posterior)'),
 3: ('Primitive streak-like', PS, 'H', 'TBXT EOMES MIXL1 NODAL; G2/M'),
 4: ('Epiblast-like (pluripotent)', PL, 'M', 'SOX2 USP44 DPPA4 DNMT3B L1TD1 (POU5F1/NANOG not in the probe set)'),
 5: ('Epiblast-like (pluripotent)', PL, 'M', 'SOX2 USP44 DPPA4 DNMT3B L1TD1 (POU5F1/NANOG not in the probe set)'),
 6: ('Epiblast-like (pluripotent)', PL, 'M', 'SOX2 PODXL TRIM71 DPPA4 L1TD1; persists at day 6-8'),
 7: LQ,
 8: ('Amnion-like (early)', AM, 'M', 'TFAP2A GATA3 TFAP2C ID4 CDH1 CLDN4 ISL1 57% with pluripotency genes; NANOS3 31%'),
 9: ('Amnion-like', AM, 'H', 'TFAP2A GATA3 ISL1 HAND1 GRHL2 ABCG2 GABRP 66%'),
 10: ('Amnion-like (late)', AM, 'H', 'GABRP 93% VTCN1 67% IGFBP7 ISL1 HAND1 TFAP2A'),
 11: ('Posterior nascent mesoderm', NM, 'H', 'TBX6 MSGN1 64% WNT8A EVX1 MESP1'),
 12: ('Nascent mesoderm', NM, 'H', 'MESP1 MESP2 MIXL1 TBX6 GATA6 LHX1 CER1'),
 13: ('Nascent mesoderm', NM, 'H', 'LHX1 HAND1 MESP1 GATA6 BMP4 IRX3 (lateral-biased)'),
 14: ('Lateral plate/cardiogenic mesoderm', LP, 'H', 'HAND1 FOXF1 NKX2-5 66% MYL7 TMEM88 MYL4 KDR'),
 15: ('Stress response (ISR)', ST, 'H', 'DDIT3 94% GDF15 INHBE BBC3 on a pluripotent/TFAP2A+ background'),
 16: ('Amnion-like', AM, 'H', 'ISL1 GATA3 HAND1 TFAP2A GABRP 54% (day 6-10)'),
 17: ('PGC-like', PGC, 'H', 'SOX17 PRDM1 TFAP2C NANOS3 60%'),
 18: LQ, 19: LQ, 20: LQ,
 21: ('Amnion-like (late)', AM, 'M', 'TFAP2A ISL1 GATA3 KRT7 with IGFBP3 IGFBP7 ANXA1 TAGLN COL3A1; 2x median UMI but low doublet score'),
 22: DB('1.9x median UMI, doublet score 0.17; pluripotent, mesoderm and PGC markers together'),
 23: ('Posterior LPM/allantois-like mesenchyme', LP, 'M', 'HAND2 GATA4 TBX4 84% PRRX1 COL1A1 COL3A1; HOX10-13 82%'),
 24: ('Lateral plate mesoderm', LP, 'M', 'KDR HAND1/2 GATA4/6 FOXF1 TEK FLT1 HAPLN1; NKX2-5 48%'),
 25: ('Lateral plate/cardiogenic mesoderm', LP, 'M', 'HAND1 KDR BMP4 ISL1 68% LHX1 NKX2-5 44% TMEM88'),
 26: ('Definitive endoderm', EN, 'H', 'SOX17 FOXA2 CXCR4 HNF1B HNF4A 70% EOMES (day 6-10, gut-like)'),
 27: ('PGC-like', PGC, 'L', 'SOX17 TFAP2C NANOS3 48% LEFTY2; n = 31, low depth'),
 28: ('Definitive endoderm', EN, 'H', 'SOX17 FOXA2 CXCR4 EOMES CER1 GATA6'),
 29: ('PGC-like', PGC, 'H', 'TFAP2C SOX17 NANOS3 62% PRDM1 CXCR4'),
 30: LQ}
OVR['Chen_probe'] = {49: ('Endothelium', EB, 'H', 'PECAM1 86% CDH5 65% KDR SOX17 TAL1 26% (day 8-10)')}

ANN['Rossi'] = {
 0: ('Gut endoderm', EN, 'H', 'FOXA2 FOXA1 SOX17 EPCAM CLDN6 SHH'),
 1: ('Epiblast-like (pluripotent)', PL, 'H', 'POU5F1 UTF1 DNMT3B NANOG 56% SOX2 (primed; TBXT 56%)'),
 2: ('Primitive streak-like', PS, 'H', 'TBXT CDX1/2 NKX1-2 FGF8 WNT8A WNT3A with POU5F1 (caudal epiblast)'),
 3: ('Neural tube progenitor', NE, 'H', 'SOX2 SOX21 NKX6-1 70% RFX4 PTCH1; OLIG2 20%, FOXA2/SHH subset (ventral)'),
 4: ('Posterior PSM', PX, 'H', 'TBX6 HES7 DLL1/3 with ALDH1A2 MEOX1 57% (includes anterior PSM)'),
 5: ('NMP/caudal epiblast-like', NMP, 'H', 'SOX2 TBXT 71% CDX2 NKX1-2 CDX4; HOX6-9 92%'),
 6: ('Node/notochord-like', AX, 'H', 'TBXT NOTO 58% SHH 71% FOXA2 CHRD NOG'),
 7: ('Lateral plate/cardiogenic mesoderm', LP, 'M', 'GATA6 HAND2 MYL7 TWIST1 GATA4 MESP1 TBX20; ETV2 35% (anterior)'),
 8: ('Somitic mesenchyme', PX, 'M', 'PRRX2 TWIST1 MEOX1 80% PRRX1 EBF1 MEIS2; TBX1 33% (paraxial/pharyngeal mesenchyme)'),
 9: ('Somite, sclerotome-biased', PX, 'H', 'MEOX1 TCF15 UNCX 62% PAX1 46% FOXC2'),
 10: ('Node/notochord-like', AX, 'M', 'TBXT FOXA2 CHRD GSC NODAL NOTO 35% with cilia genes (anterior streak/node, day 4)'),
 11: ('Anterior definitive endoderm', EN, 'H', 'SOX17 FOXA2 HHEX OTX2 CER1 55% TRH'),
 12: ('Naive-like pluripotent/PGC-like', PL, 'M', 'ZFP42 DPPA5 DPPA2 KLF2 NANOG; NANOS3 33% DPPA3 45% (ESC-like residual with PGC-like subset)'),
 13: ('Surface ectoderm-like', SE, 'M', 'DLX5 TFAP2C MSX1 ESRP1 CLDN4 KRT8/18 with CDX2 FGF8 (caudal epithelium)'),
 14: ('Endothelium', EB, 'H', 'KDR CDH5 SOX18 PECAM1 ETV2 TAL1'),
 15: ('Cardiomyocyte', CA, 'H', 'TNNT2 MYL7 TTN NKX2-5 80%'),
 16: ('Neuron', NE, 'H', 'ELAVL3/4 ISL1 NKX6-1 STMN2; MNX1 37% (motor-neuron-like)')}
OVR['Rossi'] = {2: ('Pharyngeal/foregut endoderm', EN, 'M', 'PAX9 PAX1 48% ISL1 TBX1 OTX2 IRX3 with FOXA2 50%'),
                1: ('Anterior definitive endoderm', EN, 'H', 'SOX17 FOXA2 OTX2 CER1 GSC')}

ANN['Veenvliet'] = {
 0: ('Neural tube progenitor', NE, 'H', 'SOX2 SOX1 PAX6 IRX3 HES5 SOX3'),
 1: ('NMP/caudal epiblast-like', NMP, 'H', 'SOX2 TBXT 72% CDX2 NKX1-2 FGF8'),
 2: ('Neural tube progenitor', NE, 'H', 'SOX2 SOX1 PAX6 IRX3 PAX3'),
 3: ('Somite, sclerotome-biased', PX, 'H', 'MEOX1 TWIST1 TCF15 PAX1 44% FOXD1 CXCL12'),
 4: ('Somite', PX, 'H', 'MEOX1 TCF15 PAX3 UNCX 50% PAX1 42%'),
 5: ('Somite', PX, 'H', 'TCF15 MEOX1 ALDH1A2 PAX3 FOXC2 CER1 80% (nascent)'),
 6: ('Posterior PSM', PX, 'H', 'TBX6 HES7 DLL1/3 with MESP2 39% RIPPLY2 27%'),
 7: ('Somite', PX, 'H', 'MEOX1 TCF15 PAX3 95% SIX1'),
 8: DB('2.7x median UMI, doublet score 0.23; somite and neural markers together'),
 9: ('Endothelium', EB, 'H', 'KDR ETV2 LMO2 HHEX CDH5 TAL1'),
 10: ('Somite, dermomyotome-biased', PX, 'H', 'TCF15 MEOX1 PAX3 95% DMRT2 85%; glycolytic genes high'),
 11: LQ,
 12: ('Low-quality (stressed)', XX, 'M', 'DDIT3 66%, lysosomal genes, 0.5x median UMI, no lineage programme'),
 13: ('Gut endoderm', EN, 'M', 'FOXA2 FOXA1 SOX17 EPCAM CLDN6 SHH'),
 14: ('Somite', PX, 'H', 'MEOX1 TCF15 PAX3; HOX6-9 91% (posterior)'),
 15: ('Naive-like pluripotent/PGC-like', PL, 'M', 'DPPA5 ZFP42 KLF2 NANOG with DPPA3 92% TFAP2C 92% NANOS3 63% PRDM1 61%'),
 16: ('Somite', PX, 'H', 'TCF15 MEOX1 ALDH1A2 PAX3 CER1 92% (nascent, 96 h)'),
 17: ('Anterior PSM/nascent somite', PX, 'H', 'TBX6 83% HES7 MESP2 46% RIPPLY2 44% MEOX1'),
 18: ('NMP/caudal epiblast-like', NMP, 'H', 'TBXT 88% SOX2 CDX1/2 NKX1-2 FGF8 WNT3A'),
 19: ('NMP/caudal epiblast-like', NMP, 'H', 'SOX2 CDX2 NKX1-2 75% TBXT 48%; HOX10-13 52%')}
OVR['Veenvliet'] = {21: ('Gut endoderm', EN, 'H', 'FOXA1 FOXA2 SOX17 SHH 75% HNF1B'),
                    20: ('Axial/caudal mesendoderm progenitor', AX, 'L', 'TBXT 80% CDX2 87% FOXA2 60% CHRD 51% SHH 28%; NOTO 6% (not mature notochord)'),
                    19: ('Axial/caudal mesendoderm progenitor', AX, 'L', 'TBXT FOXA2 CHRD CDX2; n = 32')}

ANN['Yamanaka'] = {
 0: ('Posterior PSM', PX, 'H', 'TBX6 MSGN1 HES7 DLL3'),
 1: ('NMP/caudal epiblast-like', NMP, 'H', 'SOX2 89% TBXT 59% CDX2 FGF8 WNT3A; HOX10-13 58%'),
 2: ('Posterior PSM', PX, 'H', 'TBX6 MSGN1 HES7 DLL1/3'),
 3: ('Anterior PSM/nascent somite', PX, 'H', 'RIPPLY1 91% MEOX1 91% TCF15 54%'),
 4: ('Somite', PX, 'H', 'MEOX1 RIPPLY1 PAX3 TCF15 UNCX 33%; G2/M'),
 5: ('Low-quality (stressed)', XX, 'M', '0.6x median UMI, mitochondrial and lncRNA transcripts; weak somite signal'),
 6: LQ, 7: LQ,
 8: ('Somitic mesenchyme', PX, 'M', 'TWIST1 FOXC2 SIX1 PAX3 with PAX9 35%; PAX1 and NKX3-2 not expressed (not definitive sclerotome); G1 (120 h)'),
 9: ('Somite', PX, 'H', 'RIPPLY1 PAX3 MEOX1 TCF15'),
 10: ('Somite', PX, 'H', 'PAX3 RIPPLY1 MEOX1 UNCX 37%'),
 11: ('Somite', PX, 'H', 'PAX3 MEOX1 RIPPLY1 TCF15 UNCX 43%; S phase'),
 12: ('Somite', PX, 'H', 'PAX3 MEOX1 RIPPLY1 with DHRS3 CYP26A1 (retinoic-acid response)'),
 13: ('Somite', PX, 'H', 'PAX3 MEOX1 RIPPLY1; G2/M'),
 14: ('Somite', PX, 'H', 'PAX3 RIPPLY1 MEOX1 with DHRS3 MEIS2 NR2F1 (retinoic-acid response)'),
 15: ('Somite', PX, 'H', 'PAX3 90% TCF15 73% UNCX 70% (retinoic acid, 120 h)'),
 16: ('Somitic mesenchyme', PX, 'M', 'TWIST1 SOX9 COL3A1 NR2F1/2 MEIS2 CDKN1C; G1 (retinoic acid, 120 h)'),
 17: ('Somite', PX, 'H', 'PAX3 UNCX 66% TCF15; G2/M (retinoic acid, 120 h)'),
 18: ('Somitic mesenchyme', PX, 'L', 'FOXC2 SIX1 EYA1 DLK1 with OSR1 31% KDR 31%; lateral-plate markers absent (HAND1, FOXF1, GATA4/6 0%); 0.6x median UMI'),
 19: ('Endothelium', EB, 'H', 'KDR ETV2 TAL1 LMO2'),
 20: ('Somitic mesenchyme', PX, 'M', 'PAX3 FOXC2 SIX1 TWIST1 with PAX9 48%; PAX1 and NKX3-2 not expressed (not definitive sclerotome) (120 h)'),
 21: ('Caudal neural plate progenitor', NMP, 'M', 'SOX2 99% CDX2 99% FGF8 NOG; HOX10-13 98%; TBXT 19%'),
 22: ('Neural tube progenitor', NE, 'M', 'SOX2 MSX1 PAX3 ZIC2 CYP26A1 HES5 30% NEUROG2 30% (retinoic acid; dorsal)')}
OVR['Yamanaka'] = {36: ('Endothelium', EB, 'H', 'KDR ETV2 TAL1')}

ANN['Hamazaki'] = {
 0: ('Primitive streak-like', PS, 'H', 'MIXL1 TBXT 72% EOMES NODAL FOXA2 46% with POU5F1'),
 1: ('Somite', PX, 'H', 'RIPPLY1 TCF15 PAX3 FST FOXC1'),
 2: LQ,
 3: ('Anterior PSM/nascent somite', PX, 'H', 'RIPPLY1 86% TCF15 85% MEOX1 FOXC2 CER1 37%'),
 4: ('Dorsal neural tube/roof plate', NE, 'M', 'SOX2 MSX1 ZIC2 PAX3 CDH6; OLIG3 22% WNT1 11% (retinoic acid)'),
 5: ('Paraxial mesoderm, early (FOXC1/2+)', PX, 'M', 'FOXC2 45% FOXC1 37% TCF15 47% ALDH1A2 TWIST1 LIX1'),
 6: ('NMP/caudal epiblast-like', NMP, 'M', 'FGF17 FGF8 CDX2 SOX2 46%; TBXT 12% (shallow library)'),
 7: ('Posterior PSM', PX, 'H', 'TBX6 MSGN1 43% HES7 DLL1/3 with MESP2 25% RIPPLY2 23%'),
 8: ('Nascent mesoderm', NM, 'H', 'MESP1 HAND1 LHX1 MSX1 BMP4 APLNR with POU5F1 (24 h; lateral-biased)'),
 9: ('Node/notochord-like', AX, 'H', 'NOTO 58% FOXA2 50% CHRD 38% FOXJ1 44% TBXT 40% TFF3; SHH 2%'),
 10: ('Posterior PSM', PX, 'H', 'TBX6 MSGN1 76% DLL3 RSPO3 HES7 with POU5F1 (24 h)'),
 11: ('Somite', PX, 'M', 'PAX3 62% SIX1 74% TCF15 50% NR2F2 80% (retinoic acid); DMRT2 0%, PAX7 1%, PAX1/PAX9 0% (no dermomyotome or sclerotome programme)'),
 12: ('Somite', PX, 'H', 'TCF15 73% RIPPLY1 PAX3 UNCX 28% FGF18'),
 13: ('Lateral plate mesoderm', LP, 'M', 'HAND1 40% PRRX1 41% HAND2 20% GATA6 LIX1 TMEM88 PDGFRA KRT19'),
 14: ('Somite', PX, 'L', 'PAX3 51% TCF15 38%; 0.5x median UMI (retinoic acid 96 h)'),
 15: ('Intermediate mesoderm-like', LP, 'M', 'PAX8 42% EMX2 LHX1 OSR1 14% WT1 11% (retinoic acid)'),
 16: ('Lateral plate mesoderm', LP, 'M', 'COL1A1 COL3A1 PDGFRA HAND2 29% GATA4/6 TBX5 10% (mesenchymal; retinoic acid 120 h)'),
 17: ('Caudal neural plate progenitor', NMP, 'M', 'SOX2 75% CDX2 45% FGFBP3 SOX3; PAX6 low'),
 18: ('Neural tube progenitor', NE, 'H', 'SOX2 PAX6 56% HES5 IRX3 SFRP2'),
 19: ('Endothelium', EB, 'H', 'KDR CDH5 PECAM1 CD34 PLVAP'),
 20: ('Neuron', NE, 'H', 'ONECUT1/2 NHLH1 NEUROG2 TUBB3 STMN2; n = 68')}
OVR['Hamazaki'] = {29: ('Endothelium', EB, 'H', 'KDR CDH5 PECAM1')}
