# staging/01_milestones/monkey_recluster.py
# Source: drive G: data/milestone_evidence/mz/monkey/recluster_monkey.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

import scanpy as sc, anndata as ad, numpy as np, pandas as pd, scipy.sparse as sp, warnings; warnings.filterwarnings('ignore')
D=(str(HGC_DATA) + '/GSE193007/'); OD=(str(HGC_DATA) + '/staging/layer_rescue/')
z=np.load(D+'counts_recovered_int.npz'); X=sp.csr_matrix((z['data'],z['indices'],z['indptr']),shape=tuple(z['shape'])).astype(np.float32)
g=pd.read_csv(D+'genes.csv').iloc[:,0].astype(str).values; m=pd.read_csv(D+'MFE56636-meta.csv')
A=ad.AnnData(X,obs=pd.DataFrame({'sample':m['sample'].values,'label':m.cell_type.astype(str).str.strip().values}),var=pd.DataFrame(index=g)); A.var_names_make_unique()
L={**{k:'E' for k in ['EPI','ECT','PS','NMP','SE1','SE2','FB/MB/HB','SC','NC']},**{k:'M' for k in ['APS','Nas.Meso','Caud.Meso','PSM','Para.Meso','LP.Meso','Inter.Meso','Pharyg.Meso','Cardi.Meso','Cardi.','Rostr.Meso','Mes']},
   'Node':'X','DE':'N','Gut':'N',**{k:'Mx' for k in ['ExE.Meso','ys.Meso1','ys.Meso2','AI']}}
A.obs['layer']=A.obs.label.map(L).fillna('other')
GS=pd.read_csv(OD+'mouse_milestone_genesets.csv')
DEF={'Notochord':('NOTO','SHH'),'Caudal epiblast':('CDX2','SOX2'),'Rostral neurectoderm':('HESX1','SIX3'),'Paraxial mesoderm':('MEOX1','TCF15'),'Cardiomyocytes':('TNNT2','MYL7')}
POOL={'Notochord':['X','M','N'],'Caudal epiblast':['E'],'Rostral neurectoderm':['E'],'Paraxial mesoderm':['M'],'Cardiomyocytes':['M','Mx']}
best=[]; ALL=[]
for s in ['CS8-e1','CS8-e2','CS9-e1','CS9-e2','CS11-e1','CS11-e2']:
    S=A[A.obs['sample']==s]
    for t,lays in POOL.items():
        P=S[S.obs.layer.isin(lays).values].copy()
        genes=[x for x in GS[GS.celltype==t].human if x in P.var_names]
        Dm=(P.X>0); P.obs['depth']=np.asarray(P.X.sum(1)).ravel()
        for x in DEF[t]: P.obs[x]=np.asarray(Dm[:,P.var_names.get_loc(x)].todense()).ravel()
        Q=P.copy(); sc.pp.normalize_total(Q,1e4); sc.pp.log1p(Q); sc.tl.score_genes(Q,genes,ctrl_size=50,n_bins=25,score_name='mod',random_state=0); P.obs['mod']=Q.obs['mod'].values
        sc.pp.highly_variable_genes(Q,n_top_genes=2000); Q=Q[:,Q.var.highly_variable].copy(); sc.pp.scale(Q,max_value=10); sc.tl.pca(Q,n_comps=30); sc.pp.neighbors(Q,n_neighbors=15)
        sc.tl.leiden(Q,resolution=2.0,flavor='igraph',n_iterations=2,key_added='sub'); P.obs['sub']=Q.obs['sub'].values
        gb=P.obs.groupby('sub'); q=gb.agg(n=('mod','size'),mod=('mod','mean'),depth=('depth','median'),m1=(DEF[t][0],'mean'),m2=(DEF[t][1],'mean'))
        p1,p2=P.obs[DEF[t][0]].mean(),P.obs[DEF[t][1]].mean(); q['marker_fe']=np.sqrt((q.m1/max(p1,1e-3))*(q.m2/max(p2,1e-3))); q['mod_z']=(q['mod']-P.obs['mod'].mean())/P.obs['mod'].std()
        q['top_labels']=gb.label.agg(lambda x: '; '.join(f'{k} {v}' for k,v in x.value_counts().head(3).items()))
        q=q[q.n>=15].sort_values('mod_z',ascending=False); b=q.iloc[0]
        q2=q.copy(); q2['sample']=s; q2['celltype']=t; ALL.append(q2.reset_index())
        best.append(dict(sample=s,celltype=t,pool_n=P.n_obs,n_sub=len(q),best_n=int(b.n),mod_z=round(b.mod_z,2),marker_fe=round(b.marker_fe,2),
             marker1=DEF[t][0],m1_best=round(100*b.m1,1),m1_pool=round(100*p1,1),marker2=DEF[t][1],m2_best=round(100*b.m2,1),m2_pool=round(100*p2,1),top_labels=b.top_labels))
        print(s,t,P.n_obs,'best',int(b.n),round(b.mod_z,2),round(100*b.m1,1),round(100*b.m2,1),b.top_labels,flush=True)
pd.DataFrame(best).to_csv('mz/monkey/monkey_recluster_best.csv',index=False); pd.concat(ALL).to_csv('mz/monkey/monkey_recluster_all.csv',index=False)
# nascent mesoderm evidence for CS11 (no Nas.Meso label)
for s in ['CS11-e1','CS11-e2']:
    S=A[(A.obs['sample']==s)&A.obs.layer.isin(['M']).values]; d=np.asarray((S[:,'MESP1'].X>0).todense()).ravel(); print(s,'MESP1+ mesoderm cells',int(d.sum()),'of',S.n_obs)
