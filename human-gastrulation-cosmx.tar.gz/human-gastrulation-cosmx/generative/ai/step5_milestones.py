import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import numpy as np, pandas as pd, anndata as ad, scipy.io, scipy.sparse as sp
B=DATA + '/cs7_cs8_matching/'; g=pd.read_csv(B+'dataprep/export/genes.csv').gene.values; gi={x:i for i,x in enumerate(g)}
O7=scipy.io.mmread(B+'dataprep/export/CS7_counts.mtx').tocsr().T.tocsr(); O8=scipy.io.mmread(B+'dataprep/export/CS8_counts.mtx').tocsr().T.tocsr()
import os; O=os.environ.get('S5OUT','ai/step5_final')+'/'; D7=sp.load_npz(O+'C7_decoded.npz'); D8=sp.load_npz(O+'C8_decoded.npz'); T=ad.read_h5ad(O+'t05_AI_generated_counts.h5ad'); D5=T.X.tocsr()
import glob; DS=[sp.load_npz(f) for f in sorted(glob.glob(O+'t05_gen_seed*_decoded.npz'))]; DL=sp.load_npz(O+'t05_linear_decoded.npz')
lab7=pd.read_csv(B+'dataprep/export/CS7_cells.csv').label_short.values; lab8=pd.read_csv(B+'dataprep/export/CS8_cells.csv').label_short.values
t05=T.obs; dest7=pd.Series(t05.dom_cs8_group.values,index=t05.cs7_idx.values).reindex(range(len(lab7))).values
def det(M,mask,gene): return 100*float((M[mask][:,gi[gene]]>0).mean()) if mask.sum() else np.nan
POOL={ # name: (CS7 mask, t05 mask, CS8 mask)
 'streak (PS)':(lab7=='PS', t05.cs7_group.values=='PS', lab8=='PS'),
 'axial (node / notochord)':(lab7=='Node', t05.cs7_group.values=='Node', np.isin(lab8,['Node','Notochord'])),
 'definitive endoderm':(np.isin(lab7,['DE','AVE']), np.isin(t05.cs7_group.values,['DE','AVE']), np.isin(lab8,['DE','ADE','AVE'])),
 'caudal-epiblast lineage':(dest7=='CLE', t05.dom_cs8_group.values=='CLE', lab8=='CLE'),
 'paraxial lineage':(dest7=='Para.Meso', t05.dom_cs8_group.values=='Para.Meso', lab8=='Para.Meso'),
 'anterior-ectoderm lineage':(dest7=='aECT', t05.dom_cs8_group.values=='aECT', lab8=='aECT'),
 'heart lineage':(dest7=='Heart.Meso', t05.dom_cs8_group.values=='Heart.Meso', lab8=='Heart.Meso'),
 'background (VE2)':(lab7=='VE2', t05.cs7_group.values=='VE2', lab8=='VE2')}
TESTS=[('Notochord: NOTO','axial (node / notochord)','NOTO','onset'),('3′ HOX: HOXA1','streak (PS)','HOXA1','onset'),('3′ HOX: HOXB1','streak (PS)','HOXB1','onset'),
 ('EOMES off','streak (PS)','EOMES','loss'),('TBXT (Fig. 6I)','streak (PS)','TBXT','ref'),('ADE regression: GSC','definitive endoderm','GSC','loss'),('ADE: CER1','definitive endoderm','CER1','loss'),
 ('Caudal epiblast: NKX1-2','caudal-epiblast lineage','NKX1-2','onset'),('Caudal epiblast: CDX2','caudal-epiblast lineage','CDX2','onset'),('5′ HOX: HOXB8','caudal-epiblast lineage','HOXB8','onset'),
 ('Paraxial: MEOX1','paraxial lineage','MEOX1','onset'),('Paraxial: TCF15','paraxial lineage','TCF15','onset'),('Neural plate: SIX3','anterior-ectoderm lineage','SIX3','onset'),('Neural plate: HESX1','anterior-ectoderm lineage','HESX1','onset'),
 ('Cardiomyocytes: NKX2-5','heart lineage','NKX2-5','onset'),('Cardiomyocytes: TNNT2','heart lineage','TNNT2','onset')]
rows=[]
for name,pool,gene,kind in TESTS:
    m7,m5,m8=POOL[pool]; b7,b5,b8=POOL['background (VE2)']
    r=dict(milestone_marker=name,pool=pool,n_CS7=int(m7.sum()),n_t05=int(m5.sum()),n_CS8=int(m8.sum()),
           CS7_observed=det(O7,m7,gene),CS7_decoded=det(D7,m7,gene),t05_decoded=det(D5,m5,gene),CS8_decoded=det(D8,m8,gene),CS8_observed=det(O8,m8,gene),
           bg_t05=det(D5,b5,gene),bg_CS8_obs=det(O8,b8,gene),t05_linear_decoded=det(DL,m5,gene),t05_seed_sd=float(np.std([det(Dm,m5,gene) for Dm in DS])))
    d=r['CS8_decoded']-r['CS7_decoded']; r['t05_position']=(r['t05_decoded']-r['CS7_decoded'])/d if abs(d)>=1 else np.nan
    x,bg=r['t05_decoded'],r['bg_t05']
    if kind=='onset': r['t05_call']='reached' if (x-bg>=5 and x>=2*bg) else ('not reached' if x-bg<2 else 'partial')
    elif kind=='loss': r['t05_call']='reached (fallen to background)' if x-bg<=3 else 'not reached (still on)'
    else: r['t05_call']=''
    rows.append(r)
R=pd.DataFrame(rows); pd.set_option('display.width',260); print(R.round(1).to_string(index=False)); R.to_csv(O+'t05_AI_milestone_markers.csv',index=False)
S4=pd.read_csv('ai/step4_t05_milestone_markers.csv').set_index('milestone_marker'); R['scVI_step4_t05']=S4.reindex(R.milestone_marker).t05_decoded.values; R['scVI_step4_call']=S4.reindex(R.milestone_marker).t05_call.values
print(R[['milestone_marker','CS7_decoded','t05_linear_decoded','t05_decoded','t05_seed_sd','CS8_decoded','bg_t05','t05_call','scVI_step4_t05','scVI_step4_call']].round(1).to_string(index=False)); R.to_csv(O+'t05_AI_milestone_markers.csv',index=False)
