# staging/04_lefty_fgf/stereo_detection_by_cluster.R
# Source: reconstructed from transcript 5113e657 (messages 1086, 1116)
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
HGC_DATA <- Sys.getenv('HGC_DATA', 'data')
HGC_OUT <- Sys.getenv('HGC_OUT', 'results')

# Stereo-seq CS7/CS8 detection (% spots with >=1 UMI) per author cluster. Reconstructed verbatim from transcript 5113e657 (messages 1086, 1116).


# ---- cell [frame 5113e657, message 1086] Loading Stereo-seq CS7/CS8 objects
suppressMessages(library(Seurat))
res <- list()
for (s in c("CS7","CS8")) {
  o <- readRDS(sprintf(paste0(HGC_DATA, "/%s-RNA-MapQ.rds"), s))
  md <- o@meta.data
  cat(s, class(o), ncol(o), "\n"); print(head(colnames(md), 30))
  g <- c("FGF8","FGF17","FGF4","CHRD","FOXJ1","NOTO","TBXT","SHH","GSC")
  cat("genes present:", g[g %in% rownames(o)], "\n")
  res[[s]] <- o
}


# ---- cell [frame 5113e657, message 1116] Computing Stereo-seq detection per cluster
dir.create("hm", showWarnings=FALSE)
for (s in names(res)) { o <- res[[s]]; cnt <- GetAssayData(o, layer="counts"); cl <- o$clusters
  B <- cnt > 0
  m <- sapply(sort(unique(cl)), function(k) 100*Matrix::rowMeans(B[, cl==k, drop=FALSE]))
  colnames(m) <- sort(unique(cl)); m <- cbind(m, ALL=100*Matrix::rowMeans(B))
  write.csv(m, sprintf("hm/stereo_%s_pct.csv", s)); cat(s, dim(m), "\n"); print(table(cl)) }
