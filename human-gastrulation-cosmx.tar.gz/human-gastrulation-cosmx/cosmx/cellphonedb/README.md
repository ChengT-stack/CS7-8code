# CellPhoneDB analysis (Figure 5E, 5G) — code not recovered

Methods [P364]: CellPhoneDB v5 statistical method (package v5.0.1, database v5.0.0; `cpdb_statistical_analysis_method.call`, counts_data = "hgnc_symbol", 1,000 permutations, threshold 0.05, P-value cutoff 0.05, seed 42) after `scanpy.pp.downsample_counts` of cells with >= 1,000 transcripts to 1,000 transcripts (random_state = 42) and re-normalisation (normalize_total 1e4, log1p); three analyses with identical parameters; HuE#1 and HuE#2 cells analysed together.

What was searched (2026-11-23): all transcripts of projects visible to this account (pattern `cpdb_statistical_analysis_method`, `counts_per_cell = 1000`, `downsample_counts`), the execution logs of sessions 0b0712b4, 13ab33ab, 5113e657, 824ef1ce, the shared folders F:/CS6-CS7 (incl. `cpdb_run/`), F:/claude, G:/data, G:/file.

What exists:
- `F:/CS6-CS7/cpdb_run/` (2026-07-31; project proj_b38193131cee, session e20f3ef7 "Load Seurat Objects CS6 and CS7"): CellPhoneDB v5.0.0 database (`db/`) and per-stage runs on the **epiblast-derived** subsets (EPI/ECT/Gast in old-CS6 = HuE#1; CLE/EPI/PS/aECT/pECT in old-CS7 = HuE#2), with the same call parameters (iterations 1000, threshold 0.05, debug_seed 42, pvalue 0.05) and a depth-matched variant downsampled to **700** transcripts. These are not the Figure 5 cell sets (VE2, Pari.ys.Endo, Al.Endo, PGC; Al.Endo with Al.Mes, ExE.Meso progenitor, ChA.Mes) and do not pool the two embryos, so they are not included here.
- Session 5113e657 (2026-10-26/27) re-plotted detection of candidate Figure 5E pairs (`Fig5E_all_CPDB_pairs_detection_CS8.csv`, `C682_CPDB_partner_detection_QC.csv`, `SuppFig6B/6C ... CPDB_highlighted`), reading an existing CellPhoneDB result; the CellPhoneDB run itself is not in that session.
- The final Figure 5 panels were supplied by the authors as `Figure 5.ai`.

Status: GAP. The authors should add the script that produced the Figure 5E/5G CellPhoneDB input matrices and the `cpdb_statistical_analysis_method.call` invocation (and the dot-plot script) before release.
