# staging/04_lefty_fgf/signalling_detection_tables.py
# Source: reconstructed from transcript 5113e657 (messages 880-1142)
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Detection (% cells or spots) per population: CosMx, Stereo-seq (R part in stereo_detection_by_cluster.R), mouse atlas; mouse organiser (Foxj1+Chrd+) by stage; human-mouse candidate table used by lefty_fgf_detection.py.
# Reconstructed verbatim from session transcript 5113e657 (code was run cell-by-cell in a
# persistent kernel and never saved as a file). Cells are concatenated in execution order;
# inspection-only and figure-polishing cells are omitted, and cells that stopped with an error are
# truncated at the failing line (marked). See PROVENANCE.md.


# ---- cell [frame 5113e657, message 880] Inspecting mouse atlas metadata
import anndata as ad, numpy as np, pandas as pd
a=ad.read_h5ad((str(HGC_DATA) + "/external/mouse_pijuan_sala/mouse_atlas_mapped_rawcounts.h5ad"),backed="r")
print(a.shape, list(a.obs.columns)[:30])


# ---- cell [frame 5113e657, message 882] Checking mouse node/Noto onset by stage
o=a.obs
print(pd.crosstab(o.celltype,o.stage).loc[lambda d: d.index.str.contains("Node|Notochord|Anterior Primitive|Primitive Streak",regex=True)])
var=pd.Index(a.var_names)
genes=[g for g in ["Noto","Foxj1","Chrd","Shh","Foxa2"] if g in var]
X=a.to_memory().X
import scipy.sparse as sp
idx=[var.get_loc(g) for g in genes]
M=(X[:,idx]>0); M=M.toarray() if sp.issparse(M) else M
df=pd.DataFrame(M,columns=genes); df["stage"]=o.stage.values; df["ct"]=o.celltype.values
sub=df[df.ct.isin(["Node","Notochord","Anterior Primitive Streak"])]
print(sub.groupby(["ct","stage"])[genes].mean().round(2))
print(df.groupby("stage")[["Noto","Foxj1"]].sum())


# ---- cell [frame 5113e657, message 1116] Computing genome-wide CosMx detection per population
import scipy.io as sio, numpy as np, pandas as pd, os
os.makedirs("hm",exist_ok=True)
DP=(str(HGC_DATA) + "/dataprep/")
gn=pd.read_csv(DP+"export/genes.csv").gene.values
for s in ["CS7","CS8"]:
    M=sio.mmread(DP+f"export/{s}_counts.mtx").tocsr()  # genes x cells
    lab=pd.read_csv(DP+f"export/{s}_cells.csv").label_short.values
    B=(M>0).astype(np.float32)
    out={}; tot=np.asarray(B.sum(1)).ravel(); N=B.shape[1]
    for g in pd.unique(lab):
        idx=np.where(lab==g)[0]
        k=np.asarray(B[:,idx].sum(1)).ravel()
        out[g]=100*k/len(idx); out[g+"__rest"]=100*(tot-k)/(N-len(idx))
    df=pd.DataFrame(out,index=gn); df["ALL"]=100*tot/N
    df.to_csv(f"hm/cosmx_{s}_pct.csv")
    print(s,df.shape, pd.Series(lab).value_counts().to_dict())


# ---- cell [frame 5113e657, message 1116] Computing mouse detection per matched cell type
import scipy.sparse as sp, os
os.makedirs("hm",exist_ok=True)
obs=o.copy() if hasattr(o,"copy") else o
st_=a.obs.stage.astype(str).values; ct_=a.obs.celltype.astype(str).values
Xc=X.tocsr() if sp.issparse(X) else sp.csr_matrix(X)
Bm=(Xc>0).astype(np.float32)
keys=[("Epiblast",["E7.0","E7.25"]),("Primitive Streak",["E7.0","E7.25"]),("Anterior Primitive Streak",["E7.0","E7.25"]),
("Notochord",["E7.5","E7.75"]),("Def. endoderm",["E7.25","E7.5"]),("Visceral endoderm",["E7.0","E7.25"]),("Visceral endoderm",["E7.5","E7.75"]),
("Nascent mesoderm",["E7.0","E7.25"]),("Nascent mesoderm",["E7.5","E7.75"]),("Primitive Streak",["E7.5","E7.75"]),("Epiblast",["E7.5","E7.75"]),
("Rostral neurectoderm",["E7.5","E7.75"]),("Caudal epiblast",["E7.75","E8.0"]),("Surface ectoderm",["E7.75","E8.0"]),("Paraxial mesoderm",["E7.75","E8.0"]),
("Mixed mesoderm",["E7.5","E7.75"]),("PGC",["E7.0","E7.25","E7.5"]),("ExE endoderm",["E7.0","E7.25","E7.5"]),("ExE mesoderm",["E7.0","E7.25","E7.5"])]
out={}; ns={}
for c,stg in keys:
    idx=np.where((ct_==c)&np.isin(st_,stg))[0]
    if len(idx)<20: print("skip",c,stg,len(idx)); continue
    nm=f"{c}|{'-'.join(stg)}"; out[nm]=100*np.asarray(Bm[idx].mean(0)).ravel(); ns[nm]=len(idx)
emb=np.isin(st_,["E7.0","E7.25","E7.5","E7.75","E8.0"])
# max across all mouse celltypes E7.0-E8.0 (groups>=50 cells)
mx=np.zeros(Bm.shape[1])
for c in pd.unique(ct_[emb]):
    idx=np.where((ct_==c)&emb)[0]
    if len(idx)>=50: mx=np.maximum(mx,100*np.asarray(Bm[idx].mean(0)).ravel())
dfm=pd.DataFrame(out,index=[g.upper() for g in a.var_names]); dfm["MAXANY"]=mx
dfm=dfm[~dfm.index.duplicated()]
dfm.to_csv("hm/mouse_pct.csv"); print(dfm.shape, ns)


# ---- cell [frame 5113e657, message 1118] Screening human-mouse expression differences
cz={s:pd.read_csv(f"hm/cosmx_{s}_pct.csv",index_col=0) for s in ["CS7","CS8"]}
sz={s:pd.read_csv(f"hm/stereo_{s}_pct.csv",index_col=0) for s in ["CS7","CS8"]}
mz=pd.read_csv("hm/mouse_pct.csv",index_col=0)
pairs=[("CS7","EPI","Epiblast|E7.0-E7.25","Epi"),("CS7","PS","Primitive Streak|E7.0-E7.25","PS"),("CS7","APS","Anterior Primitive Streak|E7.0-E7.25","PS"),
("CS7","Node","Notochord|E7.5-E7.75","Noto"),("CS7","DE","Def. endoderm|E7.25-E7.5","DE/VE"),("CS7","VE2","Visceral endoderm|E7.0-E7.25","DE/VE"),
("CS8","PS","Primitive Streak|E7.5-E7.75","Gast/PS"),("CS8","Nas.Meso","Nascent mesoderm|E7.5-E7.75","Meso"),("CS8","Para.Meso","Paraxial mesoderm|E7.75-E8.0","Meso"),
("CS8","Node","Notochord|E7.5-E7.75","Noto"),("CS8","Notochord","Notochord|E7.5-E7.75","Noto"),("CS8","aECT","Rostral neurectoderm|E7.5-E7.75","Epi/Ecto"),
("CS8","CLE","Caudal epiblast|E7.75-E8.0","Epi/Ecto"),("CS8","NNE","Surface ectoderm|E7.75-E8.0","Epi/Ecto"),("CS8","EPI","Epiblast|E7.5-E7.75","Epi/Ecto"),
("CS8","DE","Def. endoderm|E7.25-E7.5","Endo"),("CS8","VE2","Visceral endoderm|E7.5-E7.75","Visceral.Endo")]
common=cz["CS7"].index.intersection(mz.index).intersection(sz["CS7"].index).intersection(sz["CS8"].index)
bad=common[common.str.match(r"^(GM\d|RPL|RPS|MT-|HIST|H2A|H2B|H1F|H3|H4C|LOC|.*RIK$)")]
common=common.difference(bad); print(len(common))
cmax=pd.concat([cz[s][[c for c in cz[s].columns if "__rest" not in c and c!="ALL"]] for s in cz],axis=1).max(1)
smax=pd.concat([sz[s].drop(columns="ALL") for s in sz],axis=1).max(1)
rows=[]
for s,hp,mp,sp_ in pairs:
    H=cz[s].loc[common,hp]; Hr=cz[s].loc[common,hp+"__rest"]; Mm=mz.loc[common,mp]; S=sz[s].loc[common,sp_]; Sa=sz[s].loc[common,"ALL"]
    hon=(H>=20)&(H>=3*Hr)&(H-Hr>=10)&(S>=5)&(S>=2*Sa)&(Mm<=5)
    mon=(Mm>=40)&(H<=np.maximum(Hr,cz[s].loc[common,"ALL"])+3)&(H<=8)&((S<=3)|(S<=1.5*Sa))&((cmax.loc[common]>=15)|(smax.loc[common]>=10))
    for g in common[hon]: rows.append(dict(type="human-on/mouse-off",stage=s,human_pop=hp,gene=g,human_pct=H[g],human_rest=Hr[g],stereo_pct=S[g],stereo_all=Sa[g],mouse_pct=Mm[g],mouse_maxany=mz.loc[g,"MAXANY"],cosmx_max=cmax[g],stereo_max=smax[g]))
    for g in common[mon]: rows.append(dict(type="mouse-on/human-off",stage=s,human_pop=hp,gene=g,human_pct=H[g],human_rest=Hr[g],stereo_pct=S[g],stereo_all=Sa[g],mouse_pct=Mm[g],mouse_maxany=mz.loc[g,"MAXANY"],cosmx_max=cmax[g],stereo_max=smax[g]))
Rr=pd.DataFrame(rows).round(1); Rr.to_csv("hm/screen_hits.csv",index=False)
print(Rr.groupby(["type","stage","human_pop"]).size().to_string())


# ---- cell [frame 5113e657, message 1132] Stage-resolved mouse organiser gene detection
gg=[g for g in ["Nog","Chrd","Cfc1","Tdgf1","Lefty1","Lefty2","Shh","Foxa2","Noto","Fgf8","Fgf17","Bmp7"] if g in var]
Xg=X[:,[var.get_loc(g) for g in gg]]; Xg=(Xg.toarray() if sp.issparse(Xg) else np.asarray(Xg))>0
dd=pd.DataFrame(Xg,columns=gg); dd["stage"]=st_; dd["ct"]=ct_
org=dd[(dd.Foxj1 if "Foxj1" in dd else False) if False else (pd.Series(np.asarray((X[:,var.get_loc("Foxj1")]>0).todense()).ravel() if sp.issparse(X) else X[:,var.get_loc("Foxj1")]>0))&dd.Chrd]
rows=[]
for s_ in ["E7.0","E7.25","E7.5","E7.75"]:
    q=org[org.stage==s_]; n=dd[(dd.ct=="Notochord")&(dd.stage==s_)]
    rows.append({"stage":s_,"n_Foxj1Chrd":len(q),**{f"org_{g}":round(100*q[g].mean(),1) for g in gg if g!="Chrd"},"n_notochord":len(n),**{f"noto_{g}":round(100*n[g].mean(),1) if len(n) else np.nan for g in ["Nog","Cfc1","Shh","Lefty1"]}})
MM=pd.DataFrame(rows); print(MM.T.to_string()); MM.to_csv("hm/mouse_organiser_stage.csv",index=False)


# ---- cell [frame 5113e657, message 1134] Assembling candidate difference table
MM=pd.read_csv("hm/mouse_organiser_stage.csv")
genes_p=["FGF8","FGF17","LEFTY1","LEFTY2","CFC1","TDGF1","NODAL","NOG","SHH"]
mg={"FGF8":"Fgf8","FGF17":"Fgf17","LEFTY1":"Lefty1","LEFTY2":"Lefty2","CFC1":"Cfc1","TDGF1":"Tdgf1","NODAL":None,"NOG":"Nog","SHH":"Shh"}
cols=["CosMx CS7 node","CosMx CS7 APS","Stereo CS7 node","Stereo CS7 PS","CosMx CS8 node","Stereo CS8 node","Mouse organiser E7.0","Mouse organiser E7.25","Mouse organiser E7.5","Mouse APS E7.0–7.25"]
V=pd.DataFrame(index=genes_p,columns=cols,dtype=float)
for g in genes_p:
    V.loc[g,"CosMx CS7 node"]=cz["CS7"].loc[g,"Node"] if g in cz["CS7"].index else np.nan
    V.loc[g,"CosMx CS7 APS"]=cz["CS7"].loc[g,"APS"] if g in cz["CS7"].index else np.nan
    V.loc[g,"CosMx CS8 node"]=cz["CS8"].loc[g,"Node"] if g in cz["CS8"].index else np.nan
    V.loc[g,"Stereo CS7 node"]=sz["CS7"].loc[g,"Noto"]; V.loc[g,"Stereo CS7 PS"]=sz["CS7"].loc[g,"PS"]; V.loc[g,"Stereo CS8 node"]=sz["CS8"].loc[g,"Noto"]
    for i,s_ in enumerate(["E7.0","E7.25","E7.5"]):
        k=f"org_{mg[g]}"; V.loc[g,f"Mouse organiser {s_}"]=MM.loc[MM.stage==s_,k].values[0] if mg[g] and k in MM.columns else np.nan
    V.loc[g,"Mouse APS E7.0–7.25"]=mz.loc[g,"Anterior Primitive Streak|E7.0-E7.25"]
# NODAL organiser in mouse not computed: fill from mz notochord? leave NaN but compute quickly from APS
ctrl=pd.DataFrame({"CosMx max (any disc pop.)":[cmax.get(g,np.nan) for g in genes_p],"Stereo max (any cluster)":[smax.get(g,np.nan) for g in genes_p]},index=genes_p)
V.round(1).join(ctrl.round(1)).to_csv("hm/human_mouse_candidates_table.csv"); print(V.round(1).join(ctrl.round(1)).to_string())


# ---- cell [frame 5113e657, message 1140] Computing mouse Nodal in organiser cells
nod=(np.asarray(X[:,var.get_loc("Nodal")].todense()).ravel() if sp.issparse(X) else np.asarray(X[:,var.get_loc("Nodal")]).ravel())>0
fx=(np.asarray(X[:,var.get_loc("Foxj1")].todense()).ravel() if sp.issparse(X) else np.asarray(X[:,var.get_loc("Foxj1")]).ravel())>0
ch=(np.asarray(X[:,var.get_loc("Chrd")].todense()).ravel() if sp.issparse(X) else np.asarray(X[:,var.get_loc("Chrd")]).ravel())>0
print({s_:round(100*nod[(st_==s_)&fx&ch].mean(),1) for s_ in ["E7.0","E7.25","E7.5"]})


# ---- cell [frame 5113e657, message 1142] Redrawing heatmap with mouse NODAL values
V.loc["NODAL",["Mouse organiser E7.0","Mouse organiser E7.25","Mouse organiser E7.5"]]=[29.1,9.0,20.9]
V.round(1).join(ctrl.round(1)).to_csv("hm/human_mouse_candidates_table.csv")
# (rest of this cell redrew an exploratory heatmap)
