"""Replication of AIGG-OT and Euclidean OT, with and without the transition prior, on the published Stereo-seq CS7 (Cui et al.)
and CS8 (Xiao et al.) embryos (Supplementary Figure 9H; Table S3 'Benchmark settings' b-c).
Reconstructed verbatim from session 824ef1ce messages [1435] and [1439] (plus the line `tab=TTs["table"]` of [1437]).
Inputs are outputs of stereoseq_frames_pipeline.py (frames, smoothed Harmony embedding, row index, extended transition table).
The original loop also ran a streak-gated variant (tau = 25) that is not reported; it was removed.
Output: ggot_stereoseq_replication.csv (cwd).
"""
import os, sys, json
import numpy as np, pandas as pd
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lib"))   # [glue]
import ggot, ggot_match as GM                                                                 # [glue]

# ---- [1435] / [1437] (tab) / [1439]
LO=ggot.LAYER_OF
RD=DATA + "/cs7_cs8_matching/replication_stereoseq/"
F7s=pd.read_csv(RD+"CS7_stereoseq_frames.csv"); F8s=pd.read_csv(RD+"CS8_stereoseq_frames.csv")
EI=pd.read_csv(RD+"embedding_row_index.csv"); Hst=np.load(RD+"harmony_embedding_smooth_stereoseq.npy")
TTs=json.load(open(RD+"transition_table_stereoseq.json")); print(type(TTs), list(TTs)[:5] if isinstance(TTs,dict) else None)
tab=TTs["table"]   # [1437]
trans_s={tuple(k.split("->")):v for k,v in tab.items()}
EI["row"]=np.arange(len(EI))
def prep(F,stage):
    F=F[F.in_disc & (F.group!="exclude")].copy()
    cnt=F.group.value_counts(); F=F[F.group.map(cnt)>=10]
    m=EI[EI.stage==stage].set_index("spot").row
    F=F[F.spot.isin(m.index)]; return F, Hst[m.loc[F.spot].values]
F7p,H7s=prep(F7s,"CS7"); F8p,H8s=prep(F8s,"CS8"); print(len(F7p),len(F8p))
S7s=F7p[["AP_frac","LR_frac","DV_gap_units"]].to_numpy(float); S8s=F8p[["AP_frac","LR_frac","DV_gap_units"]].to_numpy(float)
g7s=F7p.group.to_numpy(str); g8s=F8p.group.to_numpy(str)
gs=ggot.Grid(ap_lim=(-0.15,1.25),lr_lim=(-0.9,0.9),step_um=20.0)
l7s=np.array([LO[x] for x in g7s]); l8s=np.array([LO[x] for x in g8s])
def stereo_metrics(M):
    coo=M.tocoo(); a7=g7s[coo.row]; a8=g8s[coo.col]
    cls=np.array([trans_s.get((x,y),"penalised") for x,y in zip(a7,a8)]); cross=np.array([LO[x]!=LO[y] for x,y in zip(a7,a8)])
    inn=np.asarray(M.sum(0)).ravel(); out=np.asarray(M.sum(1)).ravel()
    return dict(pen=(cls=="penalised").mean(),pen_cross=((cls=="penalised")&cross).mean(),pen_same=((cls=="penalised")&~cross).mean(),n8_unm=int((inn==0).sum()),n7_unm=int((out==0).sum()))
ST=[]
for name,kw in [("Euclidean",dict(space="euclid")),("GG-OT (layers)",dict(space="gated",grid=gs))]:   # streak-gate variant of the original loop removed (not reported)
    for pr in [False,True]:
        r=GM.match(H7s,H8s,S7s,S8s,g7s,g8s,np.ones(len(g7s)),np.ones(len(g8s)),trans_s,prior=pr,**kw)
        ST.append(dict(method=name,table=pr,**stereo_metrics(r["M"])))
ST=pd.DataFrame(ST); ST.to_csv("ggot_stereoseq_replication.csv",index=False); print(ST.round(3).to_string())
