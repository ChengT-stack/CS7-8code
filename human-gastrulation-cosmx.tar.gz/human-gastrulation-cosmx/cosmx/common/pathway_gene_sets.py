# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/cs7_seven_pop_trends/cs7_pathway_gene_sets.json (2026-09-28; also artifact 004a2099)
# sha256 of original: b54585c6cc44033800a7203d01e806b5f4500232165014a02a91bcd009c1ebc7
# Methods paragraphs: P361
# Produces: gene-set constants for Figure 4A-E, Supplementary Figure 6A-E
# Edits/notes: JSON converted to Python constants (no data files allowed); contents unchanged.

"""Pathway gene sets (20 sets x complete/concise) used for Figure 4 and Supplementary Figure 6.
Converted verbatim from cs7_pathway_gene_sets.json (written by seven_pop_trends.py).
"""
PATHWAY_GENE_SETS = {
    'COMPLETE': {
        'FGF_inhibitor': ['DUSP6', 'FGFBP1', 'FLRT3', 'IL17RD', 'SPRED1', 'SPRED2', 'SPRED3', 'SPRY1', 'SPRY2', 'SPRY3', 'SPRY4'],
        'FGF_ligand': ['FGF1', 'FGF10', 'FGF16', 'FGF17', 'FGF18', 'FGF19', 'FGF2', 'FGF20', 'FGF21', 'FGF22', 'FGF23', 'FGF3', 'FGF4', 'FGF5', 'FGF6', 'FGF7', 'FGF8', 'FGF9'],
        'FGF_target': ['DUSP6', 'ETV4', 'ETV5', 'FGFBP1', 'IL17RD', 'SPRY1', 'SPRY2', 'SPRY4'],
        'NODAL_inhibitor': ['BMP4', 'CER1', 'DAND5', 'FST', 'LEFTY1', 'LEFTY2', 'SMAD7', 'TMEFF1'],
        'NODAL_ligand': ['CFC1', 'GDF3', 'LEFTY1', 'NODAL'],
        'NODAL_target': ['LEFTY1', 'LEFTY2', 'NODAL', 'PITX2'],
        'NOTCH_inhibitor': ['DLK1', 'DLK2', 'DLL3', 'DTX1', 'DTX4', 'HES1', 'LFNG', 'MFNG', 'NRARP', 'NUMB', 'NUMBL', 'RFNG'],
        'NOTCH_ligand': ['DLL1', 'DLL3', 'DLL4', 'JAG1', 'JAG2'],
        'NOTCH_target': ['HES1', 'HES5', 'HEY1', 'HEY2', 'HEYL', 'NRARP'],
        'SHH_inhibitor': ['GLI3', 'HHIP', 'KIF7', 'PTCH1', 'PTCH2', 'PTCHD1', 'SUFU'],
        'SHH_ligand': ['DHH', 'IHH', 'SHH'],
        'SHH_target': ['GLI1', 'HHIP', 'PTCH1', 'PTCH2'],
        'WNT_inhibitor': ['APCDD1', 'AXIN2', 'CTBP1', 'DKK1', 'DKK2', 'DKK3', 'DKK4', 'KREMEN1', 'NKD1', 'NOTUM', 'RNF43', 'SFRP1', 'SFRP2', 'SFRP4', 'SFRP5', 'SOST', 'SOSTDC1', 'WIF1', 'ZNRF3'],
        'WNT_ligand': ['RSPO1', 'RSPO2', 'RSPO3', 'RSPO4', 'WNT1', 'WNT10A', 'WNT10B', 'WNT11', 'WNT16', 'WNT2', 'WNT2B', 'WNT3', 'WNT3A', 'WNT4', 'WNT5A', 'WNT5B', 'WNT6', 'WNT7A', 'WNT7B', 'WNT8A', 'WNT8B', 'WNT9A', 'WNT9B'],
        'WNT_target': ['AXIN2', 'CDX1', 'DKK1', 'LEF1', 'NKD1', 'NOTUM', 'RNF43', 'SP5', 'TCF7', 'ZNRF3'],
        'FGF_receptor': ['FGFR1', 'FGFR2', 'FGFR3', 'FGFR4', 'FGFRL1', 'KL', 'KLB'],
        'NODAL_receptor': ['ACVR1B', 'ACVR1C', 'ACVR2A', 'ACVR2B', 'CFC1'],
        'NOTCH_receptor': ['NOTCH1', 'NOTCH2', 'NOTCH3', 'NOTCH4'],
        'SHH_receptor': ['BOC', 'CDON', 'GAS1', 'LRP2', 'PTCH1', 'PTCH2', 'SMO'],
        'WNT_receptor': ['FZD1', 'FZD10', 'FZD2', 'FZD3', 'FZD4', 'FZD5', 'FZD6', 'FZD7', 'FZD8', 'FZD9', 'KREMEN1', 'KREMEN2', 'LGR4', 'LGR5', 'LGR6', 'LRP5', 'LRP6', 'ROR1', 'ROR2', 'RYK'],
    },
    'CONCISE': {
        'FGF_inhibitor': ['DUSP6', 'FGFBP1', 'FLRT3', 'IL17RD', 'SPRED1', 'SPRED2', 'SPRED3', 'SPRY1', 'SPRY2', 'SPRY3', 'SPRY4'],
        'FGF_ligand': ['FGF2', 'FGF3', 'FGF4', 'FGF5', 'FGF8', 'FGF9', 'FGF10', 'FGF17', 'FGF18'],
        'FGF_target': ['DUSP6', 'ETV4', 'ETV5', 'FGFBP1', 'IL17RD', 'SPRY1', 'SPRY2', 'SPRY4'],
        'NODAL_inhibitor': ['BMP4', 'CER1', 'DAND5', 'FST', 'LEFTY1', 'LEFTY2', 'SMAD7', 'TMEFF1'],
        'NODAL_ligand': ['NODAL', 'GDF3', 'CFC1', 'LEFTY1'],
        'NODAL_target': ['LEFTY1', 'LEFTY2', 'NODAL', 'PITX2'],
        'NOTCH_inhibitor': ['DLK1', 'DLK2', 'DLL3', 'DTX1', 'DTX4', 'HES1', 'LFNG', 'MFNG', 'NRARP', 'NUMB', 'NUMBL', 'RFNG'],
        'NOTCH_ligand': ['DLL1', 'DLL3', 'DLL4', 'JAG1', 'JAG2'],
        'NOTCH_target': ['HES1', 'HES5', 'HEY1', 'HEY2', 'HEYL', 'NRARP'],
        'SHH_inhibitor': ['GLI3', 'HHIP', 'KIF7', 'PTCH1', 'PTCH2', 'PTCHD1', 'SUFU'],
        'SHH_ligand': ['SHH', 'IHH', 'DHH'],
        'SHH_target': ['GLI1', 'HHIP', 'PTCH1', 'PTCH2'],
        'WNT_inhibitor': ['APCDD1', 'AXIN2', 'CTBP1', 'DKK1', 'DKK2', 'DKK3', 'DKK4', 'KREMEN1', 'NKD1', 'NOTUM', 'RNF43', 'SFRP1', 'SFRP2', 'SFRP4', 'SFRP5', 'SOST', 'SOSTDC1', 'WIF1', 'ZNRF3'],
        'WNT_ligand': ['WNT1', 'WNT2B', 'WNT3', 'WNT3A', 'WNT4', 'WNT5A', 'WNT5B', 'WNT6', 'WNT7A', 'WNT7B', 'WNT8A', 'WNT9A', 'WNT11', 'RSPO1', 'RSPO2', 'RSPO3'],
        'WNT_target': ['AXIN2', 'CDX1', 'DKK1', 'LEF1', 'NKD1', 'NOTUM', 'RNF43', 'SP5', 'TCF7', 'ZNRF3'],
        'FGF_receptor': ['FGFR1', 'FGFR2', 'FGFR3', 'FGFR4'],
        'NODAL_receptor': ['ACVR1B', 'ACVR2A', 'ACVR2B', 'SMAD2', 'SMAD3'],
        'NOTCH_receptor': ['NOTCH1', 'NOTCH2', 'NOTCH3', 'NOTCH4'],
        'SHH_receptor': ['PTCH1', 'SMO', 'GAS1', 'CDON', 'BOC'],
        'WNT_receptor': ['FZD1', 'FZD2', 'FZD3', 'FZD4', 'FZD5', 'FZD6', 'FZD7', 'FZD8', 'FZD10', 'LRP5', 'LRP6'],
    },
}
COMPLETE = PATHWAY_GENE_SETS["COMPLETE"]
CONCISE = PATHWAY_GENE_SETS["CONCISE"]
