# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: lineage record of the analysis platform of Fig2K_section_node_cells.csv, artifact 7b584403 (session 5113e657
#     kernel cell 2002; the raw cell relies on kernel state, the lineage extraction makes it standalone)
# sha256 of original: cb9f840a4ecc408b06476602235cfa9c560cca12de5f21887355fb3f691a70c4
# Methods paragraphs: P355
# Produces: Fig2K_section_node_cells.csv (Figure 2H: node cells on sections #19, #20, #22 coloured FOXJ1-only /
#     GSC-LHX1-CER1-DKK1-only / both / neither)
# Edits/notes: code text is the platform lineage extraction (checked against the raw tail of kernel cell 2002:
#     identical category rule). The drawing code of Figure 2H/2I (Fig2K_CS7_node_two_tiers.ai) is not included
#     (see GAPS).
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

import numpy as np
import pandas as pd
import scipy.io as sio
import scipy.sparse as sp

c7 = pd.read_csv((str(DATA) + "/dataprep/export/CS7_cells.csv"))

g = pd.read_csv((str(DATA) + "/dataprep/export/genes.csv")).gene.values
gi = {x: i for i, x in enumerate(g)}
X7 = sio.mmread((str(DATA) + "/dataprep/export/CS7_counts.mtx")).tocsr()

GG = ['FOXJ1', 'GSC', 'LHX1', 'CER1', 'DKK1']
E = pd.DataFrame((X7[[gi[x] for x in GG], :].T > 0).toarray(), columns=GG)
c7 = pd.concat([c7, E], axis=1)
c7['FOX'] = c7.FOXJ1
c7['VEN'] = c7[['GSC', 'LHX1', 'CER1', 'DKK1']].any(axis=1)

rows = []
for s in [19, 20, 22]:
    q = c7[c7.section == s]
    n = q[q.label_short == 'Node']
    rows.append(n.assign(category=np.where(n.FOX & n.VEN, 'both', np.where(n.FOX, 'FOXJ1 only', np.where(n.VEN, 'GSC/LHX1/CER1/DKK1 only', 'neither'))))[['cell', 'section', 'x_um', 'y_um', 'FOXJ1', 'GSC', 'LHX1', 'CER1', 'DKK1', 'category']])

src = pd.concat(rows)
src.to_csv('Fig2K_section_node_cells.csv', index=False)