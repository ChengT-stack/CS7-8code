#!/bin/bash
# Zero-shot UCE (33-layer) embedding of each dataset with its native species vocabulary
UCE_DIR=${HGC_DATA:-data}/UCE   # UCE checkout in $UCE_DIR/repo, inputs in $UCE_DIR/inputs, outputs in $UCE_DIR/out
cd $UCE_DIR/repo; export PYTHONPATH=$UCE_DIR/repo
PY=${PYTHON:-python}
for spec in "HuE1_CS7 human" "HuE2_CS8 human" "Cui_CS7 human" "Xiao_CS8 human" "Inhouse_CS7 human" "Tyser_CS7 human" "Monkey macaca_fascicularis" "Mouse mouse"; do
  set -- $spec
  [ -f ../out/$1_uce_adata.h5ad ] && { echo "skip $1"; continue; }
  echo "=== $1 ($2) $(date +%T)"
  $PY eval_single_anndata.py --adata_path ../inputs/$1.h5ad --dir ../out/ --species $2 \
     --model_loc ./model_files/33l_8ep_1024t_1280.torch --nlayers 33 --batch_size 64 2>&1 | grep -v "^ *[0-9]*%\|it/s\]" | tail -4
done
ls -la ../out/*_uce_adata.h5ad

# Mittnenzweig et al. (2021) mouse atlas, 153-embryo release (training data of the generative model); session 5113e657 [3356]
$PY eval_single_anndata.py --adata_path ../inputs/Mittnenzweig153.h5ad --dir ../out/ --species mouse \
   --model_loc ./model_files/33l_8ep_1024t_1280.torch --nlayers 33 --batch_size 64 > ../run_uce_mz153.log 2>&1
ls -la ../out/Mittnenzweig153_uce_adata.h5ad
