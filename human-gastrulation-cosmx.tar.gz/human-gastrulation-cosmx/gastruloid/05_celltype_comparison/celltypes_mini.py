# gastruloid/05_celltype_comparison/celltypes_mini.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/celltypes_mini.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Embryonic cell types of the CosMx CS7 / CS8 embryos with or without a counterpart in seven gastruloid samples (Hamazaki 0-96 h without RA, Heemskerk 42 h, Liu d11).
# Same evidence rules as celltypes_cs78.py (annotated population: >=1% of annotated cells and >=20 cells; marker-defined cells: milestone call 'reached').
# Reference embryo per sample: CS7-like -> CS7; CS8-like -> CS8; transitional -> types present in both embryos (types in one embryo only are optional); beyond CS8 -> CS8 (user decision).
# Extra-embryonic and germline types are not compared (user decision); shares are given both of all annotated cells and of embryonic-type cells.
import numpy as np, pandas as pd
OUT = 'gall/out_v2/'; src = open(Path(__file__).resolve().parent / 'celltypes_cs78.py').read(); exec(src[src.index('TYPES = ['):src.index("h = pd.read_csv('tb/out/embryo_units")])
ALLT = TYPES; EXT = [t for t in ALLT if t[2] == 'Extra-embryonic and germline']; TYPES = [t for t in ALLT if t[2] != 'Extra-embryonic and germline']
UNITS = ['Ham_0h', 'Ham_24h', 'Ham_48h', 'Ham_72h', 'Ham_96h', 'Hee_42', 'Liu_PG_d11']; EMBS = {'Human embryo CS7 (CosMx)': 'CS7', 'Human embryo CS8 (CosMx)': 'CS8'}
h = pd.read_csv('tb/out/embryo_units_cosmx38_half.csv'); EN = h.groupby(['label', 'stage']).n_cells.sum().unstack().fillna(0)
R = pd.read_csv(OUT + 'gastruloid_stage_vs_CS7_CS8.csv').set_index('unit'); ML = pd.read_csv(OUT + 'milestone_assessability_long.csv').set_index(['group', 'milestone_id'])
a = pd.read_parquet('reanno/out/all_cells_annotated.parquet', columns=['group', 'label', 'excluded']); a = a[a.group.isin(UNITS) & ~a.excluded]; NL = a.groupby(['group', 'label']).size(); NT = a.groupby('group').size(); assert set(UNITS) <= set(NT.index)
ext_labels = {l for t in EXT for l in t[4]}; emb_labels = {l for t in TYPES for l in t[4]}; both = ext_labels & emb_labels   # labels listed under an embryonic and an extra-embryonic type
first = {}
for t in TYPES:
    for l in t[4]: first.setdefault(l, t[0])
multi = [l for l in emb_labels if sum(l in t[4] for t in TYPES) > 1]
for g in UNITS:   # ambiguous labels must be negligible in these samples, otherwise the composition would double count
    for l in set(multi) | both: assert NL.get((g, l), 0) / NT[g] < 0.005, (g, l, NL.get((g, l), 0))
NEXT = {g: int(sum(NL.get((g, l), 0) for l in ext_labels - both)) for g in UNITS}; NEMB = {g: int(NT[g] - NEXT[g]) for g in UNITS}   # embryonic-type cells = annotated cells without an extra-embryonic / germline label
ETOT = {s: float(sum(EN[s].get(c, 0) for t in TYPES for c in t[3])) for s in ('CS7', 'CS8')}; EALL = {s: float(EN[s].sum()) for s in ('CS7', 'CS8')}
REF = {'CS7-like': 'CS7 embryo', 'CS8-like': 'CS8 embryo', 'CS7-to-CS8 transitional': 'types in both embryos', 'beyond CS8': 'CS8 embryo (latest available)'}
rows = []; comp = []
for key, lab, blk, ctypes, labels, ms in TYPES:
    n7 = int(sum(EN.CS7.get(c, 0) for c in ctypes)); n8 = int(sum(EN.CS8.get(c, 0) for c in ctypes)); in7, in8 = n7 > 0, n8 > 0
    for u, n_, st_, s in [('Human embryo CS7 (CosMx)', n7, in7, 'CS7'), ('Human embryo CS8 (CosMx)', n8, in8, 'CS8')]:
        rows.append(dict(unit=u, kind='embryo', stage='', type=key, type_label=lab, block=blk, in_CS7=in7, in_CS8=in8, n_cells=n_, pct_all=round(100 * n_ / EALL[s], 2), pct_embryonic=round(100 * n_ / ETOT[s], 2), labels='; '.join(ctypes), milestone=ms or '', milestone_call='', state='present' if st_ else 'absent'))
    for g in UNITS:
        n = int(sum(NL.get((g, l), 0) for l in labels)); pct = 100 * n / NT[g]; clus = (pct >= 1.0) and (n >= 20); mc = ML.loc[(g, ms), 'call_observed'] if ms else ''; mark = mc == 'reached'
        stg = R.stage[g]; exp = {'CS7-like': in7, 'CS8-like': in8, 'beyond CS8': in8, 'CS7-to-CS8 transitional': in7 and in8}[stg]; one = stg == 'CS7-to-CS8 transitional' and (in7 != in8)
        state = 'present (annotated population)' if clus else 'present (marker-defined cells only)' if mark else 'absent, present in the reference embryo' if exp else 'absent, present in one of the two embryos' if one else 'absent, not expected'
        n1 = int(sum(NL.get((g, l), 0) for l in labels if first[l] == key))
        rows.append(dict(unit=g, kind='sample', stage=stg, type=key, type_label=lab, block=blk, in_CS7=in7, in_CS8=in8, n_cells=n, pct_all=round(pct, 2), pct_embryonic=round(100 * n1 / NEMB[g], 2), labels='; '.join(l for l in labels if NL.get((g, l), 0) > 0), milestone=ms or '', milestone_call=mc, expected=bool(exp), state=state))
T = pd.DataFrame(rows); T.to_csv(OUT + 'celltypes_mini_long.csv', index=False)
P = T[T.kind == 'sample'].pivot(index='type', columns='unit', values='state').loc[[t[0] for t in TYPES], UNITS]; E = T[T.kind == 'sample'].pivot(index='type', columns='unit', values='expected').loc[P.index, UNITS]
summ = pd.DataFrame({g: dict(stage=R.stage[g], reference=REF[R.stage[g]], n_expected=int(E[g].sum()), n_missing=int(P[g].str.startswith('absent, present in the reference').sum()), missing=';'.join(t for t in P.index if P.loc[t, g].startswith('absent, present in the reference')),
                             missing_one_embryo_only=';'.join(t for t in P.index if P.loc[t, g].startswith('absent, present in one')), marker_only=';'.join(t for t in P.index if P.loc[t, g].startswith('present (marker')),
                             n_annotated_cells=int(NT[g]), pct_embryonic_type_cells=round(100 * NEMB[g] / NT[g], 1), pct_later_types=round(100 * (NEMB[g] - sum(NL.get((g, l), 0) for l in emb_labels - both)) / NEMB[g], 2)) for g in UNITS}).T
summ.to_csv(OUT + 'celltypes_mini_missing_by_sample.csv')
ab = {'present (annotated population)': 'P', 'present (marker-defined cells only)': 'm', 'absent, present in the reference embryo': 'X', 'absent, present in one of the two embryos': 'x', 'absent, not expected': '.'}
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 80); print(P.replace(ab).to_string()); print(summ.drop(columns=['reference']).to_string()); print({s: (ETOT[s], round(100 * ETOT[s] / EALL[s], 1)) for s in ETOT})
print(T[T.kind == 'sample'].groupby('unit').pct_embryonic.sum().round(1).to_dict())
