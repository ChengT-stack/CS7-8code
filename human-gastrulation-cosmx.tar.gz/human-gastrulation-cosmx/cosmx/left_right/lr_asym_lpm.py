# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/lr_asymmetry/lr_asym_lpm.py (2026-11-?? copy after the axes-height edit of session
#     0b0712b4 bash cell 2331; producing script of cs8_lpm_lr_asymmetry.pdf, artifact 50f0d51a)
# sha256 of original: e87ef6b06c3a5b4ef11a4a05e3589d44edd61def90cc08ea56e4c10fb3d2f0d2
# Methods paragraphs: Supplementary Figure 5D (distribution of the asymmetry index; LP.Meso)
# Produces: cs8_lpm_lr_asymmetry.{png,pdf,svg}, cs8_lpm_lr_asymmetry_tests.csv,
#     cs8_lpm_lr_asymmetry_all_genes.csv
# Edits/notes: lr_asym.py read from this folder.
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass
os.environ['HGC_SCRIPT_DIR'] = str(SCRIPT_DIR)   # lr_asym.py is exec-ed below

"""LP.Meso-only version of the left-right figure (CS8): every panel shares the same horizontal axis, LR' (um from
the fitted midline), with identical limits and ticks. Statistics are the same as lr_asym.py (same seeds, same window)."""
import os,sys,textwrap
os.environ["STAGE"]="CS8"
src=open(SCRIPT_DIR / "lr_asym.py").read()
exec(src[:src.index("# ---------- side definition")])
POPS={"LP.Meso":["Lateral plate mesoderm (LP.Meso)"]}
exec(src[src.index("# ---------- side definition"):src.index("# ---------- figure ----------")].replace('f"{STAGE.lower()}_lr_asymmetry_tests.csv"','"cs8_lpm_lr_asymmetry_tests.csv"').replace('f"{STAGE.lower()}_lr_asymmetry_all_genes.csv"','"cs8_lpm_lr_asymmetry_all_genes.csv"'))
pn="LP.Meso"; d=NULL[pn]; wmax=d["wmax"]; XL=(-wmax-10,wmax+10); XT=np.arange(-200,201,50)
m=pop_mask(pn)
plt.close("all"); apply_figure_style()
fig=plt.figure(figsize=(9.6,14.2))
PG=["DLL1","NOTCH1","NODAL","LEFTY2","PITX2","DAND5"]
# (a,b) LP.Meso cells in midline-corrected coordinates: x = LR', y = AP  -> same horizontal axis as everything below
for i,g in enumerate(TARGET):
    ax=fig.add_axes([0.09+i*0.33,0.690,0.29,0.175]); v=np.asarray(X[:,gi[g]].todense()).ravel()>0
    ax.scatter(LRp[m],C[m,0],s=1.2,color="#DDDDDD",lw=0)
    q=np.where(m&v)[0]; ax.scatter(LRp[q],C[q,0],s=3.0,color="#C2401A",lw=0,alpha=.75)
    ax.axvline(0,color="#111111",lw=1.0); ax.axvspan(-MID,MID,color="#BBBBBB",alpha=.35,lw=0)
    for s_ in (-1,1): ax.axvline(s_*wmax,color="#111111",lw=.6,ls=":")
    ax.set_xlim(*XL); ax.set_xticks(XT); ax.set_ylabel("anterior \u2192 posterior (\u00b5m)",fontsize=7); ax.tick_params(labelsize=6)
    ax.set_title(f"{'ab'[i]}   {g} in LP.Meso: {len(q):,} of {int(m.sum()):,} cells with \u2265 1 count",loc="left",fontsize=7.6)
    ax.set_xlabel("LR\u2032 (\u00b5m)",fontsize=7); ax.set_xticks(np.arange(-200,201,100))
    if i==1: ax.set_ylabel("")
# (c) six profiles, one column, identical x
gh=0.058
for r,g in enumerate(PG):
    ax=fig.add_axes([0.09,0.625-(r+1)*gh-r*0.008,0.29,gh])
    ctr,dd,lo,hi=PROF[(pn,g)]; col="#C2401A" if g in TARGET else "#1F6FB2"
    ax.fill_between(ctr,lo,hi,color=col,alpha=.18,lw=0); ax.plot(ctr,dd,color=col,lw=1.3)
    ax.axvline(0,color="#111111",lw=.6); ax.axvspan(-MID,MID,color="#DDDDDD",alpha=.5,lw=0)
    ax.set_xlim(*XL); ax.set_xticks(np.arange(-200,201,100)); ax.set_ylim(0,max(np.nanmax(hi) if np.isfinite(hi).any() else 0.05,0.02)*1.12)
    ax.tick_params(labelsize=5.6); ax.spines[["top","right"]].set_visible(False)
    rr=T[(T["pop"]==pn)&(T.gene==g)].iloc[0]; sig=(abs(rr.z_vs_genome)>=2 and rr.perm_p<0.01)
    ax.text(1.03,.85,f"L {rr.detL_pct:.1f}%   R {rr.detR_pct:.1f}%\nAI {rr.asym_index:+.2f}   z {rr.z_vs_genome:+.1f}   p {rr.perm_p:.2f}",transform=ax.transAxes,fontsize=6.0,va="top",ha="left",linespacing=1.5,color="#C2401A" if sig else "#777777")
    ax.set_ylabel(f"{g}\ndetection",fontsize=6.6)
    if r==0: ax.set_title(f"c   LP.Meso detection per 15-\u00b5m section\n     (L {d['nL']} / R {d['nR']} cells in the window)",loc="left",fontsize=7.6)
    if r<len(PG)-1: ax.tick_params(labelbottom=False)
    else: ax.set_xlabel("LR\u2032 (\u00b5m)",fontsize=7)
# (d) genome-wide null, x = AI (the one panel whose x cannot be LR')
ax=fig.add_axes([0.09,0.035,0.87,0.145]); AI=d["AI"]
ax.hist(AI,bins=np.linspace(-1,1,81),color="#BBBBBB",lw=0)
yt=ax.get_ylim()[1]
for k_,(g,col) in enumerate([("DLL1","#C2401A"),("NOTCH1","#7B4FA3"),("NODAL","#1F6FB2"),("LEFTY2","#2E8B57"),("PITX2","#D97706"),("DAND5","#8C510A")]):
    rr=T[(T["pop"]==pn)&(T.gene==g)].iloc[0]; ax.axvline(rr.asym_index,color=col,lw=1.2)
    ax.text(rr.asym_index+(0.015 if rr.asym_index>=0 else -0.015),yt*(0.95-0.13*k_),f"{g} {rr.asym_index:+.2f}",color=col,fontsize=5.8,ha="left" if rr.asym_index>=0 else "right",va="top",path_effects=[pe.withStroke(linewidth=1.5,foreground="white")])
ax.set_xlim(-1,1); ax.tick_params(labelsize=6); ax.spines[["top","right"]].set_visible(False); ax.set_ylabel("genes",fontsize=6.6)
ax.set_title(f"d   genome-wide control: asymmetry index of all {len(AI):,} genes detected in \u2265 2% of LP.Meso",loc="left",fontsize=7.6); ax.set_xlabel("asymmetry index (L\u2212R)/(L+R)",fontsize=7)
fig.text(.006,.975,"Is DLL1 or NOTCH1 left\u2013right asymmetric in CS8 lateral plate mesoderm?",fontsize=10.6)
fig.text(.006,.955,"\n".join(textwrap.fill(
 f"CS8 (obj7), 39Type, curation-kept, LP.Meso only ({int(m.sum()):,} cells). Horizontal axis of a\u2013c is LR\u2032 = LR \u2212 midline(AP), where the midline is a LOWESS fit through the axial chain (Node, Notochord, Prechordal plate, PS); identical limits in every panel. "
 f"'L' = LR\u2032 < 0 is the sample's \u2212LR side; WHICH SIDE IS ANATOMICAL LEFT IS NOT KNOWN. Grey band = excluded \u00b1{MID:.0f} \u00b5m; dotted lines = the mirrored window \u00b1{wmax:.0f} \u00b5m (the narrower side's 98th-percentile extent) within which the two sides are compared, so truncation of the +LR side by the sample edge cannot bias it. "
 "a, b: each LP.Meso cell at its LR\u2032 and AP; red = \u2265 1 count (the diagonal streaks are the 15-\u00b5m physical sections: subtracting a curved midline shears each section into a short diagonal). c: fraction of cells detected per 15-\u00b5m bin (one physical section), band = bootstrap 95% CI; NODAL, LEFTY2, PITX2 (left-sided in normal embryos) and DAND5 (right-biased in mouse) are the reference. AI = (meanL \u2212 meanR)/(meanL + meanR) on CP10K; z = AI relative to median/MAD over all genes in d, which absorbs section-batch and depth effects shared by every gene; p = permutation (500 shuffles of side within AP \u00d7 DV bins). Red text = |z| \u2265 2 AND p < 0.01.",175).split("\n")),fontsize=5.8,color="#8A8A8A",linespacing=1.45,va="top")
for e in ["png","pdf","svg"]: fig.savefig(f"cs8_lpm_lr_asymmetry.{e}",**({"dpi":175} if e=="png" else {}),bbox_inches="tight")
fig.canvas.draw(); r_=fig.canvas.get_renderer()
tx=[(t,t.get_window_extent(r_)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
tk={t for a_ in fig.axes for t in a_.get_xticklabels()+a_.get_yticklabels()}
print("overlaps:",[(a.get_text()[:14],b.get_text()[:14]) for i_,(a,ba) in enumerate(tx) for b,bb in tx[i_+1:] if ba.overlaps(bb) and not (a in tk or b in tk)][:6])
print(T[["gene","nL","nR","detL_pct","detR_pct","asym_index","z_vs_genome","perm_p"]].to_string(index=False))
