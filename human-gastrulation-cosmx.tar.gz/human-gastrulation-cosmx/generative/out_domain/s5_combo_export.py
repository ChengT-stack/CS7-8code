# combo variant, held-out human self-supervision diagnostics, export of the selected variant in the final_v2 file layout.
import time, shutil, sys as _s
BEST = _s.argv[1] if len(_s.argv) > 1 else 'V1a_lamh3.0'
exec(open('out_domain/dom.py').read()); print("STARTED", flush=True)
src = open('out_domain/s2_grid.py').read(); exec(src[src.index('def run_variant'):src.index('_t=time.time()')])   # run_variant()
P2 = dict(center_nominal=True, w_end_m=0.0)
run_variant('V12_lamh3.0_lamadv0.1', lambda s: finetune(s, **dict(P2, lam_h=3.0, lam_adv=0.1)), dict(P2, lam_h=3.0, lam_adv=0.1))
# ---------------- held-out human diagnostics (held-out CS7 clones; targets = held-out HuE#1 cells / held-out CS8 descendants)
def load_variant(name, s):
    if name == 'final_v2': return load_v2(s)
    kw = json.loads(json.load(open(OD + f'results/{name}.json'))['finetune_kwargs'] or '{}')
    if not kw.get('use_frac', True) and 'lam_h' not in kw:   # continued-training control still uses NetF
        pass
    n = NetF.from_net(load_v2(s)); n.load_state_dict(torch.load(OD + f'weights/{name}_seed{s}.pt', map_location=dev)); n.env = kw.get('envelope', False); n.eval(); return n
HOi = torch.as_tensor(np.where(~HTR)[0], device=dev); U7HO = torch.as_tensor(u7[~tr7], device=dev); U8HO = torch.as_tensor(u8[~tr8], device=dev)
@torch.no_grad()
def diag(net, s, cap=3000):
    g = torch.Generator(device=dev); out = {}
    torch.manual_seed(500 + s); k = HOi[torch.randperm(len(HOi), device=dev)[:cap]]; HA = Zt[HIA[k]]; HB = HBP[k]
    fr_ok = isinstance(net, NetF)
    def G(A, B, D, f): return gnet(net, A, B, D, HUM_TA, f)[0]
    g.manual_seed(1); out['ED_t1_vs_CS8_heldout'] = float(L.energy(G(HA, HB, HUM_D, 1.0), Zt[U8HO], gen=g)) if fr_ok else np.nan
    g.manual_seed(1); out['ED_t0_vs_CS7_heldout'] = float(L.energy(G(HA, HB, HUM_D, 0.0), Zt[U7HO], gen=g)) if fr_ok else np.nan
    hm = G(HA, HB, HUM_D, 0.5); qc = G(HA, hm, HUM_D / 2, 0.5)
    g.manual_seed(1); out['ED_consistency_t025'] = float(L.energy(qc, G(HA, HB, HUM_D, 0.25), gen=g)) if fr_ok else np.nan
    g.manual_seed(1); out['ED_t05_vs_HuE_heldout'] = float(L.energy(hm, torch.cat([Zt[U7HO], Zt[U8HO]]), gen=g))
    out['ED_consistency_vs_linear_t025'] = float(L.energy(qc, 0.75 * HA + 0.25 * HB, gen=g))
    return out
rows = []
for name in ['final_v2', 'C_P0_continued', 'C_P2_frac', 'V1a_lamh0.1', 'V1a_lamh0.3', 'V1a_lamh1.0', 'V1a_lamh3.0', 'V1b_env_lamh0.3', 'V1b_env_lamh1.0', 'V1b_env_lamh3.0',
             'V2_lamadv0.1', 'V2_lamadv0.3', 'V2_lamadv1.0', 'V2_lamadv3.0', 'V12_lamh3.0_lamadv0.1']:
    for s in range(5): rows.append(dict(variant=name, seed=s, **diag(load_variant(name, s), s)))
D_ = pd.DataFrame(rows); D_.to_csv(OD + 'human_heldout_diagnostics_perseed.csv', index=False)
Dm = D_.groupby('variant', sort=False).mean(numeric_only=True).drop(columns='seed'); Dm.to_csv(OD + 'human_heldout_diagnostics.csv'); print(Dm.round(4).to_string(), flush=True)
# ---------------- export selected variant in the final_v2 layout + full decoding (final_v2 decoder)
EX = OD + f'best_{BEST}/'; os.makedirs(EX, exist_ok=True)
R_ = json.load(open(OD + f'results/{BEST}.json')); kw = json.loads(R_['finetune_kwargs'])
json.dump(dict(config=CFG | {'rep': 'concat_harm_mz'}, architecture='NetF (lib7.Net + time-fraction input column; initialised from final_v2 seed s)', envelope=kw.get('envelope', False),
               finetune_kwargs=kw, finetune_steps=1500, finetune_lr=CFG['lr'] * 0.3, generation_fraction=0.5, human_D_days=0.375, human_t_CS7=7.25,
               selection='out_domain/SELECTION_RULE.txt', loader='out_domain/dom.py: NetF.from_net(load_v2(s)); load_state_dict(generator_seed{s}.pt)'), open(EX + 'generator_config.json', 'w'), indent=1, default=str)
for s in range(5): shutil.copy(OD + f'weights/{BEST}_seed{s}.pt', EX + f'generator_seed{s}.pt')
H = np.load(OD + f'latent/{BEST}_human_t05_latent.npz'); np.savez_compressed(EX + 'human_t05_latent.npz', gen=H['gen'], linear=H['linear'], h_a=H['h_a'])
import anndata as ad
m, gi, lib05 = decoder(); Dd = torch.load('ai/step7/final_v2/decoder.pt', map_location='cpu', weights_only=False)
@torch.no_grad()
def dec(z, ll, seed):
    torch.manual_seed(seed); out = []
    for k in range(0, len(z), 2048):
        mu, th = m(torch.tensor(z[k:k + 2048], device=dev, dtype=torch.float32), torch.tensor(np.log(ll[k:k + 2048]), device=dev, dtype=torch.float32))
        r = torch.distributions.Gamma(th.expand_as(mu), th.expand_as(mu) / mu.clamp_min(1e-8)).sample(); out.append(sp.csr_matrix(torch.poisson(r).cpu().numpy()))
    return sp.vstack(out).tocsr()
D5 = [dec(H['gen'][s], lib05, 10 + s) for s in range(5)]
for s, Dm_ in enumerate(D5): sp.save_npz(EX + f't05_gen_seed{s}_decoded.npz', Dm_)
for f in ['C7_decoded.npz', 'C8_decoded.npz', 't05_linear_decoded.npz']: shutil.copy('ai/step7/final_v2/' + f, EX + f)
o = T05.copy(); o['library'] = lib05; T = ad.AnnData(D5[0].astype(np.float32), obs=o, var=pd.DataFrame(index=Dd['genes'])); T.obsm['X_rep'] = H['gen'][0]
T.uns['description'] = f'AI-generated CS7-CS8 t=0.5 pseudo-cells, domain-adapted generator {BEST} (final_v2 fine-tuned with human GG-OT self-supervised endpoint + temporal-consistency terms); decoded with the final_v2 NB-MLP decoder (seed 0 sample).'
T.write_h5ad(EX + 't05_AI_generated_counts.h5ad'); print('exported', EX, T.shape, flush=True)
print('DONE', flush=True)
