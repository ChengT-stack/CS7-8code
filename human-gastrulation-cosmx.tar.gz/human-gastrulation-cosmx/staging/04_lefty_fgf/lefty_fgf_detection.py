# staging/04_lefty_fgf/lefty_fgf_detection.py
# Source: lineage export s8e_csv_code.py as executed in transcript 13ab33ab (messages 197, 210)
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Detection of LEFTY1, LEFTY2, NOG, SHH, FGF8, FGF17 (and TDGF1) per column of Figure 6F.
# Part 1: standalone script s8e_csv_code.py (platform lineage export of the code behind SuppFig8E_LEFTY_detection.csv),
# with the gene list and output path changed exactly as in transcript 13ab33ab message 197 (where it was verified to reproduce
# the original five rows). Part 2: transcript 13ab33ab message 210 (adds CosMx CS8 Rostral.Meso, drops the CosMx max column).
import os; os.makedirs('out/s8e_merge', exist_ok=True)

# ---- part 1
import pandas as pd
import numpy as np
import scipy.io
import scipy.sparse as sp
import glob
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm

for f in glob.glob(os.environ.get('HGC_FONTS', 'fonts') + '/arial*/*.ttf') + glob.glob(os.environ.get('HGC_FONTS', 'fonts') + '/*.ttf'):
    fm.fontManager.addfont(f)
mpl.rcParams.update({"font.family": "Arial" if glob.glob(os.environ.get('HGC_FONTS', 'fonts') + '/*') else "sans-serif",
                     "font.size": 6, "pdf.fonttype": 42, "svg.fonttype": "none"})

D = (str(HGC_DATA) + '/dataprep/export/')

hm = pd.read_csv((str(HGC_DATA) + '/human_mouse_candidates_table.csv')).set_index('Unnamed: 0')
mos = pd.read_csv((str(HGC_DATA) + '/mouse_organiser_stage.csv')).set_index('stage')

tyc_path = (str(HGC_DATA) + '/Tyser_CS7_signalling_detection_by_cluster.csv')
tyc = pd.read_csv(tyc_path, index_col=0)

genes_csv = pd.read_csv(D + 'genes.csv')
gcol = genes_csv.columns[0]
gl = list(genes_csv[gcol])

genesD = ['TDGF1', 'LEFTY1', 'LEFTY2', 'NOG', 'SHH', 'FGF17', 'FGF8']

pt = {}
for st in ['CS7', 'CS8']:
    M = scipy.io.mmread(D + f'{st}_counts.mtx').tocsr()
    lab = pd.read_csv(D + f'{st}_cells.csv').label_short.values
    B = pd.DataFrame({g: (np.asarray(M[gl.index(g)].todense()).ravel() > 0) for g in genesD if g in gl})
    B['grp'] = lab
    pt[st] = B.groupby('grp').mean() * 100

cols = []
vals = []
for c, l, grp in [('CosMx CS7 node', 'CosMx node', 'Human CS7'),
                   ('CosMx CS7 APS', 'CosMx APS', 'Human CS7'),
                   ('Stereo CS7 node', 'Stereo-seq node', 'Human CS7'),
                   ('Stereo CS7 PS', 'Stereo-seq PS', 'Human CS7')]:
    vals.append([hm.loc[g, c] for g in genesD])
    cols.append((grp, l))

for cl, l in [('Axial Mesoderm', 'Smart-seq2 axial'), ('Emergent Mesoderm', 'Smart-seq2 EmM')]:
    vals.append([tyc.loc[cl, g] for g in genesD])
    cols.append(('Human CS7', l))

for c, l in [('CosMx CS8 node', 'CosMx node'), ('Stereo CS8 node', 'Stereo-seq node')]:
    vals.append([hm.loc[g, c] for g in genesD])
    cols.append(('Human CS8', l))

for s in ['E7.0', 'E7.25', 'E7.5', 'E7.75']:
    vals.append([mos.loc[s, 'org_' + g.capitalize()] for g in genesD])
    cols.append(('Mouse organiser', s))

vals.append([hm.loc[g, 'Mouse APS E7.0–7.25'] for g in genesD])
cols.append(('Mouse APS', 'E7.0–7.25'))

vals.append([np.nan if g == 'TDGF1' else max(pt['CS7'][g].max(), pt['CS8'][g].max()) for g in genesD])
cols.append(('CosMx control', 'max of any type'))

E = pd.DataFrame(np.array(vals, float).T, index=genesD,
                 columns=pd.MultiIndex.from_tuples(cols, names=['group', 'column']))

E2 = E.copy()
E2.loc['LEFTY2', ('Human CS7', 'Smart-seq2 EmM')] = 100 * 147 / 185
E2.columns = pd.MultiIndex.from_tuples(
    [(g, {'Stereo-seq node': 'Stereo node', 'Stereo-seq PS': 'Stereo PS',
           'Smart-seq2 axial': 'SS2 axial', 'Smart-seq2 EmM': 'SS2 EmM',
           'max of any type': 'CosMx max', 'E7.0–7.25': 'APS E7.0–7.25'}.get(c, c))
     for g, c in E2.columns],
    names=['group', 'column']
)

E2.to_csv('out/s8e_merge/SuppFig8E_LEFTY_FGF_detection.csv')

# ---- part 2 (13ab33ab message 210)
ns = {'pt': pt, 'D': D}   # as created by exec() in message 197
import pandas as pd, numpy as np, scipy.io, os
rows = ['TDGF1', 'LEFTY1', 'LEFTY2', 'NOG', 'SHH', 'FGF8', 'FGF17']
if 'ns' in globals() and 'pt' in ns:
    pt8 = ns['pt']['CS8']; n8 = pd.read_csv(ns['D'] + 'CS8_cells.csv').label_short.value_counts()
else:
    D = (str(HGC_DATA) + '/dataprep/export/')
    gl = list(pd.read_csv(D + 'genes.csv').iloc[:, 0]); M = scipy.io.mmread(D + 'CS8_counts.mtx').tocsr(); lab = pd.read_csv(D + 'CS8_cells.csv').label_short.values
    B = pd.DataFrame({g: (np.asarray(M[gl.index(g)].todense()).ravel() > 0) for g in rows if g in gl}); B['grp'] = lab
    pt8 = B.groupby('grp').mean() * 100; n8 = pd.Series(lab).value_counts()
f = "out/s8e_merge/SuppFig8E_LEFTY_FGF_detection.csv"
E = pd.read_csv(f, header=[0, 1], index_col=0).loc[rows]
assert ('CosMx control', 'CosMx max') in E.columns and ('Human CS8', 'CosMx Rostral.Meso') not in E.columns
E.to_csv("out/s8e_merge/SuppFig8E_LEFTY_FGF_detection_v1_withCosMxMax.csv")
new = pd.Series({g: (pt8.loc['Rostral.Meso', g] if g in pt8.columns else np.nan) for g in rows})
cols = [c for c in E.columns if c != ('CosMx control', 'CosMx max')]
i = cols.index(('Human CS8', 'CosMx node')) + 1
E2 = E[cols].copy(); E2.insert(i, ('Human CS8', 'CosMx Rostral.Meso'), new)
E2.columns = pd.MultiIndex.from_tuples(list(E2.columns), names=['group', 'column'])
# node column must be unchanged by the edit
assert np.allclose(E2[('Human CS8', 'CosMx node')].values, E[('Human CS8', 'CosMx node')].values, equal_nan=True) and E2.shape == (7, 14)
E2.to_csv(f)
print("CS8 Rostral.Meso n =", int(n8['Rostral.Meso']), "| Node n =", int(n8['Node']))
print(E2['Human CS8'].round(1).to_string())
print("columns:", [c for _, c in E2.columns])
