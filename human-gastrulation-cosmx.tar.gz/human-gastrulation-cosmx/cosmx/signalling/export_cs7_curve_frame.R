# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: execution log, session 0b0712b4 R kernel (scrna) cell 1703 (producing cell of
#     cs7_proj_curves_export.csv, artifact 54d489d3)
# sha256 of original: f1d81d9090e18e1987be5a8c88b66580060c1a0c92f846d837f2480d3fa72023
# Methods paragraphs: P352, P358, P361
# Produces: handoff/cs7_proj_curves_export.csv (all HuE#1 cells: 39Type label, curated_kept, x/y/z µm, nCount,
#     10 marker genes) — input of the CS7 landmark frame in seven_pop_trends.py / seven_pop_genes.py
# Edits/notes: object path -> HGC_DATA; handoff folder created.
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

dir.create('handoff', showWarnings = FALSE)   # added: intermediate folder inside HGC_OUT
o <- readRDS(file.path(DATA, "obj6_obj7_merged_curated_final.rds"))
md <- o@meta.data
i6 <- md$source_object == "obj6"
cat("obj6 (CS7) cells:", sum(i6), "\n")
G10 <- c("TBXT","TBX6","MESP1","KDR","MIXL1","EOMES","CER1","CHRD","NOTO","FOXJ1")
cn <- LayerData(o[["RNA"]], "counts")
cat("genes present:", sum(G10 %in% rownames(cn)), "of", length(G10),
    "| MISSING:", paste(setdiff(G10, rownames(cn)), collapse=", "), "\n")
sub <- cn[G10, i6, drop=FALSE]
lab <- as.character(md$`39Type`[i6])
TG <- c("Epiblast (EPI)","Anterior primitive streak (APS)","Primitive streak (PS)","Node")
cat("\ntarget labels found:", paste(intersect(TG, unique(lab)), collapse=" | "), "\n")
cat("MISSING:", paste(setdiff(TG, unique(lab)), collapse=" | "), "\n")
cat("\nlabels containing EPI/Epi:", paste(grep("EPI|Epibl", unique(lab), value=TRUE), collapse=" | "), "\n")
out <- data.frame(cell=md$cell[i6], label=lab, curated_kept=as.logical(md$curated_kept[i6]),
                  x=md$x_um[i6], y=md$y_um[i6], z=md$z_um[i6], nCount=md$nCount[i6],
                  stringsAsFactors=FALSE)
out <- cbind(out, t(as.matrix(sub)))
write.csv(out, "handoff/cs7_proj_curves_export.csv", row.names=FALSE)
cat("\nexported", nrow(out), "x", ncol(out), "|", round(file.size("handoff/cs7_proj_curves_export.csv")/1e6,1), "MB\n")
cat("counts for the four targets (kept only):\n")
for (t_ in TG) cat(sprintf("  %-32s %5d\n", t_, sum(lab==t_ & md$curated_kept[i6])))
rm(o, cn, sub); invisible(gc())
