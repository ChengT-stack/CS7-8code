"""Figure 7B-D source tables from the default AIGG-OT coupling (CS7 group -> CS8 composition, prior-consistent share,
CS8 ancestor table, t = 0.5 positions of matched CS7 cells).
Reconstructed verbatim from session 824ef1ce messages [1689] (row masks), [1691] (ancestor, composition, t = 0.5) and
[1697] (subset: the lines writing the matching-derived tables). In the original kernel, Mg came from
FIN['GG-OT + table'] = GM.match(E7, E8, S7, S8, g7, g8, a, b, trans, space="gated", prior=True) ([1455]); here it is read
from the coupling written by 05_run_aiggot.py ref (identical call; 31,127 pairs, 1,473 unmatched CS8 cells, see PROVENANCE.md).
Ancestor rule: the CS7 partner with the largest coupling value; all values are 1, so argmax = first-listed (lowest index).
Outputs (cwd): ggot_table_cs7group_to_cs8_composition.csv, ggot_table_cs7group_to_cs8_summary.csv,
ggot_table_t05_pseudocells.csv, ggot_table_cs8_ancestor.csv, ggot_cs7_coords.csv
"""
import os, sys, json
import numpy as np, pandas as pd, anndata as ad, scipy.sparse as sp
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
OUTC = os.path.join(os.environ.get('HGC_OUT', 'results'), 'aiggot', 'couplings') + '/'   # output of 05_run_aiggot.py
B = DATA + "/cs7_cs8_matching/"
A = ad.read_h5ad(B + "dataprep/embedding/cs7_cs8_germlayers_harmony.h5ad", backed="r")             # [glue] as in [1322]
obs = A.obs.copy(); g_all = obs.label_short.astype(str).to_numpy(); emb = obs.embryo.astype(str).to_numpy()  # [glue] as in [1328]
i7 = np.where(emb == "CS7")[0]; i8 = np.where(emb == "CS8")[0]                                      # [glue] as in [1332]
SPC = ["AP_arc_frac", "LR_frac", "DV_gap_units"]; Sp = obs[SPC].to_numpy(float)                      # [glue] as in [1334]
S7, S8 = Sp[i7], Sp[i8]; g7, g8 = g_all[i7], g_all[i8]                                              # [glue] as in [1334]
TT = json.load(open(B + "matching/transition_table_used.json")); trans = {tuple(k.split("->")): v for k, v in TT.items()}  # [glue] as in [1336]

# ---- [1689] (subset)
m7=(A.obs.stage=='CS7').values; m8=(A.obs.stage=='CS8').values

# ---- [1691] ancestors, composition, t = 0.5 states
import scipy.sparse as sp
Mg=sp.load_npz(OUTC+'M_ref.npz').tocsr().astype(float)   # [glue] = FIN['GG-OT + table']['M'] of [1455]; same call as 05_run_aiggot.py 'ref'
z7=pd.read_csv(B+'dataprep/frames/CS7_frames.csv',usecols=['cell','z_weight']).set_index('cell').reindex(A.obs_names[m7]).z_weight.values
z8=pd.read_csv(B+'dataprep/frames/CS8_frames.csv',usecols=['cell','z_weight']).set_index('cell').reindex(A.obs_names[m8]).z_weight.values
assert np.isfinite(z7).all() and np.isfinite(z8).all()
Mc=Mg.tocsc(); col_has=np.diff(Mc.indptr)>0
anc=np.full(len(g8),-1); 
for j in np.where(col_has)[0]:
    s,e=Mc.indptr[j],Mc.indptr[j+1]; anc[j]=Mc.indices[s+np.argmax(Mc.data[s:e])]
cls_anc=np.array([trans.get((g7[i],g8[j]),'penalised') if i>=0 else 'unmatched' for j,i in enumerate(anc)])
G7L=["EPI","ECT","PS","APS","Node","DE","AVE","VE1","VE2"]
ORD8=["EPI","aECT","pECT","NNE","CLE","PS","Nas.Meso","Para.Meso","Rostral.Meso","LP.Meso","Heart.Meso","Node","Notochord","PrP","DE","VE1","VE2"]
ok=anc>=0
COMPg=pd.crosstab(pd.Series(g7[anc[ok]],name='cs7_group'),pd.Series(g8[ok],name='cs8')).reindex(index=G7L,columns=ORD8,fill_value=0)
# t0.5 per CS7 cell with descendants
rows=np.diff(Mg.indptr)>0
W=Mg.multiply(1/np.maximum(np.asarray(Mg.sum(1)).ravel(),1e-12)[:,None]).tocsr()
cent=W@S8  # weighted centroid of descendants in normalised coords (AP_arc_frac, LR_frac, DV_gap_units)
T5=pd.DataFrame(dict(cs7_idx=np.where(rows)[0]))
T5['cs7_group']=g7[T5.cs7_idx]
T5['AP']=0.5*(S7[T5.cs7_idx,0]+cent[T5.cs7_idx,0]); T5['LR']=0.5*(S7[T5.cs7_idx,1]+cent[T5.cs7_idx,1]); T5['DV']=0.5*(S7[T5.cs7_idx,2]+cent[T5.cs7_idx,2])
# dominant CS8 group by summed weight
coo=Mg.tocoo(); dfw=pd.DataFrame(dict(i=coo.row,h=g8[coo.col],w=coo.data)).groupby(['i','h']).w.sum().reset_index()
dom=dfw.sort_values('w',ascending=False).drop_duplicates('i').set_index('i').h
T5['dom_cs8_group']=dom.reindex(T5.cs7_idx).values
SUMg=[]
for g in G7L:
    sel=ok&(g7[np.where(ok,anc,0)]==g)
    SUMg.append(dict(group=g,n_cs7=int((g7==g).sum()),n_cs8_matched=int(sel.sum()),expected_share=float((cls_anc[sel]!='penalised').mean()),
                     AP7=float(np.median(S7[g7==g,0])),AP8=float(np.median(S8[sel,0])),AP5=float(np.median(T5.AP[T5.cs7_group==g])),n_t05=int((T5.cs7_group==g).sum())))
SUMg=pd.DataFrame(SUMg).set_index('group')
print(ok.sum(), (~ok).sum(), len(T5)); print(SUMg.round(3).to_string())
print((COMPg.div(COMPg.sum(1),axis=0)*100).round(0).astype(int).to_string())

# ---- [1697] (subset) matching-derived tables
# matching-derived tables for b/c/e
COMPg.to_csv('ggot_table_cs7group_to_cs8_composition.csv'); SUMg.to_csv('ggot_table_cs7group_to_cs8_summary.csv')
T5['X']=T5.AP*1138.282; T5['Y']=T5.LR*497.494; T5.to_csv('ggot_table_t05_pseudocells.csv',index=False)
D8=pd.DataFrame(dict(cs8_idx=np.arange(len(g8)),cs8_group=g8,ancestor_idx=anc,ancestor_group=np.where(ok,g7[np.where(ok,anc,0)],'unmatched'),cls=cls_anc,
                     X=S8[:,0]*1434.0,Y=S8[:,1]*550.0)); D8.to_csv('ggot_table_cs8_ancestor.csv',index=False)
D7=pd.DataFrame(dict(cs7_group=g7,X=S7[:,0]*904.0,Y=S7[:,1]*450.0)); D7.to_csv('ggot_cs7_coords.csv',index=False)
