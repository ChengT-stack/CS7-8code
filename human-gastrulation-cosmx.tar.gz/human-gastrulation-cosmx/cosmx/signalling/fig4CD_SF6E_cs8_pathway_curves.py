# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: execution log, session 5113e657 python kernel (flowmatch) cells 1944-1953 (producing cell 1953 of
#     SuppFig7C/7D/7F .ai = final Figure 4C, 4D and Supplementary Figure 6E; artifacts aed4792d, 16e8b4a2,
#     22cadd85; source data SuppFig7_CDF_source_data.xlsx 6c6b1642)
# sha256 of original: 747233afa94631c1a5ab49f799f6d81655d882ed1d6cd74bd8dd9e601965e8cc
# Methods paragraphs: P352 (CS8 landmark frame), P358, P361
# Produces: SuppFig7C_CS8_ecto_node_PS_pathways.* (= Figure 4C), SuppFig7D_CS8_axial_mesoderm_pathways.* (=
#     Figure 4D), SuppFig7F_CS8_endoderm_pathway_genes.* (= Supplementary Figure 6E),
#     SuppFig7_CDF_source_data.xlsx
# Edits/notes: reconstructed verbatim from the kernel log (cells concatenated in order; print-only diagnostics
#     kept). Export paths -> HGC_DATA; the final 4-line copy of outputs to a G: drive folder removed. Needs
#     cs8_meta_final.csv from export_cs8_meta.R. File names follow the pre-v8 numbering (SuppFig7 C/D/F).
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

# --- kernel cell 1944 ---
import pandas as pd, numpy as np
mt=pd.read_csv('cs8_meta_final.csv'); print(mt.shape); print(mt.curated_kept.value_counts(dropna=False).to_dict()); print(mt.disc_main_body.value_counts(dropna=False).to_dict())
e8=pd.read_csv((str(DATA) + "/dataprep/export/CS8_cells.csv"))
j=e8.merge(mt,on='cell',how='left',suffixes=('','_m')); print('export cells found in rds',j.Type39_curated.notna().mean())
print('coord equal', np.allclose(j.x_um,j.x_um_m), np.allclose(j.y_um,j.y_um_m), np.allclose(j.z_um,j.z_um_m))
print((j.label==j.Type39_curated).mean()); print(j.loc[j.label!=j.Type39_curated,['label','Type39_curated']].value_counts().head(8))
print(mt[mt.curated_kept==True].Type39_curated.value_counts().head(40).to_dict())

# --- kernel cell 1945 ---
K=mt[mt.curated_kept==True].reset_index(drop=True)
X8=K[['x_um','y_um','z_um']].to_numpy(float); l8=K.Type39_curated.to_numpy(); f8=np.isfinite(X8).all(1)
ANT8=["Anterior ectoderm (aECT)","Rostral mesoderm (Rostral.Meso)","Prechordal plate"]; POST8=["Primitive streak (PS)","Caudal lateral epiblast (CLE)","Nascent mesoderm (Nas.Meso)"]
EXE8=["Trophoblast","Distal yolk sac endoderm (Dist.ys.Endo)","Proximal yolk sac endoderm (Prox.ys.Endo)","Parietal yolk sac endoderm (Pari.Endo)","Yolk sac mesoderm (ys.Meso)","Chorion-allantois mesenchyme (ChA.Mes)"]
an8,po8,ex8=np.isin(l8,ANT8)&f8,np.isin(l8,POST8)&f8,np.isin(l8,EXE8)&f8
iap=int(np.argmax([abs((np.median(X8[po8,j])-np.median(X8[an8,j]))/np.std(X8[f8,j])) for j in range(2)])); iml=2; iview=[j for j in range(3) if j not in (iap,iml)][0]
sa8=1.0 if np.median(X8[po8,iap])>np.median(X8[an8,iap]) else -1.0; sv8=1.0 if np.median(X8[ex8,iview])>np.median(X8[~ex8&f8,iview]) else -1.0
med8=np.nanmedian(np.c_[sa8*X8[:,iap],X8[:,iml],sv8*X8[:,iview]],axis=0)
print('AP axis', 'xyz'[iap], sa8, 'origin', med8.round(1))
apall=(np.c_[sa8*X8[:,iap],X8[:,iml],sv8*X8[:,iview]]-med8)[:,0]
SETS={'C':(["Anterior ectoderm (aECT)","Posterior ectoderm (pECT)","Epiblast (EPI)","Node","Primitive streak (PS)"],[1,99]),
      'D':(["Prechordal plate","Rostral mesoderm (Rostral.Meso)","Notochord","Heart mesoderm","Node","Primitive streak (PS)"],[0.2,99.8]),
      'F':(["Definitive endoderm (DE)","Visceral endoderm 1 (VE1)","Visceral endoderm 2 (VE2)"],[1,99])}
for p,(W,bp) in SETS.items():
    m=np.isin(l8,W)&f8; lo,hi=np.percentile(apall[m],bp); u=m&(apall>=lo)&(apall<=hi)
    print(p,'band',round(lo),round(hi),{w.split('(')[-1].strip(')'):int((u&(l8==w)).sum()) for w in W})

# --- kernel cell 1946 ---
import scipy.sparse as ssp, scipy.io as sio, statsmodels.api as sm, json, os, shutil
from statsmodels.stats.multitest import multipletests
import matplotlib as mpl; mpl.use('Agg'); import matplotlib.pyplot as plt
EXP=(str(DATA) + "/dataprep/export/")
Mx=ssp.csr_matrix(sio.mmread(EXP+'CS8_counts.mtx'))   # genes x cells
G_all=pd.read_csv(EXP+'genes.csv').gene.to_numpy(); V=set(G_all)
col_of=dict(zip(e8.cell,range(len(e8))))
inV=lambda g:[x for x in g if x in V]
PW={"WNT":["AXIN2","LEF1","SP5","NKD1","NOTUM","RNF43","ZNRF3","DKK1","TCF7","CDX1"],"NODAL":["LEFTY1","LEFTY2","PITX2","NODAL"],"NOTCH":["HES1","HEY1","HEY2","HES5","NRARP","HEYL"],
    "SHH":["PTCH1","PTCH2","GLI1","HHIP"],"FGF":["SPRY1","SPRY2","SPRY4","DUSP6","ETV4","ETV5","FGFBP1","IL17RD"]}
LIG={"NODAL":["NODAL","GDF1","GDF3","TDGF1","CFC1","LEFTY1"],"NOTCH":["DLL1","DLL3","DLL4","JAG1","JAG2"],"SHH":["SHH","IHH","DHH"]}
INH={"WNT":["DKK1","DKK2","DKK3","DKK4","SFRP1","SFRP2","SFRP4","SFRP5","WIF1","SOST","SOSTDC1","NOTUM","RNF43","ZNRF3","APCDD1","KREMEN1","NKD1","AXIN2","CTBP1"],
     "NODAL":["LEFTY1","LEFTY2","CER1","DAND5","FST","SMAD7","TMEFF1","BMP4"],"NOTCH":["NUMB","NUMBL","DTX1","DTX4","NRARP","LFNG","MFNG","RFNG","DLK1","DLK2","HES1","DLL3"],
     "SHH":["PTCH1","PTCH2","HHIP","SUFU","GLI3","PTCHD1","KIF7"],"FGF":["SPRY1","SPRY2","SPRY3","SPRY4","SPRED1","SPRED2","SPRED3","DUSP6","IL17RD","FGFBP1","FLRT3"]}
WNT_ALL=["WNT"+s for s in ["1","2","2B","3","3A","4","5A","5B","6","7A","7B","8A","8B","9A","9B","10A","10B","11","16"]]
RSPO=[f"RSPO{i}" for i in range(1,5)]; FGF_SEC=[f"FGF{i}" for i in list(range(1,11))+list(range(16,24))]
REC={"WNT":[f"FZD{i}" for i in range(1,11)]+["LRP5","LRP6","RYK","ROR1","ROR2","LGR4","LGR5","LGR6","KREMEN1","KREMEN2"],"NODAL":["ACVR1B","ACVR1C","ACVR2A","ACVR2B","TDGF1","CFC1"],
     "NOTCH":[f"NOTCH{i}" for i in range(1,5)],"SHH":["PTCH1","PTCH2","SMO","GAS1","CDON","BOC","LRP2"],"FGF":["FGFR1","FGFR2","FGFR3","FGFR4","FGFRL1","KL","KLB"]}
PWS=["WNT","NODAL","NOTCH","SHH","FGF"]; KINDS=["ligand","receptor","target","inhibitor"]
CATlig={pw:inV(LIG[pw]) for pw in ["NODAL","NOTCH","SHH"]}; CATlig["WNT"]=inV(WNT_ALL+RSPO); CATlig["FGF"]=inV(FGF_SEC)
CONCISE={"WNT_ligand":["WNT1","WNT2B","WNT3","WNT3A","WNT4","WNT5A","WNT5B","WNT6","WNT7A","WNT7B","WNT8A","WNT9A","WNT11","RSPO1","RSPO2","RSPO3"],
 "FGF_ligand":["FGF2","FGF3","FGF4","FGF5","FGF8","FGF9","FGF10","FGF17","FGF18"],"WNT_receptor":["FZD1","FZD2","FZD3","FZD4","FZD5","FZD6","FZD7","FZD8","FZD10","LRP5","LRP6"],
 "NODAL_receptor":["ACVR1B","ACVR2A","ACVR2B","SMAD2","SMAD3"],"NOTCH_receptor":["NOTCH1","NOTCH2","NOTCH3","NOTCH4"],"SHH_receptor":["PTCH1","SMO","GAS1","CDON","BOC"],
 "FGF_receptor":["FGFR1","FGFR2","FGFR3","FGFR4"],"NODAL_ligand":["NODAL","GDF3","CFC1","LEFTY1"],"NOTCH_ligand":["DLL1","DLL3","DLL4","JAG1","JAG2"],"SHH_ligand":["SHH","IHH","DHH"]}
CONCISE={k:inV(v) for k,v in CONCISE.items()}
COMPLETE={f"{pw}_ligand":CATlig[pw] for pw in PWS}; COMPLETE.update({f"{pw}_receptor":inV(REC[pw]) for pw in PWS})
for pw in PWS:
    CONCISE[f"{pw}_target"]=inV(PW[pw]); COMPLETE[f"{pw}_target"]=inV(PW[pw]); CONCISE[f"{pw}_inhibitor"]=inV(INH[pw]); COMPLETE[f"{pw}_inhibitor"]=inV(INH[pw])
diff={k for k in COMPLETE if sorted(COMPLETE[k])!=sorted(CONCISE[k])}
def kernel_curve(ap,val,n_grid=80,min_h=20):
    h=max(min_h,0.06*(ap.max()-ap.min())); grid=np.linspace(ap.min(),ap.max(),n_grid)
    w=np.exp(-0.5*((grid[:,None]-ap[None,:])/h)**2); ws=w.sum(1); mean=(w*val[None,:]).sum(1)/ws
    eff=ws**2/(w**2).sum(1); var=(w*(val[None,:]-mean[:,None])**2).sum(1)/ws
    return grid,mean,np.sqrt(var/np.maximum(eff,1))
def prep(W,bp):
    m=np.isin(l8,W)&f8; lo,hi=np.percentile(apall[m],bp); u=m&(apall>=lo)&(apall<=hi)
    cells_=K.cell.values[u]; idx=np.array([col_of[c] for c in cells_]); M=Mx[:,idx].tocsr()
    dep=np.asarray(M.sum(0)).ravel().astype(float)
    return dict(M=M,ap=apall[u],lab=l8[u],dep=dep,ld=np.log(dep),lo=lo,hi=hi,det=np.asarray((M>0).sum(1)).ravel())
P={k:prep(*v) for k,v in SETS.items()}
gidx_all={g:i for i,g in enumerate(G_all)}
print({k:(v['M'].shape, round(v['lo']),round(v['hi'])) for k,v in P.items()}); print('sets differing concise/complete:',sorted(diff))

# --- kernel cell 1947 ---
import matplotlib.patheffects as pe
mpl.rcParams.update({"pdf.fonttype":42,"svg.fonttype":"none","font.family":"DejaVu Sans","axes.linewidth":0.4})
KCOL={"ligand":"#1F6FB2","receptor":"#7B4FA3","target":"#C2401A","inhibitor":"#2E8B57"}
KT={"ligand":"ligands","receptor":"receptors","target":"targets","inhibitor":"inhibitors"}
P5=["#1F6FB2","#C2401A","#2E8B57","#7B4FA3","#B08A00"]
FS=dict(title=5.0,gene=4.4,bold=4.8,tick=4.2,axis=5.4,strip=4.6,letter=8)
SHORT=lambda t: t.split('(')[-1].rstrip(')') if '(' in t else {'Prechordal plate':'PrP','Heart mesoderm':'Heart.Meso'}.get(t,t)
PCOL={'Anterior ectoderm (aECT)':'#3B6BB5','Posterior ectoderm (pECT)':'#24A9C9','Epiblast (EPI)':'#9DB4D6','Node':'#B08A00','Primitive streak (PS)':'#E4572E',
      'Prechordal plate':'#1F78B4','Rostral mesoderm (Rostral.Meso)':'#8FA8BF','Notochord':'#2E8B57','Heart mesoderm':'#C2185B',
      'Definitive endoderm (DE)':'#E4572E','Visceral endoderm 1 (VE1)':'#F28E2B','Visceral endoderm 2 (VE2)':'#C9A227'}
def strip(fig,R,W,rect,stagger=True):
    ax=fig.add_axes(rect); xs=np.linspace(R['lo'],R['hi'],300); ordn=sorted(W,key=lambda t:np.median(R['ap'][R['lab']==t]))
    for n_,t in enumerate(ordn):
        a_=R['ap'][R['lab']==t]; d=np.exp(-0.5*((xs[:,None]-a_[None,:])/26)**2).sum(1); d/=d.max()
        ax.fill_between(xs,0,d,color=PCOL[t],alpha=.40,lw=0); ax.plot(xs,d,color=PCOL[t],lw=.5)
        ax.text(np.clip(np.median(a_),R['lo']+0.07*(R['hi']-R['lo']),R['hi']-0.07*(R['hi']-R['lo'])),1.04+(0.2*(n_%2) if stagger else 0),f"{SHORT(t)} ({len(a_):,})",ha='center',fontsize=FS['strip'],color=PCOL[t])
    ax.set_xlim(R['lo'],R['hi']); ax.set_ylim(0,1.55); ax.set_yticks([]); ax.spines[['top','right','left']].set_visible(False)
    ax.tick_params(labelsize=FS['tick'],length=1.5,width=.4,pad=1); ax.set_ylabel('cell\ndensity',fontsize=FS['tick'],labelpad=1)
    return ax
def grid_axes(fig,L0,R0,GT,GB,hs=0.022,ws=0.042):
    gh=(GT-GB-hs*4)/5; gw=(R0-L0-ws*3)/4; return {(pw,kd):fig.add_axes([L0+j*(gw+ws),GT-gh-i*(gh+hs),gw,gh]) for i,pw in enumerate(PWS) for j,kd in enumerate(KINDS)}
def finish(fig,AX,R,L0,R0,GB,GT,ylab,letter):
    for (pw,kd),ax in AX.items():
        ax.set_xlim(R['lo'],R['hi']); ax.spines[['top','right']].set_visible(False)
        ax.tick_params(labelsize=FS['tick'],length=1.5,width=.4,pad=1); ax.yaxis.set_major_locator(mpl.ticker.MaxNLocator(3))
        ax.xaxis.set_major_locator(mpl.ticker.MultipleLocator(300))
        if pw!=PWS[-1]: ax.tick_params(labelbottom=False)
    fig.text((L0+R0)/2,0.012,'anterior \u2192 posterior (\u00b5m)',ha='center',fontsize=FS['axis'])
    fig.text(0.006,(GB+GT)/2,ylab,rotation=90,va='center',fontsize=FS['axis'])
    fig.text(0.004,0.995,letter,fontsize=FS['letter'],fontweight='bold',va='top')
# ---------- C / D: set mean per gene ----------
def set_panel(key,letter,fname):
    R=P[key]; W=SETS[key][0]; keep=R['det']>=10; use_g={g for g in G_all[keep]}
    SETC={}
    for ver,DEF in [("concise",CONCISE),("complete",COMPLETE)]:
        for k in DEF:
            gs=[g for g in DEF[k] if g in use_g]; ii=[gidx_all[g] for g in gs]
            v=np.asarray(R['M'][ii,:].sum(0)).ravel()/R['dep']*1e4
            be=np.polyfit(R['ld'],v,1); res=v-(be[0]*R['ld']+be[1])+v.mean()
            SETC[(ver,k)]=kernel_curve(R['ap'],res/max(len(gs),1))+(len(gs),)
    fig=plt.figure(figsize=(3.6,3.05)); L0,R0=0.085,0.99; T0=0.885
    strip(fig,R,W,[L0,T0,R0-L0,0.07]); GT=T0-0.035; GB=0.07
    AX=grid_axes(fig,L0,R0,GT,GB)
    for (pw,kd),ax in AX.items():
        k=f"{pw}_{kd}"; gc,gm,gs_,n=SETC[("complete",k)]
        ax.fill_between(gc,gm-gs_,gm+gs_,color=KCOL[kd],alpha=.18,lw=0); ax.plot(gc,gm,color=KCOL[kd],lw=.8,zorder=5)
        if k in diff: c2,m2,_,_=SETC[("concise",k)]; ax.plot(c2,m2,color="#888888",lw=.5,ls=(0,(3,1.8)),zorder=4)
        ax.text(.03,.98,f"{pw} {KT[kd]}",transform=ax.transAxes,fontsize=FS['title'],va='top',color=KCOL[kd]); ax.margins(y=0.22)
    finish(fig,AX,R,L0,R0,GB,GT,'set mean per gene (CP10K)',letter)
    fig.savefig(fname+'.pdf'); fig.savefig(fname+'.png',dpi=600); plt.close(fig)
    rows=[pd.DataFrame(dict(version=ver,set=k,n_genes=SETC[(ver,k)][3],AP_um=np.round(SETC[(ver,k)][0],2),set_mean_per_gene_CP10K=np.round(SETC[(ver,k)][1],4),sem=np.round(SETC[(ver,k)][2],4))) for (ver,k) in SETC]
    return pd.concat(rows,ignore_index=True)
CVc=set_panel('C','C','SuppFig7C_CS8_ecto_node_PS_pathways'); CVd=set_panel('D','D','SuppFig7D_CS8_axial_mesoderm_pathways')
print(CVc.shape,CVd.shape)

# --- kernel cell 1948 ---
def strip(fig,R,W,rect,stagger=True):
    ax=fig.add_axes(rect); xs=np.linspace(R['lo'],R['hi'],300); ordn=sorted(W,key=lambda t:np.median(R['ap'][R['lab']==t]))
    for t in ordn:
        a_=R['ap'][R['lab']==t]; d=np.exp(-0.5*((xs[:,None]-a_[None,:])/26)**2).sum(1); d/=d.max()
        ax.fill_between(xs,0,d,color=PCOL[t],alpha=.40,lw=0); ax.plot(xs,d,color=PCOL[t],lw=.5)
    ax.set_xlim(R['lo'],R['hi']); ax.set_ylim(0,1.1); ax.set_yticks([]); ax.spines[['top','right','left']].set_visible(False)
    ax.tick_params(labelsize=FS['tick'],length=1.5,width=.4,pad=1); ax.set_ylabel('cell\ndensity',fontsize=FS['tick'],labelpad=1)
    # legend row above the strip, ordered anterior -> posterior
    h=[mpl.patches.Patch(facecolor=PCOL[t],alpha=.6,edgecolor=PCOL[t],lw=.5,label=f"{SHORT(t)} ({(R['lab']==t).sum():,})") for t in ordn]
    ax.legend(handles=h,ncol=len(h),loc='lower center',bbox_to_anchor=(0.5,1.0),frameon=False,fontsize=FS['strip'],handlelength=0.9,handletextpad=0.3,columnspacing=0.8,borderaxespad=0.1)
    return ax
WS=0.065; L0g=0.095
def grid_axes(fig,L0,R0,GT,GB,hs=0.022,ws=WS):
    gh=(GT-GB-hs*4)/5; gw=(R0-L0-ws*3)/4; return {(pw,kd):fig.add_axes([L0+j*(gw+ws),GT-gh-i*(gh+hs),gw,gh]) for i,pw in enumerate(PWS) for j,kd in enumerate(KINDS)}
def set_panel(key,letter,fname):
    R=P[key]; W=SETS[key][0]; keep=R['det']>=10; use_g=set(G_all[keep]); SETC={}
    for ver,DEF in [("concise",CONCISE),("complete",COMPLETE)]:
        for k in DEF:
            gs=[g for g in DEF[k] if g in use_g]; ii=[gidx_all[g] for g in gs]
            v=np.asarray(R['M'][ii,:].sum(0)).ravel()/R['dep']*1e4; be=np.polyfit(R['ld'],v,1); res=v-(be[0]*R['ld']+be[1])+v.mean()
            SETC[(ver,k)]=kernel_curve(R['ap'],res/max(len(gs),1))+(len(gs),)
    fig=plt.figure(figsize=(3.6,3.15)); L0,R0=L0g,0.99; T0=0.865
    strip(fig,R,W,[L0,T0,R0-L0,0.06]); GT=T0-0.035; GB=0.07; AX=grid_axes(fig,L0,R0,GT,GB)
    for (pw,kd),ax in AX.items():
        k=f"{pw}_{kd}"; gc,gm,gs_,n=SETC[("complete",k)]
        ax.fill_between(gc,gm-gs_,gm+gs_,color=KCOL[kd],alpha=.18,lw=0); ax.plot(gc,gm,color=KCOL[kd],lw=.8,zorder=5)
        if k in diff: c2,m2,_,_=SETC[("concise",k)]; ax.plot(c2,m2,color="#888888",lw=.5,ls=(0,(3,1.8)),zorder=4)
        ax.text(.03,.98,f"{pw} {KT[kd]}",transform=ax.transAxes,fontsize=FS['title'],va='top',color=KCOL[kd]); ax.margins(y=0.30)
    finish(fig,AX,R,L0,R0,GB,GT,'set mean per gene (CP10K)',letter)
    fig.savefig(fname+'.pdf'); fig.savefig(fname+'.png',dpi=600); plt.close(fig)
    return pd.concat([pd.DataFrame(dict(version=ver,set=k,n_genes=SETC[(ver,k)][3],AP_um=np.round(SETC[(ver,k)][0],2),set_mean_per_gene_CP10K=np.round(SETC[(ver,k)][1],4),sem=np.round(SETC[(ver,k)][2],4))) for (ver,k) in SETC],ignore_index=True)
CVc=set_panel('C','C','SuppFig7C_CS8_ecto_node_PS_pathways'); CVd=set_panel('D','D','SuppFig7D_CS8_axial_mesoderm_pathways')
# ---------- F: per-gene curves in DE/VE1/VE2 ----------
R=P['F']; W=SETS['F'][0]; ap_,ld_,dep_,lab_=R['ap'],R['ld'],R['dep'],R['lab']
POPE=np.column_stack([(lab_==t).astype(float) for t in W[1:]])
cp=lambda g: np.asarray(R['M'][gidx_all[g],:].todense()).ravel()/dep_*1e4
allg=sorted({g for k in COMPLETE for g in COMPLETE[k]})
rows=[]
for g in allg:
    c=cp(g)
    if 100*(c>0).mean()<2: continue
    fit=sm.OLS(np.log1p(c),np.column_stack([np.ones(len(c)),ap_/100,ld_,POPE])).fit(); rows.append((g,fit.params[1],fit.bse[1],fit.pvalues[1],100*(c>0).mean()))
PG=pd.DataFrame(rows,columns=['gene','slope_per_100um','se','p','det_pct']); PG['FDR']=multipletests(PG.p,method='fdr_bh')[1]
FDRw=dict(zip(PG.gene,PG.FDR)); SLw=dict(zip(PG.gene,PG.slope_per_100um))
def resid(v): b=np.polyfit(ld_,v,1); return v-(b[0]*ld_+b[1])+v.mean()
CUR={g:kernel_curve(ap_,resid(cp(g))) for g in allg}
SETM={k:kernel_curve(ap_,resid(sum(cp(g) for g in gs)/len(gs))) for k,gs in COMPLETE.items()}
print('genes tested',len(PG),'FDR<0.05',(PG.FDR<0.05).sum())

# --- kernel cell 1949 ---
def strip(fig,R,W,rect):
    ax=fig.add_axes(rect); xs=np.linspace(R['lo'],R['hi'],300); ordn=sorted(W,key=lambda t:np.median(R['ap'][R['lab']==t]))
    for t in ordn:
        a_=R['ap'][R['lab']==t]; d=np.exp(-0.5*((xs[:,None]-a_[None,:])/26)**2).sum(1); d/=d.max()
        ax.fill_between(xs,0,d,color=PCOL[t],alpha=.40,lw=0); ax.plot(xs,d,color=PCOL[t],lw=.5)
    ax.set_xlim(R['lo'],R['hi']); ax.set_ylim(0,1.1); ax.set_yticks([]); ax.spines[['top','right','left']].set_visible(False)
    ax.tick_params(labelsize=FS['tick'],length=1.5,width=.4,pad=1); ax.set_ylabel('cell\ndensity',fontsize=FS['tick'],labelpad=1)
    h=[mpl.patches.Patch(facecolor=PCOL[t],alpha=.6,edgecolor=PCOL[t],lw=.5,label=f"{SHORT(t)} ({(R['lab']==t).sum():,})") for t in ordn]
    ax.legend(handles=h,ncol=len(h) if len(h)<=5 else 3,loc='lower center',bbox_to_anchor=(0.5,1.0),frameon=False,fontsize=FS['strip'],handlelength=0.9,handletextpad=0.3,columnspacing=0.8,borderaxespad=0.1,labelspacing=0.2)
    return ax
def finish(fig,AX,R,L0,R0,GB,GT,ylab,letter):
    step=400 if (R['hi']-R['lo'])>1050 else 300
    for (pw,kd),ax in AX.items():
        ax.set_xlim(R['lo'],R['hi']); ax.spines[['top','right']].set_visible(False)
        ax.tick_params(labelsize=FS['tick'],length=1.5,width=.4,pad=1); ax.yaxis.set_major_locator(mpl.ticker.MaxNLocator(3))
        ax.xaxis.set_major_locator(mpl.ticker.MultipleLocator(step))
        if pw!=PWS[-1]: ax.tick_params(labelbottom=False)
    fig.text((L0+R0)/2,0.012,'anterior \u2192 posterior (\u00b5m)',ha='center',fontsize=FS['axis'])
    fig.text(0.006,(GB+GT)/2,ylab,rotation=90,va='center',fontsize=FS['axis'])
    fig.text(0.004,0.995,letter,fontsize=FS['letter'],fontweight='bold',va='top')
def top_of(fig_h_in,nrow): return 0.865 if nrow==1 else 0.835
CVc=set_panel('C','C','SuppFig7C_CS8_ecto_node_PS_pathways')
# D needs two legend rows: patch set_panel's T0 via wrapper
_orig_strip=strip
CVd=set_panel('D','D','SuppFig7D_CS8_axial_mesoderm_pathways')
# ----- F -----
def draw_F(fname):
    fig=plt.figure(figsize=(3.6,3.15)); L0,R0=L0g,0.99; T0=0.865
    strip(fig,R,W,[L0,T0,R0-L0,0.06]); GT=T0-0.035; GB=0.07; AX=grid_axes(fig,L0,R0,GT,GB)
    lab_rows=[]
    for (pw,kd),ax in AX.items():
        k=f"{pw}_{kd}"; gs=COMPLETE[k]
        top=sorted(gs,key=lambda g:-CUR[g][1].max())[:5]
        sig=sorted([g for g in gs if FDRw.get(g,1)<0.05],key=lambda g:-abs(SLw[g]))
        for g in sig[:2]:
            if g not in top: top=top[:-1]+[g] if len(top)==5 else top+[g]
        bold=set(sig[:1])
        for g in gs:
            if g not in top: ax.plot(CUR[g][0],CUR[g][1],color="#D2D2D2",lw=.3,zorder=1)
        gm=SETM[k]; ax.plot(gm[0],gm[1],color="#888888",lw=.5,ls=(0,(3,1.8)),zorder=2)
        labs=[]
        for c_,g in enumerate(top):
            gr,mn,se=CUR[g]; col=P5[c_]
            ax.fill_between(gr,mn-se,mn+se,color=col,alpha=.15,lw=0,zorder=3); ax.plot(gr,mn,color=col,lw=.6,zorder=4)
            ix=int(np.argmax(mn)); labs.append([gr[ix],mn[ix],g,col])
        ax.set_xlim(R['lo'],R['hi']); ax.margins(y=0.12); y0,y1=ax.get_ylim(); span=y1-y0; xr=R['hi']-R['lo']
        labs.sort(key=lambda r:-r[1]); placed=[]
        for r in labs:
            x=min(max(r[0],R['lo']+0.14*xr),R['hi']-0.12*xr); y=r[1]+0.06*span
            for _ in range(30):
                if all(abs(x-px)>0.26*xr or abs(y-py)>0.13*span for px,py in placed): break
                y-=0.13*span
            y=max(y,y0+0.04*span); placed.append((x,y)); b=r[2] in bold
            ax.text(x,y,r[2],color=r[3],fontsize=FS['bold'] if b else FS['gene'],fontstyle='italic',fontweight='bold' if b else 'normal',ha='center',va='bottom',zorder=6,
                    path_effects=[pe.withStroke(linewidth=1.0,foreground='white')])
            lab_rows.append(dict(set=k,gene=r[2],labelled=True,bold=b))
        ax.set_ylim(y0,y1+0.16*span)
        ax.text(.03,.98,f"{pw} {KT[kd]}",transform=ax.transAxes,fontsize=FS['title'],va='top',color=KCOL[kd])
    finish(fig,AX,R,L0,R0,GB,GT,'expression (CP10K)','F')
    fig.savefig(fname+'.pdf'); fig.savefig(fname+'.png',dpi=600); plt.close(fig)
    return pd.DataFrame(lab_rows)
LAB=draw_F('SuppFig7F_CS8_endoderm_pathway_genes')
print(LAB.groupby('set').gene.apply(list).head(20).to_dict())

# --- kernel cell 1950 ---
HS=0.045
def grid_axes(fig,L0,R0,GT,GB,hs=HS,ws=WS):
    gh=(GT-GB-hs*4)/5; gw=(R0-L0-ws*3)/4; return {(pw,kd):fig.add_axes([L0+j*(gw+ws),GT-gh-i*(gh+hs),gw,gh]) for i,pw in enumerate(PWS) for j,kd in enumerate(KINDS)}
def title(ax,pw,kd): ax.set_title(f"{pw} {KT[kd]}",loc='left',fontsize=FS['title'],color=KCOL[kd],pad=1.2)
def set_panel(key,letter,fname):
    R=P[key]; W=SETS[key][0]; keep=R['det']>=10; use_g=set(G_all[keep]); SETC={}
    for ver,DEF in [("concise",CONCISE),("complete",COMPLETE)]:
        for k in DEF:
            gs=[g for g in DEF[k] if g in use_g]; ii=[gidx_all[g] for g in gs]
            v=np.asarray(R['M'][ii,:].sum(0)).ravel()/R['dep']*1e4; be=np.polyfit(R['ld'],v,1); res=v-(be[0]*R['ld']+be[1])+v.mean()
            SETC[(ver,k)]=kernel_curve(R['ap'],res/max(len(gs),1))+(len(gs),)
    nleg=2 if len(W)>5 else 1
    fig=plt.figure(figsize=(3.6,3.25)); L0,R0=L0g,0.99; T0=0.865 if nleg==1 else 0.84
    strip(fig,R,W,[L0,T0,R0-L0,0.055]); GT=T0-0.06; GB=0.07; AX=grid_axes(fig,L0,R0,GT,GB)
    for (pw,kd),ax in AX.items():
        k=f"{pw}_{kd}"; gc,gm,gs_,n=SETC[("complete",k)]
        ax.fill_between(gc,gm-gs_,gm+gs_,color=KCOL[kd],alpha=.18,lw=0); ax.plot(gc,gm,color=KCOL[kd],lw=.8,zorder=5)
        if k in diff: c2,m2,_,_=SETC[("concise",k)]; ax.plot(c2,m2,color="#888888",lw=.5,ls=(0,(3,1.8)),zorder=4)
        title(ax,pw,kd); ax.margins(y=0.12)
    finish(fig,AX,R,L0,R0,GB,GT,'set mean per gene (CP10K)',letter)
    fig.savefig(fname+'.pdf'); fig.savefig(fname+'.png',dpi=600); plt.close(fig)
    return pd.concat([pd.DataFrame(dict(version=ver,set=k,n_genes=SETC[(ver,k)][3],AP_um=np.round(SETC[(ver,k)][0],2),set_mean_per_gene_CP10K=np.round(SETC[(ver,k)][1],4),sem=np.round(SETC[(ver,k)][2],4))) for (ver,k) in SETC],ignore_index=True)
CVc=set_panel('C','C','SuppFig7C_CS8_ecto_node_PS_pathways'); CVd=set_panel('D','D','SuppFig7D_CS8_axial_mesoderm_pathways')
def draw_F(fname):
    fig=plt.figure(figsize=(3.6,3.25)); L0,R0=L0g,0.99; T0=0.865
    strip(fig,R,W,[L0,T0,R0-L0,0.055]); GT=T0-0.06; GB=0.07; AX=grid_axes(fig,L0,R0,GT,GB)
    lab_rows=[]
    for (pw,kd),ax in AX.items():
        k=f"{pw}_{kd}"; gs=COMPLETE[k]
        top=sorted(gs,key=lambda g:-CUR[g][1].max())[:5]
        sig=sorted([g for g in gs if FDRw.get(g,1)<0.05],key=lambda g:-abs(SLw[g]))
        for g in sig[:2]:
            if g not in top: top=top[:-1]+[g] if len(top)==5 else top+[g]
        bold=set(sig[:1])
        for g in gs:
            if g not in top: ax.plot(CUR[g][0],CUR[g][1],color="#D2D2D2",lw=.3,zorder=1)
        gm=SETM[k]; ax.plot(gm[0],gm[1],color="#888888",lw=.5,ls=(0,(3,1.8)),zorder=2)
        labs=[]
        for c_,g in enumerate(top):
            gr,mn,se=CUR[g]; col=P5[c_]
            ax.fill_between(gr,mn-se,mn+se,color=col,alpha=.15,lw=0,zorder=3); ax.plot(gr,mn,color=col,lw=.6,zorder=4)
            ix=int(np.argmax(mn)); labs.append([gr[ix],mn[ix],g,col])
        ax.set_xlim(R['lo'],R['hi']); ax.margins(y=0.10); y0,y1=ax.get_ylim(); span=y1-y0; xr=R['hi']-R['lo']
        ax.set_ylim(y0,y1+0.30*span); ytop=y1+0.22*span
        labs.sort(key=lambda r:-r[1]); placed=[]
        for r in labs:
            x=min(max(r[0],R['lo']+0.16*xr),R['hi']-0.15*xr); y=min(r[1]+0.05*span,ytop)
            for _ in range(40):
                if all(abs(x-px)>0.30*xr or abs(y-py)>0.15*span for px,py in placed): break
                y-=0.15*span
            y=max(y,y0+0.03*span); placed.append((x,y)); b=r[2] in bold
            ax.text(x,y,r[2],color=r[3],fontsize=FS['bold'] if b else FS['gene'],fontstyle='italic',fontweight='bold' if b else 'normal',ha='center',va='bottom',zorder=6,
                    path_effects=[pe.withStroke(linewidth=1.0,foreground='white')])
            lab_rows.append(dict(set=k,gene=r[2],bold=b))
        title(ax,pw,kd)
    finish(fig,AX,R,L0,R0,GB,GT,'expression (CP10K)','F')
    fig.canvas.draw(); rr=fig.canvas.get_renderer()
    ov=[(a.get_text(),b.get_text()) for ax in AX.values() for i,(a,ba) in enumerate([(t,t.get_window_extent(rr)) for t in ax.texts]) for b,bb in [(t,t.get_window_extent(rr)) for t in ax.texts][i+1:] if ba.overlaps(bb)]
    print('gene-label overlaps',len(ov),ov[:10])
    fig.savefig(fname+'.pdf'); fig.savefig(fname+'.png',dpi=600); plt.close(fig)
    return pd.DataFrame(lab_rows)
LAB=draw_F('SuppFig7F_CS8_endoderm_pathway_genes')

# --- kernel cell 1951 ---
def draw_F(fname):
    fig=plt.figure(figsize=(3.6,3.35)); L0,R0=L0g,0.99; T0=0.87
    strip(fig,R,W,[L0,T0,R0-L0,0.05]); GT=T0-0.06; GB=0.07; AX=grid_axes(fig,L0,R0,GT,GB)
    rows=[]
    for (pw,kd),ax in AX.items():
        k=f"{pw}_{kd}"; gs=COMPLETE[k]
        top=sorted(gs,key=lambda g:-CUR[g][1].max())[:5]
        sig=sorted([g for g in gs if FDRw.get(g,1)<0.05],key=lambda g:-abs(SLw[g]))
        for g in sig[:2]:
            if g not in top: top=top[:-1]+[g] if len(top)==5 else top+[g]
        bold=set(sig[:1])
        for g in gs:
            if g not in top: ax.plot(CUR[g][0],CUR[g][1],color="#D2D2D2",lw=.3,zorder=1)
        gm=SETM[k]; ax.plot(gm[0],gm[1],color="#888888",lw=.5,ls=(0,(3,1.8)),zorder=2)
        lo_=min((CUR[g][1]-CUR[g][2]).min() for g in top); hi_=max((CUR[g][1]+CUR[g][2]).max() for g in top+[]) 
        for c_,g in enumerate(top):
            gr,mn,se=CUR[g]; col=P5[c_]
            ax.fill_between(gr,mn-se,mn+se,color=col,alpha=.15,lw=0,zorder=3); ax.plot(gr,mn,color=col,lw=.6,zorder=4)
        span=hi_-lo_; ax.set_ylim(min(0,lo_-0.05*span), hi_+0.75*span)
        # name list: two rows at the top of the panel
        pos=[(0.02,0.97),(0.36,0.97),(0.69,0.97),(0.02,0.80),(0.36,0.80)]
        for (x,y),c_,g in zip(pos,range(len(top)),top):
            b=g in bold
            ax.text(x,y,g,transform=ax.transAxes,color=P5[c_],fontsize=FS['bold'] if b else FS['gene'],fontstyle='italic',fontweight='bold' if b else 'normal',ha='left',va='top',zorder=6)
            rows.append(dict(set=k,gene=g,colour_rank=c_+1,bold=b,FDR_within=FDRw.get(g,np.nan),slope_per_100um=SLw.get(g,np.nan)))
        title(ax,pw,kd)
        ax.yaxis.set_major_locator(mpl.ticker.MaxNLocator(3))
    finish(fig,AX,R,L0,R0,GB,GT,'expression (CP10K)','F')
    for ax in AX.values():   # keep y ticks only within the data range
        lo_,hi_=ax.get_ylim(); ax.set_yticks([t for t in ax.get_yticks() if lo_<=t<=lo_+0.6*(hi_-lo_)])
    fig.canvas.draw(); rr=fig.canvas.get_renderer()
    ov=[(a.get_text(),b.get_text()) for ax in AX.values() for i,(a,ba) in enumerate([(t,t.get_window_extent(rr)) for t in ax.texts]) for b,bb in [(t,t.get_window_extent(rr)) for t in ax.texts][i+1:] if ba.overlaps(bb)]
    out=[t.get_text() for ax in AX.values() for t in ax.texts if t.get_window_extent(rr).x1>ax.get_window_extent(rr).x1+2]
    print('label overlaps',len(ov),ov[:6],'| outside panel',out)
    fig.savefig(fname+'.pdf'); fig.savefig(fname+'.png',dpi=600); plt.close(fig)
    return pd.DataFrame(rows)
LAB=draw_F('SuppFig7F_CS8_endoderm_pathway_genes')

# --- kernel cell 1952 ---
def flow_labels(fig,ax,items,rr,y0=0.98,dy=0.165,gap=0.035):
    x=0.02; y=y0; out=[]
    for g,col,b in items:
        t=ax.text(x,y,g,transform=ax.transAxes,color=col,fontsize=FS['bold'] if b else FS['gene'],fontstyle='italic',fontweight='bold' if b else 'normal',ha='left',va='top',zorder=6)
        bb=t.get_window_extent(rr); axbb=ax.get_window_extent(rr); w=bb.width/axbb.width
        if x>0.02 and x+w>1.0:
            x=0.02; y-=dy; t.set_position((x,y))
        x+=w+gap; out.append(t)
    return y
def draw_F(fname):
    fig=plt.figure(figsize=(3.6,3.35)); L0,R0=L0g,0.99; T0=0.87
    strip(fig,R,W,[L0,T0,R0-L0,0.05]); GT=T0-0.06; GB=0.07; AX=grid_axes(fig,L0,R0,GT,GB)
    fig.canvas.draw(); rr=fig.canvas.get_renderer(); rows=[]
    for (pw,kd),ax in AX.items():
        k=f"{pw}_{kd}"; gs=COMPLETE[k]
        top=sorted(gs,key=lambda g:-CUR[g][1].max())[:5]
        sig=sorted([g for g in gs if FDRw.get(g,1)<0.05],key=lambda g:-abs(SLw[g]))
        for g in sig[:2]:
            if g not in top: top=top[:-1]+[g] if len(top)==5 else top+[g]
        bold=set(sig[:1])
        for g in gs:
            if g not in top: ax.plot(CUR[g][0],CUR[g][1],color="#D2D2D2",lw=.3,zorder=1)
        gm=SETM[k]; ax.plot(gm[0],gm[1],color="#888888",lw=.5,ls=(0,(3,1.8)),zorder=2)
        for c_,g in enumerate(top):
            gr,mn,se=CUR[g]; ax.fill_between(gr,mn-se,mn+se,color=P5[c_],alpha=.15,lw=0,zorder=3); ax.plot(gr,mn,color=P5[c_],lw=.6,zorder=4)
            rows.append(dict(set=k,gene=g,colour_rank=c_+1,bold=g in bold,FDR_within=FDRw.get(g,np.nan),slope_per_100um=SLw.get(g,np.nan)))
        ylast=flow_labels(fig,ax,[(g,P5[c_],g in bold) for c_,g in enumerate(top)],rr)
        lo_=min((CUR[g][1]-CUR[g][2]).min() for g in top+[k_ for k_ in []]); hi_=max((CUR[g][1]+CUR[g][2]).max() for g in top)
        lo_=min(lo_,SETM[k][1].min()); span=hi_-lo_; frac=1-(0.98-ylast+0.20)   # data must stay below the label block
        ax.set_ylim(min(0,lo_-0.04*span), lo_+span/max(frac,0.35))
        title(ax,pw,kd)
    finish(fig,AX,R,L0,R0,GB,GT,'expression (CP10K)','F')
    for ax in AX.values():
        lo_,hi_=ax.get_ylim(); ax.yaxis.set_major_locator(mpl.ticker.MaxNLocator(3)); tk=[t for t in ax.get_yticks() if lo_<=t<=lo_+0.6*(hi_-lo_)]; ax.set_yticks(tk)
    fig.canvas.draw(); rr=fig.canvas.get_renderer()
    ov=[(a.get_text(),b.get_text()) for ax in AX.values() for i,(a,ba) in enumerate([(t,t.get_window_extent(rr)) for t in ax.texts]) for b,bb in [(t,t.get_window_extent(rr)) for t in ax.texts][i+1:] if ba.overlaps(bb)]
    out=[t.get_text() for ax in AX.values() for t in ax.texts if t.get_window_extent(rr).x1>ax.get_window_extent(rr).x1+1]
    print('label overlaps',len(ov),ov[:6],'| outside panel',out)
    fig.savefig(fname+'.pdf'); fig.savefig(fname+'.png',dpi=600); plt.close(fig)
    return pd.DataFrame(rows)
LAB=draw_F('SuppFig7F_CS8_endoderm_pathway_genes')

# --- kernel cell 1953 ---
import shutil, os
print(type(PG), getattr(PG,'shape',None), list(PG.columns)[:12] if hasattr(PG,'columns') else '')
names=['SuppFig7C_CS8_ecto_node_PS_pathways','SuppFig7D_CS8_axial_mesoderm_pathways','SuppFig7F_CS8_endoderm_pathway_genes']
for n in names: shutil.copy(n+'.pdf',n+'.ai')
# F per-gene curves
gF=sorted({g for k in COMPLETE for g in COMPLETE[k] if g in CUR})
CVf=pd.concat([pd.DataFrame(dict(gene=g,AP_um=np.round(CUR[g][0],2),CP10K_mean=np.round(CUR[g][1],4),sem=np.round(CUR[g][2],4))) for g in gF],ignore_index=True)
memb=pd.DataFrame([dict(set=k,gene=g) for k in COMPLETE for g in COMPLETE[k]])
with pd.ExcelWriter('SuppFig7_CDF_source_data.xlsx') as xw:
    pd.DataFrame({'item':['CS8 cells','C populations (band 1–99 pct AP)','D populations (band 0.2–99.8 pct AP)','F populations (band 1–99 pct AP)','smoothing','depth correction','F statistics','F labels'],
      'value':['obj7 curated (cs8_meta_final; Type39_curated)','aECT 3,886; pECT 596; EPI 3,883; Node 493; PS 1,588','Heart.Meso 252; PrP 588; Rostral.Meso 4,087; Notochord 508; Node 493; PS 1,666','DE 1,505; VE1 1,738; VE2 1,223',
               'Gaussian kernel, h = max(20 µm, 0.06 × AP span), 80-point grid, ±SEM','CP10K regressed on log library size; residual + mean',
               'OLS log1p(CP10K) ~ AP/100 µm + log depth + population; BH FDR within the tested genes (detection ≥2%)',
               'coloured = top-5 genes by peak expression (FDR<0.05 genes forced in, max 2); bold = strongest significant |slope| in the set; grey = other genes; dashed = set mean']}).to_excel(xw,'methods',index=False)
    CVc.to_excel(xw,'C_set_curves',index=False); CVd.to_excel(xw,'D_set_curves',index=False)
    CVf.to_excel(xw,'F_gene_curves',index=False); memb.to_excel(xw,'F_set_membership',index=False)
    (PG if isinstance(PG,pd.DataFrame) else pd.DataFrame(PG)).to_excel(xw,'F_AP_slopes_FDR',index=False); LAB.to_excel(xw,'F_labelled_genes',index=False)
# (copy of outputs to an external G: folder removed)
if isinstance(PG,pd.DataFrame): print((PG.filter(like='FDR').iloc[:,0]<0.05).sum(), len(PG))
