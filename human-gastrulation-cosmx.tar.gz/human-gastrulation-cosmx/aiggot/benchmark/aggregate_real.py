import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import os, sys, json, glob, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bench_common as bc
HERE = bc.HERE; R = os.path.join(HERE, "results", "real"); OUT = os.path.join(HERE, "out"); os.makedirs(OUT, exist_ok=True)
ART = os.path.join(DATA, "artifacts") + "/"
FREF = pd.read_csv(f"{ART}/flow_table_reference.csv", index_col=0)
D = bc.load_inputs(); trans = D["trans"]
rows = []
for d in sorted(glob.glob(os.path.join(R, "*"))):
    tag = os.path.basename(d)
    if tag.startswith("test_") or not os.path.exists(os.path.join(d, "meta.json")):
        continue
    m = json.load(open(os.path.join(d, "meta.json")))
    F = pd.read_csv(os.path.join(d, "flow_hard.csv"), index_col=0)
    pr, sr = bc.flow_corr(F, FREF)
    conc = bc.top_target_concentration(F)
    r = dict(tag=tag, method=m["method"], embedding=m["embedding"], shuffle=m.get("shuffle"), subsample=m.get("subsample"), cfg=json.dumps(m.get("cfg", {})),
             n7=m["n7"], n8=m["n8"], time_s=m["time_s"], peak_rss_gb=m["peak_rss_gb"], n8_unmatched=m["n8_unmatched"], n7_unmatched=m["n7_unmatched"],
             flow_pearson_vs_ref=pr, flow_spearman_vs_ref=sr, top_target_conc_mean=float(conc.mean()), top_target_conc_min=float(conc.min()), top_target_conc_max=float(conc.max()),
             frac_penalised=m["frac_penalised"], frac_indirect_or_penalised=m["frac_indirect_or_penalised"],
             converged=m.get("converged"), failed=m.get("failed"), eff_parents=m.get("eff_parents"))
    for k, v in (m.get("heldout_median") or {}).items():
        r["heldout_" + k] = v
    if os.path.exists(os.path.join(d, "flow_soft.csv")):
        Fs = pd.read_csv(os.path.join(d, "flow_soft.csv"), index_col=0)
        r["flow_pearson_vs_ref_soft"], r["flow_spearman_vs_ref_soft"] = bc.flow_corr(Fs, FREF)
        r["frac_penalised_soft"] = bc.class_fraction(Fs, trans, {"penalised"}); r["top_target_conc_mean_soft"] = float(bc.top_target_concentration(Fs).mean())
    rows.append(r)
runs = pd.DataFrame(rows)
runs.to_csv(os.path.join(OUT, "benchmark_real_all_runs.csv"), index=False)
# label-shuffle drop (starmatch only; label-free methods are unchanged by construction)
def conc_drop(method):
    a = runs[(runs.method == method) & (runs.embedding == "hs") & runs.shuffle.isna()]; b = runs[(runs.method == method) & (runs.embedding == "hs") & runs.shuffle.notna()]
    return float(a.top_target_conc_mean.iloc[0] - b.top_target_conc_mean.iloc[0]) if len(a) and len(b) else np.nan
# moscot grid (hhs) and best configs
grid = runs[(runs.method == "moscot") & (runs.embedding == "hhs")].copy()
grid.to_csv(os.path.join(OUT, "benchmark_real_moscot_grid.csv"), index=False)
best = {}
for fam in ["moscot_linear_full", "moscot_fgw_sub35", "moscot_fgw_full"]:
    g = grid[grid.tag.str.startswith(fam) & (grid.failed == False)]
    if len(g):
        best[fam + "_hard"] = g.loc[g.heldout_r_matched.idxmax(), "tag"]; best[fam + "_soft"] = g.loc[g.heldout_r_soft.idxmax(), "tag"]
json.dump(best, open(os.path.join(OUT, "moscot_best_configs.json"), "w"), indent=1)
# main table: one row per method
def pick(method, fam=None, emb="hs"):
    q = runs[(runs.method == method) & (runs.embedding == emb) & runs.shuffle.isna()]
    if fam: q = q[q.tag.str.startswith(fam)]
    return q
main = []
specs = [("starmatch (reference params)", "starmatch", None), ("starmatch, no lineage prior", "starmatch_nopen", None), ("kNN expression", "knn_expr", None), ("NN space", "nn_space", None)]
FAMLAB = {"moscot_linear_full": "moscot linear/Sinkhorn on [Harmony, space] (full scale)", "moscot_fgw_sub35": "moscot FGW (35% stratified subsample, DV clipped)", "moscot_fgw_full": "moscot FGW (full scale, DV clipped)"}
for fam in ["moscot_linear_full", "moscot_fgw_sub35", "moscot_fgw_full"]:
    if fam + "_hard" in best:
        specs.append((f"{FAMLAB[fam]}, best by held-out rho", "moscot", best[fam + "_hard"].replace("_hhs", "")))
for label, method, fam in specs:
    hs = pick(method, fam, "hs"); hhs = pick(method, fam, "hhs")
    if not len(hhs): continue
    src = hs.iloc[0] if len(hs) else hhs.iloc[0]
    row = dict(method=label, config=src.cfg, n7=src.n7, n8=src.n8, subsample=src.subsample, flow_table_embedding=("full Harmony" if len(hs) else "held-out Harmony (hs run missing)"),
               flow_pearson_vs_ref=src.flow_pearson_vs_ref, flow_spearman_vs_ref=src.flow_spearman_vs_ref, top_target_conc_mean=src.top_target_conc_mean,
               top_target_conc_range=f"{src.top_target_conc_min:.2f}-{src.top_target_conc_max:.2f}", frac_penalised=src.frac_penalised, frac_indirect_or_penalised=src.frac_indirect_or_penalised,
               n8_unmatched=src.n8_unmatched, n7_unmatched=src.n7_unmatched,
               heldout_r_matched=hhs.iloc[0].get("heldout_r_matched"), heldout_r_groupmean=hhs.iloc[0].get("heldout_r_groupmean"), heldout_r_shuffled_within_pair=hhs.iloc[0].get("heldout_r_shuffled_within_pair"),
               heldout_r_soft=hhs.iloc[0].get("heldout_r_soft"), label_shuffle_conc_drop=(conc_drop(method) if method == "starmatch" else ("n/a (labels not used)" if method != "starmatch_nopen" else "n/a (labels not used; uniform k_cand)")),
               time_s=src.time_s, peak_rss_gb=src.peak_rss_gb, converged=src.converged, eff_parents=src.eff_parents)
    if "flow_pearson_vs_ref_soft" in src and pd.notna(src.get("flow_pearson_vs_ref_soft")):
        row.update(flow_pearson_vs_ref_soft=src.flow_pearson_vs_ref_soft, frac_penalised_soft=src.frac_penalised_soft, top_target_conc_mean_soft=src.top_target_conc_mean_soft)
    main.append(row)
    # flow table per method
    srcdir = os.path.join(R, src.tag); short = {"starmatch": "starmatch", "starmatch_nopen": "starmatch_nopen", "knn_expr": "knn_expr", "nn_space": "nn_space"}.get(method, fam)
    pd.read_csv(os.path.join(srcdir, "flow_hard.csv"), index_col=0).astype(int).to_csv(os.path.join(OUT, f"flow_table_{short}.csv"))
    if os.path.exists(os.path.join(srcdir, "flow_soft.csv")):
        pd.read_csv(os.path.join(srcdir, "flow_soft.csv"), index_col=0).round(1).to_csv(os.path.join(OUT, f"flow_table_{short}_soft.csv"))
    if os.path.exists(os.path.join(srcdir, "flow_cell_transition_fwd.csv")):
        pd.read_csv(os.path.join(srcdir, "flow_cell_transition_fwd.csv"), index_col=0).round(4).to_csv(os.path.join(OUT, f"flow_table_{short}_cell_transition.csv"))
shuf = runs[runs.shuffle.notna()]
if len(shuf):
    pd.read_csv(os.path.join(R, shuf.iloc[0].tag, "flow_hard.csv"), index_col=0).astype(int).to_csv(os.path.join(OUT, "flow_table_starmatch_label_shuffle.csv"))
M = pd.DataFrame(main); M.to_csv(os.path.join(OUT, "benchmark_real.csv"), index=False)
pd.set_option("display.width", 250)
print(M[["method", "flow_pearson_vs_ref", "top_target_conc_mean", "frac_penalised", "heldout_r_matched", "heldout_r_groupmean", "heldout_r_shuffled_within_pair", "heldout_r_soft", "label_shuffle_conc_drop", "time_s", "peak_rss_gb"]].round(3).to_string(index=False))
print(grid[["tag", "converged", "failed", "eff_parents", "heldout_r_matched", "heldout_r_soft", "frac_penalised", "time_s", "peak_rss_gb"]].round(3).to_string(index=False))
print(best)
