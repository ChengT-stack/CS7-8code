# gastruloid/04_denovo_annotation/finalize_tables.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/reannotation_denovo/code/finalize_tables.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

import pandas as pd, numpy as np, json, os
D = pd.read_parquet('out/all_cells_annotated.parquet')
UNITS = ['Hamazaki','Budjan','Yamanaka','Makwana','Gribaudo','Olmsted','Minn','Heemskerk','Chen_polyA','Chen_probe','Liu','Pedroza','Weatherbee','Rossi','Veenvliet']
D['unit'] = pd.Categorical(D.unit, UNITS, ordered=True)
K = D[~D.excluded].copy()
os.makedirs('out/final', exist_ok=True)
# QC by sample
rows = []
for (u, g), s in D.groupby(['unit', 'group'], observed=True):
    lab = s.label.astype(str)
    rows.append(dict(unit=u, dataset=s.dataset.iloc[0], sample=g, n_after_doublet_removal=len(s),
        n_low_quality=int((lab.str.startswith('Low-quality')).sum()), n_doublet_like=int((lab.str.startswith('Doublet')).sum()),
        n_other_excluded=int((s.excluded & ~lab.str.startswith('Low-quality') & ~lab.str.startswith('Doublet')).sum()),
        n_annotated=int((~s.excluded).sum()), frac_annotated=round(float((~s.excluded).mean()), 4),
        median_umi_annotated=float(s.n_umi2[~s.excluded].median()), median_genes_annotated=float(s.n_genes2[~s.excluded].median()),
        median_pct_mt_annotated=round(float(s.pct_mt[~s.excluded].median()), 2)))
QC = pd.DataFrame(rows); QC.to_csv('out/final/qc_by_sample.csv', index=False)
# compositions
cnt = pd.crosstab([K.unit, K.group], K.label); cnt = cnt.loc[:, cnt.sum().sort_values(ascending=False).index]
cnt.to_csv('out/final/counts_label_by_sample.csv')
(cnt.div(cnt.sum(1), axis=0) * 100).round(2).to_csv('out/final/composition_label_by_sample_pct.csv')
cc = pd.crosstab([K.unit, K.group], K.cls); (cc.div(cc.sum(1), axis=0) * 100).round(2).to_csv('out/final/composition_class_by_sample_pct.csv')
# long format composition
L = cnt.stack().rename('n').reset_index(); L = L[L.n > 0]; L['pct'] = (L.n / L.groupby(['unit', 'group'], observed=True).n.transform('sum') * 100).round(2)
L = L.sort_values(['unit', 'group', 'n'], ascending=[True, True, False]); L.to_csv('out/final/composition_long.csv', index=False)
# v3 concordance
V = K[K.v3_type.notna() & K.v3_compatible.notna()].copy(); V['v3_compatible'] = V.v3_compatible.astype(bool)
con = V.groupby('unit', observed=True).agg(n_cells=('v3_compatible', 'size'), compatible_frac=('v3_compatible', 'mean')).round(4)
con.loc['ALL'] = [len(V), round(V.v3_compatible.mean(), 4)]; con.to_csv('out/final/concordance_denovo_vs_reference_by_dataset.csv')
con2 = V.groupby('v3_cls2', observed=True).agg(n_cells=('v3_compatible', 'size'), compatible_frac=('v3_compatible', 'mean')).round(4); con2.to_csv('out/final/concordance_by_reference_confidence_class.csv')
con3 = V.groupby('cls', observed=True).agg(n_cells=('v3_compatible', 'size'), compatible_frac=('v3_compatible', 'mean')).round(4).sort_values('n_cells', ascending=False); con3.to_csv('out/final/concordance_by_denovo_class.csv')
dis = V[~V.v3_compatible].groupby(['unit', 'label', 'cls', 'v3_type'], observed=True).size().rename('n_cells').reset_index().sort_values('n_cells', ascending=False)
tot = K.groupby(['unit', 'label'], observed=True).size().rename('n_label_in_unit').reset_index(); dis = dis.merge(tot, on=['unit', 'label']); dis['frac_of_label'] = (dis.n_cells / dis.n_label_in_unit).round(3)
dis = dis.rename(columns={'label': 'denovo_label', 'cls': 'denovo_class', 'v3_type': 'reference_based_type'}); dis.to_csv('out/final/discordance_denovo_vs_reference.csv', index=False)
# author crosstabs (all cells incl. excluded)
W = D[D.unit == 'Weatherbee']; pd.crosstab(W.label, W.cell_assignment2.fillna('not labelled')).to_csv('out/final/author_crosstab_Weatherbee.csv')
H = D[D.unit == 'Heemskerk']; pd.crosstab(H.label, H.author_annotation.fillna('not in author object')).to_csv('out/final/author_crosstab_Heemskerk.csv')
print(len(D), len(K), D.excluded.sum()); print(con.to_string()); print(con2.to_string()); print(dis.head(14).to_string()); print(QC.groupby('unit', observed=True)[['n_after_doublet_removal', 'n_low_quality', 'n_doublet_like', 'n_other_excluded', 'n_annotated']].sum().assign(f=lambda x: (x.n_annotated / x.n_after_doublet_removal).round(3)).to_string())
print(QC[['n_after_doublet_removal', 'n_low_quality', 'n_doublet_like', 'n_other_excluded', 'n_annotated']].sum().to_dict())
