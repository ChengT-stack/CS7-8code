"""Comparison of AIGG-OT with alternative matchings on the CosMx CS7/CS8 disc cells (Supplementary Figure 9G; Table S3
'Benchmark settings'): AIGG-OT with and without the transition prior, Euclidean OT (this script) and moscot FGW / moscot
linear / expression nearest neighbour / nearest neighbour in space (flow tables and unmatched counts produced by
benchmark/run_real.py + aggregate_real.py; see run_benchmark.sh).
Reconstructed verbatim from session 824ef1ce messages [1322], [1328], [1332], [1334] (subsets: data loading),
[1336] (transition table), [1338] (evalM), [1340] (decomp), [1374] (metrics), [1455] (subset: the three matchings used
here; the 'Euclidean + table' and streak-gate variants and the exploratory AP-order printout are not used in the paper),
[1685] (penalised flow from flow tables) and [1697] (subset: REALtab). Output: ggot_real_comparison_penalised.csv (cwd).
"""
import os, sys, json, time
import numpy as np, pandas as pd
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
B = DATA + "/cs7_cs8_matching/"             # [glue] B as defined in the session kernel
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lib"))   # [glue] ggot, ggot_match, starmatch
import ggot, ggot_match as GM                # [glue] imported in [1324]/[1388]
LO = ggot.LAYER_OF                            # [glue] as in [1340]

# ---- [1322] (subset)
import anndata as ad, scipy.sparse as ssp, importlib, sys, time
t0=time.time()
A=ad.read_h5ad(DATA + "/cs7_cs8_matching/dataprep/embedding/cs7_cs8_germlayers_harmony.h5ad")
# ---- [1328] (subset)
obs=A.obs.copy(); g_all=obs.label_short.astype(str).to_numpy(); emb=obs.embryo.astype(str).to_numpy()
# ---- [1332] (subset)
i7=np.where(emb=="CS7")[0]; i8=np.where(emb=="CS8")[0]
# ---- [1334] (subset)
import starmatch as SM  # workspace copy
importlib.reload(SM)
Hs=np.load(DATA + "/cs7_cs8_matching/matching/harmony_smoothed.npy"); assert Hs.shape[0]==A.shape[0]
SPC=["AP_arc_frac","LR_frac","DV_gap_units"]; Sp=obs[SPC].to_numpy(float)
E7,E8=Hs[i7],Hs[i8]; S7,S8=Sp[i7],Sp[i8]; g7,g8=g_all[i7],g_all[i8]
a=obs.z_weight.to_numpy(float)[i7]; b=obs.z_weight.to_numpy(float)[i8]

# ---- [1336] (subset)
TT=json.load(open(DATA + "/cs7_cs8_matching/matching/transition_table_used.json"))
trans={tuple(k.split("->")):v for k,v in TT.items()}
# ---- [1338] (subset)
def evalM(M):
    coo=M.tocoo(); cls=np.array([trans.get((g7[i],g8[j]),"penalised") for i,j in zip(coo.row,coo.col)])
    per={g:(cls[g7[coo.row]==g]!="penalised").mean() for g in ["EPI","ECT","PS","APS","Node","DE","AVE","VE1","VE2"]}
    return dict(edges=coo.nnz,pen=(cls=="penalised").mean(),**{f"ok_{g}":v for g,v in per.items()})

# ---- [1340] (subset)
LO=ggot.LAYER_OF
def decomp(M):
    coo=M.tocoo(); a7=g7[coo.row]; a8=g8[coo.col]
    cls=np.array([trans.get((x,y),"penalised") for x,y in zip(a7,a8)])
    cross=np.array([LO[x]!=LO[y] for x,y in zip(a7,a8)])
    pen=cls=="penalised"
    top=pd.Series([f"{x}->{y}" for x,y in zip(a7[pen],a8[pen])]).value_counts().head(8)
    return dict(pen_cross=(pen&cross).mean(),pen_same=(pen&~cross).mean(),cross_all=cross.mean()),top

# ---- [1374] (subset)
def metrics(M,heldout=False):
    d,_=decomp(M); e=evalM(M); inn=np.asarray(M.sum(0)).ravel(); out=np.asarray(M.sum(1)).ravel()
    res=dict(pen=e["pen"],pen_cross=d["pen_cross"],pen_same=d["pen_same"],n8_unm=int((inn==0).sum()),n7_unm=int((out==0).sum()),**{k:v for k,v in e.items() if k.startswith("ok_")})
    if heldout: r_,s_=heldout_rho(M); res.update(rho=r_,gain=r_-s_)
    return res

# ---- [1455] (subset)
FIN={}
t0=time.time()
FIN["Euclidean"]=GM.match(E7,E8,S7,S8,g7,g8,a,b,trans,space="euclid")
FIN["GG-OT"]=GM.match(E7,E8,S7,S8,g7,g8,a,b,trans,space="gated",return_graph=True)
FIN["GG-OT + table"]=GM.match(E7,E8,S7,S8,g7,g8,a,b,trans,space="gated",prior=True)
print(round(time.time()-t0))
FR=pd.DataFrame({k:metrics(v["M"]) for k,v in FIN.items()}).T

# ---- [1685]
def pen_from_flow(ft):
    ft=ft.copy(); tot=ft.values.sum(); pc=ps=0.0
    for a in ft.index:
        for b in ft.columns:
            v=ft.loc[a,b]
            if v<=0: continue
            if trans.get((a,b),"penalised")=="penalised":
                if LO.get(a)!=LO.get(b): pc+=v
                else: ps+=v
    return pc/tot, ps/tot
BM=B+'benchmark/'
FT={ 'starmatch':'flow_table_starmatch.csv','moscot FGW':'flow_table_moscot_fgw_sub35_eps0.05_tau0.99_clipdv5.csv',
     'moscot linear':'flow_table_moscot_linear_full_eps0.0001_tau0.95.csv','kNN expression':'flow_table_knn_expr.csv','NN space':'flow_table_nn_space.csv'}
REALD={}
for k,f in FT.items():
    ft=pd.read_csv(BM+f,index_col=0); REALD[k]=pen_from_flow(ft)
for k in ['Euclidean','GG-OT','GG-OT + table']:
    coo=FIN[k]['M'].tocoo(); ft=pd.crosstab(pd.Series(g7[coo.row],name='a'),pd.Series(g8[coo.col],name='b'))
    REALD[k]=pen_from_flow(ft)
print({k:(round(a,3),round(b,3),round(a+b,3)) for k,(a,b) in REALD.items()})
print(LO)
# ---- [1697] (subset)
REALtab=pd.DataFrame([dict(method=k,pen_cross=v[0],pen_same=v[1],pen=v[0]+v[1]) for k,v in REALD.items()])
REALtab['n7_unmatched']=REALtab.method.map({'Euclidean':FR.loc['Euclidean','n7_unm'] if 'n7_unm' in FR.columns else np.nan,'GG-OT':FR.loc['GG-OT','n7_unm'],'GG-OT + table':FR.loc['GG-OT + table','n7_unm']})
br=pd.read_csv(BM+'benchmark_real.csv')
mp={'starmatch':'starmatch (reference params)','kNN expression':'kNN expression','NN space':'NN space',
    'moscot FGW':'moscot FGW (35% stratified subsample, DV clipped), best by held-out rho','moscot linear':'moscot linear/Sinkhorn on [Harmony, space] (full scale), best by held-out rho'}
for k,v in mp.items():
    r=br[br.method==v].iloc[0]; REALtab.loc[REALtab.method==k,'n7_unmatched']=r.n7_unmatched; REALtab.loc[REALtab.method==k,'n7_total']=r.n7
REALtab['n7_total']=REALtab.n7_total.fillna(17663); REALtab['frac7_unmatched']=REALtab.n7_unmatched/REALtab.n7_total
REALtab.to_csv('ggot_real_comparison_penalised.csv',index=False); print(REALtab.round(3).to_string())
