import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)

import json, sys, numpy as np, pandas as pd, matplotlib as mpl
mpl.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Patch
from matplotlib import font_manager as fm
import glob
for f in glob.glob(os.path.join(os.environ.get('HGC_FONT_DIR', 'fonts'), 'LiberationSans*.ttf')): fm.fontManager.addfont(f)
plt.rcParams.update({'font.family':'Liberation Sans','pdf.fonttype':42,'axes.linewidth':0.5,'xtick.major.width':0.5,'ytick.major.width':0.5,
                     'xtick.major.size':2,'ytick.major.size':2,'xtick.labelsize':5.5,'ytick.labelsize':5.5,'mathtext.fontset':'custom',
                     'mathtext.rm':'Liberation Sans','mathtext.it':'Liberation Sans:italic'})
FS_T, FS_L, FS_S = 6.5, 6.0, 5.5          # titles/axis labels, legends/annotations, ticks/in-cell values
DARK, LIGHT = '#B2182B', '#E7A1A6'         # across germ layers / within a layer
B = DATA + '/cs7_cs8_matching/'
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lib")); import ggot
PW, PH = 558, 779.9                        # page in pt
fig = plt.figure(figsize=(PW/72, PH/72))
def ax_pt(x0, y0, w, h): return fig.add_axes([x0/PW, 1-(y0+h)/PH, w/PW, h/PH])
def letter(x, y, L): fig.text(x/PW, 1-y/PH, L, fontsize=9, fontweight='bold', va='top', ha='left')
fig.text(36/PW, 1-40/PH, 'Supplementary Figure 9', fontsize=10.1, fontweight='bold', va='baseline')

# ---------------- A–D robustness ----------------
S = pd.read_csv(DATA + '/figure7_supplementary/FigS2_sensitivity.csv').set_index('config')
G7 = ['EPI','ECT','PS','APS','Node','DE','AVE','VE1','VE2']; G7L = {'AVE':'ADE'}
REN = {'table penalty ×0.5':'prior penalty ×0.5','table penalty ×2':'prior penalty ×2'}
CAT = [('Layered geodesic',['layer-change cost h ×0.5','layer-change cost h ×2','reverse penalty +500 µm','reverse penalty +2,000 µm',
                            'mesoderm edge weight 0.5','mesoderm edge weight 1.0','grid 15 µm','grid 30 µm']),
       ('Transition prior',['table penalty ×0.5','table penalty ×2']),
       ('Transport and star rounding',['entropy ε 0.05','entropy ε 0.2','marginal relaxation 1','marginal relaxation 10',
                                       'max descendants 4','max descendants 6','unmatched cost 3','unmatched cost 6','star-size cost 0.5']),
       ('Candidate pairs',['candidates kept 20','candidates kept 60'])]
order = ['default'] + [c for _, cs in CAT for c in cs]; S = S.loc[order]
pos, k, heads = [], 0.0, []
for c in order:
    if any(c == cs[0] for _, cs in CAT): k += 1.0; heads.append(k - 0.85)
    pos.append(k); k += 1
pos = np.array(pos); ylim = (pos.max()+0.7, -0.7)
TOP, HGT = 92, 328
axa = ax_pt(150, TOP, 105, HGT); axb = ax_pt(272, TOP, 52, HGT); axc = ax_pt(338, TOP, 52, HGT); axd = ax_pt(404, TOP, 120, HGT)
pc, ps = 100*S.pen_cross.values, 100*(S.pen-S.pen_cross).values
axa.barh(pos, pc, color=DARK, height=0.72, lw=0); axa.barh(pos, ps, left=pc, color=LIGHT, height=0.72, lw=0)
for p_, v in zip(pos, 100*S.pen.values): axa.text(v+0.15, p_, f'{v:.1f}', va='center', fontsize=FS_S)
axa.set_xlim(0, 8.6); axa.set_xticks([0,2,4,6,8]); axa.set_xlabel('matches on penalised\ntransitions (%)', fontsize=FS_T)
axa.set_yticks(pos); axa.set_yticklabels(['default (Figure 6)' if c=='default' else REN.get(c,c) for c in order], fontsize=FS_S)
axa.get_yticklabels()[0].set_fontweight('bold')
for name, cs in CAT:
    p0 = pos[order.index(cs[0])]
    axa.text(-0.02, p0-0.95, name, transform=axa.get_yaxis_transform(), fontsize=FS_S, fontweight='bold', ha='right', va='center', color='0.25')
axa.legend(handles=[Patch(color=DARK,label='across germ layers'),Patch(color=LIGHT,label='within a layer')], fontsize=FS_S, frameon=False,
           loc='lower left', bbox_to_anchor=(0.0,1.0), handlelength=0.9, handletextpad=0.4, borderaxespad=0.2, labelspacing=0.25)
axb.barh(pos, S.n7_unmatched.values, color='#8C8C8C', height=0.72, lw=0)
for p_, v in zip(pos, S.n7_unmatched.values): axb.text(v+12, p_, f'{v}', va='center', fontsize=FS_S)
axb.set_xlim(0, 640); axb.set_xticks([0,250,500]); axb.set_xlabel('CS7 cells\nunmatched', fontsize=FS_T)
sa = 100*S.same_ancestor_group.values
axc.axvline(100, color='0.8', lw=0.5, zorder=0)
axc.scatter(sa, pos, s=7, color='#2166AC', zorder=3, lw=0)
for p_, v in zip(pos, sa): axc.text(v-0.9, p_, f'{v:.0f}', va='center', ha='right', fontsize=FS_S)
axc.set_xlim(84, 101.5); axc.set_xticks([85,90,95,100]); axc.set_xlabel('same CS7\nancestor group (%)', fontsize=FS_T)
TV = S[[f'TV_{g}' for g in G7]].to_numpy(float); cm = plt.cm.Reds
for i, p_ in enumerate(pos):
    for j in range(len(G7)):
        v = TV[i, j]; axd.add_patch(Rectangle((j-0.5, p_-0.42), 1, 0.84, color=cm(min(v/0.25,1)), lw=0))
        if v >= 0.05: axd.text(j, p_, f'{v:.2f}'.lstrip('0'), ha='center', va='center', fontsize=FS_S-0.3, color='w' if v > 0.15 else 'k')
axd.set_xlim(-0.5, len(G7)-0.5); axd.set_xticks(range(len(G7))); axd.set_xticklabels([G7L.get(g,g) for g in G7], fontsize=FS_S, rotation=90)
axd.xaxis.set_ticks_position('top'); axd.tick_params(length=0, pad=1.5)
axd.set_xlabel("change in CS8 composition of\neach CS7 group (TV distance)", fontsize=FS_T); axd.set_yticks([])
for s in axd.spines.values(): s.set_visible(False)
cax = ax_pt(530, TOP+20, 5, 80); cb = fig.colorbar(mpl.cm.ScalarMappable(cmap=cm, norm=mpl.colors.Normalize(0,0.25)), cax=cax, extend='max')
cb.set_ticks([0,0.1,0.2]); cb.ax.tick_params(labelsize=FS_S, width=0.5, length=2); cb.outline.set_linewidth(0.4)
cb.set_label('TV distance\n(values ≥ 0.05 printed)', fontsize=FS_S)
for a in [axa, axb, axc, axd]:
    a.set_ylim(*ylim)
    for h in heads: a.axhline(h+0.35, color='0.88', lw=0.5, zorder=0)
for a in [axa, axb, axc]:
    a.spines[['top','right']].set_visible(False); a.tick_params(axis='x', labelsize=FS_S)
for a in [axb, axc]: a.set_yticks([]); a.spines['left'].set_visible(False)
axa.tick_params(axis='y', length=0, pad=2)
for x, L in [(36,'A'),(262,'B'),(328,'C'),(394,'D')]: letter(x, 62, L)

# ---------------- E transition prior + observed flow ----------------
TT = json.load(open(B+'matching/transition_table_used.json')); trans = {tuple(k.split('->')): v for k, v in TT.items()}
ORDER8 = ['EPI','aECT','pECT','NNE','CLE','PS','Nas.Meso','Para.Meso','Rostral.Meso','LP.Meso','Heart.Meso','Node','Notochord','PrP','DE','VE1','VE2']
COMP = pd.read_csv(B+'figure/final_ggot/ggot_table_cs7group_to_cs8_composition.csv', index_col=0).reindex(index=G7, columns=ORDER8, fill_value=0)
FR = COMP.div(COMP.sum(1), axis=0)
CCOL = {'direct':'#2F5597','allowed':'#8FAADC','indirect':'#DAE3F3','penalised':'#FFFFFF'}; PENV = {'direct':0,'allowed':0.5,'indirect':1,'penalised':3}
LO = ggot.LAYER_OF
ETOP = 482
axe = ax_pt(92, ETOP, 255, 118)
for i, g in enumerate(G7):
    for j, h in enumerate(ORDER8):
        c = trans.get((g, h), 'penalised')
        axe.add_patch(Rectangle((j-0.5, i-0.5), 1, 1, facecolor=CCOL[c], edgecolor='#C8C8C8', lw=0.35))
        v = FR.loc[g, h]
        if v >= 0.005:
            axe.text(j, i, f'{100*v:.0f}' if v >= 0.01 else '<1', ha='center', va='center', fontsize=FS_S,
                     color='white' if c == 'direct' else (DARK if c == 'penalised' else 'k'), fontweight='bold' if c == 'penalised' else 'normal')
axe.set_xlim(-0.5, len(ORDER8)-0.5); axe.set_ylim(len(G7)-0.5, -0.5)
axe.set_xticks(range(len(ORDER8))); axe.set_xticklabels(ORDER8, rotation=90, fontsize=FS_S)
axe.set_yticks(range(len(G7))); axe.set_yticklabels([f'{G7L.get(g,g)} ({LO[g]})' for g in G7], fontsize=FS_S)
for j, h in enumerate(ORDER8): axe.text(j, -0.62, LO[h], ha='center', va='bottom', fontsize=FS_S, color='0.4')
for s in axe.spines.values(): s.set_visible(False)
axe.tick_params(length=0, pad=1.5)
axe.set_xlabel('CS8 group', fontsize=FS_T, labelpad=2); axe.set_ylabel('CS7 group (layer)', fontsize=FS_T, labelpad=2)
axe.set_title('Transition prior and observed GG-OT flow (% of each CS7 group)', loc='left', fontsize=FS_T, pad=11)
fig.legend([Rectangle((0,0),1,1,facecolor=CCOL[c],edgecolor='#999999',lw=0.4) for c in CCOL], [f'{c} (penalty {PENV[c]:g})' for c in CCOL],
           fontsize=FS_S, frameon=False, ncol=4, loc='upper left', bbox_to_anchor=(88/PW, 1-648/PH), handlelength=1.0, handletextpad=0.4, columnspacing=1.0)
letter(36, 462, 'E')

# ---------------- F layer-change cost ----------------
L4 = list(ggot.LAYERS); H = ggot.H_DEFAULT; M = np.full((4,4), np.nan)
for (u, v), hv in H.items(): M[L4.index(u), L4.index(v)] = hv
for (u, v), hv in H.items():
    if (v, u) not in H: M[L4.index(v), L4.index(u)] = hv + 1000
axf = ax_pt(410, ETOP+16, 110, 80)
for i in range(4):
    for j in range(4):
        if i == j: txt, fc = '0', '#F2F2F2'
        else: txt, fc = (f'{M[i,j]:.0f}', '#DAE3F3') if M[i,j] < 1000 else (f'{M[i,j]:,.0f}', '#F4CCCC')
        axf.add_patch(Rectangle((j-0.5, i-0.5), 1, 1, facecolor=fc, edgecolor='#C8C8C8', lw=0.35)); axf.text(j, i, txt, ha='center', va='center', fontsize=FS_S)
axf.set_xlim(-0.5,3.5); axf.set_ylim(3.5,-0.5); axf.set_xticks(range(4)); axf.set_yticks(range(4))
axf.set_xticklabels(L4, fontsize=FS_S); axf.set_yticklabels(L4, fontsize=FS_S); axf.tick_params(length=0, pad=1.5)
axf.xaxis.set_ticks_position('top'); axf.xaxis.set_label_position('top')
axf.set_xlabel('to layer', fontsize=FS_T, labelpad=2); axf.set_ylabel('from layer', fontsize=FS_T, labelpad=2)
for s in axf.spines.values(): s.set_visible(False)
axf.set_title('Layer-change cost h (µm)', loc='left', fontsize=FS_T, pad=26)
fig.text(398/PW, 1-(ETOP+108)/PH, 'E  epiblast, ectoderm, streak\nM  mesoderm (edges × 0.25)\nX  axial midline\nN  definitive / visceral endoderm\nred: reverse direction, h + 1,000 µm',
         fontsize=FS_S, va='top', linespacing=1.4, color='0.2')
letter(380, 462, 'F')

# ---------------- G real CS7→CS8 method comparison ----------------
R = pd.read_csv(B+'figure/final_ggot/ggot_real_comparison_penalised.csv').set_index('method')
GM = [('GG-OT + table','GG-OT + transition prior'),('GG-OT','GG-OT, no prior'),('Euclidean','Euclidean OT'),('moscot FGW','moscot FGW*'),
      ('moscot linear','moscot linear'),('kNN expression','kNN expression'),('NN space','nearest neighbour in space')]
GTOP = 704
axg = ax_pt(118, GTOP, 140, 52)
for i, (k_, lab) in enumerate(GM):
    r = R.loc[k_]; a_, w_ = 100*r.pen_cross, 100*r.pen_same
    axg.barh(i, a_, color=DARK, height=0.7, lw=0); axg.barh(i, w_, left=a_, color=LIGHT, height=0.7, lw=0)
    axg.text(a_+w_+1, i, f'{100*r.pen:.0f}', va='center', fontsize=FS_S, fontweight='bold' if i == 0 else 'normal')
    axg.text(1.0, i, f'{100*r.frac7_unmatched:.0f}', transform=axg.get_yaxis_transform(), va='center', ha='right', fontsize=FS_S, x=1.17) if False else None
    fig.text(282/PW, 0, '')
axg.set_yticks(range(len(GM))); axg.set_yticklabels([l for _, l in GM], fontsize=FS_S); axg.get_yticklabels()[0].set_fontweight('bold')
axg.set_ylim(len(GM)-0.4, -0.6); axg.set_xlim(0, 70); axg.set_xticks([0,20,40,60])
axg.spines[['top','right']].set_visible(False); axg.tick_params(axis='y', length=0, pad=2)
axg.set_xlabel('matches on penalised transitions (%)', fontsize=FS_T)
axu = ax_pt(266, GTOP, 18, 52); axu.set_ylim(len(GM)-0.4, -0.6); axu.set_xlim(0,1); axu.axis('off')
for i, (k_, _) in enumerate(GM): axu.text(1, i, f'{100*R.loc[k_].frac7_unmatched:.0f}', ha='right', va='center', fontsize=FS_S)
axu.text(1, -0.9, 'CS7 cells\nunmatched (%)', ha='right', va='bottom', fontsize=FS_S, color='0.3')
axg.set_title('Real CS7→CS8 pairing (CosMx)', loc='left', fontsize=FS_T, pad=4)

letter(36, 682, 'G')

# ---------------- H Stereo-seq replication ----------------
# bar values read from the vector source panel (old SF9G); totals: Euclidean 31.8 / GG-OT 20.6 (no prior); 1.47 / 0.80 (with prior)
HS = {'no transition prior': {'Euclidean OT': (27.92, 3.86), 'GG-OT': (12.79, 7.84)},
      'with transition prior': {'Euclidean OT': (1.41, 0.06), 'GG-OT': (0.58, 0.22)}}
for n_, (ttl, xmax, xt) in enumerate([('no transition prior', 36, [0,10,20,30]), ('with transition prior', 1.8, [0,0.5,1.0,1.5])]):
    axh = ax_pt(372 + n_*92, GTOP+8, 72, 30)
    for i, m in enumerate(['Euclidean OT', 'GG-OT']):
        a_, w_ = HS[ttl][m]; axh.barh(i, a_, color=DARK, height=0.62, lw=0); axh.barh(i, w_, left=a_, color=LIGHT, height=0.62, lw=0)
        axh.text(a_+w_+xmax*0.03, i, f'{a_:.1f}', va='center', fontsize=FS_S, color=DARK)
    axh.set_ylim(1.6, -0.6); axh.set_xlim(0, xmax); axh.set_xticks(xt); axh.set_xticklabels([f'{x:g}' for x in xt])
    axh.set_yticks([0,1]); axh.set_yticklabels(['Euclidean OT','GG-OT'] if n_ == 0 else [], fontsize=FS_S); axh.tick_params(axis='y', length=0, pad=2)
    axh.spines[['top','right']].set_visible(False); axh.set_title(ttl, loc='left', fontsize=FS_S, pad=2)
fig.text(372/PW, 1-(GTOP-4)/PH, 'Published Stereo-seq CS7→CS8 embryos', fontsize=FS_T, va='bottom')
fig.text(410/PW, 1-(GTOP+60)/PH, 'matches on penalised transitions (%;\nvalue = across germ layers)', fontsize=FS_T, ha='center', va='top') if False else None
fig.text(454/PW, 1-(GTOP+52)/PH, 'matches on penalised transitions (%)\nvalue shown = across germ layers', fontsize=FS_T, ha='center', va='top', linespacing=1.2)
letter(340, 682, 'H')
fig.savefig(OUT + '.pdf'); fig.savefig(OUT + '.png', dpi=300)
# overlap check
fig.canvas.draw(); r_ = fig.canvas.get_renderer()
T = [(t, t.get_window_extent(r_)) for t in fig.findobj(mpl.text.Text) if t.get_visible() and t.get_text().strip()]
ov = [(a.get_text()[:20], b.get_text()[:20]) for i, (a, ba) in enumerate(T) for b, bb in T[i+1:] if ba.overlaps(bb)]
print('overlaps', len(ov), ov[:12])
