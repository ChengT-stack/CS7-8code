# gastruloid/01_preprocess/new_models.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/benchmark/v3_rounds61-120/code/new_data.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

"""Rounds 71-: additional datasets.
(a) Xu 2023 human embryos CS12-16 (GSE157329): pseudobulk units embryo x annotation (>=30 cells) -> store/xu_units.h5ad   (independent later-stage human control)
(b) embryo models: Liu 2023 peri-gastruloid d11 (GSE232861), Pedroza 2023 hEE D4/D6 (GSE208195), Weatherbee 2023 d4/d6/d8 (GSE218314; multiome nuclei)
    QC >=500 genes, <=20% mt, Leiden res 2 (as gall/prep_group.py), pseudobulk >=15 cells -> store/newmodels_clust.h5ad ; cells -> gall/groups_new/{gid}.h5ad
usage: python bm/new_data.py xu | models"""
import sys, os, gzip, json, numpy as np, pandas as pd, scipy.sparse as sp, scipy.io, anndata as ad, scanpy as sc
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / '02_milestone_scoring')); import stage_lib as L
D = (str(HGC_DATA) + '/gastruloid_sc/'); ST = (str(HGC_DATA) + '/gastruloid_benchmark/store/')

def agg(X, keys, min_n):
    u, inv = np.unique(keys, return_inverse=True); n = np.bincount(inv); M = sp.csr_matrix((np.ones(len(inv), np.float32), (inv, np.arange(len(inv)))), shape=(len(u), len(inv))); S = (M @ X).tocsr(); k = n >= min_n; return u[k], S[k], n[k]

# (function xu() for the Xu et al. 2023 CS12-16 control store removed: not used by the manuscript outputs)

def read_mtx(prefix):
    X = scipy.io.mmread(prefix + 'matrix.mtx.gz').T.tocsr(); f = pd.read_csv(prefix + 'features.tsv.gz', sep='\t', header=None); b = pd.read_csv(prefix + 'barcodes.tsv.gz', header=None)[0].values
    a = ad.AnnData(X.astype(np.float32), obs=pd.DataFrame(index=b), var=pd.DataFrame(index=f[1].astype(str).values)); a.var_names_make_unique(); return a

def loaders():
    out = {}
    def liu():
        a = sc.read_10x_h5(D + 'GSE232861/GSM7384960_filtered_feature_bc_matrix.h5'); a.var_names_make_unique(); return a
    out['Liu_PG_d11'] = dict(load=liu, dataset='Liu 2023', label='peri-gastruloid day 11', hours=264)
    for d, h in [('D4', 96), ('D6', 144)]:
        gsm = {'D4': 'GSM6338672', 'D6': 'GSM6338673'}[d]; out['Ped_hEE_' + d] = dict(load=(lambda p=D + f'GSE208195/{gsm}_{d}_': read_mtx(p)), dataset='Pedroza 2023', label=f'hEE {d}', hours=h)
    if os.path.exists(D + 'GSE218314/wea_counts.mtx'):
        def wea(day):
            X = scipy.io.mmread(D + 'GSE218314/wea_counts.mtx').T.tocsr(); g = [l.strip() for l in open(D + 'GSE218314/wea_genes.txt')]; c = [l.strip() for l in open(D + 'GSE218314/wea_cells.txt')]
            md = pd.read_csv(D + 'GSE218314/GSE218314_human_model_metadata.csv.gz', index_col=0).reindex(c); a = ad.AnnData(X.astype(np.float32), obs=md[['sample_type', 'cell_assignment2']].astype(str), var=pd.DataFrame(index=g)); a.var_names_make_unique(); return a[a.obs.sample_type == f'double_structure_day{day}'].copy()
        for day in (4, 6, 8): out[f'Wea_d{day}'] = dict(load=(lambda dd=day: wea(dd)), dataset='Weatherbee 2023', label=f'Weatherbee model day {day} (nuclei)', hours=day * 24)
    return out

def models():
    os.makedirs('gall/groups_new', exist_ok=True); parts = []
    for gid, g in loaders().items():
        a = g['load'](); b, qi = L.qc(a, 'human'); b.obs['sub'], b.obsm['X_umap'] = L.subcl(b); b.write_h5ad(f'gall/groups_new/{gid}.h5ad')
        info = dict(group=gid, dataset=g['dataset'], species='human', label=g['label'], hours=g['hours'], median_umi=float(b.obs.n_umi.median()), median_genes=float(b.obs.n_genes.median()), **qi); json.dump(info, open(f'gall/groups_new/{gid}.json', 'w')); print(json.dumps(info), flush=True)
        u, S, n = agg(b.X, (gid + '|c' + b.obs['sub'].astype(str)).values, 15)
        parts.append(ad.AnnData(S, obs=pd.DataFrame({'group': gid, 'dataset': g['dataset'], 'species': 'human', 'label': g['label'], 'hours': g['hours'], 'n_cells': n, 'group_cells': b.n_obs, 'source': 'model'}, index=u), var=pd.DataFrame(index=b.var_names)))
    allg = sorted(set().union(*[set(p.var_names) for p in parts])); gi = {x: i for i, x in enumerate(allg)}; mats = []
    for p in parts:
        idx = np.array([gi[x] for x in p.var_names]); C = sp.coo_matrix(p.X); mats.append(sp.csr_matrix((C.data, (C.row, idx[C.col])), shape=(p.n_obs, len(allg))))
    a = ad.AnnData(sp.vstack(mats).tocsr().astype(np.float32), obs=pd.concat([p.obs for p in parts]), var=pd.DataFrame(index=allg)); a.write_h5ad(ST + 'newmodels_clust.h5ad'); print('newmodels_clust', a.shape, a.obs.groupby('group').size().to_dict())

if __name__ == '__main__':
    for fn in sys.argv[1:]: globals()[fn]()
