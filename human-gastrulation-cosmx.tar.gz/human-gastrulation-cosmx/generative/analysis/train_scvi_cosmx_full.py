"""CosMx-only scVI model of the HuE#1 (CS7) and HuE#2 (CS8) disc cells on all genes (20 latent dimensions), saved as
ai/scvi_cosmx_full and used by analysis/node_layers.py for the expression-only kNN control of the node terciles.
Reconstructed from session 5113e657 message [2450] (subset: model training; the original script ai/step4_decode_t05.py
went on to decode an earlier t = 0.5 version, which was superseded by the generative model and is not included).
Run with cwd = HGC_GEN_ROOT.
"""
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import numpy as np, pandas as pd, anndata as ad, scipy.io, scipy.sparse as sp, scvi, torch, time, warnings; warnings.filterwarnings('ignore')
torch.set_float32_matmul_precision('high'); scvi.settings.seed=0; dev='cuda'
B=DATA+'/cs7_cs8_matching/'; g=pd.read_csv(B+'dataprep/export/genes.csv').gene.values
P=[]
for s in ['CS7','CS8']:
    M=scipy.io.mmread(B+f'dataprep/export/{s}_counts.mtx').tocsr().T.tocsr().astype(np.float32); c=pd.read_csv(B+f'dataprep/export/{s}_cells.csv')
    P.append(ad.AnnData(M,obs=pd.DataFrame({'stage':s,'label':c.label_short.values,'nCount':c.nCount.values}),var=pd.DataFrame(index=g)))
A=ad.concat(P,index_unique=None); A.obs_names=[f'c{i}' for i in range(A.n_obs)]; A.layers['counts']=A.X.copy()
n7=P[0].n_obs; print(A.shape, 'CS7',n7)
scvi.model.SCVI.setup_anndata(A,layer='counts')
m=scvi.model.SCVI(A,n_latent=20,n_layers=2,n_hidden=256,gene_likelihood='nb')
t=time.time(); m.train(max_epochs=200,batch_size=1024,early_stopping=True,accelerator='gpu',devices=1,plan_kwargs={'lr':2e-3},enable_progress_bar=False)
print('trained',round((time.time()-t)/60,1),'min, epochs',len(m.history['elbo_train']), 'val elbo',float(m.history['elbo_validation'].iloc[-1,0]))
m.save('ai/scvi_cosmx_full',overwrite=True)
