# gastruloid/05_celltype_comparison/celltypes_full.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/celltypes_full.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Embryonic cell types of the CosMx CS7 / CS8 embryos with or without a counterpart in all 31 samples of the eight models shown in the staging figure.
# Evidence per sample and embryo type, in this order:
#   (1) annotated counterpart population (curated de novo label -> embryo type; >=1% of annotated cells and >=20 cells);
#   (2) marker-defined cells (milestone call 'reached');
#   (3) annotated later derivative of that type (DERIV; same size rule) -> 'later derivative only': the type itself is gone but its lineage is represented; not counted as missing;
#   (4) otherwise absent: 'present in the reference embryo' (counted as missing), 'present in one of the two embryos' (transitional samples), or 'not expected'.
# Reference embryo: CS7 for CS7-like; CS8 for CS8-like and beyond CS8; types present in both embryos for transitional samples. Extra-embryonic and germline types are not compared.
import numpy as np, pandas as pd
OUT = 'gall/out_v2/'; src = open(Path(__file__).resolve().parent / 'celltypes_cs78.py').read(); exec(src[src.index('TYPES = ['):src.index("h = pd.read_csv('tb/out/embryo_units")])
ALLT = TYPES; EXT = [t for t in ALLT if t[2] == 'Extra-embryonic and germline']; TYPES = [t for t in ALLT if t[2] != 'Extra-embryonic and germline']
DERIV = {'pECT': ['Neural tube progenitor', 'Dorsal neural tube/roof plate', 'Neuron'], 'Para.Meso': ['Somite, dermomyotome-biased', 'Somite, sclerotome-biased', 'Somitic mesenchyme'], 'DE': ['Gut endoderm', 'Pharyngeal/foregut endoderm']}
INFO = pd.read_csv(OUT + 'groups.csv', index_col=0); R = pd.read_csv(OUT + 'gastruloid_stage_vs_CS7_CS8.csv').set_index('unit'); ML = pd.read_csv(OUT + 'milestone_assessability_long.csv').set_index(['group', 'milestone_id'])
KEEP = ['Hamazaki 2024', 'Budjan 2022', 'Minn 2020', 'Heemskerk 2024', 'Chen 2025', 'Liu 2023', 'Rossi 2021', 'Veenvliet 2020']
PREF = ['Ham_0h', 'Ham_24h', 'Ham_48h', 'Ham_72h', 'Ham_96h', 'Ham_RA96', 'Ham_RA120', 'Ham_RALDN', 'Vee_TLS96', 'Vee_TLSMG108', 'Vee_TLSMG120', 'Vee_G120', 'Vee_TLSMGCL120']
so = INFO.sort_values(['series', 'order']); rank = {g: i for i, g in enumerate(so.index)}
UNITS = sorted([g for g in INFO.index if INFO.dataset[g] in KEEP], key=lambda g: (KEEP.index(INFO.dataset[g]), PREF.index(g) if g in PREF else 100 + rank[g])); assert len(UNITS) == 31
h = pd.read_csv('tb/out/embryo_units_cosmx38_half.csv'); EN = h.groupby(['label', 'stage']).n_cells.sum().unstack().fillna(0)
a = pd.read_parquet('reanno/out/all_cells_annotated.parquet', columns=['group', 'label', 'excluded']); a = a[a.group.isin(UNITS) & ~a.excluded]; NL = a.groupby(['group', 'label']).size(); NT = a.groupby('group').size(); assert set(UNITS) <= set(NT.index)
ext_labels = {l for t in EXT for l in t[4]}; emb_labels = {l for t in TYPES for l in t[4]}; both = ext_labels & emb_labels; der_labels = {l for v in DERIV.values() for l in v}; assert not (der_labels & (emb_labels | ext_labels)) and set(DERIV) <= {t[0] for t in TYPES}
NEXT = {g: int(sum(NL.get((g, l), 0) for l in ext_labels - both)) for g in UNITS}; NEMB = {g: int(NT[g] - NEXT[g]) for g in UNITS}   # embryonic-type cells = annotated cells without an extra-embryonic / germline label
ETOT = {s: float(sum(EN[s].get(c, 0) for t in TYPES for c in t[3])) for s in ('CS7', 'CS8')}; EALL = {s: float(EN[s].sum()) for s in ('CS7', 'CS8')}
REF = {'CS7-like': 'CS7 embryo', 'CS8-like': 'CS8 embryo', 'CS7-to-CS8 transitional': 'types in both embryos', 'beyond CS8': 'CS8 embryo (latest available)'}
MISS, ONE = 'absent, present in the reference embryo', 'absent, present in one of the two embryos'; rows = []
for key, lab, blk, ctypes, labels, ms in TYPES:
    n7 = int(sum(EN.CS7.get(c, 0) for c in ctypes)); n8 = int(sum(EN.CS8.get(c, 0) for c in ctypes)); in7, in8 = n7 > 0, n8 > 0
    for u, n_, st_, s in [('Human embryo CS7 (CosMx)', n7, in7, 'CS7'), ('Human embryo CS8 (CosMx)', n8, in8, 'CS8')]:
        rows.append(dict(unit=u, kind='embryo', stage='', type=key, type_label=lab, block=blk, in_CS7=in7, in_CS8=in8, n_cells=n_, pct_all=round(100 * n_ / EALL[s], 2), pct_embryonic=round(100 * n_ / ETOT[s], 2), labels='; '.join(ctypes), milestone=ms or '', milestone_call='', state='present' if st_ else 'absent'))
    for g in UNITS:
        n = int(sum(NL.get((g, l), 0) for l in labels)); pct = 100 * n / NT[g]; clus = (pct >= 1.0) and (n >= 20); mc = ML.loc[(g, ms), 'call_observed'] if ms else ''; mark = mc == 'reached'
        nd = int(sum(NL.get((g, l), 0) for l in DERIV.get(key, []))); der = (100 * nd / NT[g] >= 1.0) and (nd >= 20)
        stg = R.stage[g]; exp = {'CS7-like': in7, 'CS8-like': in8, 'beyond CS8': in8, 'CS7-to-CS8 transitional': in7 and in8}[stg]; one = stg == 'CS7-to-CS8 transitional' and (in7 != in8)
        state = 'present (annotated population)' if clus else 'present (marker-defined cells only)' if mark else 'later derivative only' if (der and (exp or one)) else MISS if exp else ONE if one else 'absent, not expected'
        rows.append(dict(unit=g, kind='sample', stage=stg, type=key, type_label=lab, block=blk, in_CS7=in7, in_CS8=in8, n_cells=n, pct_all=round(pct, 2), pct_embryonic=round(100 * n / NEMB[g], 2), labels='; '.join(l for l in labels if NL.get((g, l), 0) > 0),
                         n_derivative_cells=nd, derivative_labels='; '.join(l for l in DERIV.get(key, []) if NL.get((g, l), 0) > 0), milestone=ms or '', milestone_call=mc, expected=bool(exp), state=state))
T = pd.DataFrame(rows); T['dataset'] = T.unit.map(INFO.dataset).fillna(''); T.to_csv(OUT + 'celltypes_full_long.csv', index=False)
P = T[T.kind == 'sample'].pivot(index='type', columns='unit', values='state').loc[[t[0] for t in TYPES], UNITS]; E = T[T.kind == 'sample'].pivot(index='type', columns='unit', values='expected').loc[P.index, UNITS].astype(bool)
summ = pd.DataFrame({g: dict(dataset=INFO.dataset[g], stage=R.stage[g], reference=REF[R.stage[g]], n_expected=int(E[g].sum()), n_missing=int((P[g] == MISS).sum()), missing=';'.join(t for t in P.index if P.loc[t, g] == MISS),
                             later_derivative_only=';'.join(t for t in P.index if P.loc[t, g] == 'later derivative only'), missing_one_embryo_only=';'.join(t for t in P.index if P.loc[t, g] == ONE), marker_only=';'.join(t for t in P.index if P.loc[t, g].startswith('present (marker')),
                             n_annotated_cells=int(NT[g]), pct_embryonic_type_cells=round(100 * NEMB[g] / NT[g], 1)) for g in UNITS}).T
summ.to_csv(OUT + 'celltypes_full_missing_by_sample.csv')
ab = {'present (annotated population)': 'P', 'present (marker-defined cells only)': 'm', 'later derivative only': 'd', MISS: 'X', ONE: 'x', 'absent, not expected': '.'}
pd.set_option('display.width', 300); pd.set_option('display.max_colwidth', 70); pd.set_option('display.max_columns', 50); print(P.replace(ab).rename(columns=lambda c: c.replace('Ham_', 'H').replace('Chen_', 'C').replace('Vee_', 'V').replace('Som_', 'S').replace('Ros_', 'R').replace('Liu_PG_', 'L').replace('TLSMG', 'M').replace('TLS', 'T')).to_string())
print(summ[['stage', 'n_expected', 'n_missing', 'later_derivative_only', 'pct_embryonic_type_cells']].to_string())
old = pd.read_csv(OUT + 'celltypes_mini_long.csv'); o = old[old.kind == 'sample'].set_index(['unit', 'type']).state; n_ = T[T.kind == 'sample'].set_index(['unit', 'type']).state.loc[o.index]; print('same calls as the 7-sample table:', bool((o == n_).all()), 'changed:', [(i, o[i], n_[i]) for i in o.index if o[i] != n_[i]][:10])
