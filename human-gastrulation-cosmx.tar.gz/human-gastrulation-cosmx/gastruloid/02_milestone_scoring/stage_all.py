# gastruloid/02_milestone_scoring/stage_all.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/code/stage_all.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Stage all prepared gastruloid groups on the milestone axis: depth-matched mouse curves -> per-group calls -> time-course logic -> windows, clock, tables.
# Inputs : gall/groups/*.h5ad|json (prep_group.py), Table S2 (sheet 'milestones'), mouse atlas raw counts
import json, glob, sys, os, numpy as np, pandas as pd, anndata as ad, scanpy as sc, warnings; warnings.filterwarnings('ignore')
sys.path.insert(0, str(Path(__file__).resolve().parent)); import stage_lib as L
R, N, P, A = L.R, L.N, L.P, L.A
B = (str(HGC_DATA) + '/')
INFO = pd.DataFrame([json.load(open(f)) for f in sorted(glob.glob('gall/groups/*.json'))]).set_index('group')
MM = 14848.0   # median UMI per cell of the mouse atlas (Pijuan-Sala)
INFO['eff_median_umi'] = INFO.median_umi.clip(upper=MM)          # groups deeper than the mouse atlas are down-sampled to the atlas depth (cells above it only)
INFO['downsampled_to_mouse_depth'] = INFO.median_umi > MM
INFO['keep_prob'] = (INFO.eff_median_umi / MM).clip(upper=1).round(4)

# ---- mouse calibration curves thinned to each group's depth (as mouse_depth_matched_curves.py)
if not os.path.exists('gall/mouse_curves_depth_matched.csv'):
    mm = ad.read_h5ad(B + 'external/mouse_pijuan_sala/mouse_atlas_mapped_rawcounts.h5ad')
    GM = ['T', 'Eomes', 'Hoxa1', 'Hoxb1', 'Hoxb8', 'Hoxb9']; sts = ['E6.5', 'E6.75', 'E7.0', 'E7.25', 'E7.5', 'E7.75', 'E8.0', 'E8.25', 'E8.5']
    Xm = np.asarray(mm[:, GM].X.todense()).astype(np.int64); stg = mm.obs.stage.astype(str).values; ct = mm.obs.celltype.astype(str)
    okm = ~ct.isin(['Visceral endoderm', 'Mesenchyme']).values; ce = (ct == 'Caudal epiblast').values; assert abs(float(np.median(np.asarray(mm.X.sum(1)).ravel())) - MM) < 1
    def curves(p, seed=0):
        Y = np.random.default_rng(seed).binomial(Xm, p) if p < 1 else Xm
        D_ = pd.DataFrame(Y > 0, columns=GM); D_['st'] = stg
        tpl = D_[D_['T'].values & okm]; a_ = tpl.groupby('st')[['Eomes', 'Hoxa1', 'Hoxb1']].mean().mul(100).loc[sts]; a_['n'] = tpl.groupby('st').size().loc[sts]
        cc = D_[ce]; b_ = cc.groupby('st')[['Hoxb8', 'Hoxb9']].mean().mul(100); b_['n'] = cc.groupby('st').size(); b_ = b_.loc[[s for s in sts if s in b_.index and b_.loc[s, 'n'] >= 50]]
        return a_, b_
    rows = []
    for name, p in [('native', 1.0)] + [(g, float(r.keep_prob)) for g, r in INFO.iterrows()]:
        a_, b_ = curves(p)
        for ref, tab in [('T+ pool', a_), ('caudal epiblast', b_)]:
            for s_, r_ in tab.iterrows():
                for g_ in [c for c in tab.columns if c != 'n']: rows.append(dict(sample=name, median_umi=np.nan if name == 'native' else float(INFO.loc[name, 'median_umi']), keep_prob=round(p, 4), reference=ref, stage=s_, E=float(s_[1:]), gene=g_, detection_pct=r_[g_], n_cells=int(r_['n'])))
    pd.DataFrame(rows).to_csv('gall/mouse_curves_depth_matched.csv', index=False); del mm
CV = pd.read_csv('gall/mouse_curves_depth_matched.csv')

# ---- stage every group
EV, CALLS, CALLS_D, CK = [], {}, {}, []
for gid, r in INFO.iterrows():
    a = ad.read_h5ad(f'gall/groups/{gid}.h5ad')
    if r.downsampled_to_mouse_depth: sc.pp.downsample_counts(a, counts_per_cell=int(MM), random_state=0)
    ev, c, cd, ck = L.stage_group(a, r.species, gid, CV); EV += ev; CALLS[gid] = c; CALLS_D[gid] = cd; CK += ck
    print(gid, r.cells_kept, flush=True)
EV = pd.DataFrame(EV); CK = pd.DataFrame(CK)

# ---- time courses: groups of one series, ordered; 'reached' persists; absent transient populations are informative only for time courses starting from the pluripotent state or samples <=48 h
SERIES = {g: list(INFO[(INFO.series == r.series) & (INFO.order < r.order)].sort_values('order').index) for g, r in INFO.iterrows()}
ORDER = list(INFO.sort_values(['species', 'dataset', 'series', 'order']).index)
KW = dict(naive_first=['Ham_0h'], hours=INFO.hours.to_dict(), naive_series=['Ham'], series_id=INFO.series.to_dict())
MS = sorted(L.ONSET)
def table(fin):
    C = pd.DataFrame({g: [fin[g][m] for m in MS] for g in ORDER}, index=MS)
    C.insert(0, 'milestone', [L.MNAME[m] for m in MS]); C.insert(1, 'domain', [L.DOM[m] for m in MS]); C.insert(2, 'mouse_onset', [L.ONSET[m] for m in MS]); return C
C = table(L.onset_logic(ORDER, CALLS, SERIES, mode='timeaware', **KW)); CD = table(L.onset_logic(ORDER, CALLS_D, SERIES, mode='timeaware', **KW))
CS = table(L.onset_logic(ORDER, CALLS, SERIES, mode='strict', **KW)); CSD = table(L.onset_logic(ORDER, CALLS_D, SERIES, mode='strict', **KW))
EV['call'] = [C.loc[m, s] for s, m in zip(EV['sample'], EV.milestone_id)]; EV['call_depth_matched'] = [CD.loc[m, s] for s, m in zip(EV['sample'], EV.milestone_id)]; EV['call_strict'] = [CS.loc[m, s] for s, m in zip(EV['sample'], EV.milestone_id)]
EV.insert(2, 'milestone', EV.milestone_id.map(L.MNAME)); EV.insert(3, 'domain', EV.milestone_id.map(L.DOM)); EV.insert(4, 'mouse_onset', EV.milestone_id.map(L.ONSET))
def wtab(C_, thr, rule):
    return pd.DataFrame([dict(group=g, group_label=INFO.loc[g, 'label'], dataset=INFO.loc[g, 'dataset'], gene_thresholds=thr, transient_rule=rule, milestone_set=ms_, **L.window(C_, g, sel)) for g in ORDER
                         for ms_, sel in [('all 14 disc milestones', None), ('posterior module (m01, m08, m09, m11, m12, m13)', L.POST)]])
W = pd.concat([wtab(C, 'fixed', 'time-aware'), wtab(CD, 'depth-matched', 'time-aware'), wtab(CS, 'fixed', 'strict'), wtab(CSD, 'depth-matched', 'strict')], ignore_index=True)
os.makedirs('gall/out', exist_ok=True)
INFO.to_csv('gall/out/groups.csv'); C.to_csv('gall/out/calls.csv'); CD.to_csv('gall/out/calls_depth_matched.csv'); CS.to_csv('gall/out/calls_strict.csv'); EV.to_csv('gall/out/evidence.csv', index=False); W.to_csv('gall/out/windows.csv', index=False); CK.to_csv('gall/out/gene_clock.csv', index=False)
