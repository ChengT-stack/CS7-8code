# gastruloid/05_celltype_comparison/build_sfig8B.py
# Source: artifact build_sf8B_human_only.py (version da78e3e2; session 824ef1ce, 2026-11-17)
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))


# Supplementary gastruloid panel B (cell types vs the CS7/CS8 embryos), human samples only (Rossi 2021 and Veenvliet 2020 removed).
import sys, glob, shutil, numpy as np, pandas as pd, matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt, matplotlib.font_manager as fm
from matplotlib.patches import Rectangle, Patch
from matplotlib.lines import Line2D
T_path, SM_path, R_path, INFO_path, ASSESS_path, OUT = sys.argv[1:7]
for f_ in glob.glob(os.environ.get('HGC_FONTS', 'fonts') + '/arial*.ttf'): fm.fontManager.addfont(f_)
mpl.rcParams.update({'font.family': 'Arial', 'pdf.fonttype': 42, 'svg.fonttype': 'none', 'font.size': 6, 'xtick.labelsize': 6, 'ytick.labelsize': 6})
T = pd.read_csv(T_path); SM = pd.read_csv(SM_path, index_col=0).fillna(''); R = pd.read_csv(R_path).fillna('').set_index('unit'); INFO = pd.read_csv(INFO_path, index_col=0)
src = open(ASSESS_path).read(); exec(src[src.index('SHORT = {'):src.index('assert all(g in SL')])
ALL = list(SM.index); assert len(ALL) == 31
UNITS = [u for u in ALL if INFO.species[u] == 'human']; REMOVED = [u for u in ALL if u not in UNITS]
assert (SM.stage[UNITS] == R.loc[UNITS, 'stage']).all()
EMBS = ['Human embryo CS7 (CosMx)', 'Human embryo CS8 (CosMx)']
SCOL = {'CS7-like': '#CBC9E2', 'CS7-to-CS8 transitional': '#9E9AC8', 'CS8-like': '#6A51A3', 'beyond CS8': '#3F007D', 'not stageable': '#FFFFFF'}; SLAB = {'CS7-to-CS8 transitional': 'CS7–CS8 transitional'}
rows = [(u, 'embryo') for u in EMBS] + [(g, INFO.dataset[g]) for g in UNITS]; sp_ = {}; cur = 0.0; prev = None
for u, d in rows:
    if prev is not None and d != prev: cur += 0.45 if prev != 'embryo' else 0.8
    sp_[u] = cur; cur += 1; prev = d
ST = cur; DS = list(dict.fromkeys(d for u, d in rows[2:]))
TY = list(T.drop_duplicates('type').type); meta = T.drop_duplicates('type').set_index('type'); BLOCKS = list(meta.block.drop_duplicates()); D = T.set_index(['unit', 'type'])
PRES = 'present (annotated population)'; MARK = 'present (marker-defined cells only)'; DER = 'later derivative only'
MISS = 'absent, present in the reference embryo'; ONE = 'absent, present in one of the two embryos'
COL = {PRES: '#1F5FA8', MISS: '#D55E00', ONE: '#F5CBAA', 'embryo': '#4D4D4D'}
ABM = {'EPI': 'EPI', 'aECT': 'ECT/aECT', 'pECT': 'pECT', 'NNE': 'NNE', 'CLE': 'CLE', 'PS': 'PS', 'APS': 'APS', 'Node': 'Node', 'Notochord': 'Notochord', 'PrP': 'PrP', 'Nas.Meso': 'Nas.Meso', 'Para.Meso': 'Para.Meso',
       'Rostral.Meso': 'Rostral.Meso', 'LP.Meso': 'LP.Meso', 'Heart.Meso': 'Heart.Meso', 'DE': 'DE', 'ADE': 'AVE', 'VE': 'VE'}
assert list(ABM) == TY
tp = {}; cur = 0.0; prev = None; bl, br = {}, {}
for t in TY:
    b = meta.block[t]
    if prev is not None and b != prev: cur += 0.5
    if b != prev: bl[b] = cur
    tp[t] = cur; cur += 1; br[b] = cur; prev = b
TT = cur
dsz = lambda p: (2.5 + 8.5 * np.sqrt(min(p, 60) / 60)) ** 2
cw, rh = 0.178, 0.162; x0 = 1.5; top = 0.1; hdr = 0.72; RW = 2.15; bot = 1.1
W = x0 + TT * cw + RW; H = top + hdr + ST * rh + bot
fig = plt.figure(figsize=(W, H)); ax = fig.add_axes([x0 / W, bot / H, TT * cw / W, ST * rh / H]); ax.set_xlim(0, TT); ax.set_ylim(ST, 0)
used = set()
for u, d in rows:
    for t in TY:
        s = D.loc[(u, t), 'state']; used.add(s) if u not in EMBS else None
        if s in (MISS, ONE): ax.add_patch(Rectangle((tp[t] + 0.05, sp_[u] + 0.05), 0.9, 0.9, fc=COL[s], ec='none'))
        else: ax.add_patch(Rectangle((tp[t] + 0.09, sp_[u] + 0.09), 0.82, 0.82, fc='white', ec='#C8C8C8', lw=0.4))
        if s in (PRES, 'present'): ax.scatter([tp[t] + 0.5], [sp_[u] + 0.5], s=dsz(D.loc[(u, t), 'pct_embryonic']), color=COL['embryo'] if u in EMBS else COL[PRES], linewidths=0, zorder=3)
        elif s == MARK: ax.scatter([tp[t] + 0.5], [sp_[u] + 0.5], s=4.5 ** 2, facecolors='white', edgecolors=COL[PRES], linewidths=0.8, zorder=3)
        elif s == DER: ax.scatter([tp[t] + 0.52], [sp_[u] + 0.5], s=4.5 ** 2, marker='>', color=COL[PRES], linewidths=0, zorder=3)
for spn in ax.spines.values(): spn.set_visible(False)
ax.set_xticks([tp[t] + 0.5 for t in TY]); ax.set_xticklabels([ABM[t] for t in TY], rotation=90); ax.xaxis.tick_top(); ax.tick_params(length=0, pad=14)
for b in BLOCKS:
    ax.plot([bl[b] + 0.1, br[b] - 0.1], [-0.18, -0.18], color='#555555', lw=0.6, clip_on=False)
    ax.text((bl[b] + br[b]) / 2, -0.3, b.replace('Streak and axial mesoderm', 'Streak and axial'), ha='center', va='bottom', fontsize=5, color='#333333', clip_on=False)
ax.set_yticks([sp_[u] + 0.5 for u, d in rows]); ax.set_yticklabels(['CS7 (CosMx)', 'CS8 (CosMx)'] + [SL[g] for g in UNITS]); xl = -(x0 - 0.08) / cw
ax.text(xl, (sp_[EMBS[0]] + sp_[EMBS[1]] + 1) / 2, 'Human\nembryos', ha='left', va='center', fontsize=6, clip_on=False, linespacing=1.0)
for d in DS:
    gs = [g for g in UNITS if INFO.dataset[g] == d]; ax.text(xl, (sp_[gs[0]] + sp_[gs[-1]] + 1) / 2, SHORT[d].split(' ')[0], ha='left', va='center', fontsize=6, clip_on=False)
xm = TT + 1.45; xs_ = TT + 3.3
for u, d in rows:
    if u not in EMBS:
        ax.text(xm, sp_[u] + 0.52, f'{int(SM.n_missing[u])} of {int(SM.n_expected[u])}', ha='center', va='center', fontsize=6, color=COL[MISS] if int(SM.n_missing[u]) else '#333333', clip_on=False)
    c = R.stage[u]; ax.add_patch(Rectangle((xs_, sp_[u] + 0.12), 0.76, 0.76, fc=SCOL[c], ec='none', clip_on=False)); ax.text(xs_ + 1.05, sp_[u] + 0.52, SLAB.get(c, c), ha='left', va='center', fontsize=6, clip_on=False)
ax.text(xm, -0.5, 'Missing', ha='center', va='bottom', fontsize=6, clip_on=False); ax.text(xs_, -0.5, 'Stage', ha='left', va='bottom', fontsize=6, clip_on=False)
HS = [Line2D([0], [0], marker='o', ls='none', mfc=COL[PRES], mec='none', ms=6, label='present (annotated population)'),
      Line2D([0], [0], marker='o', ls='none', mfc='white', mec=COL[PRES], mew=0.8, ms=4.5, label='marker-defined cells only')]
if DER in used: HS.append(Line2D([0], [0], marker='>', ls='none', mfc=COL[PRES], mec='none', ms=4.5, label='later derivative only'))
HS += [Patch(fc=COL[MISS], label='absent, present in the reference embryo'), Patch(fc=COL[ONE], label='absent, present in only one embryo'),
       Patch(fc='white', ec='#C8C8C8', lw=0.4, label='absent, not expected'), Line2D([0], [0], marker='o', ls='none', mfc=COL['embryo'], mec='none', ms=6, label='embryo: present')]
HZ = [Line2D([0], [0], marker='o', ls='none', mfc='#888888', mec='none', ms=np.sqrt(dsz(p)), label=l) for p, l in [(1, '1%'), (10, '10%'), (50, '50%')]]
kw = dict(frameon=False, fontsize=6, handlelength=1.0, labelspacing=0.4, borderaxespad=0.0, borderpad=0.0)
fig.legend(handles=HS, loc='upper left', bbox_to_anchor=(x0 / W, (bot - 0.08) / H), ncol=1, handleheight=1.0, **kw)
fig.legend(handles=HZ, loc='upper left', bbox_to_anchor=((x0 + TT * cw - 0.75) / W, (bot - 0.08) / H), ncol=3, handleheight=2.2, handletextpad=0.6, columnspacing=1.2, title='Dot area: share of embryonic-type cells', title_fontsize=6, **kw)
name = 'SuppFig_gastruloid_celltypes_B_human_only'
for ext in ('png', 'pdf', 'svg'): fig.savefig(OUT + name + '.' + ext, dpi=300)
shutil.copy(OUT + name + '.pdf', OUT + name + '.ai')
fig.canvas.draw(); r = fig.canvas.get_renderer(); texts = [(t, t.get_window_extent(r)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
ov = [(a.get_text()[:25], b.get_text()[:25]) for i, (a, ba) in enumerate(texts) for b, bb in texts[i + 1:] if ba.overlaps(bb)]
outb = [t.get_text()[:30] for t, bb in texts if not (bb.x0 >= 0 and bb.y0 >= 0 and bb.x1 <= fig.bbox.x1 and bb.y1 <= fig.bbox.y1)]
print(round(W, 2), round(H, 2), 'overlaps', ov[:8], 'outside', outb[:8]); print('states used', sorted(used)); print('removed', REMOVED)
m = SM.loc[UNITS]; print('missing range', int(m.n_missing.astype(int).min()), int(m.n_missing.astype(int).max()))
print(m[['n_missing', 'n_expected']].astype(int).assign(lab=[SL[g] for g in UNITS], ds=INFO.dataset[UNITS]).to_string())
