# Merged t = 0.5 deliverable for all 17,378 GG-OT-matched CS7 cells (existing 15,819 rows unchanged and first; 1,559 new rows appended and flagged)
# + classifier columns for the new cells (same classifier recipe, gated on reproducing the existing calls) + comparison tables new vs existing cells.
# Reads existing files only; writes only into OUT (never overwrites).
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
GEN_ROOT = os.environ.get('HGC_GEN_ROOT', '.')   # generative working directory (original ai_t05_v153 layout)
import os, json, numpy as np, pandas as pd, scipy.sparse as sp, scipy.io as sio, anndata as ad, warnings; warnings.filterwarnings('ignore')
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
V = GEN_ROOT + '/'; B = DATA + '/cs7_cs8_matching/'; BB = DATA + '/bridge_bundle/'; DEL = DATA + '/t05_AI_expression_matrix/'
OUT = V + 'out_gencv/human_fill_1559/'; MD = OUT + 'merged_t05_expression_matrix_17378/'; WORK = os.path.dirname(os.path.abspath(__file__)) + '/'
EX = V + 'out_gencv/human_rot0_V1a/'
REWRITE = os.environ.get('FILL_REWRITE') == '1'      # only to replace this workflow's own earlier outputs inside OUT (used once: the first run parsed the existing cell table
#                                                      without float round-trip precision, which changed the last digit of library_target in 2,593 existing rows)
assert os.path.isdir(OUT) and (REWRITE or not os.path.exists(MD)); os.makedirs(MD, exist_ok=REWRITE)
def save(path, fn):
    assert path.startswith(OUT) and (REWRITE or not os.path.exists(path)); fn(path)
rep = {}
# ---------------- existing deliverable and inputs
cells_old = pd.read_csv(DEL + 't05_cells.csv', float_precision='round_trip'); prob_old = pd.read_csv(DEL + 't05_CS8type_probabilities.csv', float_precision='round_trip'); genes = pd.read_csv(DEL + 'genes.csv').gene.values
c7 = pd.read_csv(BB + 'CS7_cells.csv'); c8 = pd.read_csv(BB + 'CS8_cells.csv')
T05 = pd.read_csv(V + 'ai/step5_human_t05_index.csv'); NEW = pd.read_csv(OUT + 'fill_t05_index.csv'); links = pd.read_csv(OUT + 'fill_partner_links.csv')
n_old, n_new = len(T05), len(NEW); assert (links.cs7_idx.values == NEW.cs7_idx.values).all() and len(cells_old) == n_old
seeds_old = [sp.load_npz(EX + f't05_gen_seed{s}_decoded.npz').tocsr() for s in range(5)]; seeds_new = [sp.load_npz(OUT + f't05_gen_seed{s}_decoded.npz').tocsr() for s in range(5)]
Hn = np.load(OUT + 'fill_human_t05_latent.npz'); Ho = np.load(V + 'out_gencv/rot0_human_t05_latent.npz'); lib_new = np.load(OUT + 'cache_lib05_fill.npy'); lib_old = np.load(V + 'out_gencv/cache_lib05.npy')
assert (cells_old.cell.values == ['t05_' + c for c in c7.cell.values[T05.cs7_idx.values]]).all()
assert (cells_old.nCount.values == np.asarray(seeds_old[0].sum(1)).ravel().astype(int)).all() and np.allclose(cells_old.library_target.values, lib_old)

# ---------------- classifier (recipe of the existing deliverable: standardised 94-d latent, class-balanced multinomial logistic regression, C = 0.5, all CS8 cells)
L = np.load(BB + 'latent.npz', allow_pickle=True); Z = L['Z']; i8 = L['i8']; z8 = Z[i8]; l8 = L['label'][i8].astype(str)
clf = make_pipeline(StandardScaler(), LogisticRegression(max_iter=4000, C=0.5, class_weight='balanced')); clf.fit(z8, l8); cls = np.array(clf.classes_)
def calls(G5):
    P_seed = np.stack([clf.predict_proba(G5[s]) for s in range(5)]); P = P_seed.mean(0); pred = cls[P.argmax(1)]
    return P, pred, P.max(1), cls[np.argsort(P, 1)[:, -2]], (cls[P_seed.argmax(2)] == pred[None]).mean(0)
P_o, pred_o, conf_o, sec_o, agr_o = calls(Ho['gen_V1a'])
pc = ['prob_' + c for c in cls]; assert list(prob_old.columns[1:]) == pc
rep['classifier_gate'] = dict(calls_identical_frac=float((pred_o == cells_old.t05_pred_CS8type.values).mean()), second_identical_frac=float((sec_o == cells_old.t05_pred_second.values).mean()),
                              prob_maxabs_vs_saved_4dp=float(np.abs(P_o.round(4) - prob_old[pc].values).max()), conf_maxabs=float(np.abs(conf_o.round(3) - cells_old.t05_pred_prob.values).max()),
                              seed_agreement_maxabs=float(np.abs(agr_o - cells_old.t05_pred_seed_agreement.values).max()))
clf_ok = rep['classifier_gate']['calls_identical_frac'] == 1.0 and rep['classifier_gate']['prob_maxabs_vs_saved_4dp'] <= 2e-4
rep['classifier_gate']['pass'] = bool(clf_ok); print(rep['classifier_gate'], flush=True)
LOm = cells_old.groupby('t05_pred_CS8type').t05_pred_layer.agg(lambda x: x.unique().tolist()).to_dict(); assert all(len(v) == 1 for v in LOm.values()); LOm = {k: v[0] for k, v in LOm.items()}

# ---------------- rows of the new cells (same columns as the existing t05_cells.csv)
ci = NEW.cs7_idx.values; src = c7.iloc[ci].reset_index(drop=True); p8 = c8.iloc[links.cs8_idx.values].reset_index(drop=True); X0n = seeds_new[0]
new_rows = pd.DataFrame({'cell': ['t05_' + c for c in src.cell], 'stage': cells_old.stage.iloc[0], 'label_short': NEW.dom_cs8_group.values, 'cs7_label_short': src.label_short.values,
    'AP_frac': NEW.AP.values, 'LR_frac': NEW.LR.values, 'DV_gap_units': NEW.DV.values, 'AP_um': NEW.X.values, 'LR_um': NEW.Y.values,
    'nCount': np.asarray(X0n.sum(1)).ravel().astype(int), 'nFeature': np.diff(X0n.indptr), 'library_target': lib_new,
    'cs7_cell': src.cell.values, 'cs7_section': src.section.values, 'cs7_x_um': src.x_um.values, 'cs7_y_um': src.y_um.values, 'cs7_z_um': src.z_um.values,
    'cs8_top_partner': p8.cell.values, 'cs8_top_partner_label': p8.label_short.values, 'cs8_n_partners': 1})
assert (new_rows.cs7_label_short.values == NEW.cs7_group.values).all() and (new_rows.cs8_top_partner_label.values == NEW.dom_cs8_group.values).all()
if clf_ok:
    P_n, pred_n, conf_n, sec_n, agr_n = calls(Hn['gen_V1a'])
    new_rows['t05_pred_CS8type'] = pred_n; new_rows['t05_pred_prob'] = conf_n.round(3); new_rows['t05_pred_second'] = sec_n; new_rows['t05_pred_layer'] = [LOm[x] for x in pred_n]; new_rows['t05_pred_seed_agreement'] = agr_n
else:
    for c in ['t05_pred_CS8type', 't05_pred_prob', 't05_pred_second', 't05_pred_layer', 't05_pred_seed_agreement']: new_rows[c] = np.nan
assert list(new_rows.columns) == list(cells_old.columns)
cells = pd.concat([cells_old, new_rows], ignore_index=True); cells['fill_1559'] = np.r_[np.zeros(n_old, bool), np.ones(n_new, bool)]
assert cells.cell.is_unique and len(cells) == 17378
import io; _b = io.StringIO(); cells.iloc[:n_old].drop(columns='fill_1559').to_csv(_b, index=False)
assert _b.getvalue() == open(DEL + 't05_cells.csv', newline='').read(), 'existing rows would not be written identically'
# ---------------- merged matrix (existing cells first, same order; new cells appended)
Xs = [sp.vstack([seeds_old[s], seeds_new[s]]).tocsr().astype(np.float32) for s in range(5)]
old_mtx_hdr = open(DEL + 't05_counts.mtx').readlines()[2].split(); assert int(old_mtx_hdr[1]) == n_old and int(old_mtx_hdr[2]) == seeds_old[0].nnz
save(MD + 't05_counts.mtx', lambda f: sio.mmwrite(f, Xs[0].T.tocoo().astype(np.int32), field='integer'))
save(MD + 'genes.csv', lambda f: pd.DataFrame({'gene': genes}).to_csv(f, index=False))
save(MD + 't05_cells.csv', lambda f: cells.to_csv(f, index=False))
if clf_ok:
    probs = pd.concat([prob_old, pd.concat([pd.DataFrame({'cell': new_rows.cell.values}), pd.DataFrame(P_n.round(4), columns=pc)], axis=1)], ignore_index=True)
    save(MD + 't05_CS8type_probabilities.csv', lambda f: probs.to_csv(f, index=False))
obs = cells.set_index('cell'); obs.index.name = None
A = ad.AnnData(Xs[0], obs=obs, var=pd.DataFrame(index=genes))
for s in range(1, 5): A.layers[f'counts_seed{s}'] = Xs[s]
A.obsm['spatial'] = cells[['AP_um', 'LR_um']].to_numpy(); A.obsm['X_latent_V1a'] = np.vstack([Ho['gen_V1a'][0], Hn['gen_V1a'][0]])
if clf_ok: A.obsm['P_CS8type_classifier'] = pd.DataFrame(np.vstack([P_o, P_n]), index=A.obs_names, columns=cls)
Aold = ad.read_h5ad(DEL + 't05_AI_V1a.h5ad', backed='r')
A.uns['classifier'] = str(Aold.uns['classifier'])
A.uns['description'] = ('AI-generated t = 0.5 state between CS7 (HuE#1) and CS8 (HuE#2): one pseudo-cell per GG-OT-matched CS7 cell (17,378 = the 15,819 cells of the earlier matrix, unchanged and in the same order, '
    'followed by 1,559 fill-in cells flagged by obs.fill_1559). Fill-in cells are CS7 cells linked in the GG-OT coupling to a CS8 cell shared with other CS7 cells and not recorded as its ancestor; '
    'their CS8 target is that CS8 cell. Same generator weights (5 seeds), latent, decoder and settings for all cells. X = integer counts sampled for generator seed 0 (layers counts_seed1-4 = seeds 1-4). '
    'Position: straight midpoint of the CS7 cell and its CS8 partner(s) in the normalised embryo frame; AP_um/LR_um = fractions x 1,138.3 / 497.5 um.')
save(MD + 't05_AI_V1a.h5ad', lambda f: A.write_h5ad(f, compression='gzip'))
rep['merged'] = dict(n_cells=int(A.n_obs), n_genes=int(A.n_vars), nnz_seed0=int(Xs[0].nnz), existing_block_identical_to_existing_deliverable=bool((abs(Xs[0][:n_old] - Aold.X[:]).sum() == 0)))

# ---------------- checks: new vs existing cells of the same CS7 group
GRP = ['VE2', 'DE', 'AVE']; g_old = T05.cs7_group.values; g_new = NEW.cs7_group.values
rep['counts_new_by_cs7_group'] = pd.Series(g_new).value_counts().to_dict(); rep['counts_existing_by_cs7_group'] = {g: int((g_old == g).sum()) for g in GRP}
rep['new_by_cs7_group_and_cs8_partner_group'] = pd.crosstab(g_new, NEW.dom_cs8_group.values).to_dict('index')
rep['existing_by_cs7_group_and_dom_cs8_group'] = pd.crosstab(g_old[np.isin(g_old, GRP)], T05.dom_cs8_group.values[np.isin(g_old, GRP)]).to_dict('index')
br = np.load(BB + 'bridge.npz', allow_pickle=True); A_o, B_o = br['A'], br['B']; u7 = np.load(V + 'ai/step5_u7.npy'); u8 = np.load(V + 'ai/step5_u8.npy'); Zr = np.load(V + 'ai/step7/rep.npz')['Z']
A_n = Zr[u7[ci]]; B_n = Zr[u8[links.cs8_idx.values]]
def lat(G5, LIN, Aa, Bb):
    dd = np.linalg.norm(G5 - LIN[None], axis=2).mean(0); ab = np.linalg.norm(Bb - Aa, axis=1); return dd, ab
d_o, ab_o = lat(Ho['gen_V1a'], Ho['linear'], A_o, B_o); d_n, ab_n = lat(Hn['gen_V1a'], Hn['linear'], A_n, B_n)
nc_o = np.mean([np.asarray(x.sum(1)).ravel() for x in seeds_old], 0); nc_n = np.mean([np.asarray(x.sum(1)).ravel() for x in seeds_new], 0)
nf_o = np.mean([np.diff(x.indptr) for x in seeds_old], 0); nf_n = np.mean([np.diff(x.indptr) for x in seeds_new], 0)
q = lambda v: '%.2f [%.2f, %.2f]' % tuple(np.percentile(v, [50, 25, 75]))
rows = []
for g in GRP:
    for nm, m, lib, nc, nf, dd, ab in [('existing', g_old == g, lib_old, nc_o, nf_o, d_o, ab_o), ('new (fill-in)', g_new == g, lib_new, nc_n, nf_n, d_n, ab_n)]:
        rows.append(dict(cs7_group=g, set=nm, n=int(m.sum()), library_target_median_IQR=q(lib[m]), decoded_total_counts_median_IQR=q(nc[m]), decoded_genes_detected_median_IQR=q(nf[m]),
                         ratio_decoded_to_target_median=float(np.median(nc[m] / lib[m])), dist_generated_to_linear_midpoint_median_IQR=q(dd[m]), dist_CS7_to_CS8_target_median_IQR=q(ab[m]),
                         dist_generated_to_linear_over_CS7_CS8_dist_median=float(np.median(dd[m] / ab[m]))))
SUM = pd.DataFrame(rows); save(OUT + 'check_group_summary.csv', lambda f: SUM.to_csv(f, index=False)); print(SUM.to_string(), flush=True)
# marker genes: chosen from the observed CS7 counts only (top 8 genes by detection-rate difference, group vs all other CS7 cells; detection in group >= 15%)
X7 = sp.load_npz(WORK + 'X7_observed.npz').tocsr(); X8 = sp.load_npz(WORK + 'X8_observed.npz').tocsr(); D7 = sp.load_npz(V + 'out_gencv/decoder/C7_decoded.npz').tocsr(); D8 = sp.load_npz(V + 'out_gencv/decoder/C8_decoded.npz').tocsr()
l7 = c7.label_short.values; det = lambda Mx, r: np.asarray((Mx[r] > 0).mean(0)).ravel()
anc = pd.read_csv(B + 'figure/final_ggot/ggot_table_cs8_ancestor.csv'); ancm = anc[anc.cls != 'unmatched']; desc = ancm.groupby('ancestor_idx').cs8_idx.apply(np.array)
mk_rows = []
for g in GRP:
    dg = det(X7, np.where(l7 == g)[0]); dr = det(X7, np.where(l7 != g)[0]); sc = np.where(dg >= 0.15, dg - dr, -9); top = np.argsort(-sc)[:8]
    for nm, idx7, part, SD in [('existing', T05.cs7_idx.values[g_old == g], np.concatenate([desc[i] for i in T05.cs7_idx.values[g_old == g]]), [x[g_old == g] for x in seeds_old]),
                               ('new (fill-in)', ci[g_new == g], links.cs8_idx.values[g_new == g], [x[g_new == g] for x in seeds_new])]:
        t5 = np.stack([np.asarray((x > 0).mean(0)).ravel()[top] for x in SD]); o7 = det(X7, idx7)[top]; dc7 = det(D7, idx7)[top]; dc8 = det(D8, part)[top]; o8 = det(X8, part)[top]
        for k, j in enumerate(top):
            mk_rows.append(dict(cs7_group=g, gene=genes[j], observed_CS7_det_group=dg[j], observed_CS7_det_other=dr[j], set=nm, n_cells=len(idx7), CS7_source_observed=o7[k], CS7_source_decoded=dc7[k],
                                t05_decoded_mean5seeds=t5[:, k].mean(), t05_decoded_sd5seeds=t5[:, k].std(), CS8_partners_decoded=dc8[k], CS8_partners_observed=o8[k]))
MK = pd.DataFrame(mk_rows); save(OUT + 'check_marker_detection.csv', lambda f: MK.to_csv(f, index=False))
W = MK.pivot_table(index=['cs7_group', 'gene'], columns='set', values=['CS7_source_decoded', 't05_decoded_mean5seeds', 'CS8_partners_decoded'], sort=False)
pd.set_option('display.width', 250); print((100 * W).round(1).to_string(), flush=True)
lo = np.minimum(MK.CS7_source_decoded, MK.CS8_partners_decoded); hi = np.maximum(MK.CS7_source_decoded, MK.CS8_partners_decoded)
MK['t05_within_endpoint_range_pm5pts'] = (MK.t05_decoded_mean5seeds >= lo - 0.05) & (MK.t05_decoded_mean5seeds <= hi + 0.05)
rep['markers_t05_within_decoded_endpoint_range_pm5pts'] = MK.groupby(['cs7_group', 'set']).t05_within_endpoint_range_pm5pts.agg(lambda x: f'{int(x.sum())}/{len(x)}').unstack().to_dict('index')
ex = MK[MK.set == 'existing'].set_index(['cs7_group', 'gene']); nw = MK[MK.set != 'existing'].set_index(['cs7_group', 'gene'])
rep['markers_max_abs_diff_t05_detection_new_vs_existing_pts'] = (100 * (nw.t05_decoded_mean5seeds - ex.t05_decoded_mean5seeds).abs()).groupby(level=0).max().round(1).to_dict()
rep['latent_noise_sd_new_vs_existing'] = dict(new=float((Hn['gen_V1a'] - Hn['linear'][None]).std()), existing_same_groups=float((Ho['gen_V1a'] - Ho['linear'][None])[:, np.isin(g_old, GRP)].std()))
if clf_ok:
    rep['classifier_call_new_by_cs7_group'] = pd.crosstab(g_new, pred_n).to_dict('index'); rep['classifier_call_existing_same_groups'] = pd.crosstab(g_old[np.isin(g_old, GRP)], pred_o[np.isin(g_old, GRP)]).to_dict('index')
    rep['classifier_call_equals_cs8_partner_label'] = dict(new=float((pred_n == NEW.dom_cs8_group.values).mean()), existing_same_groups=float((pred_o == T05.dom_cs8_group.values)[np.isin(g_old, GRP)].mean()))
save(OUT + 'check_summary.json', lambda f: json.dump(rep, open(f, 'w'), indent=1, default=str)); print(json.dumps(rep, indent=1, default=str), flush=True)
