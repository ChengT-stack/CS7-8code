import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import numpy as np, pandas as pd, anndata as ad, scipy.io, scipy.sparse as sp, h5py, warnings; warnings.filterwarnings('ignore')
B=DATA + '/cs7_cs8_matching/'; OD=B+'staging/layer_rescue/'; rng=np.random.default_rng(0)
COARSE={}
for k in ['EPI','ECT','aECT','pECT','NNE','CLE','Epiblast','NMP','Caudal epiblast','Caudal neurectoderm','Rostral neurectoderm','Forebrain/Midbrain/Hindbrain','Surface ectoderm','Spinal cord','SE1','SE2','FB/MB/HB','SC','1','2','3','4','5','12']: COARSE[k]='EPI'
for k in ['PS','APS','Primitive Streak','Anterior Primitive Streak','15']: COARSE[k]='PS'
for k in ['Nas.Meso','Para.Meso','Rostral.Meso','LP.Meso','Heart.Meso','Heart mesoderm','Adv.Meso','Other.Meso','Caudal.Meso','Nascent Mesoderm','Emergent Mesoderm','Advanced Mesoderm',
          'Caud.Meso','PSM','Inter.Meso','Pharyg.Meso','Cardi.Meso','Cardi.','Rostr.Meso','Mes','16','17','18','19','20','21','22','23','24','25','26','27','28']: COARSE[k]='MESO'
for k in ['Node','Notochord','PrP','Axial Mesoderm','9','10']: COARSE[k]='AXIAL'
for k in ['DE','AVE','ADE','Gut','DE(P)','DE(NP)','35','36','37']: COARSE[k]='DE'
for k in ['VE','VE1','VE2','Hypoblast','38']: COARSE[k]='VE'
def mk(X,genes,obs):
    a=ad.AnnData(sp.csr_matrix(X).astype(np.float32),obs=obs.reset_index(drop=True),var=pd.DataFrame(index=pd.Index(genes).astype(str))); a.var_names_make_unique(); return a
parts=[]
# --- our CosMx embryos (endpoints)
g=pd.read_csv(B+'dataprep/export/genes.csv').gene.values
for s,nm in [('CS7','HuE1_CS7'),('CS8','HuE2_CS8')]:
    M=scipy.io.mmread(B+f'dataprep/export/{s}_counts.mtx').tocsr().T; c=pd.read_csv(B+f'dataprep/export/{s}_cells.csv')
    o=pd.DataFrame({'cell':c.cell.values,'dataset':nm,'batch':'CosMx_human','species':'human','label':c.label_short.values,'mouse_time':np.nan})
    parts.append(mk(M,g,o))
# --- Stereo-seq Cui CS7, Xiao CS8
L=pd.read_csv(B+'external/human_stereoseq/stereoseq_cell_labels.csv').set_index('cell')
for s,nm in [('CS7','Cui_CS7'),('CS8','Xiao_CS8')]:
    a=ad.read_h5ad(f'{DATA}/stereoseq_h5ad/{s}.h5ad'); cells=[v.split('_',1)[1] for v in a.obs_names]
    lab=L.loc[cells].our_group_fine.fillna('exclude').values
    o=pd.DataFrame({'cell':cells,'dataset':nm,'batch':'Stereo_human','species':'human','label':lab,'mouse_time':np.nan})
    parts.append(mk(a.layers['counts'],a.var_names,o))
# --- in-house 10x CS7-15
M=scipy.io.mmread(OD+'inhouse10x_CS7_counts.mtx').tocsr().T; gg=open(OD+'inhouse10x_CS7_genes.txt').read().split('\n')[:M.shape[1]]
c=pd.read_csv(OD+'inhouse10x_CS7_cells.csv'); lab=c.label.str.split().str[0].values
parts.append(mk(M,gg,pd.DataFrame({'cell':[f'inh_{i}' for i in range(len(c))],'dataset':'Inhouse_CS7','batch':'10x_human','species':'human','label':lab,'mouse_time':np.nan})))
# --- Tyser
M=scipy.io.mmread(OD+'tyser_CS7_counts.mtx').tocsr().T; gg=open(OD+'tyser_CS7_genes.txt').read().split('\n')[:M.shape[1]]
c=pd.read_csv(OD+'tyser_CS7_cells.csv')
parts.append(mk(M,gg,pd.DataFrame({'cell':[f'ty_{i}' for i in range(len(c))],'dataset':'Tyser_CS7','batch':'SS2_human','species':'human','label':c.label.values,'mouse_time':np.nan})))
# --- monkey Zhai 2022
D=DATA + '/GSE193007/'; z=np.load(D+'counts_recovered_int.npz'); M=sp.csr_matrix((z['data'],z['indices'],z['indptr']),shape=tuple(z['shape']))
gm=pd.read_csv(D+'genes.csv').iloc[:,0].astype(str).values; gm=np.where(gm=='T','TBXT',gm); m=pd.read_csv(D+'MFE56636-meta.csv')
o=pd.DataFrame({'cell':m['Unnamed: 0'].values,'dataset':'Monkey_'+m['sample'].values,'batch':'10x_monkey','species':'monkey','label':m.cell_type.astype(str).str.strip().values,'mouse_time':np.nan})
parts.append(mk(M,gm,o))
# --- mouse Pijuan-Sala raw counts, orthologs -> human symbols
a=ad.read_h5ad(B+'external/mouse_pijuan_sala/mouse_atlas_mapped_rawcounts.h5ad'); a=a[a.obs.stage.astype(str).str.startswith('E')].copy()
orth=pd.read_csv(B+'external/mouse_pijuan_sala/mouse_human_orthologs_one2one_Ensembl116.csv'); orth=orth[orth.homology_type=='ortholog_one2one']
sym=a.var['symbol'].astype(str).values if 'symbol' in a.var else a.var_names.astype(str).values
mp=dict(zip(orth.mouse_symbol,orth.human_symbol)); keep=[i for i,s in enumerate(sym) if s in mp]
a=a[:,keep].copy(); hs=[mp[sym[i]] for i in keep]
st=a.obs.stage.astype(str).values; o=pd.DataFrame({'cell':a.obs_names.values,'dataset':'Mouse_'+st,'batch':'10x_mouse','species':'mouse','label':a.obs.our_group.astype(str).values,'mouse_time':st.astype(object)})
o['mouse_time']=[float(x[1:]) for x in st]
parts.append(mk(a.X,hs,o))
# --- common genes, coarse groups, subsampling
common=set(parts[0].var_names)
for p in parts[1:]: common&=set(p.var_names)
common=sorted(common); print('common genes',len(common))
out=[]
for p in parts:
    p=p[:,common].copy(); p.obs['group']=p.obs.label.astype(str).map(COARSE)
    p=p[p.obs.group.notna().values].copy()
    out.append(p); print(p.obs.dataset.iloc[0] if p.obs.dataset.nunique()==1 else p.obs.dataset.unique()[:3], p.n_obs)
A=ad.concat(out,join='inner',index_unique=None); A.obs_names=[f'c{i}' for i in range(A.n_obs)]
# subsample mouse to <=3000 per stage, monkey to <=4000 per embryo
keep=np.ones(A.n_obs,bool)
for dsn,ix in A.obs.groupby('dataset').indices.items():
    cap=3000 if dsn.startswith('Mouse') else (4000 if dsn.startswith('Monkey') else None)
    if cap and len(ix)>cap: drop=rng.choice(ix,len(ix)-cap,replace=False); keep[drop]=False
A=A[keep].copy(); A.layers['counts']=A.X.copy()
print(A.shape); print(pd.crosstab(A.obs.dataset,A.obs.group).to_string())
A.write_h5ad('ai/integrated_input.h5ad')
