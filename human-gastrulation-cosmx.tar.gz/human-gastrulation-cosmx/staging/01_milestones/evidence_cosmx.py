# staging/01_milestones/evidence_cosmx.py
# Source: reconstructed from transcript ce4e1bd4
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Milestone evidence review, CosMx HuE#1/HuE#2 (input to audit_calls.py).
# Reconstructed verbatim from session transcript ce4e1bd4 (code was run cell-by-cell in a
# persistent kernel and never saved as a file). Cells are concatenated in execution order;
# inspection-only and figure-polishing cells are omitted, and cells that stopped with an error are
# truncated at the failing line (marked). See PROVENANCE.md.


# ---- cell [frame ce4e1bd4, message 7] Reading workbook rules and CosMx calls
import pandas as pd, os
os.chdir((str(HGC_DATA) + '/milestone_evidence'))
wb='20261030-Fig_milestone_axis_human_monkey_data.xlsx'
x=pd.ExcelFile(wb); print(x.sheet_names)
pd.set_option('display.width',250,'display.max_colwidth',200,'display.max_columns',30)
r=pd.read_excel(wb,'rules'); print(r.to_string())
d=pd.read_excel(wb,'milestone_definitions'); print(d.to_string())
c=pd.read_excel(wb,'milestone_calls'); print(c.columns.tolist()); print(c.shape)


# ---- cell [frame ce4e1bd4, message 10] Printing rules and definitions compactly
for i,row in r.iterrows(): print(i, row['rule'][:600]); print()
print(d.columns.tolist())
for _,row in d.iterrows(): print(' | '.join(str(v)[:120] for v in row.values))


# ---- cell [frame ce4e1bd4, message 12] Reading CosMx calls from workbook
print(c.columns.tolist())
cc=c[c.astype(str).apply(lambda s: s.str.contains('CosMx')).any(axis=1)] if 'dataset' not in c.columns else c[c['dataset'].str.contains('CosMx')]
for _,row in cc.iterrows(): print(' | '.join(str(v)[:300] for v in row.values))


# ---- cell [frame ce4e1bd4, message 14] Listing all CosMx calls and evidence
for _,row in c.iterrows():
    print(row['milestone'],'|',row['mouse_onset'],'\n  HuE1:',row['HuE#1 CS7 (CosMx)'],'::',row['HuE#1 CS7 (CosMx) | evidence'],'\n  HuE2:',row['HuE#2 CS8 (CosMx)'],'::',row['HuE#2 CS8 (CosMx) | evidence'])


# ---- cell [frame ce4e1bd4, message 16] Inspecting CosMx staging workbooks
out=[]
for f in ['mz/Fig_milestone_axis_CS7_CS8_data.xlsx','mz/20261028-CS7_CS8_milestone_staging.xlsx']:
    X=pd.ExcelFile(f); out.append(f'#### {f} {X.sheet_names}')
    for s in X.sheet_names:
        df=pd.read_excel(f,s); out.append(f'== {s} {df.shape}'); out.append(df.to_string(max_colwidth=250))
open('handoff_cosmx_wb.txt','w').write('\n'.join(out)); print(len('\n'.join(out)))


# ---- cell [frame ce4e1bd4, message 41] Loading germ-layer CosMx exports for marker genes
import numpy as np, scipy.sparse as sp
E=(str(HGC_DATA) + '/dataprep/export/')
genes=pd.read_csv(E+'genes.csv').gene.values
G=["MESP1","TBX6","TBXT","GSC","FOXA2","FOXJ1","CHRD","SOX17","CER1","LHX1","NOTO","SHH","HOXA1","HOXB1","NKX1-2","CDX2","HESX1","SIX3","MEOX1","TCF15","EOMES","HOXB8","NKX2-5","TNNT2","MYL7","DPPA3","NANOS3","TFAP2C","PRDM1","SOX2","ETV2","KDR","HAND1","TBX4","HOXA10","HBZ","HBE1","GATA1"]
gidx={g:int(np.where(genes==g)[0][0])+1 for g in G}
D={}
for s in ['CS7','CS8']:
    m=pd.read_csv(E+f'{s}_counts.mtx',sep=' ',comment='%',header=None,names=['g','c','v'],skiprows=2,dtype={'g':np.int32,'c':np.int32,'v':np.int32})
    cells=pd.read_csv(E+f'{s}_cells.csv')
    sub=m[m.g.isin(gidx.values())]
    inv={v:k for k,v in gidx.items()}
    M=sp.coo_matrix((sub.v.values,(sub.c.values-1,sub.g.map({v:i for i,v in enumerate(gidx.values())}).values)),shape=(len(cells),len(G))).toarray()
    X=pd.DataFrame(M,columns=list(gidx.keys())); X['label']=cells.label_short.values; X['nCount']=cells.nCount.values
    X['cell']=cells.cell.values
    D[s]=X; print(s,len(m),X.shape, X.label.value_counts().to_dict())
co7=pd.read_csv((str(HGC_DATA) + '/figure/final_ggot/ggot_cs7_coords.csv'))
co8=pd.read_csv((str(HGC_DATA) + '/figure/final_ggot/ggot_table_cs8_ancestor.csv'))
print((co7.cs7_group.values==D['CS7'].label.values).mean(), (co8.cs8_group.values==D['CS8'].label.values).mean())
D['CS7'][['X','Y']]=co7[['X','Y']].values; D['CS8'][['X','Y']]=co8[['X','Y']].values
# check sanity vs workbook: CS7 PS HOXB1, Node NOTO
for s,t,g in [('CS7','PS','HOXB1'),('CS7','Node','NOTO'),('CS8','Node','NOTO'),('CS7','DE','GSC'),('CS8','PS','EOMES')]:
    X=D[s]; print(s,t,g, round(100*(X.loc[X.label==t,g]>0).mean(),1))


# ---- cell [frame ce4e1bd4, message 43] Loading full-object markers and checking layout
F=pd.read_csv('out_cosmx/_full_object_markers.csv.gz'); F=F[F.kept].reset_index(drop=True)
print(F.shape, F.groupby('stage').size().to_dict())
for s in ['CS7','CS8']:
    X=D[s].set_index('cell'); f=F.set_index('cell').reindex(X.index)
    print(s,'export cells in full:',f.stage.notna().mean(), 'label agree',(f.label.str.extract(r'\(([^)]+)\)$')[0].fillna(f.label).values==X.label.values).mean())
    for g in ['NOTO','HOXB1','GSC']: print('  ',g,'count equal',(f[g].values==X[g].values).mean())
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
fig,ax=plt.subplots(1,2,figsize=(14,6))
for a,s in zip(ax,['CS7','CS8']):
    f=F[F.stage==s]; a.scatter(f.x_um,f.y_um,s=0.2,c=f.disc_main_body.map({True:'r',False:'grey'})); a.set_aspect('equal'); a.set_title(s)
fig.savefig('out_cosmx/_layout_check.png',dpi=80)


# ---- cell [frame ce4e1bd4, message 45] Viewing full-object layout and label mismatches
X=D['CS8'].set_index('cell'); f=F.set_index('cell').reindex(X.index)
lab=f.label.str.extract(r'\(([^)]+)\)$')[0].fillna(f.label)
print(pd.crosstab(lab[lab.values!=X.label.values], X.label[lab.values!=X.label.values]))


# ---- cell [frame ce4e1bd4, message 51] Computing evidence rows for 19 milestones
import re
F['short']=F.label.str.extract(r'\(([^)]+)\)$')[0].fillna(F.label)
FS={s:F[F.stage==s].reset_index(drop=True) for s in ['CS7','CS8']}
DSN={'CS7':'HuE#1 CS7 (CosMx)','CS8':'HuE#2 CS8 (CosMx)'}
MID=['m01','m02','m03','m04','m05','m06','m07','m08','m09','m10','m11','m12','m13','m14','m15','m16','m17','m18','m19']
MNAME=c.milestone.tolist()
FIGCALL={s:dict(zip(MID,c[DSN[s]])) for s in DSN}
VE=['VE1','VE2']; EPROPER_EXCL=['VE1','VE2','AVE']
def pct(X,mask,g): n=int(mask.sum()); return (100*(X.loc[mask,g]>0).mean() if n else np.nan), n
def pco(X,mask,a,b): n=int(mask.sum()); return (100*((X.loc[mask,a]>0)&(X.loc[mask,b]>0)).mean() if n else np.nan), n
def onrule(p,b,n): return (n>=10) and (p-b>=5) and (p>=2*b)
def lostrule(p,b,n): return (n>=10) and (p-b<=3)
rows=[]
def add(s,mid,tp,mask,metric,gene=None,co=None,bgp='EPI',bgmask=None,ref='',note='',X=None,value=None,bgval=None,nb=None):
    X=D[s] if X is None else X
    if value is None:
        if co: v,n=pco(X,mask,*co); 
        else: v,n=pct(X,mask,gene)
        if bgmask is None: bgmask=(X.label=='EPI')
        if co: bv,nb=pco(X,bgmask,*co)
        else: bv,nb=pct(X,bgmask,gene)
        # VE null
        if X is D[s]:
            vm=X.label.isin(VE); vv=(pco(X,vm,*co) if co else pct(X,vm,gene))
        else: vv=(np.nan,0)
    else:
        v=value; n=int(mask.sum()) if mask is not None else 0; bv=bgval; vv=(np.nan,0)
    r=dict(dataset=DSN[s],milestone_id=mid,milestone=MNAME[MID.index(mid)],figure_call=FIGCALL[s][mid],target_population=tp,n_target=n,metric=metric,
           value_target=None if v is None or (isinstance(v,float) and np.isnan(v)) else round(float(v),2),background_population=bgp,n_background=nb,
           value_background=None if bv is None or (isinstance(bv,float) and np.isnan(bv)) else round(float(bv),2),
           null_background_VE_pct=None if np.isnan(vv[0]) else round(vv[0],2), n_VE=vv[1] if vv[1] else None,mouse_reference=ref,note=note)
    rows.append(r); return r
lab=lambda s,*L: D[s].label.isin(L)
for s in ['CS7','CS8']:
    X=D[s]; nall=len(FS[s]); EP=~X.label.isin(EPROPER_EXCL); nep=int(EP.sum())
    # m01
    if s=='CS7':
        add(s,'m01','annotated nascent mesoderm',lab(s,'Nas.Meso'),'cells annotated as nascent mesoderm',value=0,bgval=None,bgp='',ref='mouse Nas.Meso 14.5% of embryo-proper at E7.0 (onset E6.625)')
        for g in ['MESP1','TBX6']: add(s,'m01','PS',lab(s,'PS'),f'{g} detection %',gene=g,ref='mouse Mesp1 98.6% in nascent mesoderm vs 9.3% other')
    else:
        add(s,'m01','Nas.Meso',lab(s,'Nas.Meso'),'Nas.Meso % of embryo-proper cells',value=100*lab(s,'Nas.Meso').sum()/nep,bgp='embryo-proper (export minus VE)',bgval=None,ref='mouse 14.5% E7.0, 19.6% E7.25, 11.4% E7.5, 1.6% E7.75')
        for g in ['MESP1','TBX6']: add(s,'m01','Nas.Meso',lab(s,'Nas.Meso'),f'{g} detection %',gene=g,ref='mouse Mesp1 98.6% in nascent mesoderm vs 9.3% other')
    # m02
    aps='APS' if s=='CS7' else 'PrP'
    if s=='CS7':
        add(s,'m02','APS',lab(s,'APS'),'APS % of embryo-proper cells',value=100*976/nep,bgval=None,bgp='',ref='mouse APS 5.27% E7.0 (max), 3.98% E7.25; onset E6.875')
        for g in ['GSC','FOXA2']: add(s,'m02','APS',lab(s,'APS'),f'{g} detection %',gene=g,ref='mouse APS Gsc 91.7% / Foxa2 81.7% vs 6.9/8.8% other')
        add(s,'m02','APS',lab(s,'APS'),'GSC+FOXA2+ % of APS',co=('GSC','FOXA2'),ref='mouse APS Gsc 91.7% / Foxa2 81.7%')
    else:
        add(s,'m02','APS (not annotated at CS8)',lab(s,'APS'),'cells annotated as APS',value=0,bgval=None,bgp='',ref='mouse APS 1 cell at E7.75 (transient; derivatives persist)')
        for g in ['GSC','FOXA2']: add(s,'m02','PrP (APS derivative)',lab(s,'PrP'),f'{g} detection %',gene=g,ref='mouse APS Gsc 91.7% / Foxa2 81.7% vs 6.9/8.8% other')
        add(s,'m02','Node+Notochord+PrP (APS derivatives)',lab(s,'Node','Notochord','PrP'),'FOXA2 detection %',gene='FOXA2',ref='mouse APS Foxa2 81.7%')
    # m03
    for g in ['FOXJ1','CHRD']: add(s,'m03','Node',lab(s,'Node'),f'{g} detection %',gene=g,ref='mouse notochord Foxj1 90.9% / Chrd 64.2% vs 2.3/1.9%')
    add(s,'m03','Node',lab(s,'Node'),'FOXJ1+CHRD+ % of Node',co=('FOXJ1','CHRD'),ref='')
    pool=lab(s,'PS','APS','Node','Notochord','DE'); k=int(((X.FOXJ1>0)&(X.CHRD>0)&pool).sum())
    bgco=pco(X,lab(s,'EPI'),'FOXJ1','CHRD')[0]
    add(s,'m03','FOXJ1+CHRD+ cells in PS/APS/Node/Notochord/DE',pool,'FOXJ1+CHRD+ cells % of embryo-proper',value=100*k/nep,bgp='expected from EPI co-detection rate x pool',bgval=bgco*pool.sum()/nep,nb=int(lab(s,'EPI').sum()),
        ref='mouse 1.27% E7.0, 1.94% E7.25, 2.40% E7.5 (max); onset threshold 0.60%',note=f'{k} FOXJ1+CHRD+ cells of {int(pool.sum())} pool cells; embryo-proper n={nep}')
    # m04
    add(s,'m04','DE',lab(s,'DE'),'DE % of all kept cells (full object)',value=100*lab(s,'DE').sum()/nall,bgp='',bgval=None,ref='mouse Def. endoderm 0.56% E7.0, 3.49% E7.25, 4.15% E7.5 (max); onset threshold 1.04%',note=f'denominator = {nall} curated kept cells')
    for g in ['FOXA2','SOX17']: add(s,'m04','DE',lab(s,'DE'),f'{g} detection %',gene=g,ref='mouse DE Foxa2 70.8% / Sox17 53.0% vs 8.9/12.9%')
    add(s,'m04','DE',lab(s,'DE'),'FOXA2+SOX17+ % of DE',co=('FOXA2','SOX17'),ref='')
    # m05
    for tp,L in ([('DE',['DE']),('AVE-labelled (=ADE in staging table)',['AVE']),('DE+AVE',['DE','AVE'])] if s=='CS7' else [('DE',['DE'])]):
        add(s,'m05',tp,lab(s,*L),'GSC+CER1+ % of population',co=('GSC','CER1'),ref='mouse Gsc+Cer1+ DE: 0.26% (E7.0), 2.15% (E7.25, max), 0.92% (E7.5), 0.03% (E7.75) of embryo-proper')
        for g in ['GSC','CER1']: add(s,'m05',tp,lab(s,*L),f'{g} detection %',gene=g,ref='mouse DE Gsc 69.7% E7.25 / Cer1 83.6%')
    m=lab(s,'DE','AVE'); k=int(((X.GSC>0)&(X.CER1>0)&m).sum()); bgco=pco(X,lab(s,'EPI'),'GSC','CER1')[0]
    add(s,'m05','GSC+CER1+ cells in DE(+AVE)',m,'GSC+CER1+ DE cells % of embryo-proper',value=100*k/nep,bgp='expected from EPI co-detection rate x DE n',bgval=bgco*m.sum()/nep,nb=int(lab(s,'EPI').sum()),
        ref='mouse 0.26% E7.0, 2.15% E7.25 (max); onset threshold 0.54%',note=f'{k} cells; embryo-proper n={nep}')
    # m06
    add(s,'m06','DE',lab(s,'DE'),'GSC detection %',gene='GSC',ref='mouse DE Gsc 52.5 E7.0, 69.7 E7.25 (peak), 22.6 E7.5, 2.3 E7.75; loss <52.3 (75% of peak), offset E7.375')
    ee=lab(s,'ECT','EPI')
    add(s,'m06','DE',lab(s,'DE'),'GSC detection % (bkg ECT+EPI, as rescue.py)',gene='GSC',bgp='ECT+EPI' if s=='CS7' else 'EPI (no ECT label at CS8)',bgmask=ee,ref='same')
    # m07
    add(s,'m07','Notochord (annotated)',lab(s,'Notochord'),'Notochord % of all kept cells',value=100*lab(s,'Notochord').sum()/nall,bgval=None,bgp='',ref='mouse notochord 10 cells E7.25 (0.07%), 69 E7.5 (0.63%), 140 E7.75',note=f'{int(lab(s,"Notochord").sum())} notochord cells / {nall}')
    for tp,L in [('Node',['Node'])]+([('Notochord',['Notochord'])] if s=='CS8' else []):
        for g in ['NOTO','SHH']: add(s,'m07',tp,lab(s,*L),f'{g} detection %',gene=g,ref='mouse node/notochord Noto 89.9% E7.5; Shh 30.4% E7.5')
    # m08
    for g,ref in [('HOXB1','mouse PS Hoxb1 3.7 E7.25, 10.0 E7.5, 21.9 E7.75; onset thr 5.5%'),('HOXA1','mouse PS Hoxa1 0.8 E7.25, 5.2 E7.5, 15.6 E7.75; onset thr 3.9%')]:
        add(s,'m08','PS',lab(s,'PS'),f'{g} detection %',gene=g,ref=ref)
    # m09
    add(s,'m09','CLE (annotated)',lab(s,'CLE'),'CLE % of all kept cells',value=100*lab(s,'CLE').sum()/nall,bgval=None,bgp='',ref='mouse caudal epiblast 8 cells E7.25, 418 E7.5 (3.8%)',note=f'{int(lab(s,"CLE").sum())} CLE cells')
    if s=='CS8':
        for g in ['NKX1-2','CDX2']: add(s,'m09','CLE',lab(s,'CLE'),f'{g} detection %',gene=g,ref='mouse caudal epiblast Nkx1-2 89.8% / Cdx2 97.2% vs 8.9/31.9%')
    Elay=lab(s,'EPI','ECT','aECT','pECT','NNE','CLE','PS')
    add(s,'m09','ectoderm/epiblast layer (EPI,ECT,aECT,pECT,NNE,CLE,PS)',Elay,'NKX1-2+CDX2+ % of layer',co=('NKX1-2','CDX2'),bgp='VE1+VE2',bgmask=lab(s,'VE1','VE2'),ref='mouse caudal epiblast Nkx1-2 89.8% / Cdx2 97.2%')
    # m10
    tp,L=('aECT',['aECT']) if s=='CS8' else ('ECT (not subdivided)',['ECT'])
    for g in ['HESX1','SIX3']: add(s,'m10',tp,lab(s,*L),f'{g} detection %',gene=g,ref='mouse rostral neurectoderm Hesx1 38.9% / Six3 22.8% vs 5.9/2.5%')
    add(s,'m10',tp,lab(s,*L),'HESX1+SIX3+ % of population',co=('HESX1','SIX3'),ref='')
    # m11
    tp,L=('Para.Meso',['Para.Meso']) if s=='CS8' else ('APS+PS (only mesoderm-like labels at CS7)',['APS','PS'])
    for g in ['MEOX1','TCF15']: add(s,'m11',tp,lab(s,*L),f'{g} detection %',gene=g,ref='mouse paraxial mesoderm Meox1 53.0% / Tcf15 72.1% vs 5.1/10.3%')
    add(s,'m11',tp,lab(s,*L),'MEOX1+TCF15+ % of population',co=('MEOX1','TCF15'),ref='')
    # m12
    add(s,'m12','PS',lab(s,'PS'),'EOMES detection %',gene='EOMES',ref='mouse PS Eomes 89.4 E7.25 (peak), 75.3 E7.5, 54.7 E7.75; loss <67.0, offset E7.625')
    # m13
    if s=='CS8': add(s,'m13','CLE',lab(s,'CLE'),'HOXB8 detection %',gene='HOXB8',ref='mouse caudal epiblast Hoxb8 5.3 E7.5, 52.7 E7.75; onset thr 23.6%')
    ncd=Elay&(X['NKX1-2']>0)&(X.CDX2>0)
    add(s,'m13','NKX1-2+CDX2+ cells (EPI/ECT/PS/CLE layer)',ncd,'HOXB8 detection %',gene='HOXB8',ref='mouse caudal epiblast Hoxb8 5.3 E7.5, 52.7 E7.75; onset thr 23.6%')
    # m14
    if s=='CS8':
        oth=~lab(s,'Heart.Meso')
        for g in ['NKX2-5','TNNT2','MYL7']: add(s,'m14','Heart.Meso',lab(s,'Heart.Meso'),f'{g} detection %',gene=g,bgp='all other germ-layer cells',bgmask=oth,ref='mouse cardiomyocytes Nkx2-5 94.4% / Tnnt2 99.8% (onset E7.875)')
        add(s,'m14','Heart.Meso',lab(s,'Heart.Meso'),'NKX2-5+TNNT2+ % of population',co=('NKX2-5','TNNT2'),bgp='all other germ-layer cells',bgmask=oth,ref='')
    else:
        add(s,'m14','cardiac population',lab(s,'Heart.Meso'),'cells annotated as heart mesoderm / cardiomyocyte (full object)',value=0,bgval=None,bgp='',ref='mouse cardiomyocytes 0 E7.5, 102 E7.75')
        for g in ['NKX2-5','TNNT2']: add(s,'m14','APS+PS (mesoderm-like)',lab(s,'APS','PS'),f'{g} detection %',gene=g,bgp='all other germ-layer cells',bgmask=~lab(s,'APS','PS'),ref='mouse cardiomyocytes Nkx2-5 94.4% / Tnnt2 99.8%')
R=pd.DataFrame(rows); print(len(R)); print(R[['dataset','milestone_id','target_population','n_target','metric','value_target','n_background','value_background','null_background_VE_pct']].to_string())


# ---- cell [frame ce4e1bd4, message 54] Printing compact evidence values
def show(R):
    for _,r in R.iterrows():
        print(r.dataset[:5],r.milestone_id,r.target_population[:28],r.n_target,'|',r.metric[:40],'|',r.value_target,'vs',r.value_background,f'(n={r.n_background})','VE',r.null_background_VE_pct)
show(R)


# ---- cell [frame ce4e1bd4, message 56] Adding extra-embryonic and supplementary rows
for s in ['CS7','CS8']:
    if s=='CS7':
        for g in ['LHX1','CER1']: add(s,'m02','APS',lab(s,'APS'),f'{g} detection % (substitute organiser marker)',gene=g,ref='mouse APS Gsc 91.7% / Foxa2 81.7% (Lhx1/Cer1 not in workbook for APS)')
    else:
        add(s,'m02','PS',lab(s,'PS'),'GSC+FOXA2+ % of PS',co=('GSC','FOXA2'),ref='mouse APS Gsc 91.7% / Foxa2 81.7%')
    # m06 supporting organiser genes in DE
    for g in ['CER1','LHX1']: add(s,'m06','DE',lab(s,'DE'),f'{g} detection % (supporting organiser gene)',gene=g,ref='mouse DE Cer1 82.0 E7.0 -> 79.3 E7.75; Lhx1 79.3 E7.25 -> 50.2 E7.5')
    # m12 TBXT+ pool as rescue
    Xs=D[s]; tb=Xs.label.isin(['EPI','ECT','aECT','pECT','NNE','CLE','PS','APS','Nas.Meso','Para.Meso','Rostral.Meso','LP.Meso','Heart.Meso'])&(Xs.TBXT>0)
    add(s,'m12','TBXT+ cells in ectoderm/epiblast+mesoderm layers (rescue pool)',tb,'EOMES detection %',gene='EOMES',bgp='VE1+VE2 (rescue.py background)',bgmask=lab(s,'VE1','VE2'),ref='mouse TBXT+ embryonic cells Eomes 86.2 E7.25, 39.6 E7.5, 9.3 E7.75')
    add(s,'m08','TBXT+ cells in ectoderm/epiblast+mesoderm layers (rescue pool)',tb,'HOXB1 detection %',gene='HOXB1',bgp='VE1+VE2 (rescue.py background)',bgmask=lab(s,'VE1','VE2'),ref='mouse PS Hoxb1 onset threshold 5.5%')
# rescue best subclusters (cited, not recomputed)
rb=pd.read_csv('mz/rescue/recluster_best_subclusters.csv')
for _,q in rb[rb.dataset.str.contains('CosMx')&rb.milestone.isin(['Neural plate (rostral neurectoderm)','Paraxial mesoderm forms'])].iterrows():
    s='CS7' if 'CS7' in q.dataset else 'CS8'; mid='m10' if 'Neural' in q.milestone else 'm11'
    for mk,vb,vp in [('marker1','m1_best','m1_pool'),('marker2','m2_best','m2_pool')]:
        rows.append(dict(dataset=q.dataset,milestone_id=mid,milestone=MNAME[MID.index(mid)],figure_call=FIGCALL[s][mid],target_population=f'best re-clustered subcluster (n={q.best_sub_n}; {q.best_top_labels})',n_target=int(q.best_sub_n),
            metric=f'{q[mk]} detection % (from mz/rescue/recluster_best_subclusters.csv; cited, not recomputed)',value_target=q[vb],background_population=f'layer pool {q.pool_layers}',n_background=int(q.pool_n),value_background=q[vp],
            mouse_reference=f'mouse module z of best subcluster {q.mod_z}',note=f'module z {q.mod_z}, marker fold-enrichment {q.marker_fe}'))
# extra-embryonic from full object
mt=pd.read_excel('mz/20261028-CS7_CS8_milestone_staging.xlsx','mouse_celltype_counts').set_index('celltype')
tot=mt.sum()
def mpct(ct,st): return 100*mt.loc[ct,st]/tot[st]
print({st:round(tot[st]) for st in tot.index})
EX=[('m15',['PGC'],'PGC',[('DPPA3','mouse PGC Dppa3 56.9% vs 1.9%'),('NANOS3','mouse PGC Nanos3 28.8% vs 0.4%'),('TFAP2C',''),('SOX17',''),('PRDM1','')],'PGC'),
    ('m16',['Endothelium','Hema'],'Endothelium+Hema',[('ETV2','mouse HE progenitors Etv2 88.1% vs 14.8%'),('KDR','mouse Kdr 83.0% vs 6.1%'),('CDH5',''),('TAL1',''),('RUNX1','')],'Haematoendothelial progenitors'),
    ('m17',['ys.Meso','ChA.Mes','Exe.Meso progenitor','Am.Mes'],'ExE mesoderm (ys.Meso+ChA.Mes+Exe.Meso progenitor+Am.Mes)',[('HAND1','mouse ExE mesoderm Hand1 80.6% vs 25.5%')],'ExE mesoderm'),
    ('m18',['Al.Mes'],'Al.Mes',[('TBX4','mouse allantois Tbx4 31.6% vs 0.4%'),('HOXA10','mouse Hoxa10 79.3% vs 2.3%')],'Allantois'),
    ('m19',['Primitive erythroblast'],'Primitive erythroblast',[('HBZ','mouse Erythroid1 Hba-x 99.6% vs 22.9%'),('HBE1',''),('GATA1','mouse Gata1 92.2% vs 9.1%')],'Erythroid1')]
for s in ['CS7','CS8']:
    Xf=FS[s]
    for mid,L,tp,gl,mct in EX:
        msk=Xf.short.isin(L); n=int(msk.sum())
        ms=', '.join(f'{st} {mpct(mct,st):.2f}%' for st in ['E7.0','E7.25','E7.5','E7.75','E8.0'])
        add(s,mid,tp,msk,'population % of all kept cells',X=Xf,value=100*n/len(Xf),bgp='all kept cells',bgval=None,ref=f'mouse {mct} % of all cells: {ms}',note=f'{n} of {len(Xf)} kept cells')
        for g,ref in gl:
            r=add(s,mid,tp,msk,f'{g} detection %',gene=g,X=Xf,bgp='all other kept cells (same embryo)',bgmask=~msk,ref=ref)
        if mid in('m15','m18','m19','m16'):
            a,b={'m15':('DPPA3','NANOS3'),'m16':('ETV2','KDR'),'m18':('TBX4','HOXA10'),'m19':('HBZ','GATA1')}[mid]
            add(s,mid,tp,msk,f'{a}+{b}+ % of population',co=(a,b),X=Xf,bgp='all other kept cells (same embryo)',bgmask=~msk,ref='')
    # Al.Endo extra row
    msk=Xf.short.isin(['Al.Endo'])
    for g in ['TBX4','HOXA10']: add(s,'m18','Al.Endo',msk,f'{g} detection %',gene=g,X=Xf,bgp='all other kept cells (same embryo)',bgmask=~msk,ref='')
R=pd.DataFrame(rows); show(R[R.milestone_id.isin(['m02','m06','m08','m12','m10','m11','m15','m16','m17','m18','m19'])&(R.index>=90)])


# ---- cell [frame ce4e1bd4, message 58] Assigning verdicts and writing evidence CSV
V={('CS7','m01'):('reached','yes','MESP1 21.3% / TBX6 30.3% in PS vs EPI 6.6/4.7% (onset rule met); no separate Nas.Meso label.'),
('CS7','m02'):('reached (annotation + LHX1/CER1 only)','partly','APS annotated (976 cells, 7.0% of embryo-proper; mouse max 5.3%), but the defining markers are not enriched: GSC 13.3% vs EPI 11.2%, FOXA2 5.9% vs 6.8%; organiser genes LHX1 33.9% vs 9.4% and CER1 25.3% vs 4.0% are enriched (substitute markers).'),
('CS7','m03'):('reached','yes','FOXJ1+CHRD+ 27.4% of Node vs 0.38% EPI; 1.33% of embryo-proper vs mouse onset threshold 0.60%.'),
('CS7','m04'):('reached','yes','DE 2.56% of all kept cells (mouse threshold 1.04%); SOX17 15.3% vs EPI 5.4%, FOXA2 11.9% vs 6.8%.'),
('CS7','m05'):('borderline reached','partly','GSC+CER1+ 2.55% of DE vs 0.41% EPI (6x), but only 0.40% of embryo-proper with DE alone (mouse threshold 0.54%); 0.57% only if the 371 AVE-labelled cells (export label "Anterior visceral endoderm", called ADE in 20261028 table) are counted as DE. rescue.py co-expression test not significant (O/E 1.33, P=0.12).'),
('CS7','m06'):('not reached','yes','GSC in DE 14.2% vs ECT+EPI 8.7% (+5.5 pts: still on; rescue rule lost if <=3 pts); CER1 10.2% vs 4.0%, LHX1 19.9% vs 9.4% still on. Fragile: vs EPI alone the gap is exactly 3.0 pts.'),
('CS7','m07'):('not reached','yes','No notochord label; Node NOTO 5.5% vs EPI 3.9% (off; mouse 89.9%).'),
('CS7','m08'):('not reached','yes','HOXB1 in PS 5.5% vs EPI 5.8%; HOXA1 3.6% vs 2.7%; TBXT+ pool HOXB1 6.7% vs VE 3.9% (off).'),
('CS7','m09'):('not reached','yes','No CLE label; NKX1-2+CDX2+ 0.20% of ectoderm/epiblast layer (20 cells) vs VE 0.32%.'),
('CS7','m10'):('not assessable','yes','ECT HESX1 4.1% / SIX3 2.6% are below EPI (7.7/4.3%); best re-clustered subcluster 13.7/8.8% vs CS8 aECT subcluster 11.7/5.2% -> markers do not separate the embryos.'),
('CS7','m11'):('not assessable','yes','No paraxial label; APS+PS MEOX1 1.7% / TCF15 5.6% vs EPI 3.2/8.4%; best subcluster (n=36) 8.3/11.1% vs CS8 5.7/13.2%. Same-platform positive control fails, so not assessable rather than not reached.'),
('CS7','m12'):('not reached','yes','EOMES in PS 14.6% vs VE null 5.6% (still on; TBXT+ pool 15.1% vs 5.6%). Background-dependent: vs EPI (11.7%) the gap is 2.9 pts, which the <=3-pt loss rule would score as lost.'),
('CS7','m13'):('not reached','yes','No CLE; HOXB8 0/20 NKX1-2+CDX2+ cells (EPI 3.8%).'),
('CS7','m14'):('not reached','yes','No cardiac label in germ-layer export or full object; NKX2-5 6.4% / TNNT2 1.6% in APS+PS at background.'),
('CS7','m15'):('annotated, weak marker support','partly','PGC 53 cells (0.06% of kept cells; mouse 0.24% E7.0); NANOS3 9.4% vs 5.0%, PRDM1 9.4% vs 4.2%, TFAP2C 5.7% vs 2.5%, DPPA3 7.5% vs 7.3%; no marker meets the onset rule (+5 pts and 2x). DPPA3+NANOS3+ 1/53 cells.'),
('CS7','m16'):('reached','yes','Endothelium+Hema 3,498 cells; KDR 30.4% vs 3.6%, CDH5 14.4% vs 4.5%; ETV2 3.4% vs 2.8% (uninformative on CosMx).'),
('CS7','m17'):('reached','yes','ExE mesoderm 20,983 cells; HAND1 37.6% vs 11.8%.'),
('CS7','m18'):('not supported by markers (annotation only)','no','Al.Mes 564 cells, but TBX4 4.6% vs 3.75% and HOXA10 3.7% vs 3.4% (background); TBX4+HOXA10+ 3/564. Al.Endo TBX4 5.4%, HOXA10 5.1%. Mouse onset E7.625 is later than the CS7 disc window.'),
('CS7','m19'):('reached','yes','Primitive erythroblast 4,701 cells (5.6%); HBZ 97.3% vs 10.2%, HBE1 99.0% vs 7.3%; GATA1 1.4% vs 1.7% is at background (GATA1 uninformative on CosMx).'),
('CS8','m01'):('reached','yes','Nas.Meso 2,143 cells (7.7% of embryo-proper); TBX6 32.5% vs EPI 4.7%; MESP1 6.5% vs 5.5% is not enriched.'),
('CS8','m02'):('reached (indirect)','yes','APS no longer annotated (transient; mouse 1 cell at E7.75); APS derivatives present: Node 493, Notochord 508, PrP 588; PrP FOXA2 16.5% vs 4.35%, GSC 9.5% vs 5.5%.'),
('CS8','m03'):('reached','yes','FOXJ1+CHRD+ 27.2% of Node vs 0.20% EPI; 0.78% of embryo-proper (threshold 0.60%).'),
('CS8','m04'):('reached','yes','DE 1.74% of kept cells; FOXA2 18.3% vs 4.35%, SOX17 10.0% vs 3.7%.'),
('CS8','m05'):('not observable (ADE already regressed); reached by inference only','partly','GSC+CER1+ 1/1505 DE cells (0.07%) vs EPI 0.10%; 0.00% of embryo-proper. Reached is inferred from m06; the in-house 10x embryo with the same pattern was called "not assessable".'),
('CS8','m06'):('reached','yes','GSC in DE 6.05% vs EPI 5.51% (+0.5 pts, lost); CER1 2.9% vs 2.2%, LHX1 8.0% vs 5.0%.'),
('CS8','m07'):('reached','yes','Notochord 508 cells (0.59% of kept cells; mouse E7.5 0.63%); NOTO 10.4% vs EPI 3.5% (onset rule met); Node NOTO 28.6%.'),
('CS8','m08'):('reached','yes','HOXB1 in PS 18.2% vs EPI 5.4%; HOXA1 12.9% vs 7.2%; TBXT+ pool HOXB1 16.6% vs VE 3.2%.'),
('CS8','m09'):('reached (annotation; markers just below rule)','partly','CLE 2,351 cells (2.7%; mouse E7.5 3.8%); NKX1-2 17.1% vs EPI 9.3% (1.84x), CDX2 21.1% vs 10.7% (1.97x) - both +>5 pts but below the 2x criterion; NKX1-2 5x over VE (3.4%). NKX1-2+CDX2+ 1.77% of layer vs VE 0.66% (2.7x; rescue requires 3x).'),
('CS8','m10'):('not assessable','no','aECT HESX1 5.95% vs EPI 4.19%, SIX3 4.54% vs 2.67% (<2 pts above background); HESX1+SIX3+ 0.43%; best subcluster 11.7/5.2% is lower than CS7 (13.7/8.8%). The criterion that made HuE#1 not assessable applies equally; the reached call rests on the aECT annotation.'),
('CS8','m11'):('not assessable','no','Para.Meso MEOX1 5.6% vs EPI 2.8%, TCF15 5.9% vs 4.3% (onset rule not met); best subcluster 5.7/13.2% vs CS7 8.3/11.1%. Same argument as HuE#1; reached rests on the Para.Meso annotation. Window unchanged (EOMES off, E7.625, still reached).'),
('CS8','m12'):('reached','yes','EOMES in PS 5.3% vs EPI 5.2% / VE 4.5% (lost); TBXT+ pool 6.1% vs VE 4.5%.'),
('CS8','m13'):('not reached','yes','HOXB8 in CLE 3.4% vs EPI 3.2%; 4.7% in 253 NKX1-2+CDX2+ cells (mouse onset 23.6%).'),
('CS8','m14'):('not reached','yes','Heart.Meso 267 cells: NKX2-5 7.9% vs 4.6% other cells (mouse cardiomyocytes 94.4%), TNNT2 5.6% vs 1.7%, MYL7 18.0% vs 3.6%; NKX2-5+TNNT2+ 0/267.'),
('CS8','m15'):('reached','yes','PGC 218 cells (0.25%); NANOS3 30.7% vs 3.5%, TFAP2C 12.8% vs 1.35%, DPPA3 16.5% vs 5.9%.'),
('CS8','m16'):('reached','yes','Endothelium+Hema 5,238 cells; KDR 34.9% vs 4.7%, RUNX1 12.7% vs 3.8%; ETV2 at background (3.4% vs 2.8%).'),
('CS8','m17'):('reached','yes','ExE mesoderm 16,383 cells; HAND1 50.1% vs 14.5%.'),
('CS8','m18'):('reached','yes','Al.Mes 1,485 cells; TBX4 8.3% vs 3.2% (onset rule met), HOXA10 6.8% vs 3.2% (2.1x); TBX4+HOXA10+ 1.41% vs 0.21%.'),
('CS8','m19'):('reached','yes','Primitive erythroblast 11,010 cells (12.7%); HBZ 98.8%, HBE1 99.96% vs 12.5/14.6%; GATA1 3.1% vs 1.7% (weak).')}
R=pd.DataFrame(rows)
sk=R.dataset.map({v:k for k,v in DSN.items()})
R['recomputed_call']=[V[(a,b)][0] for a,b in zip(sk,R.milestone_id)]
R['supports_figure_call']=[V[(a,b)][1] for a,b in zip(sk,R.milestone_id)]
R['milestone_verdict_note']=[V[(a,b)][2] for a,b in zip(sk,R.milestone_id)]
R['note']=(R.note.fillna('')+'; '+R.milestone_verdict_note).str.strip('; ')
R=R.drop(columns='milestone_verdict_note')
R['source']=np.where(R.milestone_id.isin(['m15','m16','m17','m18','m19']),'full curated object obj6_obj7_merged_curated_v3.rds (curated_kept)','germ-layer export dataprep/export')
R.loc[R.metric.str.contains('cited, not recomputed'),'source']='mz/rescue/recluster_best_subclusters.csv'
R['_o']=R.milestone_id.map(MID.index); R['_d']=R.dataset.map({DSN['CS7']:0,DSN['CS8']:1})
R=R.sort_values(['_d','_o'],kind='stable').drop(columns=['_o','_d'])
cols=['dataset','milestone_id','milestone','figure_call','target_population','n_target','metric','value_target','background_population','n_background','value_background','mouse_reference','recomputed_call','supports_figure_call','note','null_background_VE_pct','n_VE','source']
R=R[cols]; R.to_csv('out_cosmx/evidence_cosmx.csv',index=False)
print(R.shape, R.groupby('dataset').milestone_id.nunique().to_dict())
print(R.drop_duplicates(['dataset','milestone_id']).groupby(['dataset','supports_figure_call']).size())
