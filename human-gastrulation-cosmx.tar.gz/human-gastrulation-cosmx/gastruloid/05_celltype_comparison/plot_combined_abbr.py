# gastruloid/05_celltype_comparison/plot_combined_abbr.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/plot_combined_abbr.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Combined figure: milestone staging (left block) and embryonic cell types versus the stage-matched CosMx embryo (right block); seven samples on shared rows.
# Data and calls are those of plot_stage_cs78_mini.py (staging) and celltypes_mini.py / cm_common.py (cell types); only the layout is new.
import numpy as np, pandas as pd, matplotlib as mpl, matplotlib.pyplot as plt, matplotlib.font_manager as fm, glob, shutil
from matplotlib.patches import Rectangle, Patch
from matplotlib.lines import Line2D
g1 = dict(globals()); _s = open(Path(__file__).resolve().parent / 'plot_stage_cs78_mini.py').read(); exec(_s[:_s.index('def draw(LAND, name):')], g1)   # staging data and geometry
g2 = dict(globals()); exec(open(Path(__file__).resolve().parent / 'cm_common.py').read(), g2)                                                          # cell-type data and geometry
for f_ in glob.glob(os.environ.get('HGC_FONTS', 'fonts') + '/arial*.ttf'): fm.fontManager.addfont(f_)
assert any(f_.name == 'Arial' for f_ in fm.fontManager.ttflist); mpl.rcParams.update({'font.family': 'Arial', 'pdf.fonttype': 42, 'svg.fonttype': 'none'})
OUT = 'gall/out_v2/'; LGS, R, INFO, MSO, mp, sl, sr, BAR, rows, sp_, MT, ST = [g1[k] for k in ('LGS', 'R', 'INFO', 'MSO', 'mp', 'sl', 'sr', 'BAR', 'rows', 'sp_', 'MT', 'ST')]
C1, MUT, SCOL, SLAB, SL, SHORT, DS, SO, SETL, meta1, UNITS, EMBS, HS1 = [g1[k] for k in ('COL', 'MUT', 'SCOL', 'SLAB', 'SL', 'SHORT', 'DS', 'SO', 'SETL', 'meta', 'UNITS', 'EMBS', 'HS')]
SM, TY, tp, bl, br, TT, D, C2, PRES, MARK, MISS, ONE, BLOCKS = [g2[k] for k in ('SM', 'TY', 'tp', 'bl', 'br', 'TT', 'D', 'COL', 'PRES', 'MARK', 'MISS', 'ONE', 'BLOCKS')]
assert g2['sp_'] == sp_ and g2['UNITS'] == UNITS and g2['EMBS'] == EMBS and all(g2['STG'][u] == R.stage[u] for u in UNITS)   # both blocks use the same rows and the same stage calls
MAB = {'m01': 'Nas.Meso: Mesp1+ onset', 'm02': 'APS: Gsc+Foxa2+ onset', 'm03': 'Node: Foxj1+Chrd+ onset', 'm04': 'DE: Foxa2+Sox17+ onset', 'm06': 'AVE: Gsc regression', 'm07': 'Notochord: Noto+ onset', 'm08': 'PS: Hoxa1+/Hoxb1+ onset',
       'm12': 'PS: Eomes loss', 'm13': 'CLE: Hoxb8+ onset', 'm14': 'CM: Nkx2-5+Tnnt2+ onset', 'm05': 'AVE: Gsc+Cer1+ onset', 'm09': 'CLE: Nkx1-2+Cdx2+ onset', 'm10': 'NP: Hesx1+Six3+ onset', 'm11': 'Para.Meso: Meox1+Tcf15+ onset'}; assert set(MAB) == set(MSO)
ABM = {'EPI': 'EPI', 'aECT': 'ECT/aECT', 'pECT': 'pECT', 'NNE': 'NNE', 'CLE': 'CLE', 'PS': 'PS', 'APS': 'APS', 'Node': 'Node', 'Notochord': 'Notochord', 'PrP': 'PrP', 'Nas.Meso': 'Nas.Meso', 'Para.Meso': 'Para.Meso',
       'Rostral.Meso': 'Rostral.Meso', 'LP.Meso': 'LP.Meso', 'Heart.Meso': 'Heart.Meso', 'DE': 'DE', 'ADE': 'AVE', 'VE': 'VE'}; assert list(ABM) == TY   # the embryo type keyed ADE in the tables is displayed as AVE
dsz = lambda p: (2.0 + 6.0 * np.sqrt(min(p, 60) / 60)) ** 2   # dot area (pt^2) from the share of embryonic-type cells
cw, rh = 0.125, 0.135; x0 = 1.15; SW = 1.16; MW = 0.56; top = 0.3; hdr = 1.56; bot = 0.82
xA = x0; wA = MT * cw; xB = xA + wA + SW; wB = TT * cw; W = xB + wB + MW; H = top + hdr + ST * rh + bot
fig = plt.figure(figsize=(W, H)); axA = fig.add_axes([xA / W, bot / H, wA / W, ST * rh / H]); axA.set_xlim(0, MT); axA.set_ylim(ST, 0); axB = fig.add_axes([xB / W, bot / H, wB / W, ST * rh / H]); axB.set_xlim(0, TT); axB.set_ylim(ST, 0)
# ---- left block: milestones and stage ----
for u, d in rows:
    st = LGS[LGS.unit == u].set_index('milestone_id').state
    for m in MSO:
        s = st[m]
        if s in C1 or s in MUT: axA.add_patch(Rectangle((mp[m] + 0.05, sp_[u] + 0.05), 0.9, 0.9, fc=C1.get(s, MUT.get(s)), ec='none'))
        else: axA.add_patch(Rectangle((mp[m] + 0.09, sp_[u] + 0.09), 0.82, 0.82, fc='white', ec='#C8C8C8' if not s.startswith('not used') else '#E2E2E2', lw=0.4))
    if R.most_advanced_set[u] in BAR: axA.plot([BAR[R.most_advanced_set[u]]] * 2, [sp_[u] + 0.02, sp_[u] + 0.98], color='black', lw=1.4, solid_capstyle='butt', clip_on=False)
for u, k in zip(EMBS, BAR): axA.plot([BAR[k]] * 2, [sp_[u] + 1.0, ST], color='#555555', lw=0.6, ls=(0, (3, 2)), zorder=0)
axA.set_xticks([mp[m] + 0.5 for m in MSO]); axA.set_xticklabels([f"{m[1:]}  {MAB[m]}" for m in MSO], rotation=90); axA.xaxis.tick_top(); axA.tick_params(length=0, pad=14)
for lab_, m in zip(axA.get_xticklabels(), MSO):
    if meta1.milestone_set[m] == 'unused': lab_.set_color('#888888')
for k in SO:
    axA.plot([sl[k] + 0.1, sr[k] - 0.1], [-0.2, -0.2], color='#555555' if k != 'unused' else '#AAAAAA', lw=0.6, clip_on=False); axA.text((sl[k] + sr[k]) / 2, -0.34, SETL[k], ha='center', va='bottom', fontsize=5, color='#333333' if k != 'unused' else '#888888', clip_on=False)
axA.text(-0.4, -0.34, 'Reached in CosMx embryo', ha='right', va='bottom', fontsize=5, color='#333333', clip_on=False)
axA.set_yticks([sp_[u] + 0.5 for u, d in rows]); axA.set_yticklabels(['CS7 (CosMx)', 'CS8 (CosMx)'] + [SL[g] for g in UNITS]); xl = -(x0 - 0.08) / cw
axA.text(xl, (sp_[EMBS[0]] + sp_[EMBS[1]] + 1) / 2, 'Human\nembryos', ha='left', va='center', fontsize=6, clip_on=False, linespacing=1.0)
for d in DS:
    gs = [g for g in UNITS if INFO.dataset[g] == d]; axA.text(xl, (sp_[gs[0]] + sp_[gs[-1]] + 1) / 2, SHORT[d].split(' ')[0], ha='left', va='center', fontsize=6, clip_on=False)
xs_ = MT + 0.7
for u, d in rows:
    c = R.stage[u]; axA.add_patch(Rectangle((xs_, sp_[u] + 0.12), 0.82, 0.76, fc=SCOL[c], ec='none', clip_on=False)); axA.text(xs_ + 1.15, sp_[u] + 0.52, SLAB.get(c, c), ha='left', va='center', fontsize=6, clip_on=False)
axA.text(xs_, -0.5, 'Stage', ha='left', va='bottom', fontsize=6, clip_on=False)
# ---- right block: cell types versus the reference embryo ----
for u, d in rows:
    for t in TY:
        s = D.loc[(u, t), 'state']
        if s in (MISS, ONE): axB.add_patch(Rectangle((tp[t] + 0.05, sp_[u] + 0.05), 0.9, 0.9, fc=C2[s], ec='none'))
        else: axB.add_patch(Rectangle((tp[t] + 0.09, sp_[u] + 0.09), 0.82, 0.82, fc='white', ec='#C8C8C8', lw=0.4))
        if s in (PRES, 'present'): axB.scatter([tp[t] + 0.5], [sp_[u] + 0.5], s=dsz(D.loc[(u, t), 'pct_embryonic']), color=C2['embryo'] if u in EMBS else C2[PRES], linewidths=0, zorder=3)
        elif s == MARK: axB.scatter([tp[t] + 0.5], [sp_[u] + 0.5], s=3.6 ** 2, facecolors='white', edgecolors=C2[PRES], linewidths=0.7, zorder=3)
axB.set_xticks([tp[t] + 0.5 for t in TY]); axB.set_xticklabels([ABM[t] for t in TY], rotation=90); axB.xaxis.tick_top(); axB.tick_params(length=0, pad=14); axB.set_yticks([])
for b in BLOCKS: axB.plot([bl[b] + 0.1, br[b] - 0.1], [-0.2, -0.2], color='#555555', lw=0.6, clip_on=False); axB.text((bl[b] + br[b]) / 2, -0.34, {'Epiblast and ectoderm': 'Epiblast, ectoderm', 'Streak and axial mesoderm': 'Streak, axial'}.get(b, b), ha='center', va='bottom', fontsize=5, color='#333333', clip_on=False)
xm = TT + 1.9
for u in UNITS: axB.text(xm, sp_[u] + 0.52, f'{int(SM.n_missing[u])} of {int(SM.n_expected[u])}', ha='center', va='center', fontsize=6, color=C2[MISS] if int(SM.n_missing[u]) else '#333333', clip_on=False)
axB.text(xm, -0.5, 'Missing', ha='center', va='bottom', fontsize=6, clip_on=False)
for a_ in (axA, axB):
    for spn in a_.spines.values(): spn.set_visible(False)
# ---- titles, keys ----
lo, hi = int(SM.n_missing.min()), int(SM.n_missing.max()); ytl = (bot + ST * rh + hdr - 0.1) / H
fig.text(0.02, 1 - 0.1 / H, f'Samples staged against the CosMx embryos still lack {lo} to {hi} embryonic cell types of their reference embryo', fontsize=7, ha='left', va='top')
fig.text(xA / W, ytl, 'Developmental milestones', fontsize=6, ha='left', va='top', fontweight='bold'); fig.text(xB / W, ytl, 'Embryonic cell types versus the reference embryo', fontsize=6, ha='left', va='top', fontweight='bold')
HS2 = [Line2D([0], [0], marker='o', ls='none', mfc=C2[PRES], mec='none', ms=5, label='present (annotated population)'), Line2D([0], [0], marker='o', ls='none', mfc='white', mec=C2[PRES], mew=0.7, ms=3.6, label='marker-defined cells only'),
       Line2D([0], [0], marker='o', ls='none', mfc=C2['embryo'], mec='none', ms=5, label='embryo: present'), Patch(fc=C2[MISS], label='absent, present in the reference embryo'), Patch(fc=C2[ONE], label='absent, present in only one embryo'), Patch(fc='white', ec='#C8C8C8', lw=0.4, label='absent, not expected')]
HZ = [Line2D([0], [0], marker='o', ls='none', mfc='#888888', mec='none', ms=np.sqrt(dsz(p)), label=l) for p, l in [(1, '1%'), (10, '10%'), (50, '50%')]]
kw = dict(frameon=False, fontsize=5, handlelength=1.0, columnspacing=1.4, labelspacing=0.45, borderaxespad=0.0, borderpad=0.0)
legA = fig.legend(handles=HS1, loc='lower left', bbox_to_anchor=(0.02, 0.22 / H), ncol=2, handleheight=1.0, **kw); legB = fig.legend(handles=HS2, loc='lower left', bbox_to_anchor=((xB - 0.05) / W, 0.22 / H), ncol=2, handleheight=1.0, **kw)
legZ = fig.legend(handles=HZ, loc='upper left', bbox_to_anchor=(xB / W, ytl - 0.2 / H), ncol=3, handleheight=2.2, handletextpad=0.8, title='Dot area: share of embryonic-type cells', title_fontsize=5, alignment='left', **kw)
fig.text(0.02, 0.05 / H, 'Reference embryo: CS7 for CS7-like samples; CS8 for CS8-like and beyond-CS8 samples; cell types present in both embryos for transitional samples.', fontsize=5, ha='left', va='bottom')
name = 'Fig_gastruloid_stage_and_celltypes_combined'
for ext in ('png', 'pdf', 'svg'): fig.savefig(OUT + name + '.' + ext, dpi=300)
shutil.copy(OUT + name + '.pdf', OUT + name + '.ai')   # PDF-compatible .ai
fig.canvas.draw(); r = fig.canvas.get_renderer(); texts = [(t, t.get_window_extent(r)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
ov = [(a.get_text()[:25], b.get_text()[:25]) for i, (a, ba) in enumerate(texts) for b, bb in texts[i + 1:] if ba.overlaps(bb)]; outb = [t.get_text()[:30] for t, bb in texts if not (bb.x0 >= 0 and bb.y0 >= 0 and bb.x1 <= fig.bbox.x1 and bb.y1 <= fig.bbox.y1)]
lg = [l.get_window_extent(r) for l in (legA, legB, legZ)]; axb = [a_.get_window_extent(r) for a_ in (axA, axB)]; tlb = [t.get_window_extent(r) for t in axB.get_xticklabels()]
print(name, round(W, 2), round(H, 2), 'overlaps', len(ov), ov[:8], 'outside', outb[:8], 'legend-legend', lg[0].overlaps(lg[1]), 'legend over axes', any(l.overlaps(a_) for l in lg for a_ in axb), 'size key over labels', any(lg[2].overlaps(b) for b in tlb), 'legends inside', all(l.x1 <= fig.bbox.x1 and l.y0 >= 0 for l in lg))
