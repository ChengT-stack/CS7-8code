# Fill-in generation for the 1,559 GG-OT-matched CS7 cells without a generated state.
# usage:  python fill_generate.py gate       -> reproducibility gate on the existing 15,819 cells (writes gate_result.json next to this script only)
#         python fill_generate.py generate   -> requires a passed gate, re-checks it, then generates and decodes the 1,559 new cells into OUT
# No training. Same weights (rotation-0 fine-tuned networks, 5 seeds), same latent (rep.npz), same decoder, same settings as the existing outputs.
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
GEN_ROOT = os.environ.get('HGC_GEN_ROOT', '.')   # generative working directory (original ai_t05_v153 layout)
import os, sys, json, time, numpy as np, pandas as pd, scipy.sparse as sp, scipy.io, torch, torch.nn as nn
PHASE = sys.argv[1]; assert PHASE in ('gate', 'generate')
V = GEN_ROOT + '/'; AIO = DATA + '/ai_t05/'; B = DATA + '/cs7_cs8_matching/'; BB = DATA + '/bridge_bundle/'
OUT = V + 'out_gencv/human_fill_1559/'; WORK = os.environ.get('FILLWORK', os.path.dirname(os.path.abspath(__file__))) + '/'
dev = 'cuda'; t00 = time.time(); TOL = 1e-5
def log(*a): print(*a, flush=True)
if PHASE == 'generate':
    assert json.load(open(WORK + 'gate_result.json'))['pass'], 'run the gate first; it must pass'
    assert not os.path.exists(OUT), 'output directory already exists'

# ---------------- inputs (all read-only)
R = np.load(V + 'ai/step7/rep.npz', allow_pickle=True); Z = R['Z']; d = Z.shape[1]
u7 = np.load(V + 'ai/step5_u7.npy'); u8 = np.load(V + 'ai/step5_u8.npy')
T05 = pd.read_csv(V + 'ai/step5_human_t05_index.csv')                                   # the 15,819 existing rows, existing order
TALL = pd.read_csv(B + 'figure/final_ggot/ggot_table_t05_pseudocells.csv')               # all 17,378 matched CS7 cells
anc = pd.read_csv(B + 'figure/final_ggot/ggot_table_cs8_ancestor.csv'); ancm = anc[anc.cls != 'unmatched']
z_ = np.load(BB + 'M_ref.npz'); M = sp.csr_matrix((z_['data'], z_['indices'], z_['indptr']), shape=tuple(z_['shape'])); M.sort_indices()
assert M.shape == (len(u7), len(u8)) and set(np.unique(M.data)) == {1.0}
CFG = json.load(open(V + 'ai/step7/final_v2_orig/generator_config.json'))['config']
V1A = json.load(open(V + 'out_gencv/V1a_config_ref.json')); HUM_D, HUM_TA = V1A['human_D_days'], V1A['human_t_CS7']
assert (HUM_D, HUM_TA) == (0.375, 7.25) and V1A['generation_fraction'] == 0.5
H = np.load(V + 'out_gencv/rot0_human_t05_latent.npz'); GV1_saved = H['gen_V1a']; LIN_saved = H['linear']
TR = np.load(AIO + 'out_trajectory/human_traj_12fr_v153.npz'); FR = TR['fr']; TRG = TR['gen']; assert TRG.shape == (5, 12, len(T05), d)
EX = V + 'out_gencv/human_rot0_V1a/'
lib05_saved = np.load(V + 'out_gencv/cache_lib05.npy')

# ---------------- partner lists
old_idx = T05.cs7_idx.values; n_old = len(old_idx)
assert set(TALL.cs7_idx) == set(np.where(np.diff(M.indptr) > 0)[0])
new_tab = TALL[~TALL.cs7_idx.isin(set(old_idx))].reset_index(drop=True); new_idx = new_tab.cs7_idx.values; n_new = len(new_idx)
rows = lambda i: M.indices[M.indptr[i]:M.indptr[i + 1]]
# existing rule (rep.py): descendants = CS8 cells whose single recorded ancestor (ancestor table) is this CS7 cell; target = unweighted mean latent
desc_old = ancm.groupby('ancestor_idx').cs8_idx.apply(np.array).reindex(old_idx)
assert all(np.array_equal(np.sort(dv), rows(i)) for i, dv in zip(old_idx, desc_old.values)), 'M rows != ancestor-table descendants for existing cells'
assert not set(new_idx) & set(ancm.ancestor_idx)                                          # new cells are nobody's recorded ancestor
part_new = [rows(i) for i in new_idx]
log('existing', n_old, 'new', n_new, 'partners per new cell', np.bincount([len(p) for p in part_new]))
B_old = np.stack([Z[u8[dv]].mean(0) for dv in desc_old.values]).astype(np.float32)      # same expression as rep.py
B_new = np.stack([Z[u8[p]].mean(0) for p in part_new]).astype(np.float32)               # same rule applied to the M-row partners
hia_old = u7[old_idx]; hia_new = u7[new_idx]
assert np.array_equal(hia_old, H['h_a'])
br = np.load(BB + 'bridge.npz', allow_pickle=True)
gate = dict(B_recomputed_vs_bundle_maxabs=float(np.abs(B_old - br['B']).max()), A_vs_bundle_maxabs=float(np.abs(Z[hia_old] - br['A']).max()))

# ---------------- model (definitions copied from ai/step5_lib.py mlp and out_gencv/gencv_lib.py NetF / gnet / gen_human)
def mlp(i, o, h, L, drop, act=nn.SiLU):
    layers = []; dd = i
    for _ in range(L): layers += [nn.Linear(dd, h), act(), nn.Dropout(drop)]; dd = h
    layers += [nn.Linear(dd, o)]; return nn.Sequential(*layers)
class NetF(nn.Module):
    def __init__(s, d, h, Ly, drop, sig_init):
        super().__init__(); s.f = mlp(2 * d + 3, 2 * d, h, Ly, drop); s.d = d
    def forward(s, lin, dlt, D, ta, fr):
        o = s.f(torch.cat([lin, dlt, D[:, None], ta[:, None] - 7.5, fr[:, None] - 0.5], 1)); return o[:, :s.d], o[:, s.d:].clamp(-6, 2)
def _full(n, v): return torch.full((n,), float(v), device=dev)
def gnet(net, A, Bp, D, ta, fr, eps):
    lin = (1 - fr) * A + fr * Bp; n = len(A)
    mu, ls = net(lin, Bp - A, _full(n, D), _full(n, ta), _full(n, fr))
    return lin + 1.0 * (CFG['ds'] * mu + CFG['ns'] * torch.exp(ls) * eps)
Zt = torch.tensor(Z, device=dev)
A_old = Zt[torch.as_tensor(hia_old, device=dev)]; Bt_old = torch.as_tensor(B_old, device=dev, dtype=torch.float32)
A_new = Zt[torch.as_tensor(hia_new, device=dev)]; Bt_new = torch.as_tensor(B_new, device=dev, dtype=torch.float32)
LIN_old = (0.5 * (A_old + Bt_old)).cpu().numpy(); LIN_new = (0.5 * (A_new + Bt_new)).cpu().numpy()
gate['linear_vs_saved_maxabs'] = float(np.abs(LIN_old - LIN_saved).max())
def load_net(s):
    net = NetF(d, CFG['h'], CFG['L'], CFG['drop'], CFG['sig_init']).to(dev)
    net.load_state_dict(torch.load(V + f'out_gencv/weights/rot0_V1a_seed{s}.pt', map_location=dev)); net.eval(); return net
@torch.no_grad()
def noise(s):
    """Original: torch.manual_seed(seed); eps = randn_like(A) for the 15,819 cells. Here one seeded draw for 17,378 rows (existing cells first);
    its first 15,819 rows are checked to equal the original draw, and the remaining 1,559 rows are the noise of the new cells."""
    torch.manual_seed(s); e_old = torch.randn_like(A_old)
    torch.manual_seed(s); e_all = torch.randn(n_old + n_new, d, device=dev)
    assert torch.equal(e_all[:n_old], e_old), 'noise stream is not prefix-consistent'
    return e_old, e_all[n_old:]
SAMPLE = np.sort(np.random.default_rng(0).choice(n_old, 500, replace=False))            # random sample of 500 existing cells for the gate report

# ---------------- decoder (copied from out_gencv/gencv_lib.py Dec / human_v153.py dec)
class Dec(nn.Module):
    def __init__(s, d, G, h, Ly, drop):
        super().__init__(); s.net = mlp(d, G, h, Ly, drop); s.logth = nn.Parameter(torch.zeros(G))
    def forward(s, z, loglib): return torch.softmax(s.net(z), 1) * torch.exp(loglib)[:, None], torch.exp(s.logth)
D_ = torch.load(V + 'out_gencv/decoder/decoder.pt', map_location=dev, weights_only=False); p_ = D_['params']; GENES = list(D_['genes'])
dec_m = Dec(d, len(GENES), p_['h'], p_['L'], p_['drop']).to(dev); dec_m.load_state_dict(D_['state']); dec_m.eval()
@torch.no_grad()
def dec_cont(z, ll):
    """human_v153.py dec() loop without the reseed: continues the current RNG stream."""
    out = []
    for k in range(0, len(z), 2048):
        mu, th = dec_m(torch.tensor(z[k:k + 2048], device=dev, dtype=torch.float32), torch.tensor(np.log(ll[k:k + 2048]), device=dev, dtype=torch.float32))
        r = torch.distributions.Gamma(th.expand_as(mu), th.expand_as(mu) / mu.clamp_min(1e-8)).sample(); out.append(sp.csr_matrix(torch.poisson(r).cpu().numpy()))
    return sp.vstack(out).tocsr()
def sdiff(a, b):
    dlt = (a - b).tocsr(); dlt.eliminate_zeros(); return int(dlt.nnz), (float(np.abs(dlt.data).max()) if dlt.nnz else 0.0)

# ---------------- library sizes (step5_decoder.py: lib05 = sqrt(lib_CS7 x mean lib of CS8 partners))
libf = WORK + 'lib_cache.npz'
if os.path.exists(libf): L_ = np.load(libf); lib7, lib8 = L_['lib7'], L_['lib8']
else:
    X7 = scipy.io.mmread(B + 'dataprep/export/CS7_counts.mtx').tocsr().T.tocsr().astype(np.float32); X8 = scipy.io.mmread(B + 'dataprep/export/CS8_counts.mtx').tocsr().T.tocsr().astype(np.float32)
    lib = np.asarray(sp.vstack([X7, X8]).tocsr().sum(1)).ravel(); lib7, lib8 = lib[:X7.shape[0]], lib[X7.shape[0]:]
    np.savez(libf, lib7=lib7, lib8=lib8); sp.save_npz(WORK + 'X7_observed.npz', X7); sp.save_npz(WORK + 'X8_observed.npz', X8)
lib7 = lib7.astype(np.float64); lib8 = lib8.astype(np.float64)                             # float64 reproduces the saved library sizes exactly
lib05_old = np.array([np.sqrt(lib7[i] * lib8[dv].mean()) for i, dv in zip(old_idx, desc_old.values)])
lib05_new = np.array([np.sqrt(lib7[i] * lib8[p].mean()) for i, p in zip(new_idx, part_new)])
gate['lib05_recomputed_vs_saved_maxabs'] = float(np.abs(lib05_old - lib05_saved).max()); gate['lib05_dtype'] = [str(lib05_old.dtype), str(lib05_saved.dtype)]
log('inputs ready', round(time.time() - t00), 's', gate)

# ---------------- gate / generation
per_seed = []; GEN_new = []; TRAJ_new = []; DEC_new = []
for s in range(5):
    net = load_net(s); e_old, e_new = noise(s)
    with torch.no_grad():
        g_old = gnet(net, A_old, Bt_old, HUM_D, HUM_TA, 0.5, e_old).cpu().numpy()
        tr_old = np.stack([gnet(net, A_old, Bt_old, HUM_D, HUM_TA, float(f), e_old).cpu().numpy().astype(np.float32) for f in FR])
    dl = np.abs(g_old - GV1_saved[s]); dt = np.abs(tr_old - TRG[s])
    torch.manual_seed(10 + s); dc_old = dec_cont(GV1_saved[s], lib05_saved)                  # exactly the original call: saved latent, saved library, seed 10+s
    saved_dc = sp.load_npz(EX + f't05_gen_seed{s}_decoded.npz').tocsr(); nd, md = sdiff(dc_old, saved_dc); nds, mds = sdiff(dc_old[SAMPLE], saved_dc[SAMPLE])
    rec = dict(seed=s, latent_t05_maxabs_all=float(dl.max()), latent_t05_maxabs_sample500=float(dl[SAMPLE].max()), traj12_maxabs_all=float(dt.max()), traj12_maxabs_sample500=float(dt[:, SAMPLE].max()),
               decoded_n_entries_differing_all=nd, decoded_maxabs_all=md, decoded_n_entries_differing_sample500=nds, decoded_maxabs_sample500=mds,
               decoded_total_counts_rerun=float(dc_old.sum()), decoded_total_counts_saved=float(saved_dc.sum()))
    per_seed.append(rec); log(rec)
    if PHASE == 'generate':
        assert rec['latent_t05_maxabs_all'] <= TOL and rec['traj12_maxabs_all'] <= TOL and nd == 0, 'gate failed - no new cells generated'
        with torch.no_grad():
            g_new = gnet(net, A_new, Bt_new, HUM_D, HUM_TA, 0.5, e_new).cpu().numpy().astype(np.float32)
            tr_new = np.stack([gnet(net, A_new, Bt_new, HUM_D, HUM_TA, float(f), e_new).cpu().numpy().astype(np.float32) for f in FR])
        GEN_new.append(g_new); TRAJ_new.append(tr_new)
        DEC_new.append(dec_cont(g_new, lib05_new))                                           # continuation of the seed-(10+s) stream after the 15,819 existing cells
torch.manual_seed(99); dl_old = dec_cont(LIN_saved, lib05_saved); ndl, mdl = sdiff(dl_old, sp.load_npz(EX + 't05_linear_decoded.npz').tocsr())
gate.update(linear_decoded_n_entries_differing=ndl, linear_decoded_maxabs=mdl, per_seed=per_seed, sample500_first10=SAMPLE[:10].tolist(), torch=torch.__version__, gpu=torch.cuda.get_device_name(0))
gate['pass'] = bool(all(r['latent_t05_maxabs_all'] <= TOL and r['traj12_maxabs_all'] <= TOL and r['decoded_n_entries_differing_all'] == 0 for r in per_seed) and ndl == 0
                    and gate['B_recomputed_vs_bundle_maxabs'] <= 1e-6 and gate['linear_vs_saved_maxabs'] <= 1e-6 and gate['lib05_recomputed_vs_saved_maxabs'] <= 1e-9)
log('GATE PASS' if gate['pass'] else 'GATE FAIL', round(time.time() - t00), 's')
if PHASE == 'gate':
    json.dump(gate, open(WORK + 'gate_result.json', 'w'), indent=1); sys.exit(0)

# ---------------- write outputs for the 1,559 new cells (new directory only; never overwrites)
assert gate['pass']
import anndata as ad
os.makedirs(OUT, exist_ok=False)
def save(path, fn):
    assert path.startswith(OUT) and not os.path.exists(path); fn(path)
DL_new = dec_cont(LIN_new, lib05_new)                                                    # continuation of the seed-99 stream
GEN_new = np.stack(GEN_new); TRAJ_new = np.stack(TRAJ_new)
save(OUT + 'fill_human_t05_latent.npz', lambda f: np.savez_compressed(f, gen_V1a=GEN_new, linear=LIN_new, h_a=hia_new, cs7_idx=new_idx))
save(OUT + 'human_traj_12fr_fill.npz', lambda f: np.savez_compressed(f, gen=TRAJ_new, fr=FR, h_a=hia_new, cs7_idx=new_idx))
save(OUT + 'cache_lib05_fill.npy', lambda f: np.save(f, lib05_new))
for s, Dm in enumerate(DEC_new): save(OUT + f't05_gen_seed{s}_decoded.npz', lambda f, Dm=Dm: sp.save_npz(f, Dm))
save(OUT + 't05_linear_decoded.npz', lambda f: sp.save_npz(f, DL_new))
save(OUT + 'fill_t05_index.csv', lambda f: new_tab.to_csv(f, index=False))
c7 = pd.read_csv(BB + 'CS7_cells.csv'); c8 = pd.read_csv(BB + 'CS8_cells.csv'); ncs7 = np.diff(M.tocsc().indptr)
assert (anc.cs8_idx.values == np.arange(len(anc))).all()
links = pd.DataFrame([dict(cs7_idx=i, cs7_cell=c7.cell.values[i], cs7_group=c7.label_short.values[i], cs8_idx=j, cs8_cell=c8.cell.values[j], cs8_group=c8.label_short.values[j],
                           n_cs7_cells_linked_to_this_cs8=int(ncs7[j]), recorded_ancestor_cs7_idx=int(anc.ancestor_idx.values[j])) for i, p in zip(new_idx, part_new) for j in p])
save(OUT + 'fill_partner_links.csv', lambda f: links.to_csv(f, index=False))
o = new_tab.copy(); o['library'] = lib05_new; o.index = o.index.astype(str)
T = ad.AnnData(DEC_new[0].astype(np.float32), obs=o, var=pd.DataFrame(index=GENES)); T.obsm['X_rep'] = GEN_new[0]
T.uns['description'] = ('AI-generated CS7-CS8 t=0.5 pseudo-cells for the 1,559 GG-OT-matched CS7 cells that had no generated state (fill-in): same rotation-0 fine-tuned generator (5 seeds), '
                        'same 153-embryo latent and same NB-MLP decoder as human_rot0_V1a; CS8 target = latent of the CS8 cell linked to the CS7 cell in the GG-OT coupling; seed 0 sample.')
save(OUT + 't05_AI_generated_counts.h5ad', lambda f: T.write_h5ad(f))
gate['n_new'] = int(n_new); gate['new_by_cs7_group'] = new_tab.cs7_group.value_counts().to_dict(); gate['new_by_dom_cs8_group'] = new_tab.dom_cs8_group.value_counts().to_dict()
save(OUT + 'gate_result.json', lambda f: json.dump(gate, open(f, 'w'), indent=1))
log('written', sorted(os.listdir(OUT)), round(time.time() - t00), 's')
