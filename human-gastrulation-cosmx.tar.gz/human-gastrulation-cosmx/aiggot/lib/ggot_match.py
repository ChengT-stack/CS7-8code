"""Generic GG-OT matcher: works on any pair of snapshots given expression features, normalised
disc coordinates (AP_arc_frac, LR_frac, DV_gap_units) and cell-type labels.

match(E7, E8, S7, S8, g7, g8, a, b, trans, space="gated"|"euclid", gate=..., prior=bool, ...)
  -> dict(M=star matching (csr, n7 x n8), parent=array (n8,), C=cost, info=...)
"""
import numpy as np, pandas as pd, scipy.sparse as ssp
from scipy.spatial import cKDTree
import ggot, starmatch as SM

PEN = {"direct": 0.0, "allowed": 0.5, "indirect": 1.0, "penalised": 3.0}
STREAK_TYPES = ("PS", "APS", "Node")
DEFAULTS = dict(tau=0.0, reverse=1000.0, h=None, h_scale=1.0, layer_cost={"M": 0.25}, k_space=100, k_expr=50, k_keep=40,
                eps=0.1, tau_sk=3.0, K=5, c_unmatched=4.0, delta=0.25, grid_step=20.0)


def knn_pairs(Xa, Xb, k):
    k = min(k, len(Xb)); _, j = cKDTree(Xb).query(Xa, k=k, workers=16)
    return np.repeat(np.arange(len(Xa)), k), np.asarray(j).reshape(-1)


def prune(R, C, v, k):
    df = pd.DataFrame(dict(r=R, c=C, v=v)).sort_values("v")
    keep = np.union1d(df.groupby("r").head(k).index, df.groupby("c").head(k).index)
    return R[keep], C[keep], v[keep]


def to_um(S):
    return np.c_[S[:, 0] * ggot.AP_SPAN, S[:, 1] * ggot.LR_SPAN]


def gate_from_score(grid, P_list, score_list, layer_list, sigma_um=40.0, q=90, w_rel=0.4, support=0.05):
    """gate = logistic((F - q-th percentile of F) / (w_rel * sd F)), F = smoothed score of E/M/X cells
    computed per snapshot and averaged; zero where either snapshot has little tissue support."""
    fs, sp = [], []
    for P, sc, L in zip(P_list, score_list, layer_list):
        m = np.isin(L, ["E", "M", "X"]); f, Ng = grid.smooth_mean(P[m], sc[m], sigma_um); fs.append(f); sp.append(Ng)
    F = np.nanmean(np.stack(fs), 0); Fz = np.nan_to_num(F, nan=np.nanmin(F))
    g = 1 / (1 + np.exp(-(Fz - np.nanpercentile(F, q)) / (w_rel * max(np.nanstd(F), 1e-9))))
    S = np.minimum.reduce(sp); return np.where(S > support * S.max(), g, 0.0)


def gate_from_labels(grid, P_list, g_list, layer_list, **kw):
    """annotation-based gate: local fraction of streak-annotated cells (PS/APS/Node)."""
    scores = [np.isin(g, STREAK_TYPES).astype(float) for g in g_list]
    return gate_from_score(grid, P_list, scores, layer_list, **kw)


def match(E7, E8, S7, S8, g7, g8, a, b, trans, space="gated", gate=None, prior=False, grid=None, occ=None,
          return_graph=False, **kw):
    p = dict(DEFAULTS); p.update(kw)
    g7 = np.asarray(g7).astype(str); g8 = np.asarray(g8).astype(str)
    lay7 = np.array([ggot.LAYER_OF[x] for x in g7]); lay8 = np.array([ggot.LAYER_OF[x] for x in g8])
    se = SM.knn_scale(np.vstack([E7, E8])); ss = SM.knn_scale(np.vstack([S7, S8]))
    Y7 = np.hstack([E7 / se, S7 / ss]); Y8 = np.hstack([E8 / se, S8 / ss])
    r1, c1 = knn_pairs(Y7, Y8, p["k_space"]); c2, r2 = knn_pairs(Y8, Y7, p["k_space"])
    r3, c3 = knn_pairs(E7 / se, E8 / se, p["k_expr"]); c4, r4 = knn_pairs(E8 / se, E7 / se, p["k_expr"])
    n8 = len(g8)
    key = np.unique(np.concatenate([r1, r2, r3, r4]).astype(np.int64) * n8 + np.concatenate([c1, c2, c3, c4]))
    R = (key // n8).astype(np.int64); C = (key % n8).astype(np.int64)
    dE = ((E7[R] / se - E8[C] / se) ** 2).sum(1); dS = ((S7[R] / ss - S8[C] / ss) ** 2).sum(1)
    same = lay7[R] == lay8[C]; direct = g7[R] == g8[C]
    graph = None
    if space == "gated":
        grid = grid or ggot.Grid(step_um=p["grid_step"])
        gate = np.ones((grid.nx, grid.ny)) if gate is None else gate
        P7, P8 = to_um(S7), to_um(S8)
        if occ is None:
            occ = ggot.occupancy(grid, {L: np.vstack([P7[lay7 == L], P8[lay8 == L]]) for L in ggot.LAYERS})
        gt = {k: gate for k in ggot.H_DEFAULT}
        hh = {k: v * p["h_scale"] for k, v in (p["h"] or ggot.H_DEFAULT).items()}
        G, nid = ggot.build_graph(grid, occ, gt, h=hh, tau=p["tau"], layer_cost=p["layer_cost"], reverse=p["reverse"])
        D, pred = ggot.all_pairs(G)
        m7 = ggot.node_of(grid, nid, P7, lay7); m8 = ggot.node_of(grid, nid, P8, lay8)
        Dd = D[m7[R], m8[C]].astype(float)
        s2 = np.median(Dd[same] ** 2) / np.median(dS[same]); sp = Dd ** 2 / s2
        if return_graph:
            nxy = np.zeros((G.shape[0], 2)); nl = np.zeros(G.shape[0], int)
            for li in range(len(ggot.LAYERS)):
                ii, jj = np.where(nid[li] >= 0); nxy[nid[li, ii, jj]] = np.c_[grid.x[ii], grid.y[jj]]; nl[nid[li, ii, jj]] = li
            graph = dict(D=D, pred=pred, m7=m7, m8=m8, nxy=nxy, nl=nl, grid=grid, occ=occ)
    else:
        sp = dS
    raw = dE + sp; ref = direct if direct.any() else np.ones_like(direct)
    raw = raw / np.median(raw[ref])
    if prior:
        raw = raw + np.array([PEN[trans.get((x, y), "penalised")] for x, y in zip(g7[R], g8[C])])
    r_, c_, w_ = prune(R, C, raw, p["k_keep"])
    Cm = ssp.csr_matrix((w_, (r_, c_)), shape=(len(g7), n8))
    res = SM.run_matching(None, None, None, None, g7, g8, a, b, trans, C=Cm, scales={}, eps=p["eps"], tau=p["tau_sk"],
                          K=p["K"], c_unmatched=p["c_unmatched"], delta=p["delta"])
    M = res["M"].tocsr(); par = -np.ones(n8, int); coo = M.tocoo(); par[coo.col] = coo.row
    return dict(M=M, parent=par, C=Cm, summary=res["summary"], graph=graph)
