# gastruloid/05_celltype_comparison/cm_common.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/cm_common.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Shared data and helpers for the draft figures "embryonic cell types missing at the matched stage" (seven samples)
import numpy as np, pandas as pd, matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Patch
from matplotlib.lines import Line2D
import matplotlib.colors as mcolors
OUT = 'gall/out_v2/'; apply_figure_style(sizes=(7, 6, 5))
T = pd.read_csv(OUT + 'celltypes_mini_long.csv'); SM = pd.read_csv(OUT + 'celltypes_mini_missing_by_sample.csv', index_col=0).fillna('')
EMBS = ['Human embryo CS7 (CosMx)', 'Human embryo CS8 (CosMx)']; UNITS = ['Ham_0h', 'Ham_24h', 'Ham_48h', 'Ham_72h', 'Ham_96h', 'Hee_42', 'Liu_PG_d11']; ALLU = EMBS + UNITS
GRP = dict(zip(ALLU, ['embryo', 'embryo'] + ['Hamazaki'] * 5 + ['Heemskerk', 'Liu'])); TL = dict(zip(ALLU, ['CS7 (CosMx)', 'CS8 (CosMx)', '0 h', '24 h', '48 h', '72 h', '96 h', '42 h', 'd11']))
FULL = {u: (TL[u] if GRP[u] == 'embryo' else f'{GRP[u]} {TL[u]}') for u in ALLU}; STG = {EMBS[0]: 'CS7-like', EMBS[1]: 'CS8-like', **SM.stage.to_dict()}
TY = list(T.drop_duplicates('type').type); meta = T.drop_duplicates('type').set_index('type'); BLOCKS = list(meta.block.drop_duplicates()); D = T.set_index(['unit', 'type'])
AB = {'EPI': 'EPI', 'aECT': 'ECT', 'pECT': 'pECT', 'NNE': 'NNE', 'CLE': 'CLE', 'PS': 'PS', 'APS': 'APS', 'Node': 'Node', 'Notochord': 'Noto', 'PrP': 'PrP', 'Nas.Meso': 'Nas', 'Para.Meso': 'Para', 'Rostral.Meso': 'Rost', 'LP.Meso': 'LP', 'Heart.Meso': 'Heart', 'DE': 'DE', 'ADE': 'ADE', 'VE': 'VE'}
PRES, MARK, MISS, ONE, NOEXP = 'present (annotated population)', 'present (marker-defined cells only)', 'absent, present in the reference embryo', 'absent, present in one of the two embryos', 'absent, not expected'
COL = {PRES: '#1F5FA8', MARK: '#9CC3E6', MISS: '#D55E00', ONE: '#F5CBAA', 'embryo': '#4D4D4D'}
SCOL = {'CS7-like': '#CBC9E2', 'CS7-to-CS8 transitional': '#9E9AC8', 'CS8-like': '#6A51A3', 'beyond CS8': '#3F007D'}; SLAB = {'CS7-to-CS8 transitional': 'CS7–CS8 transitional'}
sp_ = {}; cur = 0.0; prev = None
for u in ALLU:   # same sample spacing as the compact staging figure
    if prev is not None and GRP[u] != prev: cur += 0.45 if prev != 'embryo' else 0.8
    sp_[u] = cur; cur += 1; prev = GRP[u]
ST = cur; tp = {}; cur = 0.0; prev = None; bl, br = {}, {}
for t in TY:
    b = meta.block[t]
    if prev is not None and b != prev: cur += 0.5
    if b != prev: bl[b] = cur
    tp[t] = cur; cur += 1; br[b] = cur; prev = b
TT = cur
def state(u, t): return D.loc[(u, t), 'state']
def audit(fig, name):
    fig.canvas.draw(); r = fig.canvas.get_renderer(); texts = [(t, t.get_window_extent(r)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
    ov = [(a.get_text()[:22], b.get_text()[:22]) for i, (a, ba) in enumerate(texts) for b, bb in texts[i + 1:] if ba.overlaps(bb)]; outb = [t.get_text()[:30] for t, bb in texts if not (bb.x0 >= 0 and bb.y0 >= 0 and bb.x1 <= fig.bbox.x1 and bb.y1 <= fig.bbox.y1)]
    print(name, [round(v, 2) for v in fig.get_size_inches()], 'overlaps', len(ov), ov[:6], 'outside', outb[:6])
def save(fig, name):
    for ext in ('png', 'pdf', 'svg'): fig.savefig(OUT + name + '.' + ext, dpi=300)
    audit(fig, name)
