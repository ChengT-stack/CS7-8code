# gastruloid/01_preprocess/prep_group.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/code/prep_group.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Load groups (one or more ids), light QC (>=500 genes, <=20% mitochondrial UMI), sub-cluster, save counts + labels.
import sys, json, time; sys.path.insert(0, str(Path(__file__).resolve().parent)); sys.path.insert(0, str(Path(__file__).resolve().parents[1] / '02_milestone_scoring'))
import stage_lib as L, loaders as LD, anndata as ad, numpy as np
for gid in sys.argv[1:]:
    t0 = time.time(); g = LD.G[gid]; a = g['load']()
    info = dict(group=gid, dataset=g['dataset'], species=g['species'], label=g['label'], hours=g['hours'], series=g['series'], order=g['order'], genes_in_matrix=int(a.n_vars))
    ham = g['dataset'] == 'Hamazaki 2024'   # authors' objects are already filtered (>=500 genes, <=20% mt); no further filtering
    b, qi = L.qc(a, g['species'], min_genes=0 if ham else 500, max_mt=100.0 if ham else 20.0); info.update(qi)
    b.obs['sub'], b.obsm['X_umap'] = L.subcl(b)
    info.update(median_umi=float(b.obs.n_umi.median()), median_genes=float(b.obs.n_genes.median()), n_sub15=int((b.obs['sub'].value_counts() >= 15).sum()), seconds=round(time.time() - t0))
    b.write_h5ad(f'gall/groups/{gid}.h5ad'); json.dump(info, open(f'gall/groups/{gid}.json', 'w')); print(json.dumps(info), flush=True)
