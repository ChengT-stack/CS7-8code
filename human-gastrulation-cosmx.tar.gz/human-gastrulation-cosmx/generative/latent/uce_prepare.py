# Build per-dataset raw-count AnnData (full native gene panels) for the same 134,343 cells used in step 1.
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import numpy as np, pandas as pd, anndata as ad, scipy.io, scipy.sparse as sp, warnings; warnings.filterwarnings('ignore')
B=DATA + '/cs7_cs8_matching/'; OD=B+'staging/layer_rescue/'; OUT=DATA + '/UCE/inputs/'
ref=ad.read_h5ad('ai/integrated_input.h5ad',backed='r'); RO=ref.obs[['cell','dataset','group']].copy(); RO['uid']=RO.index
def save(X,genes,cells,dsn,species,fname):
    X=sp.csr_matrix(X); a=ad.AnnData(X.astype(np.float32),obs=pd.DataFrame(index=pd.Index(cells).astype(str)),var=pd.DataFrame(index=pd.Index(genes).astype(str)))
    a.var_names_make_unique()
    r=RO[RO.dataset.isin(dsn)].copy(); r['cell']=r.cell.astype(str)
    key=dict(zip(a.obs_names,range(a.n_obs))); idx=[key[c] for c in r.cell]
    a=a[idx].copy(); a.obs_names=r.uid.values; a.obs['dataset']=r.dataset.values; a.obs['group']=r.group.values
    a.X.data=np.round(a.X.data); a.write_h5ad(OUT+fname); print(fname,species,a.shape,flush=True)
g=pd.read_csv(B+'dataprep/export/genes.csv').gene.values
for s,nm in [('CS7','HuE1_CS7'),('CS8','HuE2_CS8')]:
    M=scipy.io.mmread(B+f'dataprep/export/{s}_counts.mtx').tocsr().T; c=pd.read_csv(B+f'dataprep/export/{s}_cells.csv')
    save(M,g,c.cell.values,[nm],'human',f'{nm}.h5ad')
for s,nm in [('CS7','Cui_CS7'),('CS8','Xiao_CS8')]:
    a=ad.read_h5ad(f'{DATA}/stereoseq_h5ad/{s}.h5ad'); cells=[v.split('_',1)[1] for v in a.obs_names]
    save(a.layers['counts'],a.var_names,cells,[nm],'human',f'{nm}.h5ad')
M=scipy.io.mmread(OD+'inhouse10x_CS7_counts.mtx').tocsr().T; gg=open(OD+'inhouse10x_CS7_genes.txt').read().split('\n')[:M.shape[1]]
save(M,gg,[f'inh_{i}' for i in range(M.shape[0])],['Inhouse_CS7'],'human','Inhouse_CS7.h5ad')
M=scipy.io.mmread(OD+'tyser_CS7_counts.mtx').tocsr().T; gg=open(OD+'tyser_CS7_genes.txt').read().split('\n')[:M.shape[1]]
save(M,gg,[f'ty_{i}' for i in range(M.shape[0])],['Tyser_CS7'],'human','Tyser_CS7.h5ad')
D=DATA + '/GSE193007/'; z=np.load(D+'counts_recovered_int.npz'); M=sp.csr_matrix((z['data'],z['indices'],z['indptr']),shape=tuple(z['shape']))
gm=pd.read_csv(D+'genes.csv').iloc[:,0].astype(str).values; m=pd.read_csv(D+'MFE56636-meta.csv')
save(M,gm,m['Unnamed: 0'].values,[d for d in RO.dataset.unique() if d.startswith('Monkey')],'macaca_fascicularis','Monkey.h5ad')
a=ad.read_h5ad(B+'external/mouse_pijuan_sala/mouse_atlas_mapped_rawcounts.h5ad'); a=a[a.obs.stage.astype(str).str.startswith('E')].copy()
sym=a.var['symbol'].astype(str).values if 'symbol' in a.var else a.var_names.astype(str).values
save(a.X,sym,a.obs_names.values,[d for d in RO.dataset.unique() if d.startswith('Mouse')],'mouse','Mouse.h5ad')
