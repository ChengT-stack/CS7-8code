# gastruloid/ — Benchmarking of gastruloid models against the CS7 and CS8 embryos

Code for the STAR Methods sections 'Benchmarking of gastruloid models against the CS7 and CS8 embryos' (P384-P397): datasets and pre-processing, milestone scoring, staging against the CosMx embryos, cell-type comparison of the manuscript on the human CS7 (HuE#1) and CS8 (HuE#2) CosMx embryos. Embryo naming: HuE#1 = CS7 (`obj6`, called CS6 in old files), HuE#2 = CS8 (`obj7`). CS8 groups EPI1/ECT/EPI2 = old EPI/aECT/pECT; AVE = old ADE.

Each script carries a header naming its source; `PROVENANCE.md` documents how the final version was chosen, the sha256 of the original, the edits made (paths, headers and comments only) and which scripts were reconstructed from session transcripts.

## Methods -> script -> figure

| Script | Methods [P#] | Produces (figure / table) |
|---|---|---|
| `01_preprocess/export_hamazaki.R` | P386 | GSE208369/export/<sample>_{counts.mtx,genes.csv,meta.csv} for the 8 Hamazaki samples |
| `01_preprocess/loaders.py` | P386 | group registry/loaders of all gastruloid matrices (GEO supplementary files) |
| `01_preprocess/prep_group.py` | P386; P389 | gall/groups/<id>.h5ad and .json (QC >=500 genes, <=20% mt UMI; Hamazaki objects as provided; Leiden sub-clusters, res 2) |
| `01_preprocess/new_models.py` | P386; P389 | gall/groups_new/Liu_PG_d11 (peri-gastruloid, GSE232861) and other new models |
| `01_preprocess/fix_heemskerk_group.py` | P386 | gall/groups_fix/Hee_42.h5ad (GSE271604, 42 h, rep1 re-read in correct orientation) |
| `02_milestone_scoring/stage_lib.py` | P389; P390 | milestone scoring library (sub-cluster pass rule, onset-frequency rule, MESP1+TBX6, TBXT+/NKX1-2+CDX2+ pools, time-course and transient rules) |
| `02_milestone_scoring/stage_all.py` | P389; P390 | gall/mouse_curves_depth_matched.csv, gall/out/{calls,calls_depth_matched,evidence,windows,...}.csv |
| `02_milestone_scoring/stage_v2.py` | P389; P390 | gall/out_v2/calls_all_samples.csv, milestone_assessability_long.csv, marker_gene_measured_by_library.csv, groups.csv |
| `02_milestone_scoring/assess_v2.py` | P390 | gall/out_v2/milestone_assessability_by_model.csv (+ final time-aware calls with probe-set rule) |
| `03_staging_vs_cosmx/stage_cs78.py` | P393 | gall/out_v2/gastruloid_stage_vs_CS7_CS8.csv, gastruloid_stage_vs_CS7_CS8_long.csv (stage calls behind Figure 6H left and Supplementary Figure 8A) |
| `04_denovo_annotation/pipeline.py` | P396 | reanno/out/<unit>/ (Scrublet per library, normalisation, 3,000 HVG excl. MT/RP/cell-cycle, PCA 50, Harmony for Minn/Heemskerk, kNN 15 on 30 PCs, Leiden 1.0/2.0, Wilcoxon markers) |
| `04_denovo_annotation/markers.py` | P396 | 34 marker panels (SIG), panel genes, cell-cycle and HOX groups |
| `04_denovo_annotation/annotations.py` | P396 | curated cluster -> label tables (resolution 1.0 with resolution 2.0 overrides) |
| `04_denovo_annotation/apply.py` | P396 | reanno/out/all_cells_annotated.parquet, cluster_annotation.csv, qc_by_group.csv, compositions |
| `04_denovo_annotation/finalize_tables.py` | P396 | out/final/qc_by_sample.csv and composition tables (annotated-cell counts) |
| `05_celltype_comparison/celltypes_cs78.py` | P397 | embryo-type definitions (TYPES: label -> CosMx type, milestone) exec-imported by celltypes_full/mini; own outputs celltypes_vs_CS7_CS8_long.csv (intermediate version) |
| `05_celltype_comparison/celltypes_full.py` | P397 | gall/out_v2/celltypes_full_long.csv, celltypes_full_missing_by_sample.csv (Supplementary Figure 8B data; 31 samples incl. mouse) |
| `05_celltype_comparison/celltypes_mini.py` | P397 | gall/out_v2/celltypes_mini_long.csv (7 samples of Figure 6H right) |
| `05_celltype_comparison/cm_common.py` | P397 | cell-type data and geometry for Figure 6H (exec-imported by plot_combined_abbr.py) |
| `05_celltype_comparison/plot_assess.py` | P390 | assessability figure (not in manuscript); its SHORT/label block is exec-imported by the Figure 6H and SF8 scripts |
| `05_celltype_comparison/plot_stage_cs78_mini.py` | P393 | staging data and geometry for Figure 6H (exec-imported by plot_combined_abbr.py) |
| `05_celltype_comparison/plot_combined_abbr.py` | P393; P397; legend P501 | Fig_gastruloid_stage_and_celltypes_combined.{png,ai} = Figure 6H (7 samples) |
| `05_celltype_comparison/build_sfig8A.py` | P393; legend P555 | SuppFig_gastruloid_staging_A_human_only.{png,ai} = Supplementary Figure 8A (22 human samples) |
| `05_celltype_comparison/build_sfig8B.py` | P397; legend P556 | SuppFig_gastruloid_celltypes_B_human_only.{png,ai} = Supplementary Figure 8B (22 human samples) |

## Run order

1. 01_preprocess/export_hamazaki.R
2. 01_preprocess/prep_group.py <group ids> (all groups in loaders.py), new_models.py models, fix_heemskerk_group.py
3. 02_milestone_scoring/stage_all.py, then stage_v2.py, then assess_v2.py
4. 03_staging_vs_cosmx/stage_cs78.py
5. 04_denovo_annotation/pipeline.py <unit> for every unit, then apply.py, then finalize_tables.py (cwd = reanno/)
6. 05_celltype_comparison/celltypes_full.py, celltypes_mini.py
7. 05_celltype_comparison/plot_combined_abbr.py  -> Figure 6H
8. 05_celltype_comparison/build_sfig8A.py, build_sfig8B.py  -> Supplementary Figure 8A, 8B


## Paths and environment

| Variable | Meaning | Default |
|---|---|---|
| `HGC_DATA` | root of the input data (original relative layout kept, e.g. `external/mouse_pijuan_sala/...`, `milestone_evidence/...`, `GSE193007/...`) | `data` |
| `HGC_OUT` | root of the outputs (`figure4_staging/...`, `figure6/...`, `figure6_cs9/...`) | `results` |
| `HGC_FONTS` | folder with Arial TTF files (optional; figures fall back to the default font) | `fonts` |
| `HGC_TABLE_S2` | path of the user-supplied Table S2 xlsx (gastruloid module) | `$HGC_DATA/Table_S2_milestones.xlsx` |

Several upstream scripts write intermediate tables back to the sub-path that the next script reads (as in the original analysis). For a full re-run either set `HGC_OUT` equal to `HGC_DATA`, or copy the intermediates. Scripts that use relative paths (`mz/...`, `gall/...`, `reanno/...`, `hm/...`, `out/...`) must be run from the working directory noted in the table. No data files are included in the repository.

## Expected input files (under `$HGC_DATA`)

- `$HGC_DATA/`
- `$HGC_DATA/GSE208369/`
- `$HGC_DATA/GSE208369/GSM6341941_hGas_48h.RDS`
- `$HGC_DATA/GSE208369/GSM6341942_hGas_72h.RDS`
- `$HGC_DATA/GSE208369/GSM6341943_hGas_96h.RDS`
- `$HGC_DATA/GSE208369/export/`
- `$HGC_DATA/external/mouse_pijuan_sala/mouse_human_orthologs_one2one_Ensembl116.csv`
- `$HGC_DATA/gastruloid_benchmark/store/`
- `$HGC_DATA/gastruloid_sc/`
- `$HGC_DATA/gastruloid_sc/GSE208369/GSM6341946_RA_LDN.RDS.gz`
- `$HGC_DATA/gastruloid_sc/GSE271604/`

Supplementary tables: Table S2 (`Table_S2_milestones.xlsx`, sheet `milestones`) is read by `02_milestone_scoring/stage_lib.py` and `03_staging_vs_cosmx/stage_cs78.py`. Table S1 lists the 22 gastruloid samples and their GEO files (sheet `gastruloid samples`); the sample registry itself is coded in `01_preprocess/loaders.py`.

Working-directory inputs produced by earlier scripts of this module (relative paths): ./gall/groups, ./gall/groups/Hee_42.h5ad, ./gall/groups_fix, ./gall/groups_fix/, ./gall/groups_fix/Hee_42.h5ad, ./gall/groups_fix/Hee_42.json, ./gall/groups_new, ./gall/groups_new/, ./gall/mouse_curves_depth_matched.csv, ./gall/out, ./gall/out/calls.csv, ./gall/out/calls_depth_matched.csv, ./gall/out/calls_strict.csv, ./gall/out/evidence.csv, ./gall/out/gene_clock.csv, ./gall/out/groups.csv, ./gall/out/windows.csv, ./gall/out_v2/, ./out/all_cells_annotated.parquet, ./out/final, ./out/final/author_crosstab_Heemskerk.csv, ./out/final/author_crosstab_Weatherbee.csv, ./out/final/composition_class_by_sample_pct.csv, ./out/final/composition_label_by_sample_pct.csv, ./out/final/composition_long.csv, ./out/final/concordance_by_denovo_class.csv, ./out/final/concordance_by_reference_confidence_class.csv, ./out/final/concordance_denovo_vs_reference_by_dataset.csv, ./out/final/counts_label_by_sample.csv, ./out/final/discordance_denovo_vs_reference.csv, ./out/final/qc_by_sample.csv, ./reanno/out/all_cells_annotated.parquet, ./reanno/out/cluster_annotation.csv, ./reanno/out/composition_class_by_group.csv, ./reanno/out/composition_label_by_group.csv, ./reanno/out/counts_label_by_group.csv, ./reanno/out/qc_by_group.csv, ./tb/out/embryo_units, ./tb/out/embryo_units_cosmx38_half.csv, ./tb/out/sample_window.csv

## Dependencies

Python: python 3.11; numpy 2.4; pandas 2.3; scipy 1.17; matplotlib 3.10-3.11; anndata 0.12.19; scanpy 1.11.5; harmonypy 2.x; python-igraph 1.0; leidenalg 0.12; openpyxl 3.1.5; h5py 3.16; pyarrow (parquet); Pillow.
R: R 4.3.3; Seurat 5.3.0; SeuratObject 5.2.0; Matrix 1.6.5; data.table 1.17.8.
Versions are those of the conda environments in which the analyses were run (checked 2026-11-23); exact versions at run time were not recorded.

## Gaps (Methods steps without code in this module)

- Download of the gastruloid GEO supplementary files (GSE208369, GSE194214, GSE144897, GSE271604, GSE262081, GSE232861): download commands were run interactively and are not included; accessions and files are listed in Table S1 and loaders.py.
- tb/out/embryo_units_cosmx38_half.csv (CosMx cell numbers per type; read by celltypes_cs78/full/mini.py) and tb/out/sample_window.csv (informational column in stage_cs78.py) are produced by the transition-benchmark scripts (gastruloid_comparison/transition_benchmark/code/embryo.py, window.py) and benchmark/build_store.py, which are outside this module.
- The totals quoted in Methods (244,947 cells after QC; 222,670 annotated cells in the 22 samples) were not re-computed here.
- Table S2 sheet "gastruloid calls" is not written by these scripts (assembled when the supplementary tables were compiled).

## Points for the authors to confirm

- Depth matching: stage_all.py derives depth-matched thresholds (call_observed_depth_matched) for every sample, but stage_v2.py / assess_v2.py build the final call tables from call_observed (fixed thresholds; deeper samples down-sampled to 14,848 UMI). Methods P390 describes re-derived thresholds for lower-depth samples; authors should confirm which call set underlies Figure 6H and Supplementary Figure 8.
- Heemskerk 42 h (Hee_42): in gall/groups_fix/Hee_42.h5ad the rep1 cells carry sub = "NA" (fix_heemskerk_group.py); stage_v2.py re-clusters only when the "sub" column is absent, so rep1 cells may have been scored as one sub-cluster. Verify before release.
- Table S2 is now read from the final Table_S2_milestones.xlsx (sheet milestones, rows with Row type = milestone) instead of the exported gall/tableS2_milestones.csv; checked: onsets, thresholds, domains, E8.5 metrics and CosMx calls are identical; only the m05/m06 names changed (ADE -> AVE).
- Sample sets: the scripts carry all 31 samples of the 8 models (incl. mouse Rossi/Veenvliet) and 55 total groups; the manuscript (22 human samples of 6 studies) is the human subset selected inside build_sfig8A/B.py. Earlier 31/46-sample figure versions are superseded.
- Dataset labels inside the code still use the working names (e.g. "Heemskerk 2024" for Jo et al. GSE271604, "Liu 2023" for the peri-gastruloid, "Chen 2025" for GSE262081).


Licence: MIT (see the repository root).
