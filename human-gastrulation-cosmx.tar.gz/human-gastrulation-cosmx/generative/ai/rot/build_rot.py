# Build train/val/locked Mittnenzweig triplets for one rotated embryo assignment, exactly as ai/step7/rep.py
# (same Z, same spacing/tolerance rules, same partners(); RNG replayed to the state rep.py had when building triplets).
# usage: python out_robustness/build_rot.py <rot>   (rot 0 = existing split, rebuilt and checked against ai/step7/pairs.pkl)
import sys, pickle, numpy as np, pandas as pd, ot, warnings; warnings.filterwarnings('ignore')
sys.path.insert(0,'ai'); import step5_lib as L
rot=int(sys.argv[1]); O='ai/rot/'
R=np.load('ai/step7/rep.npz',allow_pickle=True); Z=R['Z']; ds=R['ds'].astype(str); grp=R['grp'].astype(str); mt=R['mt']; emb=R['emb'].astype(str); valid=R['valid']; n0=int(R['n0'])
GB=np.array(sorted(set(grp)))
rng=np.random.default_rng(0)
_=np.concatenate([rng.choice(np.where(ds==d)[0],min(3000,int((ds==d).sum())),replace=False) for d in np.unique(ds[:n0])])
for i,a in enumerate(L.STG):
    for b in L.STG[i+1:]:
        if round(b-a,2) not in (0.25,0.5,1.0): continue
        ia=np.where((mt==a)&valid)[0]; _=rng.choice(ia,min(1500,len(ia)),replace=False)
def plan(ia,ib,reg=None):
    M=ot.dist(Z[ia],Z[ib]); M/=M.max(); a=np.ones(len(ia))/len(ia); b=np.ones(len(ib))/len(ib)
    G=ot.emd(a,b,M,numItermax=3000000) if reg is None else ot.sinkhorn(a,b,M,reg,numItermax=2000)
    return G/G.sum(1,keepdims=True)
def partners(ia,ib):
    out={}; r=np.random.default_rng(len(ia)+len(ib))
    for tag,reg in [('emd',None),('ent',0.02)]:
        W=plan(ia,ib,reg); out[f'{tag}_cen']=(W@Z[ib]).astype(np.float32)
        out[f'{tag}_sample']=Z[ib[[r.choice(len(ib),p=w/w.sum()) for w in W]]]
        if tag=='emd':
            out['emd_top']=Z[ib[W.argmax(1)]]; Wg=np.stack([W[:,grp[ib]==g].sum(1) for g in GB],1); out['dom']=GB[Wg.argmax(1)]
    return out
E=pd.read_csv(f'ai/mz_bench/rot/split_rot{rot}.csv',index_col=0).sort_values('t',kind='stable')
pass
pass
pass
def trip(mset,eset,lo,hi,tol):
    out=[]
    for ea,ra in E[E.split.isin(eset)].iterrows():
        for eb,rb in E[E.split.isin(eset)].iterrows():
            D=rb.t-ra.t
            if not(lo<=D<=hi and ra.t>=6.6): continue
            mm=E[E.split.isin(mset)&(np.abs(E.t-(ra.t+rb.t)/2)<=tol)&~E.index.isin([ea,eb])]
            out+=[(ea,em,eb,ra.t,rm.t,rb.t) for em,rm in mm.iterrows()]
    return out
TR={}
for nm,ms,es,lo,hi,tol in [('train',['T'],['T'],0.25,0.5,0.06),('val',['V'],['T','V'],0.3,0.45,0.05),('locked',['L'],['T','V'],0.3,0.45,0.05)]:
    lst=[]
    for (ea,em,eb,ta,tm,tb) in trip(ms,es,lo,hi,tol):
        ia=np.where((emb==ea)&valid)[0]; ib=np.where((emb==eb)&valid)[0]; im=np.where((emb==em)&valid)[0]
        ia=rng.choice(ia,min(600,len(ia)),replace=False) if len(ia)>600 else ia
        lst.append(dict(ea=ea,em=em,eb=eb,ta=ta,tm=tm,tb=tb,ia=ia,im=im,**partners(ia,ib)))
    TR[nm]=lst; print(rot,nm,len(lst),'mids',len(set(t['em'] for t in lst)),flush=True)
if rot==0:
    T0=pickle.load(open('ai/step7/pairs.pkl','rb'))['TR']; ok=True
    for s in TR:
        ok&=len(TR[s])==len(T0[s])
        for a,b in zip(TR[s],T0[s]):
            ok&=(a['em']==b['em']) and np.array_equal(a['ia'],b['ia']) and np.allclose(a['emd_cen'],b['emd_cen'],atol=1e-5) and (a['dom']==b['dom']).all()
    print('rotation 0 identical to ai/step7/pairs.pkl:',ok,flush=True)
pickle.dump(TR,open(O+f'TR_rot{rot}.pkl','wb')); print('done',rot)
