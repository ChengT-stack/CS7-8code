# Control couplings for the Fate_timing track: expression-only (no spatial term) with/without transition table, and GG-OT without table.
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import os, sys, json, numpy as np, pandas as pd, scipy.sparse as sp, anndata as ad
os.environ.update(KMP_AFFINITY="disabled", OMP_NUM_THREADS="8")
B = DATA + "/cs7_cs8_matching/"
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "lib"))   # repo copy of ggot_proposal/final + starmatch.py
import ggot_match as GM, ggot, starmatch as SM
OUT = os.path.join(os.environ.get("HGC_OUT", "results"), "aiggot", "control_couplings") + "/"; os.makedirs(OUT, exist_ok=True)   # original: bridge_bundle/tracks/Fate_timing/couplings/
A = ad.read_h5ad(B + "dataprep/embedding/cs7_cs8_germlayers_harmony.h5ad", backed="r")
obs = A.obs.copy(); g_all = obs.label_short.astype(str).to_numpy(); emb = obs.embryo.astype(str).to_numpy()
i7 = np.where(emb == "CS7")[0]; i8 = np.where(emb == "CS8")[0]; g7 = g_all[i7]; g8 = g_all[i8]
pd.DataFrame(dict(cell=np.array(A.obs_names[i7]))).to_csv(OUT + "h5ad_cs7_cells.csv", index=False)
pd.DataFrame(dict(cell=np.array(A.obs_names[i8]))).to_csv(OUT + "h5ad_cs8_cells.csv", index=False)
SPC = ["AP_arc_frac", "LR_frac", "DV_gap_units"]
fr7 = pd.read_csv(B + "dataprep/frames/CS7_frames.csv").set_index("cell"); fr8 = pd.read_csv(B + "dataprep/frames/CS8_frames.csv").set_index("cell")
S7 = fr7.reindex(A.obs_names[i7])[SPC].to_numpy(float); S8 = fr8.reindex(A.obs_names[i8])[SPC].to_numpy(float)
Hhs = np.load(B + "matching/harmony_smoothed.npy")
TT = json.load(open(B + "matching/transition_table_used.json")); trans = {tuple(k.split("->")): v for k, v in TT.items()}
a = obs.z_weight.to_numpy(float)[i7]; b = obs.z_weight.to_numpy(float)[i8]
_ks = SM.knn_scale
SM.knn_scale = lambda X: max(float(_ks(X)), 1e-9) if np.ptp(X) > 0 else 1.0
for tag, kw, S7_, S8_ in [("ref_check_table", dict(prior=True, space="gated"), S7, S8),
                          ("expr_only_table", dict(prior=True, space="euclid"), np.zeros_like(S7), np.zeros_like(S8)),
                          ("expr_only_noprior", dict(prior=False, space="euclid"), np.zeros_like(S7), np.zeros_like(S8)),
                          ("gated_noprior", dict(prior=False, space="gated"), S7, S8)]:
    res = GM.match(Hhs[i7], Hhs[i8], S7_, S8_, g7, g8, a, b, trans, **kw)
    sp.save_npz(OUT + f"M_{tag}.npz", res["M"].tocsr().astype(float)); print(tag, res["M"].nnz, flush=True)
