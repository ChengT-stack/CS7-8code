# staging/03_ps_dynamics/stereo_pb.R
# Source: drive F: CS6-CS7/cs7_cs8_matching/figure4_staging/ps_dynamics/work/stereo_pb.R
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
HGC_DATA <- Sys.getenv('HGC_DATA', 'data')
HGC_OUT <- Sys.getenv('HGC_OUT', 'results')

suppressMessages({library(Seurat);library(Matrix)})
pb <- function(m, grp, tag){
  tot <- colSums(m); n <- Matrix(diag(1e4/tot), sparse=TRUE)
  cp <- m %*% Diagonal(x=1e4/tot); lg <- cp; lg@x <- log1p(lg@x); det <- m>0
  out <- list()
  for(g in sort(unique(grp))){ s <- which(grp==g); if(length(s)<1) next
    out[[g]] <- data.frame(gene=rownames(m), group=g, n=length(s), mean_cp10k=Matrix::rowMeans(cp[,s,drop=FALSE]),
      mean_log1p=Matrix::rowMeans(lg[,s,drop=FALSE]), det=Matrix::rowMeans(det[,s,drop=FALSE]), sum_counts=Matrix::rowSums(m[,s,drop=FALSE]))}
  d <- do.call(rbind,out); d$dataset <- tag; d
}
for(f in c('CS7','CS8','CS9')){
  path <- c(CS7=paste0(HGC_DATA, '/CS7-RNA-MapQ.rds'),CS8=paste0(HGC_DATA, '/CS8-RNA-MapQ.rds'),CS9=paste0(HGC_DATA, '/CS9-28798-RNA-MapQ.rds'))[f]
  o <- readRDS(path); md <- o@meta.data; m <- GetAssayData(o, assay='RNA', layer='counts')
  cat(f, dim(m), '\n'); print(colnames(md))
  batch <- if(f=='CS9') sub('_.*','',sub('^(CS9-[12]).*','\\1',colnames(m))) else rep(f,ncol(m))
  print(table(batch))
  for(b in unique(batch)){ s <- batch==b
    t2 <- as.character(md$Type2)[s]; t3 <- paste0(t2,' | ',as.character(md$Type3)[s])
    d <- pb(m[,s], t2, b); write.csv(d, paste0('stereo_',b,'_Type2_pb.csv'), row.names=FALSE)
    keep <- t2 %in% c('15 PS','2   EPI/ECT(p)','5   NMP','9   Node')
    d3 <- pb(m[,s][,keep], t3[keep], b); write.csv(d3, paste0('stereo_',b,'_Type3_pb.csv'), row.names=FALSE)
    write.csv(as.data.frame(table(t3)), paste0('stereo_',b,'_Type3_counts.csv'), row.names=FALSE)
  }
  rm(o,m); gc()
}
cat('done\n')
