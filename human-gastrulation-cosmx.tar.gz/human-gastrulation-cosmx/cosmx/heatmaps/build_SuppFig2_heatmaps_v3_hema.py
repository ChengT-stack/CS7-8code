# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source:
#     [F:]/CS6-CS7/cs7_cs8_matching/figure1_L_heatmap_by_stage/v2_HESX1_SFRP1/build_SuppFig2_heatmaps_v3_hema.py
#     (2026-11-11 18:40; artifact 559ba6a8)
# sha256 of original: 1adbf69c24be2959643ff6706b6440b362843dd0d4d8b13e95ab7a474a0127dc
# Methods paragraphs: P349
# Produces: Supplementary Figure 2A (HuE#1, 27 types incl. small types such as Hema; file
#     SuppFig2A_CS7_marker_heatmap_withHema.*, artifact 377e3089)
# Edits/notes: font folder -> HGC_FONTS; scheme39.py read from this folder.
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

import os
import numpy as np, pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm

FD = os.path.join(FONT_DIR, "")
for f in ["arial.ttf", "arialbd.ttf", "ariali.ttf", "arialbi.ttf"]:
    if os.path.exists(FD + f):
        fm.fontManager.addfont(FD + f)
mpl.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
                     "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
                     "axes.unicode_minus": False})

# per type x stage means (CP10K) and detection, curated_kept cells of obj6_obj7_merged_curated_final.rds
ME = pd.read_csv("hm/mean_cp10k_type_stage_v2.csv", index_col=0)
FR = pd.read_csv("hm/frac_type_stage_v2.csv", index_col=0)
NT = pd.read_csv("hm/n_type_stage.csv")
NT = dict(zip(NT.key, NT.Freq))

SCHEME = [  # (full 39Type label, colour) in the object's own Type39_scheme order (1-38)
 ("Epiblast (EPI)", "#4C4FA3"), ("Ectoderm (ECT)", "#2F80ED"), ("Anterior ectoderm (aECT)", "#0057B8"),
 ("Posterior ectoderm (pECT)", "#00A6D6"), ("Primitive streak (PS)", "#9ACD32"),
 ("Anterior primitive streak (APS)", "#2E8B57"), ("Node", "#00441B"), ("Notochord", "#008B8B"),
 ("Prechordal plate", "#00C49A"), ("Caudal lateral epiblast (CLE)", "#6A5ACD"),
 ("Primordial germ cell (PGC)", "#FF1493"), ("Non-neural ectoderm (NNE)", "#40C4FF"),
 ("Amniotic epithelium progenitor (Am.Epi progenitor)", "#8C6FF7"), ("Amniotic epithelium (Am.Epi)", "#AFCBFF"),
 ("Nascent mesoderm (Nas.Meso)", "#F4A261"), ("Lateral plate mesoderm (LP.Meso)", "#E76F51"),
 ("Heart mesoderm", "#E31A1C"), ("Extraembryonic mesoderm progenitor (Exe.Meso progenitor)", "#F7B6D2"),
 ("Amniotic mesenchyme (Am.Mes)", "#E75480"), ("Allantois mesenchyme (Al.Mes)", "#F768A1"),
 ("Chorion-allantois mesenchyme (ChA.Mes)", "#C51B8A"), ("Yolk sac mesoderm (ys.Meso)", "#8E3A9C"),
 ("Paraxial mesoderm (Para.Meso)", "#D97706"), ("Rostral mesoderm (Rostral.Meso)", "#F43F5E"),
 ("Definitive endoderm (DE)", "#FF5A1F"), ("Visceral endoderm 1 (VE1)", "#FF8C00"),
 ("Visceral endoderm 2 (VE2)", "#FFCA3A"), ("Parietal yolk sac endoderm (Pari.Endo)", "#D4A017"),
 ("Proximal yolk sac endoderm (Prox.ys.Endo)", "#FFE08A"), ("Distal yolk sac endoderm (Dist.ys.Endo)", "#FFF1B8"),
 ("Allantois endoderm (Al.Endo)", "#8F6B00"), ("Anterior visceral endoderm (AVE)", "#C2410C"),
 ("Hematopoietic progenitor (Hema)", "#C4A1FF"), ("Endothelium", "#3B82A0"), ("Macrophage", "#3C1361"),
 ("Megakaryocyte", "#7B2CBF"), ("Primitive erythroblast", "#D65DB1"), ("Trophoblast", "#7A4A00")]
def short(t):
    s = t[t.index("(") + 1:t.rindex(")")] if "(" in t else t
    return {"Prechordal plate": "PrP", "AVE": "ADE", "Pari.Endo": "Pari.ys.Endo"}.get(s, s)

# gene order of the original Figure 1L (pooled diagonal order, top-to-bottom = peak column 1 -> 38)
ORIG = ['LIN28A','SOX2','TBXT','MIXL1','EOMES','MESP1','MESP2','CHRD','NOTO','WNT3A','NODAL','WNT3','FOXA2',
 'NOG','CDH2','OTX2','POU5F1','NKX1-2','NANOG','WNT1','TBX1','CDH1','PAX6','TBX6','HOXB1','WNT8A','HOXA3',
 'HOXA2','HOXD3','HOXB3','WNT5A','CDX2','VIM','BMP4','NKX2-5','UNCX','HAND1','HOXB2','HAND2','OSR1','EN1',
 'TBX4','HESX1','ALDH1A2','MSGN1','HOXA1','FOXC1','TCF15','EPCAM','BMP2','PITX2','AFP','TTR','APOE','SHH',
 'HOXA10','ISL1','SOX1','HOXA11','PAX2','TBX18','HOXD1','GATA6','SOX17','GATA4','SNAI1','POU3F1','CYP26A1',
 'FOXG1','RUNX1','OLIG2','KDR','PECAM1','TAL1','GCM1']
LPNEW = ["ETV2", "TAL1", "TBX4", "OSR1"]
g = [x for x in ORIG if x not in LPNEW]
i = g.index("CDX2") + 1                 # last gene peaking in LP.Meso (column 16) in the pooled map
GORD = g[:i] + LPNEW + g[i:]
GORD.insert(GORD.index("SOX2") + 1, "SFRP1")   # pooled peak in aECT, same block as LIN28A / SOX2
GCOL = GORD[::-1]                        # as in Figure 1L: columns run right (EPI) -> left (Trophoblast)
assert len(GCOL) == 77 and len(set(GCOL)) == 77

MIN_CELLS = 20
DET_MIN = 0.005
BWG = mpl.colors.LinearSegmentedColormap.from_list("bwg", ["#B8B8B8", "#F2F2F2", "#0B4F8A"], N=256)
MM = 1 / 25.4

def draw(stage, out, hue):
    LAB = lambda tfull: "Primitive node" if (tfull == "Node" and stage == "CS7") else short(tfull)
    rows = [(k + 1, t, c) for k, (t, c) in enumerate(SCHEME)
            if f"{t}|{stage}" in ME.columns and NT.get(f"{t}|{stage}", 0) >= 1]
    dropped = [(t, NT[f"{t}|{stage}"]) for t, _ in SCHEME
               if f"{t}|{stage}" in ME.columns and NT[f"{t}|{stage}"] < MIN_CELLS]
    keys = [f"{t}|{stage}" for _, t, _ in rows]
    A = ME.loc[GCOL, keys].to_numpy(float).T          # rows = types, cols = genes
    D = FR.loc[GCOL, keys].to_numpy(float).T
    big = np.array([NT[k] >= MIN_CELLS for k in keys])          # the colour scale is set by types with >= MIN_CELLS cells only
    lo, hi = A[big].min(0, keepdims=True), A[big].max(0, keepdims=True)
    N = np.clip(np.where(hi > lo, (A - lo) / np.where(hi > lo, hi - lo, 1), 0), 0, 1)
    Nm = np.ma.masked_where(D < DET_MIN, N)
    nr, nc = A.shape
    t = 1.85                                           # tile size (mm)
    L, B = 4.0, 14.0
    Wf = L + nc * t + 34
    Hf = B + nr * t + 7
    fig = plt.figure(figsize=(Wf * MM, Hf * MM))
    ax = fig.add_axes([L / Wf, B / Hf, nc * t / Wf, nr * t / Hf])
    qm = ax.pcolormesh(np.arange(nc + 1), np.arange(nr + 1), Nm, cmap=BWG, vmin=0, vmax=1,
                       edgecolors="white", linewidth=0.35)
    qm.cmap.set_bad((1, 1, 1, 0))
    ax.set_xlim(0, nc); ax.set_ylim(nr, 0); ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_color("#DDDDDD"); s.set_linewidth(0.5)
    for j, gname in enumerate(GCOL):
        ax.text(j + 0.5, nr + 0.35, gname, rotation=90, ha="center", va="top", fontsize=5,
                style="italic", color="#2A2A2A")
    for r, (num, tfull, col) in enumerate(rows):
        ax.add_patch(plt.Rectangle((nc + 0.35, r + 0.1), 0.8, 0.8, facecolor=col, edgecolor="none",
                                   clip_on=False))
        ax.text(nc + 1.45, r + 0.5, f"{r + 1} {LAB(tfull)}" + ("" if big[r] else f" (n = {NT[keys[r]]})"), ha="left", va="center", fontsize=5,
                color="#2A2A2A")
    fig.text(L / Wf, (B + nr * t + 2.0) / Hf, f"{stage} ({hue})", fontsize=7, fontweight="bold",
             va="bottom")
    cax = fig.add_axes([(L + nc * t + 24) / Wf, (B + nr * t - 13) / Hf, 1.6 / Wf, 12 / Hf])
    cb = fig.colorbar(qm, cax=cax, ticks=[0, .25, .5, .75, 1])
    cb.ax.set_yticklabels(["0%", "25%", "50%", "75%", "100%"], fontsize=5)
    cb.ax.invert_yaxis()
    cb.ax.tick_params(length=1.2, width=0.35, pad=0.8); cb.outline.set_linewidth(0.35)
    for ext in ["png", "pdf", "svg"]:
        fig.savefig(f"{out}.{ext}", dpi=600 if ext == "png" else None)
    fig.savefig(f"{out}.ai", format="pdf")
    plt.close(fig)
    src = pd.DataFrame(A.T, index=GCOL, columns=[f"{k + 1} {LAB(tf)}" for k, (n, tf, _) in enumerate(rows)])
    src.to_csv(f"{out}_mean_cp10k.csv")
    pd.DataFrame(D.T * 100, index=GCOL, columns=src.columns).round(2).to_csv(f"{out}_detection_pct.csv")
    return rows, dropped

os.makedirs("hm/out", exist_ok=True)
r7, d7 = draw("CS7", "hm/out/SuppFig2A_CS7_marker_heatmap_withHema", "HuE#1")
r8, d8 = draw("CS8", "hm/out/_tmp_CS8_check", "HuE#2")
print(len(r7), d7, len(r8), d8)
