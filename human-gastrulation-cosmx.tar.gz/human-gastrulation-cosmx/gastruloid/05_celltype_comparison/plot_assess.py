# gastruloid/05_celltype_comparison/plot_assess.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/plot_assess.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Figure: which of the 19 milestones can be tested in each gastruloid / embryo model (a: per model, b: per sample)
import numpy as np, pandas as pd, matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Patch
OUT = 'gall/out_v2/'; apply_figure_style(sizes=(7, 6, 5))
LG = pd.read_csv(OUT + 'milestone_assessability_long.csv'); LG['reason_not_testable'] = LG.reason_not_testable.fillna(''); INFO = pd.read_csv(OUT + 'groups.csv', index_col=0)
M = pd.read_csv(OUT + 'milestone_assessability_by_model.csv', index_col=0); S = pd.read_csv(OUT + 'milestone_assessability_summary_by_model.csv', index_col=0); CA = pd.read_csv(OUT + 'calls_all_samples.csv', index_col=0)
MS = [m for m in M.index if M.domain[m] == 'embryonic disc']; DS = list(S.index); ORDER = list(CA.columns); nM = len(MS)   # embryonic-disc milestones only (extra-embryonic lineages run ahead of the disc in human embryos)
KEEP = ['Hamazaki 2024', 'Budjan 2022', 'Minn 2020', 'Heemskerk 2024', 'Chen 2025', 'Liu 2023', 'Rossi 2021', 'Veenvliet 2020']   # models shown (tables keep all 14)
DS = [d for d in DS if d in KEEP]; ORDER = [g for g in ORDER if INFO.dataset[g] in KEEP]; nD = len(DS)
COL = {'reached': '#1F5FA8', 'reached (earlier)': '#9CC3E6', 'partial': '#F2C14E', 'not reached': '#D55E00', 'na': '#E6E6E6'}
def code(reason): return 'D' if reason.startswith('no corresponding') else 'P' if reason.startswith('reference pool') else 'G' if reason.startswith('marker') else 'T'
SHORT = {'Hamazaki 2024': 'Hamazaki gastruloid', 'Budjan 2022': 'Budjan somitoid', 'Yamanaka 2023': 'Yamanaka axioloid', 'Makwana 2025': 'Makwana hTLS', 'Gribaudo 2023': 'Gribaudo spinoid', 'Olmsted & Paluh 2021': 'Olmsted EMLOC', 'Minn 2020': 'Minn 2D',
         'Heemskerk 2024': 'Heemskerk 2D', 'Chen 2025': 'Chen 2D', 'Liu 2023': 'Liu peri-gastruloid', 'Pedroza 2023': 'Pedroza hEE', 'Weatherbee 2023': 'Weatherbee model', 'Rossi 2021': 'Rossi (mouse)', 'Veenvliet 2020': 'Veenvliet TLS (mouse)'}
SL = {'Ham_0h': '0 h', 'Ham_24h': '24 h', 'Ham_48h': '48 h', 'Ham_72h': '72 h', 'Ham_96h': '96 h', 'Ham_RALDN': 'RA+LDN 120 h', 'Ham_RA96': 'RA 96 h', 'Ham_RA120': 'RA 120 h', 'Som_d1': 'd1', 'Som_d2': 'd2', 'Som_d3': 'd3', 'Som_d5': 'd5',
      'Ax_48h': '48 h', 'Ax_72h': '72 h', 'Ax_96h': '96 h', 'Ax_120h': '120 h', 'Ax_96h_MG': 'MG 96 h', 'Ax_120h_MG': 'MG 120 h', 'Ax_96h_MG_RA': 'MG+RA 96 h', 'Ax_120h_MG_RA': 'MG+RA 120 h', 'Ax_96h_MG_RAL': 'MG+retinal 96 h', 'Ax_120h_MG_RAL': 'MG+retinal 120 h',
      'Mak_72': '72 h', 'Mak_96': '96 h', 'Mak_120': '120 h', 'Gri_spinoid7': 'd7', 'Emloc_D7': 'd7', 'Emloc_D16': 'd16', 'Min_44': '44 h', 'Min_48re': '48 h reseeded', 'Hee_42': '42 h', 'Chen_48': '48 h', 'Chen_72': '72 h', 'Chen_96': '96 h', 'Chen_D6': 'd6', 'Chen_D8': 'd8',
      'Chen_D10': 'd10', 'Liu_PG_d11': 'd11', 'Ped_hEE_D4': 'd4', 'Ped_hEE_D6': 'd6', 'Wea_d4': 'd4', 'Wea_d6': 'd6', 'Wea_d8': 'd8', 'Ros_d4': 'd4', 'Ros_d5': 'd5', 'Ros_d6': 'd6', 'Ros_d7': 'd7', 'Vee_TLS96': 'TLS 96 h', 'Vee_TLSMG108': 'TLS MG 108 h',
      'Vee_TLSMG120': 'TLS MG 120 h', 'Vee_G120': 'no MG 120 h', 'Vee_TLSMGCL120': 'CHIR+LDN 120 h'}
assert all(g in SL for g in ORDER)
ypos = {m: i for i, m in enumerate(MS)}
LD = LG[LG.milestone_id.isin(MS)]; St = LD.groupby('dataset').apply(lambda d: d.groupby('milestone_id').testable.any().sum()); Sr = LD.groupby('dataset').apply(lambda d: d.groupby('milestone_id').call.apply(lambda s: s.str.startswith('reached').any()).sum())
pd.DataFrame({'samples': LD.groupby('dataset').group.nunique(), 'disc_milestones_testable_in_any_sample': St, 'of_which_reached': Sr}).to_csv(OUT + 'milestone_assessability_summary_by_model_disc.csv')
W, H = 7.2, 7.75; fig = plt.figure(figsize=(W, H))
PREF = ['Ham_0h', 'Ham_24h', 'Ham_48h', 'Ham_72h', 'Ham_96h', 'Ham_RA96', 'Ham_RA120', 'Ham_RALDN', 'Vee_TLS96', 'Vee_TLSMG108', 'Vee_TLSMG120', 'Vee_G120', 'Vee_TLSMGCL120']
ORDER = sorted(ORDER, key=lambda g: (DS.index(INFO.dataset[g]), PREF.index(g) if g in PREF else ORDER.index(g)))
# ---------- a: per model
cw, ch = 0.19, 0.15; x0, ytop = 2.72, 6.45; hA = nM * ch
axa = fig.add_axes([x0 / W, (ytop - hA) / H, nD * cw / W, hA / H]); axa.set_xlim(0, nD); axa.set_ylim(nM, 0)
for j, d in enumerate(DS):
    for m in MS:
        s = M.loc[m, d]; k = 'reached' if s.startswith('reached') else 'partial' if s.startswith('partial') else 'not reached' if s.startswith('testable') else 'na'
        axa.add_patch(Rectangle((j + 0.04, ypos[m] + 0.04), 0.92, 0.92, fc=COL[k], ec='none'))
        if k == 'na': axa.text(j + 0.5, ypos[m] + 0.52, code(s.split(': ', 1)[1]), ha='center', va='center', fontsize=5, color='#555555')
axa.set_xticks(np.arange(nD) + 0.5); axa.set_xticklabels([SHORT[d] for d in DS], rotation=90); axa.xaxis.tick_top(); axa.tick_params(length=0, pad=2)
axa.set_yticks([ypos[m] + 0.5 for m in MS]); axa.set_yticklabels([f"{m[1:]}  {M.milestone[m]}" for m in MS])
for sp in axa.spines.values(): sp.set_visible(False)

nmod = (~M[DS].apply(lambda c: c.str.startswith('not testable'))).sum(1)
for m in MS: axa.text(nD + 0.35, ypos[m] + 0.52, str(int(nmod[m])), ha='center', va='center', fontsize=6)
axa.text(nD + 0.35, -0.35, f'models\n(of {nD})', ha='center', va='bottom', fontsize=5, linespacing=0.95)
for j, d in enumerate(DS):
    axa.text(j + 0.5, nM + 0.55, str(int(St[d])), ha='center', va='center', fontsize=6, fontweight='bold'); axa.text(j + 0.5, nM + 1.4, str(int(Sr[d])), ha='center', va='center', fontsize=6, color=COL['reached'])
axa.text(-0.3, nM + 0.55, f'Milestones testable (of {nM})', ha='right', va='center', fontsize=6, fontweight='bold'); axa.text(-0.3, nM + 1.4, 'of which reached', ha='right', va='center', fontsize=6, color=COL['reached'])
fig.text(0.03, (ytop + 1.06) / H, 'Embryonic-disc milestones that each model can test in at least one of its samples', fontsize=7, ha='left', va='bottom')
fig.text(0.005, (ytop + 1.04) / H, 'a', fontsize=9, fontweight='bold', ha='left', va='bottom')
hs = [Patch(fc=COL['reached'], label='testable, reached'), Patch(fc=COL['reached (earlier)'], label='testable, reached at an\nearlier time point (b)'), Patch(fc=COL['partial'], label='testable, population below\nthe onset frequency'), Patch(fc=COL['not reached'], label='testable, not reached'), Patch(fc=COL['na'], label='not testable\n(letter: reason)')]
lg = fig.legend(handles=hs, loc='upper left', bbox_to_anchor=((x0 + nD * cw + 0.45) / W, (ytop + 0.05) / H), frameon=False, fontsize=6, handlelength=1.0, handleheight=1.0, labelspacing=0.5)
fig.text((x0 + nD * cw + 0.52) / W, (ytop - 1.3) / H, "Reasons\nT  transient population and a late sample:\n    absence may mean 'not yet' or 'already past'\nD  no corresponding cell population (06: no\n    endoderm-like cells in which GSC loss can\n    be read; Hamazaki gastruloid with RA:\n    population absent)\nP  reference pool < 15 cells (TBXT+ cells: 08,\n    12; NKX1-2+CDX2+ cells: 13)\nG  marker outside the probe set of the library", fontsize=6, ha='left', va='top', linespacing=1.25)
# ---------- b: per sample
n = len(ORDER); ds_of = INFO.dataset.reindex(ORDER).values; gaps = np.cumsum([0] + [0.45 if ds_of[i] != ds_of[i - 1] else 0 for i in range(1, n)]); xs = np.arange(n) + gaps; tot = xs[-1] + 1
bx0 = 0.62; bw = min(W - 0.62 - 0.08, tot * 0.165); chb = 0.13; hB = nM * chb; by_top = 2.85
axb = fig.add_axes([bx0 / W, (by_top - hB) / H, bw / W, hB / H]); axb.set_xlim(0, tot); axb.set_ylim(nM, 0)
L2 = LG.set_index(['group', 'milestone_id'])
for i, g in enumerate(ORDER):
    for m in MS:
        c = CA.loc[m, g]; k = c if c in COL else 'na'
        axb.add_patch(Rectangle((xs[i] + 0.05, ypos[m] + 0.05), 0.9, 0.9, fc=COL[k], ec='none'))
        if k == 'na': axb.text(xs[i] + 0.5, ypos[m] + 0.54, code(L2.loc[(g, m), 'reason_not_testable']), ha='center', va='center', fontsize=5, color='#555555')
axb.set_xticks(xs + 0.5); axb.set_xticklabels([SL[g] for g in ORDER], rotation=90); axb.tick_params(length=0, pad=2)
axb.set_yticks([ypos[m] + 0.5 for m in MS]); axb.set_yticklabels([m[1:] for m in MS])
for sp in axb.spines.values(): sp.set_visible(False)
for d in DS:
    ii = [i for i in range(n) if ds_of[i] == d]; a, b = xs[ii[0]], xs[ii[-1]] + 1
    axb.plot([a + 0.1, b - 0.1], [-0.35, -0.35], color='#333333', lw=0.6, clip_on=False); axb.text((a + b) / 2, -0.6, SHORT[d].split(' ')[0] + (' (mouse)' if 'mouse' in SHORT[d] else ''), rotation=90, ha='center', va='bottom', fontsize=6)
axb.set_ylabel('Milestone', labelpad=3)
fig.text(0.03, (by_top + 0.98) / H, 'The same for every sample (columns grouped by model; time after induction or culture day below)', fontsize=7, ha='left', va='bottom')
fig.text(0.005, (by_top + 0.96) / H, 'b', fontsize=9, fontweight='bold', ha='left', va='bottom')
fig.savefig(OUT + 'Fig_milestone_assessability.png', dpi=300); fig.savefig(OUT + 'Fig_milestone_assessability.pdf'); fig.savefig(OUT + 'Fig_milestone_assessability.svg')
fig.canvas.draw(); r = fig.canvas.get_renderer(); texts = [(t, t.get_window_extent(r)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
ov = [(a.get_text()[:25], b.get_text()[:25], [round(v) for v in ba.extents], [round(v) for v in bb.extents]) for i, (a, ba) in enumerate(texts) for b, bb in texts[i + 1:] if ba.overlaps(bb)]; outb = [t.get_text()[:30] for t, bb in texts if not (bb.x0 >= 0 and bb.y0 >= 0 and bb.x1 <= fig.bbox.x1 and bb.y1 <= fig.bbox.y1)]
print('overlaps', len(ov), ov[:8]); print('outside', outb[:10])
