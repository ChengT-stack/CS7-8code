# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: execution log, session 824ef1ce python kernel cells 2126-2131 (2131 = producing cell of
#     lpm_map_profiles_data.npz 28a0c8b9 and lpm_map_profiles_tests.csv 5077d4cf)
# sha256 of original: 0b6938c5d3a0e189dbd0fd062a915f686ec9773b47ca4105fa5369760b4d5ed1
# Methods paragraphs: Supplementary Figure 5D-E legends (L-R comparison; no separate Methods paragraph in v8)
# Produces: lr/lpm_map_profiles_data.npz, lr/lpm_map_profiles_tests.csv,
#     lr/cs8_lpm_lr_asymmetry_tests_rerun.csv, lr/cs8_lpm_lr_asymmetry_all_genes_rerun.csv
# Edits/notes: reconstructed from kernel log; comparison with the earlier test table, diagnostic plot and prints
#     removed; `obs = ns["obs"]` taken from cell 2128. lr_asym.py read from this folder; frames path ->
#     HGC_DATA.
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass
os.environ['HGC_SCRIPT_DIR'] = str(SCRIPT_DIR)   # lr_asym.py is exec-ed below

# --- kernel cell 2126 (comparison with an earlier output file and diagnostics removed) ---
import sys, types, os, numpy as np, pandas as pd, matplotlib
os.makedirs('lr', exist_ok=True)
src = open(SCRIPT_DIR / 'lr_asym.py').read()
fs = types.ModuleType('figure_style'); fs.apply_figure_style = lambda *a, **k: None; fs.panel_letter = lambda *a, **k: None; sys.modules['figure_style'] = fs
os.environ['STAGE'] = 'CS8'
ns = {}
cwd = os.getcwd(); os.chdir('lr')
try:
    exec(src[:src.index("# ---------- side definition")], ns)
    ns['POPS'] = {"LP.Meso": ["Lateral plate mesoderm (LP.Meso)"]}
    exec(src[src.index("# ---------- side definition"):src.index("# ---------- figure ----------")].replace('f"{STAGE.lower()}_lr_asymmetry_tests.csv"', '"cs8_lpm_lr_asymmetry_tests_rerun.csv"').replace('f"{STAGE.lower()}_lr_asymmetry_all_genes.csv"', '"cs8_lpm_lr_asymmetry_all_genes_rerun.csv"'), ns)
finally:
    os.chdir(cwd)
new = pd.read_csv('lr/cs8_lpm_lr_asymmetry_tests_rerun.csv')
C, LRp, lab, ok, disc = ns['C'], ns['LRp'], ns['lab'], ns['ok'], ns['disc']; m = ns['pop_mask']('LP.Meso'); d = ns['NULL']['LP.Meso']
# --- kernel cell 2127 (definitions only; diagnostic plot removed) ---
DISC = ['Epiblast (EPI)','Anterior ectoderm (aECT)','Posterior ectoderm (pECT)','Non-neural ectoderm (NNE)','Caudal lateral epiblast (CLE)','Primitive streak (PS)','Node','Notochord','Prechordal plate','Nascent mesoderm (Nas.Meso)','Paraxial mesoderm (Para.Meso)','Rostral mesoderm (Rostral.Meso)','Lateral plate mesoderm (LP.Meso)','Heart mesoderm','Definitive endoderm (DE)','Visceral endoderm 1 (VE1)','Visceral endoderm 2 (VE2)']
bg = np.isin(lab, DISC) & ok & np.isfinite(LRp)
ax_m = np.isin(lab, ns['AXIAL']) & ok
wmax = d['wmax']; MID = ns['MID']
# --- kernel cell 2128 (frame folder) ---
F = (str(DATA) + "/dataprep/frames/")
obs = ns['obs']
# --- kernel cell 2130 (diagnostic prints removed) ---
fr = pd.read_csv(F+'CS8_frames.csv', usecols=['cell','label_short','AP_arc_um','AP_um','LR_um','z_um']).set_index('cell')
idx = pd.Index(obs.index)
arc = fr['AP_arc_um'].reindex(idx).to_numpy(); 
node0 = np.nanmedian(arc[lab=='Node']); arcn = arc - node0
# --- kernel cell 2131 ---
PROF = ns['PROF']; PG = ["DLL1","NOTCH1","NODAL","LEFTY2","PITX2","DAND5"]
np.savez_compressed('lr/lpm_map_profiles_data.npz', LRp=LRp[bg], arcn=arcn[bg], is_lp=m[bg], is_axial=ax_m[bg], wmax=wmax, MID=MID,
    **{f'prof_{g}': np.vstack(PROF[('LP.Meso', g)]) for g in PG})
new[new.gene.isin(PG)].to_csv('lr/lpm_map_profiles_tests.csv', index=False)
