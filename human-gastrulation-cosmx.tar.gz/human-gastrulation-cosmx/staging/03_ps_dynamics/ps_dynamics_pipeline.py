# staging/03_ps_dynamics/ps_dynamics_pipeline.py
# Source: reconstructed from transcript 1c2d1a43
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# PS dynamics: mouse PS-dynamic genes, cross-dataset PS pseudobulks, CosMx/Stereo-seq/10x/monkey log2FC, background rule, permutation tests, HOX tiles, source-data workbook (Figure 6C-E, 6G).
# Reconstructed verbatim from session transcript 1c2d1a43 (code was run cell-by-cell in a
# persistent kernel and never saved as a file). Cells are concatenated in execution order;
# inspection-only and figure-polishing cells are omitted, and cells that stopped with an error are
# truncated at the failing line (marked). See PROVENANCE.md.
import numpy as np, pandas as pd, anndata as ad


# ---- cell [frame 1c2d1a43, message 23] Loading mouse raw-count atlas
B=ad.read_h5ad((str(HGC_DATA) + '/external/mouse_pijuan_sala/mouse_atlas_mapped_rawcounts.h5ad'))
print(B.obs.celltype.value_counts().head(40).to_string())
x=B.X[:500]; print(x.max(), np.allclose(x.data,np.round(x.data)))
print(B.obs.our_group.value_counts().head(10))
# is per-cell total from full gene set?


# ---- cell [frame 1c2d1a43, message 25] Computing mouse PS/APS pseudobulk per stage and sample
import scipy.sparse as sp, os
OUT=(str(HGC_OUT) + '/figure4_staging/ps_dynamics/')
W=OUT+'work/'
X=B.X.tocsr().astype(np.float32); tot=np.asarray(X.sum(1)).ravel()
o=B.obs; genes_m=np.array(B.var.symbol if 'symbol' in B.var else B.var_names)
STAGES=['E6.5','E6.75','E7.0','E7.25','E7.5','E7.75','E8.0']
def pbstats(Xc, totc):
    cp=sp.diags(1e4/totc)@Xc; lg=cp.copy(); lg.data=np.log1p(lg.data)
    return (np.asarray(cp.mean(0)).ravel(), np.asarray(lg.mean(0)).ravel(), np.asarray((Xc>0).mean(0)).ravel(), np.asarray(Xc.sum(0)).ravel())
rows=[]; rows_s=[]
for ct,lab in [('Primitive Streak','PS'),('Anterior Primitive Streak','APS')]:
    for s in STAGES:
        idx=np.where((o.celltype==ct)&(o.stage==s))[0]
        if len(idx)==0: rows.append(dict(celltype=lab,stage=s,n=0)); continue
        cp,lg,dt,sm=pbstats(X[idx],tot[idx])
        rows.append(dict(celltype=lab,stage=s,n=len(idx),cp=cp,lg=lg,dt=dt))
        for smp in sorted(o['sample'].iloc[idx].unique(),key=lambda z:int(z)):
            j=idx[o['sample'].values[idx]==smp]
            if len(j)<10: continue
            cp2,lg2,dt2,_=pbstats(X[j],tot[j]); rows_s.append(dict(celltype=lab,stage=s,sample=smp,n=len(j),cp=cp2,lg=lg2,dt=dt2))
print([(r['celltype'],r['stage'],r['n']) for r in rows])
print([(r['celltype'],r['stage'],r['sample'],r['n']) for r in rows_s])
orth=pd.read_csv((str(HGC_DATA) + '/external/mouse_pijuan_sala/mouse_human_orthologs_one2one_Ensembl116.csv')); print(orth.head(3)); print(orth.shape)


# ---- cell [frame 1c2d1a43, message 27] Saving mouse pseudobulk tables with orthologs
def wide(rows,key):
    d={}
    for r in rows:
        if r.get('n',0)==0 or 'cp' not in r: continue
        k=key(r)
        d[f'{k}|cp10k']=r['cp']; d[f'{k}|log1p']=r['lg']; d[f'{k}|det']=r['dt']
    return pd.DataFrame(d,index=genes_m)
MP=wide(rows,lambda r:f"{r['celltype']}_{r['stage']}")
MS=wide(rows_s,lambda r:f"{r['celltype']}_{r['stage']}_s{r['sample']}")
o2o=orth[orth.homology_type=='ortholog_one2one'].drop_duplicates('mouse_symbol').drop_duplicates('human_symbol').set_index('mouse_symbol').human_symbol
MP.insert(0,'human_symbol',MP.index.map(o2o)); MS.insert(0,'human_symbol',MS.index.map(o2o))
# [not executed in the original run: the cell stopped with an error at the next line]
# MP.to_parquet(W+'mouse_PS_pseudobulk_stage.parquet'); MS.to_parquet(W+'mouse_PS_pseudobulk_sample.parquet')
# ncell=pd.DataFrame([dict(celltype=r['celltype'],stage=r['stage'],sample=r.get('sample','all'),n=r['n']) for r in rows+rows_s])
# ncell.to_csv(W+'mouse_PS_cellnumbers.csv',index=False)
# print(MP.shape, MP.human_symbol.notna().sum())
# for g in ['T','Rspo2','Rspo3','Hoxa1','Hoxb1','Eomes','Mesp1','Mixl1','Tbx3','Hoxb8','Hoxb9']:
#     print(g, o2o.get(g), MP.loc[g,[f'PS_{s}|det' for s in STAGES[:6]]].round(3).tolist())
# 


# ---- cell [frame 1c2d1a43, message 29] Saving mouse pseudobulk tables as pickles
MP.to_pickle(W+'mouse_PS_pseudobulk_stage.pkl'); MS.to_pickle(W+'mouse_PS_pseudobulk_sample.pkl')
ncell=pd.DataFrame([dict(celltype=r['celltype'],stage=r['stage'],sample=r.get('sample','all'),n=r['n']) for r in rows+rows_s])
ncell.to_csv(W+'mouse_PS_cellnumbers.csv',index=False)
print(MP.shape, MP.human_symbol.notna().sum())
# [not executed in the original run: the cell stopped with an error at the next line]
# for g in ['T','Rspo2','Rspo3','Hoxa1','Hoxb1','Eomes','Mesp1','Mixl1','Tbx3','Hoxb8','Hoxb9']:
#     print(g, o2o.get(g), MP.loc[g,[f'PS_{s}|det' for s in STAGES[:6]]].round(3).tolist())
# 


# ---- cell [frame 1c2d1a43, message 31] Fixing duplicate mouse gene symbols
print(pd.Index(genes_m).duplicated().sum(), [g for g in ['T','Tbxt'] if g in set(genes_m)])
MP=MP[~MP.index.duplicated()]; MS=MS[~MS.index.duplicated()]
MP.to_pickle(W+'mouse_PS_pseudobulk_stage.pkl'); MS.to_pickle(W+'mouse_PS_pseudobulk_sample.pkl')
for g in ['T','Rspo2','Rspo3','Hoxa1','Hoxb1','Eomes','Mesp1','Mixl1','Tbx3','Hoxb8','Hoxb9']:
    print(g, o2o.get(g), MP.loc[g,[f'PS_{s}|det' for s in STAGES[:6]]].astype(float).round(3).tolist())


# ---- cell [frame 1c2d1a43, message 33] Inspecting CosMx cell tables
E=(str(HGC_DATA) + '/dataprep/export/')
import scipy.io as sio
gC=pd.read_csv(E+'genes.csv'); print(gC.head(3), gC.shape)
c7=pd.read_csv(E+'CS7_cells.csv'); c8=pd.read_csv(E+'CS8_cells.csv'); print(c7.columns.tolist()); print(c7.label_short.value_counts().to_string()); print(pd.crosstab(c8.label_short,c8.get('batch',c8.columns[0])).to_string() if 'batch' in c8 else c8.label_short.value_counts())


# ---- cell [frame 1c2d1a43, message 37] Computing CosMx CS7/CS8 pseudobulk per label
def load_mtx(p):
    m=sio.mmread(p).tocsr().T.tocsr().astype(np.float32)  # cells x genes
    return m
C7=load_mtx(E+'CS7_counts.mtx'); C8=load_mtx(E+'CS8_counts.mtx'); print(C7.shape,C8.shape,len(c7),len(c8))
gH=gC.gene.values
def group_pb(Xc, labels, tag, genes, extra_groups=None):
    totc=np.asarray(Xc.sum(1)).ravel(); out={}; ns={}
    labs=pd.Series(labels)
    groups={l:np.where(labs.values==l)[0] for l in labs.unique()}
    if extra_groups: groups.update(extra_groups)
    for l,idx in groups.items():
        if len(idx)==0: continue
        cp,lg,dt,_=pbstats(Xc[idx],totc[idx])
        out[f'{tag}:{l}|cp10k']=cp; out[f'{tag}:{l}|log1p']=lg; out[f'{tag}:{l}|det']=dt; ns[f'{tag}:{l}']=len(idx)
    return pd.DataFrame(out,index=genes), ns, totc
m8=(c8.batch=='CS8_main').values
P7,n7,t7=group_pb(C7,c7.label_short.values,'CosMx_CS7',gH,{'VE':np.where(c7.label_short.isin(['VE1','VE2']))[0]})
P8,n8,t8=group_pb(C8[m8],c8.label_short.values[m8],'CosMx_CS8',gH,{'VE':np.where(c8.label_short.values[m8]=='VE1')[0].tolist()+np.where(c8.label_short.values[m8]=='VE2')[0].tolist()})
P8b,n8b,_=group_pb(C8,c8.label_short.values,'CosMx_CS8all',gH)
print(n7, n8); print(np.median(t7[c7.label_short=='PS']), np.median(t8[c8.label_short.values[m8]=='PS']))


# ---- cell [frame 1c2d1a43, message 41] Loading 10x, Tyser and monkey matrices
SC=(str(HGC_DATA) + '/milestone_evidence/')
T10=sio.mmread(SC+'out_scrna/work/tenx_counts.mtx').tocsr().T.tocsr().astype(np.float32); g10=open(SC+'out_scrna/work/tenx_genes.txt').read().split('\n')[:T10.shape[1]]
H11=sio.mmread(SC+'hue11/CS8-16_counts.mtx').tocsr().T.tocsr().astype(np.float32); g11=open(SC+'hue11/CS8-16_genes.txt').read().split('\n')[:H11.shape[1]]
TY=sio.mmread(SC+'out_scrna/work/tyser_counts.mtx').tocsr().astype(np.float32); gty=open(SC+'out_scrna/work/tyser_genes.txt').read().split('\n')
print(T10.shape,len(g10),H11.shape,len(g11),TY.shape,len(gty), g10==g11)
z=np.load((str(HGC_DATA) + '/GSE193007/counts_recovered_int.npz'),allow_pickle=True); print(z.files)
mk=pd.read_csv((str(HGC_DATA) + '/GSE193007/MFE56636-meta.csv')); gmk=pd.read_csv((str(HGC_DATA) + '/GSE193007/genes.csv')); print(mk.columns.tolist(), gmk.head(2)); print(pd.crosstab([mk.theiler_stage,mk['sample']],mk.cell_type.isin(['PS','APS'])))


# ---- cell [frame 1c2d1a43, message 43] Resolving Tyser and monkey gene names
gty2=open((str(HGC_DATA) + '/staging/layer_rescue/tyser_CS7_genes.txt')).read().split('\n'); gty2=[g for g in gty2 if g!='']; print(len(gty2), gty2[:3], [g for g in gty2 if g in('TBXT','T','EOMES','HOXA1')])
M=sp.csr_matrix((z['data'],z['indices'],z['indptr']),shape=tuple(z['shape'])); print(M.shape, z['format'])
gm=gmk.iloc[:,0].values; print(len(gm), [g for g in ['T','TBXT','EOMES','MESP1','HOXA1','RSPO2','RSPO3','TBX3'] if g in set(gm)])


# ---- cell [frame 1c2d1a43, message 47] Building unified pseudobulk for human and monkey datasets
def pbframe(Xc, genes, groups, tag, totc=None):
    if totc is None: totc=np.asarray(Xc.sum(1)).ravel()
    out={}; ns={}
    for l,idx in groups.items():
        idx=np.asarray(idx)
        if len(idx)==0: continue
        cp,lg,dt,_=pbstats(Xc[idx],totc[idx])
        out[f'{tag}:{l}|cp10k']=cp; out[f'{tag}:{l}|log1p']=lg; out[f'{tag}:{l}|det']=dt; ns[f'{tag}:{l}']=len(idx)
    df=pd.DataFrame(out,index=pd.Index(genes,name='gene')); df=df[~df.index.duplicated()]
    return df, ns
def lab_groups(labels, extra={}):
    labs=np.asarray(labels); g={l:np.where(labs==l)[0] for l in pd.unique(labs)}; 
    for k,v in extra.items(): g[k]=np.where(np.isin(labs,v))[0]
    return g
PB={}; NS={}
# CosMx
P,n=pbframe(C7,gH,lab_groups(c7.label_short.values,{'VEbkg':['VE1','VE2'],'PS+APS':['PS','APS']}),'CosMx_CS7'); PB['CosMx_CS7']=P; NS.update(n)
P,n=pbframe(C8[m8],gH,lab_groups(c8.label_short.values[m8],{'VEbkg':['VE1','VE2']}),'CosMx_CS8'); PB['CosMx_CS8']=P; NS.update(n)
P,n=pbframe(C8,gH,lab_groups(c8.label_short.values,{'VEbkg':['VE1','VE2']}),'CosMx_CS8both'); PB['CosMx_CS8both']=P; NS.update(n)
# 10x
# [not executed in the original run: the cell stopped with an error at the next line]
# P,n=pbframe(T10,g10,lab_groups(t.Type2.values,{'bkg':['13 AME','39 Trophoblast']}),'10x_CS7'); PB['10x_CS7']=P; NS.update(n)
# P,n=pbframe(H11,g11,lab_groups(m.Type2.values,{'bkg':['13 AME','39 Trophoblast']}),'10x_CS8'); PB['10x_CS8']=P; NS.update(n)
# # Tyser
# P,n=pbframe(TY,gty2,lab_groups(ty.label.values,{'PScluster':['Primitive Streak','PGC'],'bkg':['Amnion','Hypoblast','YS Endoderm']}),'Tyser_CS7'); PB['Tyser_CS7']=P; NS.update(n)
# # monkey per embryo
# gmh=['TBXT' if g=='T' else g for g in gm]
# totm=np.asarray(M.sum(1)).ravel()
# for s in ['CS8-e1','CS8-e2','CS9-e1','CS9-e2','CS11-e1','CS11-e2']:
#     sel=(mk['sample']==s).values; ctv=mk.cell_type.values
#     grp={'PS':np.where(sel&(ctv=='PS'))[0],'APS':np.where(sel&(ctv=='APS'))[0],'PS+APS':np.where(sel&np.isin(ctv,['PS','APS']))[0],'EPI':np.where(sel&(ctv=='EPI'))[0],'bkg':np.where(sel&np.isin(ctv,['AM','VE']))[0]}
#     P,n=pbframe(M,gmh,grp,f'Monkey_{s}',totm); PB[f'Monkey_{s}']=P; NS.update(n)
# print({k:v for k,v in NS.items() if any(x in k for x in ['PS','APS','bkg','VEbkg'])})
# 


# ---- cell [frame 1c2d1a43, message 49] Building 10x, Tyser and monkey pseudobulk
t=pd.read_csv(SC+'out_scrna/work/tenx_meta.csv'); m=pd.read_csv(SC+'hue11/CS8-16_meta.csv')
assert len(t)==T10.shape[0] and len(m)==H11.shape[0] and len(ty)==TY.shape[0] and len(mk)==M.shape[0]
P,n=pbframe(T10,g10,lab_groups(t.Type2.values,{'bkg':['13 AME','39 Trophoblast']}),'10x_CS7'); PB['10x_CS7']=P; NS.update(n)
P,n=pbframe(H11,g11,lab_groups(m.Type2.values,{'bkg':['13 AME','39 Trophoblast']}),'10x_CS8'); PB['10x_CS8']=P; NS.update(n)
P,n=pbframe(TY,gty2,lab_groups(ty.label.values,{'PScluster':['Primitive Streak','PGC'],'bkg':['Amnion','Hypoblast','YS Endoderm']}),'Tyser_CS7'); PB['Tyser_CS7']=P; NS.update(n)
gmh=['TBXT' if g=='T' else g for g in gm]
totm=np.asarray(M.sum(1)).ravel()
for s in ['CS8-e1','CS8-e2','CS9-e1','CS9-e2','CS11-e1','CS11-e2']:
    sel=(mk['sample']==s).values; ctv=mk.cell_type.values
    grp={'PS':np.where(sel&(ctv=='PS'))[0],'APS':np.where(sel&(ctv=='APS'))[0],'PS+APS':np.where(sel&np.isin(ctv,['PS','APS']))[0],'EPI':np.where(sel&(ctv=='EPI'))[0],'bkg':np.where(sel&np.isin(ctv,['AM','VE']))[0]}
    P,n=pbframe(M,gmh,grp,f'Monkey_{s}',totm); PB[f'Monkey_{s}']=P; NS.update(n)
print({k:v for k,v in NS.items() if any(x in k for x in ['PS','APS','bkg','VEbkg'])})


# ---- cell [frame 1c2d1a43, message 57] Defining mouse PS-dynamic genes E7.0→E7.75
PSEUDO=0.1
def lfc(a,b): return np.log2((b+PSEUDO)/(a+PSEUDO))
mp=MP.copy(); ms=MS.copy()
cols=lambda s,stat='cp10k': f'PS_{s}|{stat}'
def mouse_dyn(s0,s1):
    d=pd.DataFrame(index=mp.index); d['human']=mp.human_symbol
    d['cp0']=mp[cols(s0)].astype(float); d['cp1']=mp[cols(s1)].astype(float)
    d['det0']=mp[cols(s0,'det')].astype(float); d['det1']=mp[cols(s1,'det')].astype(float)
    d['lfc']=lfc(d.cp0,d.cp1)
    sc0=[c for c in ms.columns if c.startswith(f'PS_{s0}_s') and c.endswith('|cp10k')]
    sc1=[c for c in ms.columns if c.startswith(f'PS_{s1}_s') and c.endswith('|cp10k')]
    pairs=np.stack([lfc(ms[a].astype(float).values,ms[b].astype(float).values) for a in sc0 for b in sc1],1)
    d['pair_frac_same']=(np.sign(pairs)==np.sign(d.lfc.values)[:,None]).mean(1)
    d['n_pairs']=pairs.shape[1]
    d['sample_lfc_min']=pairs.min(1); d['sample_lfc_max']=pairs.max(1)
    d['dynamic']=(d.lfc.abs()>=1)&(np.maximum(d.det0,d.det1)>=0.10)&(d.pair_frac_same>=0.8)
    d['direction']=np.where(d.lfc>0,'up','down')
    return d
D75=mouse_dyn('E7.0','E7.75'); D50=mouse_dyn('E7.0','E7.5')
for nm,d in [('E7.0->E7.75',D75),('E7.0->E7.5',D50)]:
    dd=d[d.dynamic]; print(nm, len(dd), (dd.lfc>0).sum(), (dd.lfc<0).sum(), dd.human.notna().sum(), d.n_pairs.iloc[0])
print(len(set(D75[D75.dynamic].index)&set(D50[D50.dynamic].index)))
print(D75.loc[['T','Rspo3','Hoxa1','Hoxb1','Eomes','Mesp1','Mixl1','Tbx3','Cdx2','Hoxb9','Fgf8','Nodal']].round(3).to_string())


# ---- cell [frame 1c2d1a43, message 59] Computing CosMx CS7→CS8 concordance with mouse
def hum_change(P, tag0, tag1, g0='PS', g1='PS', bkg0=None, bkg1=None):
    """P0,P1 frames; returns per-gene table"""
    A,Bf=PB[tag0],PB[tag1]
    common=A.index.intersection(Bf.index)
    d=pd.DataFrame(index=common)
    d['cp0']=A.loc[common,f'{tag0}:{g0}|cp10k']; d['cp1']=Bf.loc[common,f'{tag1}:{g1}|cp10k']
    d['det0']=A.loc[common,f'{tag0}:{g0}|det']; d['det1']=Bf.loc[common,f'{tag1}:{g1}|det']
    d['lfc']=lfc(d.cp0,d.cp1)
    if bkg0: d['bkg0']=A.loc[common,f'{tag0}:{bkg0}|det']; d['bkg1']=Bf.loc[common,f'{tag1}:{bkg1}|det']
    return d
def above_bkg(d, fold=2, pp=0.05):
    return ((d.det0>=fold*d.bkg0)&(d.det0-d.bkg0>=pp))|((d.det1>=fold*d.bkg1)&(d.det1-d.bkg1>=pp))
Hc=hum_change(None,'CosMx_CS7','CosMx_CS8',bkg0='VEbkg',bkg1='VEbkg')
Hc['pass_strict']=above_bkg(Hc,2,0.05); Hc['pass_lenient']=above_bkg(Hc,1.5,0.02)
ref=D75[D75.dynamic&D75.human.notna()].copy()
J=ref.join(Hc.add_prefix('h_'),on='human',how='inner')
print(len(ref), len(J), J.h_pass_strict.sum(), J.h_pass_lenient.sum())
from scipy.stats import spearmanr
rng=np.random.default_rng(0)
def concord(mf, hf, nperm=10000, seed=0):
    mf=np.asarray(mf,float); hf=np.asarray(hf,float); r=np.random.default_rng(seed)
    same=np.mean(np.sign(mf)==np.sign(hf)); rho=spearmanr(mf,hf)[0]
    ns=np.empty(nperm); nr=np.empty(nperm)
    for i in range(nperm):
        p=r.permutation(hf); ns[i]=np.mean(np.sign(mf)==np.sign(p)); nr[i]=spearmanr(mf,p)[0]
    return dict(n=len(mf), same_sign=same, n_same=int(np.sum(np.sign(mf)==np.sign(hf))), rho=rho, null_same_median=np.median(ns), P_same=(1+(ns>=same).sum())/(1+nperm), P_rho=(1+(nr>=rho).sum())/(1+nperm),
                up_agree=np.mean(hf[mf>0]>0) if (mf>0).any() else np.nan, down_agree=np.mean(hf[mf<0]<0) if (mf<0).any() else np.nan, n_up=int((mf>0).sum()), n_down=int((mf<0).sum()))
for nm,sel in [('all',J.index==J.index),('strict',J.h_pass_strict),('lenient',J.h_pass_lenient)]:
    print(nm, {k:(round(v,3) if isinstance(v,float) else v) for k,v in concord(J.lfc[sel],J.h_lfc[sel]).items()})


# ---- cell [frame 1c2d1a43, message 61] Recomputing concordance with VE-max background rule
for tg in ['CosMx_CS7','CosMx_CS8']:
    Pp=PB[tg]; Pp[f'{tg}:VEmax|det']=np.maximum(Pp[f'{tg}:VE1|det'],Pp[f'{tg}:VE2|det'])
Hc=hum_change(None,'CosMx_CS7','CosMx_CS8',bkg0='VEmax',bkg1='VEmax')
Hc['pass_primary']=above_bkg(Hc,2,0.02); Hc['pass_strict']=above_bkg(Hc,2,0.05); Hc['pass_none']=True
J=ref.join(Hc.add_prefix('h_'),on='human',how='inner')
RES={}
for nm in ['primary','strict','none']:
    sel=J[f'h_pass_{nm}']; RES[nm]=concord(J.lfc[sel],J.h_lfc[sel]); print(nm,{k:(round(float(v),4)) for k,v in RES[nm].items()})
# matched random-gene null for primary
uni=Hc[Hc.pass_primary].index.intersection(set(D75.human.dropna()))
lm=np.log10((Hc.cp0+Hc.cp1)/2+1e-4)
qs=np.quantile(lm[uni],np.linspace(0,1,11)); binof=lambda g: min(9,max(0,np.searchsorted(qs,lm[g],side='right')-1))
sel=J[J.h_pass_primary]; refb=[binof(g) for g in sel.human]; pools={b:[g for g in uni if binof(g)==b] for b in range(10)}
dirs=np.sign(sel.lfc.values); obs=np.mean(np.sign(sel.h_lfc.values)==dirs)
r2=np.random.default_rng(1); null=[np.mean(np.sign(Hc.lfc[[r2.choice(pools[b]) for b in refb]].values)==dirs) for _ in range(5000)]
print('matched null', len(uni), obs, np.median(null), (1+np.sum(np.array(null)>=obs))/5001)


# ---- cell [frame 1c2d1a43, message 65] Tabulating key genes and HOX in mouse and CosMx
HOX3=['HOXA1','HOXB1','HOXA2','HOXB2','HOXA3','HOXB3','HOXD1','HOXD3']
HOX5=['HOXB8','HOXB9','HOXC8','HOXC9','HOXA9','HOXA10','HOXD9','HOXC6','HOXB6','HOXB7','HOXA7','HOXB5','HOXA5']
KEY=['TBXT','RSPO2','RSPO3','HOXA1','HOXB1','EOMES','MESP1','MIXL1','TBX3','CDX2','FGF8','NODAL','WNT3','GSC','FOXA2','CER1']
h2m={v:k for k,v in o2o.items()}
rowsK=[]
for g in KEY+HOX3+HOX5:
    mg=h2m.get(g); r=dict(gene=g, mouse=mg)
    if mg in mp.index:
        for s in STAGES[:6]: r[f'm_det_{s}']=float(mp.loc[mg,cols(s,'det')])
        r['m_lfc_7.0_7.75']=float(D75.loc[mg,'lfc']); r['m_dyn']=bool(D75.loc[mg,'dynamic'])
    if g in Hc.index:
        h=Hc.loc[g]; r.update(h_det_CS7=h.det0,h_det_CS8=h.det1,h_bkg7=h.bkg0,h_bkg8=h.bkg1,h_lfc=h.lfc, h_APS7=PB['CosMx_CS7'].loc[g,'CosMx_CS7:APS|det'])
    rowsK.append(r)
K=pd.DataFrame(rowsK); print(K.round(3).to_string())


# ---- cell [frame 1c2d1a43, message 75] Loading Stereo-seq pseudobulk tables
for b in ['CS7','CS8','CS9-1','CS9-2']:
    d=pd.read_csv(W+f'stereo_{b}_Type2_pb.csv')
    piv=d.pivot_table(index='gene',columns='group',values=['mean_cp10k','mean_log1p','det'])
    n=d.drop_duplicates('group').set_index('group').n
    P=pd.DataFrame(index=piv.index)
    for gname in n.index:
        P[f'Stereo_{b}:{gname}|cp10k']=piv[('mean_cp10k',gname)]; P[f'Stereo_{b}:{gname}|log1p']=piv[('mean_log1p',gname)]; P[f'Stereo_{b}:{gname}|det']=piv[('det',gname)]
        NS[f'Stereo_{b}:{gname}']=int(n[gname])
    PB[f'Stereo_{b}']=P
    print(b, n.to_dict())


# ---- cell [frame 1c2d1a43, message 77] Computing concordance for every dataset pair
def get_group(tag, groups):
    P=PB[tag]; ns=np.array([NS[f'{tag}:{g}'] for g in groups],float)
    cp=sum(P[f'{tag}:{g}|cp10k'].fillna(0)*n for g,n in zip(groups,ns))/ns.sum()
    lg=sum(P[f'{tag}:{g}|log1p'].fillna(0)*n for g,n in zip(groups,ns))/ns.sum()
    dt=sum(P[f'{tag}:{g}|det'].fillna(0)*n for g,n in zip(groups,ns))/ns.sum()
    return cp,lg,dt,int(ns.sum())
def get_bkg(tag, groups): return pd.concat([PB[tag][f'{tag}:{g}|det'] for g in groups],axis=1).max(1)
BKG={'CosMx':['VE1','VE2'],'Stereo':['13 AME','38 VE_YE'],'10x':['13 AME','39 Trophoblast'],'Monkey':['bkg'],'Tyser':['bkg']}
PAIRS=[ # name, tag0, groups0, tag1, groups1, platform, role
 ('CosMx CS7→CS8','CosMx_CS7',['PS'],'CosMx_CS8',['PS'],'CosMx','primary'),
 ('CosMx CS7 PS+APS→CS8 PS','CosMx_CS7',['PS','APS'],'CosMx_CS8',['PS'],'CosMx','sensitivity'),
 ('Stereo-seq CS7→CS8','Stereo_CS7',['15 PS'],'Stereo_CS8',['15 PS'],'Stereo','primary'),
 ('Stereo-seq CS8→CS9','Stereo_CS8',['15 PS'],'Stereo_CS9-2',['15 PS'],'Stereo','primary (CS9-2 PS n=13 spots)'),
 ('Stereo-seq CS7→CS8 (PS+EPI(p))','Stereo_CS7',['15 PS','2   EPI/ECT(p)'],'Stereo_CS8',['15 PS','2   EPI/ECT(p)'],'Stereo','sensitivity'),
 ('Stereo-seq CS8→CS9 (PS+EPI(p)+NMP)','Stereo_CS8',['15 PS','2   EPI/ECT(p)'],'Stereo_CS9-2',['15 PS','2   EPI/ECT(p)','5   NMP'],'Stereo','sensitivity'),
 ('Stereo-seq CS7→CS9 (PS+EPI(p)+NMP)','Stereo_CS7',['15 PS','2   EPI/ECT(p)'],'Stereo_CS9-2',['15 PS','2   EPI/ECT(p)','5   NMP'],'Stereo','sensitivity'),
 ('10x CS7→CS8','10x_CS7',['15 PS'],'10x_CS8',['15 PS'],'10x','primary'),
]
for a in ['e1','e2']:
    for b in ['e1','e2']:
        PAIRS.append((f'Monkey CS8-{a}→CS9-{b} (PS)',f'Monkey_CS8-{a}',['PS'],f'Monkey_CS9-{b}',['PS'],'Monkey','primary (CS8 PS n=10/16)'))
        PAIRS.append((f'Monkey CS8-{a}→CS9-{b} (PS+APS)',f'Monkey_CS8-{a}',['PS+APS'],f'Monkey_CS9-{b}',['PS+APS'],'Monkey','sensitivity'))
for a in ['e1','e2']:
    PAIRS.append((f'Monkey CS9-{a}→CS11-{a} (PS)',f'Monkey_CS9-{a}',['PS'],f'Monkey_CS11-{a}',['PS'],'Monkey','extra'))
def pair_table(tag0,g0,tag1,g1,plat):
    cp0,lg0,d0,n0=get_group(tag0,g0); cp1,lg1,d1,n1=get_group(tag1,g1)
    com=cp0.index.intersection(cp1.index)
    d=pd.DataFrame({'cp0':cp0[com],'cp1':cp1[com],'det0':d0[com],'det1':d1[com],'log1p0':lg0[com],'log1p1':lg1[com]})
    d['bkg0']=get_bkg(tag0,BKG[plat])[com]; d['bkg1']=get_bkg(tag1,BKG[plat])[com]
    d['lfc']=lfc(d.cp0,d.cp1); d['pass_primary']=above_bkg(d,2,0.02); d['pass_strict']=above_bkg(d,2,0.05)
    return d,n0,n1
REFSET=ref[['human','lfc','direction','det0','det1','pair_frac_same']].rename(columns={'lfc':'mouse_lfc','det0':'mouse_det_E7.0','det1':'mouse_det_E7.75'})
summ=[]; PT={}
for i,(nm,t0,g0,t1,g1,plat,role) in enumerate(PAIRS):
    d,n0,n1=pair_table(t0,g0,t1,g1,plat); PT[nm]=d
    Jx=REFSET.join(d,on='human',how='inner')
    for filt in ['primary','none']:
        s=Jx[Jx[f'pass_{filt}']] if filt!='none' else Jx
        if len(s)<5: continue
        c=concord(s.mouse_lfc,s.lfc,nperm=10000,seed=i)
        summ.append(dict(pair=nm,platform=plat,role=role,n_cells_earlier=n0,n_cells_later=n1,filter=filt,**c))
S=pd.DataFrame(summ); print(S[['pair','filter','n_cells_earlier','n_cells_later','n','same_sign','rho','P_same','P_rho']].round(4).to_string())


# ---- cell [frame 1c2d1a43, message 79] Concordance with alternative mouse references
def concord(mf, hf, nperm=10000, seed=0):
    mf=np.asarray(mf,float); hf=np.asarray(hf,float); r=np.random.default_rng(seed)
    same=np.mean(np.sign(mf)==np.sign(hf)); rho=spearmanr(mf,hf)[0]
    ns=np.empty(nperm); nr=np.empty(nperm)
    for i in range(nperm):
        p=r.permutation(hf); ns[i]=np.mean(np.sign(mf)==np.sign(p)); nr[i]=spearmanr(mf,p)[0]
    return dict(n=len(mf), n_same=int(np.sum(np.sign(mf)==np.sign(hf))), same_sign=same, rho=rho, null_same_median=np.median(ns),
                P_same_upper=(1+(ns>=same).sum())/(1+nperm), P_same_lower=(1+(ns<=same).sum())/(1+nperm),
                P_rho_upper=(1+(nr>=rho).sum())/(1+nperm), P_rho_lower=(1+(nr<=rho).sum())/(1+nperm),
                up_agree=np.mean(hf[mf>0]>0) if (mf>0).any() else np.nan, down_agree=np.mean(hf[mf<0]<0) if (mf<0).any() else np.nan, n_up=int((mf>0).sum()), n_down=int((mf<0).sum()))
# mouse reference variants
D75b=D75.copy(); D75b['dynamic']=(D75b.lfc.abs()>=0.585)&(np.maximum(D75b.det0,D75b.det1)>=0.10)&(D75b.pair_frac_same>=0.8)
REFS={'E7.0→E7.75 (primary)':D75,'E7.0→E7.5':D50,'E7.0→E7.75 |log2FC|≥0.585':D75b}
summ=[]
for rname,Dm in REFS.items():
    R=Dm[Dm.dynamic&Dm.human.notna()][['human','lfc']].rename(columns={'lfc':'mouse_lfc'})
    for i,(nm,t0,g0,t1,g1,plat,role) in enumerate(PAIRS):
        if rname!='E7.0→E7.75 (primary)' and role.startswith('sens'): continue
        Jx=R.join(PT[nm],on='human',how='inner')
        for filt in ['primary','strict','none']:
            s=Jx[Jx[f'pass_{filt}']] if filt!='none' else Jx
            if len(s)<5: continue
            summ.append(dict(mouse_reference=rname,pair=nm,platform=plat,role=role,n_cells_earlier=get_group(t0,g0)[3],n_cells_later=get_group(t1,g1)[3],filter=filt,**concord(s.mouse_lfc,s.lfc,nperm=10000,seed=i)))
S=pd.DataFrame(summ)
# [not executed in the original run: the cell stopped with an error at the next line]
# print(S[S.filter=='primary'][['mouse_reference','pair','n','same_sign','rho','P_same_upper','P_same_lower','P_rho_upper','P_rho_lower']].round(4).to_string())


# ---- cell [frame 1c2d1a43, message 81] Printing concordance summary
S=S.rename(columns={'filter':'gene_filter'})
print(S[S.gene_filter=='primary'][['mouse_reference','pair','n','same_sign','rho','P_same_upper','P_same_lower','P_rho_upper','P_rho_lower']].round(4).to_string())


# ---- cell [frame 1c2d1a43, message 83] Saving unified PS pseudobulk long table
recs=[]
def add(dataset, stage, sample, group, cp, lg, dt, n, platform, species):
    recs.append(pd.DataFrame({'gene':cp.index,'dataset':dataset,'species':species,'platform':platform,'stage':stage,'sample':sample,'group':group,'n_cells':n,'mean_cp10k':cp.values,'mean_log1p_cp10k':lg.values,'detection':dt.values}))
# mouse (human symbols for orthologs; mouse symbol kept)
for r in rows+rows_s:
    if r.get('n',0)==0 or 'cp' not in r: continue
    s=pd.Series(r['cp'],index=genes_m); keep=~s.index.duplicated()
    idx=pd.Index(genes_m)[keep]
    add('Mouse Pijuan-Sala 2019',r['stage'],f"s{r['sample']}" if 'sample' in r else 'pooled',r['celltype'],pd.Series(r['cp'][keep],idx),pd.Series(r['lg'][keep],idx),pd.Series(r['dt'][keep],idx),r['n'],'10x','mouse')
spec=[('HuE#1 CS7 CosMx','CosMx_CS7','CS7',['PS'],'PS'),('HuE#1 CS7 CosMx','CosMx_CS7','CS7',['APS'],'APS'),('HuE#1 CS7 CosMx','CosMx_CS7','CS7',['VE1','VE2'],'VE bkg (VE1+VE2)'),
      ('HuE#2 CS8 CosMx','CosMx_CS8','CS8',['PS'],'PS'),('HuE#2 CS8 CosMx','CosMx_CS8','CS8',['VE1','VE2'],'VE bkg (VE1+VE2)'),
      ('Stereo-seq CS7 (Cui 2025)','Stereo_CS7','CS7',['15 PS'],'PS'),('Stereo-seq CS7 (Cui 2025)','Stereo_CS7','CS7',['2   EPI/ECT(p)'],'EPI/ECT(p)'),
      ('Stereo-seq CS8 (label "Xiao" in plot.py; attribution unverified)','Stereo_CS8','CS8',['15 PS'],'PS'),('Stereo-seq CS8 (label "Xiao" in plot.py; attribution unverified)','Stereo_CS8','CS8',['2   EPI/ECT(p)'],'EPI/ECT(p)'),
      ('Stereo-seq CS9-2','Stereo_CS9-2','CS9',['15 PS'],'PS'),('Stereo-seq CS9-2','Stereo_CS9-2','CS9',['2   EPI/ECT(p)'],'EPI/ECT(p)'),('Stereo-seq CS9-2','Stereo_CS9-2','CS9',['5   NMP'],'NMP'),
      ('In-house 10x CS7 (CS7-15)','10x_CS7','CS7',['15 PS'],'PS'),('In-house 10x CS8 (CS8-16)','10x_CS8','CS8',['15 PS'],'PS'),
      ('Tyser 2021 CS7 Smart-seq2','Tyser_CS7','CS7',['PScluster'],'PS cluster (195 PS + 7 PGC)')]
for s_ in ['CS8-e1','CS8-e2','CS9-e1','CS9-e2','CS11-e1','CS11-e2']:
    for g in ['PS','APS']: spec.append(('Monkey Zhai 2022',f'Monkey_{s_}',s_.split('-')[0],[g],g))
for ds,tag,stg,grp,gl in spec:
    cp,lg,dt,n=get_group(tag,grp); sp_='human' if not ds.startswith('Monkey') else 'cynomolgus monkey'
    plat='CosMx WTX' if 'CosMx' in tag else 'Stereo-seq' if 'Stereo' in tag else 'Smart-seq2' if 'Tyser' in tag else '10x'
    add(ds,stg,tag.split('_')[-1] if ds.startswith('Monkey') else 'single embryo',gl,cp,lg,dt,n,plat,sp_)
LONG=pd.concat(recs,ignore_index=True)
LONG.to_csv(OUT+'PS_pseudobulk_all_datasets.csv.gz',index=False)
CN=LONG.drop_duplicates(['dataset','stage','sample','group'])[['dataset','species','platform','stage','sample','group','n_cells']]
CN.to_csv(OUT+'PS_pseudobulk_cell_numbers.csv',index=False); print(LONG.shape); print(CN.to_string())


# ---- cell [frame 1c2d1a43, message 87] Building full concordance and discordant-gene table
# Full concordance table: mouse dynamic genes (E7.0->E7.75) x human CosMx + 10x cross-check + Stereo + monkey
FT=D75[D75.dynamic].copy()
FT=FT.rename(columns={'cp0':'mouse_cp10k_E7.0','cp1':'mouse_cp10k_E7.75','det0':'mouse_det_E7.0','det1':'mouse_det_E7.75','lfc':'mouse_log2FC_E7.0_E7.75','pair_frac_same':'mouse_sample_pair_consistency','direction':'mouse_direction'})
FT['mouse_log2FC_E7.0_E7.5']=D50.loc[FT.index,'lfc']
FT.index.name='mouse_gene'; FT=FT.reset_index()
c=PT['CosMx CS7→CS8']; x=PT['10x CS7→CS8']
def take(d,cols,pref):
    out=d.reindex(FT.human)[cols]; out.columns=[pref+k for k in cols]; return out.reset_index(drop=True)
FT=pd.concat([FT, take(c,['cp0','cp1','det0','det1','bkg0','bkg1','lfc','pass_primary','pass_strict'],'CosMx_'),
               take(x,['det0','det1','lfc','pass_primary'],'10x_'),
               take(PT['Stereo-seq CS7→CS8'],['det0','det1','lfc','pass_primary'],'StereoCS7_8_'),
               take(PT['Stereo-seq CS8→CS9'],['det0','det1','lfc','pass_primary'],'StereoCS8_9_')],axis=1)
mon=np.nanmean(np.stack([PT[f'Monkey CS8-{a}→CS9-{b} (PS)'].reindex(FT.human).lfc.values for a in ['e1','e2'] for b in ['e1','e2']]),0)
FT['Monkey_CS8_9_PS_mean_log2FC_4pairs']=mon
FT['in_CosMx_panel']=FT.CosMx_lfc.notna()
FT['CosMx_same_sign']=np.where(FT.in_CosMx_panel, np.sign(FT.CosMx_lfc)==np.sign(FT['mouse_log2FC_E7.0_E7.75']), np.nan)
def reason(r):
    if r.human is None or pd.isna(r.human): return 'no one-to-one human ortholog'
    if not r.in_CosMx_panel: return 'not in CosMx panel'
    if r.CosMx_same_sign: return ''
    R=[]
    near=((r.CosMx_det0-r.CosMx_bkg0)<0.05)&((r.CosMx_det1-r.CosMx_bkg1)<0.05)
    if not r.CosMx_pass_primary: R.append('below CosMx background (PS detection <2x VE and <2 pp above it)')
    elif near: R.append('near CosMx background (<5 pp above VE)')
    if abs(r.CosMx_lfc)<0.3: R.append('negligible human change (|log2FC|<0.3)')
    if r.CosMx_pass_primary and abs(r.CosMx_lfc)>=0.3 and not pd.isna(r['10x_lfc']):
        if np.sign(r['10x_lfc'])==np.sign(r['mouse_log2FC_E7.0_E7.75']): R.append('10x CS7→CS8 agrees with mouse: CosMx-specific (platform/annotation)')
        elif abs(r['10x_lfc'])>=0.3: R.append('10x CS7→CS8 also opposite to mouse: candidate species difference')
        else: R.append('10x change negligible')
    if r.mouse_sample_pair_consistency<1: R.append(f'mouse sample pairs consistent {r.mouse_sample_pair_consistency:.2f}')
    return '; '.join(R)
FT['discordance_note']=FT.apply(reason,axis=1)
FT=FT.sort_values(['CosMx_pass_primary','mouse_log2FC_E7.0_E7.75'],ascending=[False,True])
DISC=FT[(FT.CosMx_same_sign==False)]
print(len(FT), FT.in_CosMx_panel.sum(), FT.human.notna().sum(), len(DISC), DISC.CosMx_pass_primary.sum())
print(DISC[['human','mouse_log2FC_E7.0_E7.75','CosMx_det0','CosMx_det1','CosMx_bkg0','CosMx_bkg1','CosMx_lfc','10x_lfc','CosMx_pass_primary','discordance_note']].round(3).to_string())


# ---- cell [frame 1c2d1a43, message 89] Checking each specific text claim with numbers
def hv(pt,g,k): 
    d=PT[pt]; return float(d.loc[g,k]) if g in d.index else np.nan
CL=[]
for g in ['TBXT','RSPO2','RSPO3','HOXA1','HOXB1','HOXA2','HOXB2','HOXA3','HOXB3','EOMES','MESP1','MIXL1','TBX3','GSC','CDX2','FGF8','NODAL']+['HOXB8','HOXB9','HOXC8','HOXC9','HOXA9','HOXA10','HOXD9']:
    mg=h2m.get(g); r=dict(gene=g,mouse_gene=mg)
    for s in STAGES[:6]: r[f'mouse_PS_det_{s}']=float(mp.loc[mg,cols(s,'det')]) if mg in mp.index else np.nan
    r['mouse_log2FC_E7.0_E7.75']=float(D75.loc[mg,'lfc']) if mg in D75.index else np.nan
    r['mouse_dynamic']=bool(D75.loc[mg,'dynamic']) if mg in D75.index else False
    for k,lab in [('det0','CosMx_CS7_PS_det'),('det1','CosMx_CS8_PS_det'),('bkg0','CosMx_CS7_VEmax_det'),('bkg1','CosMx_CS8_VEmax_det'),('lfc','CosMx_log2FC')]: r[lab]=hv('CosMx CS7→CS8',g,k)
    r['CosMx_CS7_above_bkg']=(r['CosMx_CS7_PS_det']>=2*r['CosMx_CS7_VEmax_det'])&(r['CosMx_CS7_PS_det']-r['CosMx_CS7_VEmax_det']>=0.02)
    r['CosMx_CS8_above_bkg']=(r['CosMx_CS8_PS_det']>=2*r['CosMx_CS8_VEmax_det'])&(r['CosMx_CS8_PS_det']-r['CosMx_CS8_VEmax_det']>=0.02)
    for pt,lab in [('10x CS7→CS8','10x'),('Stereo-seq CS7→CS8','StereoCS7_8'),('Stereo-seq CS8→CS9','StereoCS8_9')]:
        r[f'{lab}_det0']=hv(pt,g,'det0'); r[f'{lab}_det1']=hv(pt,g,'det1'); r[f'{lab}_log2FC']=hv(pt,g,'lfc')
    for a in ['e1','e2']:
        for b in ['e1','e2']: r[f'Monkey_CS8{a}_CS9{b}_PS_log2FC']=hv(f'Monkey CS8-{a}→CS9-{b} (PS)',g,'lfc')
    CL.append(r)
CL=pd.DataFrame(CL)
print(CL[['gene','mouse_PS_det_E7.0','mouse_PS_det_E7.5','mouse_PS_det_E7.75','mouse_log2FC_E7.0_E7.75','CosMx_CS7_PS_det','CosMx_CS8_PS_det','CosMx_CS7_VEmax_det','CosMx_CS8_VEmax_det','CosMx_log2FC','10x_log2FC','StereoCS7_8_log2FC','StereoCS8_9_log2FC','StereoCS7_8_det0','StereoCS7_8_det1']].round(3).to_string())
print(CL.filter(like='Monkey').round(2).assign(g=CL.gene).to_string())


# ---- cell [frame 1c2d1a43, message 91] Adding E7.25→E7.75 mouse reference sensitivity
D25=mouse_dyn('E7.25','E7.75'); print(D25.dynamic.sum(), D25[D25.dynamic].human.notna().sum(), len(set(D25[D25.dynamic].index)&set(D75[D75.dynamic].index)))
REFS['E7.25→E7.75']=D25
R=D25[D25.dynamic&D25.human.notna()][['human','lfc']].rename(columns={'lfc':'mouse_lfc'})
add_=[]
for i,(nm,t0,g0,t1,g1,plat,role) in enumerate(PAIRS):
    if role.startswith('sens') or role=='extra': continue
    Jx=R.join(PT[nm],on='human',how='inner')
    for filt in ['primary','strict','none']:
        s=Jx[Jx[f'pass_{filt}']] if filt!='none' else Jx
        if len(s)<5: continue
        add_.append(dict(mouse_reference='E7.25→E7.75',pair=nm,platform=plat,role=role,n_cells_earlier=get_group(t0,g0)[3],n_cells_later=get_group(t1,g1)[3],gene_filter=filt,**concord(s.mouse_lfc,s.lfc,nperm=10000,seed=i)))
S=pd.concat([S,pd.DataFrame(add_)],ignore_index=True)
print(S[(S.mouse_reference=='E7.25→E7.75')][['pair','gene_filter','n','same_sign','rho','P_same_upper','P_same_lower','P_rho_upper','P_rho_lower']].round(4).to_string())
print(S[(S.pair=='CosMx CS7→CS8')][['mouse_reference','gene_filter','n','same_sign','rho','P_same_upper','P_rho_upper']].round(4).to_string())


# ---- cell [frame 1c2d1a43, message 93] Saving concordance tables to F drive
S.to_csv(OUT+'concordance_summary_all_pairs.csv',index=False)
FT.to_csv(OUT+'PS_dynamic_genes_mouseE7.0-E7.75_vs_human.csv',index=False)
DISC.to_csv(OUT+'CosMx_discordant_genes.csv',index=False)
CL.to_csv(OUT+'key_gene_claim_checks.csv',index=False)
for nm,d in [('E7.0_E7.75',D75),('E7.0_E7.5',D50),('E7.25_E7.75',D25)]:
    d.reset_index().rename(columns={'index':'mouse_gene'}).to_csv(W+f'mouse_PS_change_{nm}_allgenes.csv.gz',index=False)
import pickle; pickle.dump(dict(PT=PT,S=S,FT=FT,CL=CL,NS=NS,D75=D75,D50=D50,D25=D25),open(W+'analysis_state.pkl','wb'))
print('ok')


# ---- cell [frame 1c2d1a43, message 95] Checking figure-style helper availability
try: apply_figure_style; print('plugin present')
except NameError:
    exec(open(str(Path(__file__).resolve().parents[1] / 'common') + '/figure_style.py').read()); print('loaded helper copy')
import inspect; print(inspect.signature(apply_figure_style))


# ---- cell [frame 1c2d1a43, message 97] Drawing panel 4C draft
import matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib.lines import Line2D
apply_figure_style(sizes=(7,6,5), font='DejaVu Sans')
mpl.rcParams.update({'pdf.fonttype':42,'svg.fonttype':'none','axes.linewidth':0.5,'xtick.major.width':0.5,'ytick.major.width':0.5,'xtick.major.size':1.8,'ytick.major.size':1.8})
COL={'CS7':'#2c5fa8','CS8':'#c0333d','mouse':'0.15','band':'0.82'}
WIN={'CS7':(7.125,7.375),'CS8':(7.5,7.75)}
xs=np.array([6.5,6.75,7.0,7.25,7.5,7.75])
UPG=['TBXT','HOXA1','HOXB1','CDX2','RSPO3','RSPO2']; DNG=['EOMES','MIXL1','MESP1','GSC','NODAL','TBX3']
smp_cols={s:[c for c in ms.columns if c.startswith(f'PS_{s}_s') and c.endswith('|det')] for s in STAGES[:6]}
C4=[]  # source data
def mouse_series(g):
    mg=h2m[g]; mean=np.array([float(mp.loc[mg,cols(s,'det')]) for s in STAGES[:6]])
    lo=np.array([ms.loc[mg,smp_cols[s]].astype(float).min() for s in STAGES[:6]]); hi=np.array([ms.loc[mg,smp_cols[s]].astype(float).max() for s in STAGES[:6]])
    return mean,lo,hi
def draw_gene(ax,g):
    mean,lo,hi=mouse_series(g); mx=mean.max()
    h=PT['CosMx CS7→CS8'].loc[g]; hraw=np.array([h.det0,h.det1]); hb=np.array([h.bkg0,h.bkg1]); hsub=np.clip(hraw-hb,0,None)
    above=(hraw>=2*hb)&(hraw-hb>=0.02)
    hmx=hsub.max()
    for i,s in enumerate(STAGES[:6]): C4.append(dict(gene=g,series='mouse PS',stage=s,x=xs[i],det=mean[i],sample_min=lo[i],sample_max=hi[i],plotted_frac_of_max=mean[i]/mx if mx>=0.05 else np.nan))
    if mx>=0.05:
        ax.fill_between(xs,lo/mx,hi/mx,color=COL['band'],lw=0,zorder=1)
        ax.plot(xs,mean/mx,'-o',c=COL['mouse'],ms=1.8,lw=0.8,zorder=2)
    else:
        ax.text(0.04,0.93,f'mouse PS ≤{mx*100:.0f}%',transform=ax.transAxes,fontsize=5,va='top',color='0.35')
    for k,(st,v,vs,ab) in enumerate(zip(['CS7','CS8'],hraw,hsub,above)):
        y=vs/hmx if (hmx>=0.02 and above.any()) else 0
        c=COL[st]; a,b=WIN[st]; xm=(a+b)/2
        ax.plot([a,b],[y,y],c=c,lw=1.1,solid_capstyle='butt',zorder=3)
        ax.plot(xm,y,'o',ms=3.0,mfc=c if ab else 'white',mec=c,mew=0.8,zorder=4)
        C4.append(dict(gene=g,series=f'CosMx {st} PS',stage=st,x=xm,window=f'{a}-{b}',det=v,VE_bkg=hb[k],det_minus_bkg=vs,above_bkg=bool(ab),plotted_frac_of_max=y))
    if not above.any(): ax.text(0.96,0.06,'human at bkg',transform=ax.transAxes,fontsize=5,ha='right',color='0.35')
    ax.set_xlim(6.42,7.83); ax.set_ylim(-0.08,1.12)
    ax.set_xticks([6.5,7.0,7.5]); ax.set_yticks([0,0.5,1])
    ax.text(0.04,1.0,g,transform=ax.transAxes,fontsize=6,fontstyle='italic',va='top',ha='left') if mx>=0.05 else ax.set_title(g,fontsize=6,fontstyle='italic',loc='left',pad=1)
fig=plt.figure(figsize=(180/25.4,62/25.4))
gs=fig.add_gridspec(2,7,width_ratios=[1]*6+[2.15],left=0.055,right=0.985,bottom=0.17,top=0.86,wspace=0.12,hspace=0.32)
axes=[[fig.add_subplot(gs[r,c]) for c in range(6)] for r in range(2)]
for r,gl in enumerate([UPG,DNG]):
    for c,g in enumerate(gl):
        ax=axes[r][c]; draw_gene(ax,g)
        if c>0: ax.set_yticklabels([])
        else: ax.set_yticklabels(['0','50','100'])
        if r==0: ax.set_xticklabels([])
        else: ax.set_xticklabels(['E6.5','E7.0','E7.5'])
        ax.spines[['top','right']].set_visible(False)
fig.text(0.012,0.515,'% of within-species maximum (detection)',rotation=90,va='center',ha='center',fontsize=6)
fig.text(0.055+ (0.985-0.055)*6/8.15/2, 0.045,'mouse stage (human embryos placed on milestone windows)',ha='center',fontsize=6)
fig.text(0.058,0.95,'Up in mouse PS E7.0→E7.75',fontsize=6,ha='left',va='bottom',color='0.2')
fig.text(0.058,0.505,'Down in mouse PS E7.0→E7.75',fontsize=6,ha='left',va='bottom',color='0.2')
# legend
H=[Line2D([],[],c=COL['mouse'],marker='o',ms=1.8,lw=0.8,label='mouse PS (mean; band = sample range)'),
   Line2D([],[],c=COL['CS7'],marker='o',ms=3,lw=1.1,label='HuE#1 CS7 PS'),Line2D([],[],c=COL['CS8'],marker='o',ms=3,lw=1.1,label='HuE#2 CS8 PS'),
   Line2D([],[],ls='',marker='o',ms=3,mfc='white',mec='0.3',mew=0.8,label='at CosMx background')]
fig.legend(handles=H,loc='lower left',bbox_to_anchor=(0.28,0.88),ncol=4,frameon=False,fontsize=5,handlelength=1.6,columnspacing=1.0,borderaxespad=0)
# HOX heatmap
axh=fig.add_subplot(gs[:,6])
H3=['HOXA1','HOXB1','HOXA2','HOXB2','HOXA3','HOXB3']; H5=['HOXB8','HOXB9','HOXC8','HOXA9','HOXA10','HOXD9']
mcols=['E7.0','E7.25','E7.5','E7.75']
Mx=[]; HX=[]
for g in H3+H5:
    mg=h2m[g]; rowv=[float(mp.loc[mg,cols(s,'det')])*100 for s in mcols]
    h=PT['CosMx CS7→CS8'].loc[g]; hv_=[max(0,(h.det0-h.bkg0))*100,max(0,(h.det1-h.bkg1))*100]
    Mx.append(rowv+hv_)
    HX.append(dict(gene=g,block="3′" if g in H3 else "5′",**{f'mouse_det_pct_{s}':v for s,v in zip(mcols,rowv)},CosMx_CS7_det_pct=h.det0*100,CosMx_CS7_VEbkg_pct=h.bkg0*100,CosMx_CS8_det_pct=h.det1*100,CosMx_CS8_VEbkg_pct=h.bkg1*100,CosMx_CS7_minus_bkg_pp=hv_[0],CosMx_CS8_minus_bkg_pp=hv_[1]))
Mx=np.array(Mx); ny=len(H3+H5)
yy=np.r_[np.arange(6),np.arange(6)+6.5]
xx=np.r_[np.arange(4),np.arange(2)+4.5]
cmap=mpl.colormaps['YlGnBu']; norm=mpl.colors.Normalize(0,25)
for i in range(ny):
    for j in range(6):
        v=Mx[i,j]; axh.add_patch(mpl.patches.Rectangle((xx[j]-0.5,yy[i]-0.5),1,1,fc=cmap(norm(min(v,25))),ec='white',lw=0.5))
        axh.text(xx[j],yy[i],f'{v:.0f}',ha='center',va='center',fontsize=5,color='white' if norm(v)>0.6 else '0.15')
axh.set_xlim(-0.5,6.0); axh.set_ylim(yy.max()+0.5,-0.5)
axh.set_xticks(xx); axh.set_xticklabels(['E7.0','E7.25','E7.5','E7.75','CS7','CS8'],rotation=90)
for tl,c in zip(axh.get_xticklabels(),['0.15']*4+[COL['CS7'],COL['CS8']]): tl.set_color(c)
axh.set_yticks(yy); axh.set_yticklabels(H3+H5,fontstyle='italic')
axh.tick_params(length=0,pad=1.5)
for s in axh.spines.values(): s.set_visible(False)
axh.text(-0.75,2.5,"3′ HOX",rotation=90,ha='right',va='center',fontsize=6,transform=mpl.transforms.blended_transform_factory(axh.transAxes,axh.transData)) if False else None
axh.annotate('',xy=(-0.22,yy[0]-0.4),xytext=(-0.22,yy[5]+0.4),xycoords=('axes fraction','data'),arrowprops=dict(arrowstyle='-',lw=0.6,color='0.3'),annotation_clip=False)
axh.annotate('',xy=(-0.22,yy[6]-0.4),xytext=(-0.22,yy[11]+0.4),xycoords=('axes fraction','data'),arrowprops=dict(arrowstyle='-',lw=0.6,color='0.3'),annotation_clip=False)
axh.text(-0.25,np.mean(yy[:6]),"3′",transform=mpl.transforms.blended_transform_factory(axh.transAxes,axh.transData),ha='right',va='center',fontsize=6)
axh.text(-0.25,np.mean(yy[6:]),"5′",transform=mpl.transforms.blended_transform_factory(axh.transAxes,axh.transData),ha='right',va='center',fontsize=6)
axh.set_title('PS detection (%; human minus VE bkg)',fontsize=6,loc='left',pad=2)
axh.text(1.5,-1.35,'mouse',ha='center',fontsize=5,color='0.3'); axh.text(5.0,-1.35,'CosMx',ha='center',fontsize=5,color='0.3')
fig.savefig(OUT+'Fig4C_PS_gene_dynamics.png',dpi=400); 
print('saved')


# ---- cell [frame 1c2d1a43, message 101] Redrawing 4C with separated heatmap
def draw_gene(ax,g):
    mean,lo,hi=mouse_series(g); mx=mean.max()
    h=PT['CosMx CS7→CS8'].loc[g]; hraw=np.array([h.det0,h.det1]); hb=np.array([h.bkg0,h.bkg1]); hsub=np.clip(hraw-hb,0,None)
    above=(hraw>=2*hb)&(hraw-hb>=0.02); hmx=hsub.max()
    for i,s in enumerate(STAGES[:6]): C4.append(dict(gene=g,series='mouse PS',stage=s,x=xs[i],det=mean[i],sample_min=lo[i],sample_max=hi[i],plotted_frac_of_max=mean[i]/mx if mx>=0.05 else np.nan))
    if mx>=0.05:
        ax.fill_between(xs,lo/mx,hi/mx,color=COL['band'],lw=0,zorder=1)
        ax.plot(xs,mean/mx,'-o',c=COL['mouse'],ms=1.8,lw=0.8,zorder=2)
    else:
        ax.text(0.05,0.80,f'mouse PS\nmax {mx*100:.0f}%',transform=ax.transAxes,fontsize=5,va='top',color='0.35',linespacing=1.0)
    for k,(st,v,vs,ab) in enumerate(zip(['CS7','CS8'],hraw,hsub,above)):
        y=vs/hmx if (hmx>=0.02 and above.any()) else 0
        c=COL[st]; a,b=WIN[st]; xm=(a+b)/2
        ax.plot([a,b],[y,y],c=c,lw=1.1,solid_capstyle='butt',zorder=3)
        ax.plot(xm,y,'o',ms=3.0,mfc=c if ab else 'white',mec=c,mew=0.8,zorder=4)
        C4.append(dict(gene=g,series=f'CosMx {st} PS',stage=st,x=xm,window=f'{a}-{b}',det=v,VE_bkg=hb[k],det_minus_bkg=vs,above_bkg=bool(ab),plotted_frac_of_max=y))
    ax.set_xlim(6.42,7.83); ax.set_ylim(-0.08,1.14)
    ax.set_xticks([6.5,7.0,7.5]); ax.set_yticks([0,0.5,1])
    ax.text(0.05,1.0,g,transform=ax.transAxes,fontsize=6,fontstyle='italic',va='top',ha='left')
def build_4C():
    global C4; C4=[]
    fig=plt.figure(figsize=(180/25.4,62/25.4))
    gs=fig.add_gridspec(2,6,left=0.055,right=0.735,bottom=0.17,top=0.80,wspace=0.12,hspace=0.36)
    for r,gl in enumerate([UPG,DNG]):
        for c,g in enumerate(gl):
            ax=fig.add_subplot(gs[r,c]); draw_gene(ax,g)
            ax.set_yticklabels(['0','50','100'] if c==0 else [])
            ax.set_xticklabels(['E6.5','E7.0','E7.5'] if r==1 else [])
            ax.spines[['top','right']].set_visible(False)
            if c==0: ax.text(0.0,1.12,['Up in mouse PS, E7.0→E7.75','Down in mouse PS, E7.0→E7.75'][r],transform=ax.transAxes,fontsize=6,ha='left',va='bottom',color='0.2')
    fig.text(0.013,0.485,'% of within-species max (PS detection)',rotation=90,va='center',ha='center',fontsize=6)
    fig.text((0.055+0.735)/2,0.035,'mouse stage (human embryos placed on milestone windows)',ha='center',fontsize=6)
    H=[Line2D([],[],c=COL['mouse'],marker='o',ms=1.8,lw=0.8,label='mouse PS (mean; band = sample range)'),
       Line2D([],[],c=COL['CS7'],marker='o',ms=3,lw=1.1,label='HuE#1 CS7 PS'),Line2D([],[],c=COL['CS8'],marker='o',ms=3,lw=1.1,label='HuE#2 CS8 PS'),
       Line2D([],[],ls='',marker='o',ms=3,mfc='white',mec='0.3',mew=0.8,label='at CosMx background')]
    fig.legend(handles=H,loc='lower left',bbox_to_anchor=(0.05,0.905),ncol=4,frameon=False,fontsize=5,handlelength=1.6,columnspacing=1.2,borderaxespad=0)
    axh=fig.add_axes([0.825,0.17,0.165,0.63])
    yy=np.r_[np.arange(6),np.arange(6)+6.6]; xx=np.r_[np.arange(4),np.arange(2)+4.5]
    for i in range(len(yy)):
        for j in range(6):
            v=Mx[i,j]; axh.add_patch(mpl.patches.Rectangle((xx[j]-0.5,yy[i]-0.5),1,1,fc=cmap(norm(min(v,25))),ec='white',lw=0.5))
            axh.text(xx[j],yy[i],f'{v:.0f}',ha='center',va='center',fontsize=5,color='white' if norm(v)>0.6 else '0.15')
    axh.set_xlim(-0.5,5.0); axh.set_ylim(yy.max()+0.5,-0.5)
    axh.set_xticks(xx); axh.set_xticklabels(['E7.0','E7.25','E7.5','E7.75','CS7','CS8'],rotation=90)
    for tl,c in zip(axh.get_xticklabels(),['0.15']*4+[COL['CS7'],COL['CS8']]): tl.set_color(c)
    axh.set_yticks(yy); axh.set_yticklabels(H3+H5,fontstyle='italic'); axh.tick_params(length=0,pad=1.5)
    for s in axh.spines.values(): s.set_visible(False)
    tr=mpl.transforms.blended_transform_factory(axh.transAxes,axh.transData)
    for blk,lab in [(yy[:6],"3′"),(yy[6:],"5′")]:
        axh.plot([-0.36,-0.36],[blk[0]-0.4,blk[-1]+0.4],transform=tr,c='0.3',lw=0.6,clip_on=False)
        axh.text(-0.40,blk.mean(),lab+' HOX',transform=tr,ha='right',va='center',fontsize=6,rotation=90)
    axh.text(1.5,-0.75,'mouse',ha='center',va='bottom',fontsize=5,color='0.3'); axh.text(5.0-0.25,-0.75,'CosMx',ha='center',va='bottom',fontsize=5,color='0.3')
    axh.text(-0.38,1.075,'PS detection, % (human: minus VE bkg, pp)',transform=axh.transAxes,fontsize=5,ha='left',va='bottom')
    return fig
fig=build_4C()
def bbox_check(fig):
    r=fig.canvas.get_renderer()
    tx=[(t,t.get_window_extent(r)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
    ov=[(a.get_text(),b.get_text()) for i,(a,ba) in enumerate(tx) for b,bb in tx[i+1:] if ba.overlaps(bb)]
    out=[t.get_text() for t,b in tx if b.x0<fig.bbox.x0-1 or b.y0<fig.bbox.y0-1 or b.x1>fig.bbox.x1+1 or b.y1>fig.bbox.y1+1]
    return ov,out
print(bbox_check(fig))
fig.savefig(OUT+'Fig4C_PS_gene_dynamics.png',dpi=400)


# ---- cell [frame 1c2d1a43, message 103] Running text-overlap check on 4C
def bbox_check(fig):
    fig.canvas.draw(); r=fig.canvas.get_renderer()
    tx=[(t,t.get_window_extent(r)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
    ov=[(a.get_text(),b.get_text()) for i,(a,ba) in enumerate(tx) for b,bb in tx[i+1:] if ba.overlaps(bb)]
    out=[t.get_text() for t,b in tx if b.x0<fig.bbox.x0-1 or b.y0<fig.bbox.y0-1 or b.x1>fig.bbox.x1+1 or b.y1>fig.bbox.y1+1]
    return ov,out
print(bbox_check(fig))


# ---- cell [frame 1c2d1a43, message 107] Fixing 4C titles and heatmap clipping
_old=draw_gene
def draw_gene2(ax,g):
    _old(ax,g)
    for t in list(ax.texts):
        if t.get_text()==g: t.remove()
    ax.set_title(g,fontsize=6,fontstyle='italic',loc='left',pad=1.5)
draw_gene=draw_gene2
src=inspect.getsource(build_4C) if False else None
fig=build_4C()
axh=fig.axes[-1]; axh.set_xlim(-0.5,6.0)
for t in axh.texts:
    if t.get_text()=='CosMx': t.set_x(5.0)
# adjust row header positions upward
for ax in fig.axes[:-1]:
    for t in ax.texts:
        if t.get_text().startswith(('Up in','Down in')): t.set_y(1.2)
fig.subplots_adjust(hspace=0.5)
print(bbox_check(fig))
fig.savefig(OUT+'Fig4C_PS_gene_dynamics.png',dpi=400)


# ---- cell [frame 1c2d1a43, message 111] Adjusting 4C row spacing
def finalize_4C():
    fig=build_4C()
    axh=fig.axes[-1]; axh.set_xlim(-0.5,6.0)
    for t in axh.texts:
        if t.get_text()=='CosMx': t.set_x(5.0)
    small=fig.axes[:12]
    for i,ax in enumerate(small):
        p=ax.get_position()
        if i>=6: ax.set_position([p.x0,p.y0,p.width,p.height-0.05])
        else: ax.set_position([p.x0,p.y0+0.0,p.width,p.height-0.02])
        for t in ax.texts:
            if t.get_text().startswith(('Up in','Down in')): t.set_y(1.17)
    return fig
fig=finalize_4C(); print(bbox_check(fig))
fig.savefig(OUT+'Fig4C_PS_gene_dynamics.png',dpi=400)


# ---- cell [frame 1c2d1a43, message 115] Saving 4C and assembling 4D data
for ext in ['png','svg','pdf']: fig.savefig(OUT+f'Fig4C_PS_gene_dynamics.{ext}',**({'dpi':400} if ext=='png' else {}))
C4df=pd.DataFrame(C4); HXdf=pd.DataFrame(HX)
plt.close('all')
ROWS4D=[('CosMx CS7→CS8','HuE#1 CS7 → HuE#2 CS8 (CosMx)','#2c5fa8','#c0333d'),
        ('Stereo-seq CS7→CS8','Stereo-seq CS7 → CS8','#4a9bb0','#e08a6b'),
        ('Stereo-seq CS8→CS9','Stereo-seq CS8 → CS9-2*','#e08a6b','#8c6d5a'),
        ('10x CS7→CS8','In-house 10x CS7 → CS8','#7b4fa0','#3d1a63'),
        ('Monkey CS8-e1→CS9-e1 (PS)','Monkey CS8-e1 → CS9-e1*','#9fd08a','#4fa64a'),
        ('Monkey CS8-e1→CS9-e2 (PS)','Monkey CS8-e1 → CS9-e2*','#9fd08a','#4fa64a'),
        ('Monkey CS8-e2→CS9-e1 (PS)','Monkey CS8-e2 → CS9-e1*','#9fd08a','#4fa64a'),
        ('Monkey CS8-e2→CS9-e2 (PS)','Monkey CS8-e2 → CS9-e2*','#9fd08a','#4fa64a')]
KG=['EOMES','MIXL1','MESP1','GSC','NODAL','TBXT','CDX2','HOXA1','HOXB1','TBX3']
P4=S[(S.mouse_reference=='E7.0→E7.75 (primary)')]
D4=[]; KM=[]
mrow=[float(D75.loc[h2m[g],'lfc']) for g in KG]
for key,lab,c0,c1 in ROWS4D:
    pr=P4[(P4.pair==key)&(P4.gene_filter=='primary')].iloc[0]; al=P4[(P4.pair==key)&(P4.gene_filter=='none')].iloc[0]
    D4.append(dict(pair=key,label=lab,n_cells_earlier=pr.n_cells_earlier,n_cells_later=pr.n_cells_later,n_genes_primary=pr.n,n_same_primary=pr.n_same,same_sign_primary=pr.same_sign,rho_primary=pr.rho,P_rho_upper_primary=pr.P_rho_upper,P_rho_lower_primary=pr.P_rho_lower,P_same_upper_primary=pr.P_same_upper,P_same_lower_primary=pr.P_same_lower,
                   n_genes_all=al.n,n_same_all=al.n_same,same_sign_all=al.same_sign,rho_all=al.rho,P_rho_upper_all=al.P_rho_upper,P_rho_lower_all=al.P_rho_lower))
    d=PT[key]; KM.append(dict(pair=key,**{f'{g}_log2FC':float(d.loc[g,'lfc']) for g in KG},**{f'{g}_above_bkg':bool(d.loc[g,'pass_primary']) for g in KG},**{f'{g}_det_earlier':float(d.loc[g,'det0']) for g in KG},**{f'{g}_det_later':float(d.loc[g,'det1']) for g in KG}))
D4=pd.DataFrame(D4); KM=pd.DataFrame(KM)
print(D4[['pair','n_genes_primary','n_same_primary','rho_primary','P_rho_upper_primary','P_rho_lower_primary','n_same_all','n_genes_all','rho_all']].round(4).to_string())
print(KM[[f'{g}_log2FC' for g in KG]].round(2).assign(p=KM.pair).to_string()); print(np.round(mrow,2))
print(KM[[f'{g}_above_bkg' for g in KG]].assign(p=KM.pair).to_string())


# ---- cell [frame 1c2d1a43, message 117] Drawing panel 4D draft
def fmtp(p):
    return '<10⁻³' if p<0.001 else f'{p:.3f}' if p<0.01 else f'{p:.2f}'
def build_4D():
    fig=plt.figure(figsize=(180/25.4,58/25.4))
    axL=fig.add_axes([0.205,0.16,0.20,0.66]); axR=fig.add_axes([0.62,0.16,0.33,0.66])
    n=len(ROWS4D); y=np.arange(n)
    axL.axvline(0,c='0.5',lw=0.5,zorder=0)
    for i,(key,lab,c0,c1) in enumerate(ROWS4D):
        r=D4.iloc[i]
        axL.plot([0,r.rho_primary],[i,i],c=c0,lw=1.4,solid_capstyle='butt',zorder=1)
        axL.plot(r.rho_primary,i,'o',ms=4,mfc=c1,mec=c0,mew=0.9,zorder=3)
        axL.plot(r.rho_all,i,'D',ms=2.6,mfc='white',mec='0.35',mew=0.6,zorder=2)
        P=r.P_rho_upper_primary if r.rho_primary>0 else r.P_rho_lower_primary
        axL.text(1.06,i,f'{r.n_same_primary}/{r.n_genes_primary}',transform=mpl.transforms.blended_transform_factory(axL.transAxes,axL.transData),va='center',ha='left',fontsize=5)
        axL.text(1.36,i,fmtp(P),transform=mpl.transforms.blended_transform_factory(axL.transAxes,axL.transData),va='center',ha='left',fontsize=5)
    axL.text(1.06,-0.85,'same\nsign',transform=mpl.transforms.blended_transform_factory(axL.transAxes,axL.transData),ha='left',va='bottom',fontsize=5,linespacing=0.95)
    axL.text(1.36,-0.85,'perm.\nP',transform=mpl.transforms.blended_transform_factory(axL.transAxes,axL.transData),ha='left',va='bottom',fontsize=5,linespacing=0.95)
    axL.set_yticks(y); axL.set_yticklabels([r[1] for r in ROWS4D]); axL.set_ylim(n-0.4,-0.9)
    axL.set_xlim(-1,1); axL.set_xticks([-1,-0.5,0,0.5,1]); axL.set_xticklabels(['−1','−0.5','0','0.5','1'])
    axL.spines[['top','right']].set_visible(False); axL.tick_params(axis='y',length=0,pad=2)
    axL.set_xlabel('Spearman ρ with mouse PS\nlog2FC E7.0→E7.75',fontsize=6,labelpad=1.5)
    axL.set_title('Agreement with mouse PS dynamics',fontsize=6,loc='left',pad=10,x=-0.02)
    from matplotlib.lines import Line2D as L2
    axL.legend(handles=[L2([],[],ls='',marker='o',ms=4,mfc='0.6',mec='0.2',mew=0.9,label='genes above bkg'),L2([],[],ls='',marker='D',ms=2.6,mfc='white',mec='0.35',mew=0.6,label='all 1:1 orthologs')],
               loc='lower left',bbox_to_anchor=(-0.02,1.0),ncol=2,frameon=False,fontsize=5,handletextpad=0.2,columnspacing=0.8,borderaxespad=0.1)
    # heatmap
    M=np.vstack([mrow]+[KM.loc[i,[f'{g}_log2FC' for g in KG]].values.astype(float) for i in range(n)])
    AB=np.vstack([[True]*len(KG)]+[KM.loc[i,[f'{g}_above_bkg' for g in KG]].values.astype(bool) for i in range(n)])
    yr=np.r_[-1.2,np.arange(n)]
    cm=mpl.colormaps['RdBu_r']; nm=mpl.colors.TwoSlopeNorm(0,-3,3)
    for i in range(M.shape[0]):
        for j in range(len(KG)):
            v=M[i,j]; fc=cm(nm(np.clip(v,-3,3))) if AB[i,j] else '0.93'
            axR.add_patch(mpl.patches.Rectangle((j-0.5,yr[i]-0.5),1,1,fc=fc,ec='white',lw=0.6))
            txtc='white' if (AB[i,j] and abs(v)>2.0) else ('0.55' if not AB[i,j] else '0.1')
            axR.text(j,yr[i],f'{v:.1f}'.replace('-','−'),ha='center',va='center',fontsize=5,color=txtc)
    axR.set_xlim(-0.5,len(KG)-0.5); axR.set_ylim(n-0.5,-1.75)
    axR.set_xticks(range(len(KG))); axR.set_xticklabels(KG,fontstyle='italic',rotation=45,ha='left',rotation_mode='anchor'); axR.xaxis.tick_top()
    axR.set_yticks(yr); axR.set_yticklabels(['Mouse PS E7.0→E7.75']+['']*n); axR.tick_params(length=0,pad=1.5)
    for s in axR.spines.values(): s.set_visible(False)
    cax=fig.add_axes([0.958,0.30,0.008,0.38]); cb=fig.colorbar(mpl.cm.ScalarMappable(nm,cm),cax=cax,ticks=[-3,0,3]); cb.ax.set_yticklabels(['≤−3','0','≥3']); cb.outline.set_linewidth(0.4)
    cb.set_label('PS log2FC (later/earlier)',fontsize=5,labelpad=1); cb.ax.tick_params(length=1.5,labelsize=5)
    axR.text(-0.5,n-0.5+0.95,'grey = not above platform background at either stage',fontsize=5,color='0.4',va='top')
    return fig
fig=build_4D(); print(bbox_check(fig)); fig.savefig(OUT+'Fig4D_crossdataset_PS_dynamics.png',dpi=400)


# ---- cell [frame 1c2d1a43, message 121] Redrawing 4D with aligned rows
def build_4D():
    fig=plt.figure(figsize=(180/25.4,58/25.4))
    axL=fig.add_axes([0.20,0.20,0.20,0.66]); axR=fig.add_axes([0.555,0.20,0.36,0.66])
    n=len(ROWS4D); y=np.arange(n); YL=(n-0.5,-1.75)
    tr=mpl.transforms.blended_transform_factory(axL.transAxes,axL.transData)
    axL.axvline(0,c='0.5',lw=0.5,zorder=0,ymin=0,ymax=(n-0.5+0.7)/(n-0.5+1.75))
    for i,(key,lab,c0,c1) in enumerate(ROWS4D):
        r=D4.iloc[i]
        axL.plot([0,r.rho_primary],[i,i],c=c0,lw=1.4,solid_capstyle='butt',zorder=1)
        axL.plot(r.rho_primary,i,'o',ms=4,mfc=c1,mec=c0,mew=0.9,zorder=3)
        axL.plot(r.rho_all,i,'D',ms=2.6,mfc='white',mec='0.35',mew=0.6,zorder=2)
        P=r.P_rho_upper_primary if r.rho_primary>0 else r.P_rho_lower_primary
        axL.text(1.05,i,f'{r.n_same_primary}/{r.n_genes_primary}',transform=tr,va='center',ha='left',fontsize=5)
        axL.text(1.33,i,fmtp(P),transform=tr,va='center',ha='left',fontsize=5)
    axL.text(1.05,-1.2,'same\nsign',transform=tr,ha='left',va='center',fontsize=5,linespacing=0.95)
    axL.text(1.33,-1.2,'perm.\nP (ρ)',transform=tr,ha='left',va='center',fontsize=5,linespacing=0.95)
    axL.set_yticks(np.r_[-1.2,y]); axL.set_yticklabels(['Mouse PS E7.0→E7.75 (reference)']+[r[1] for r in ROWS4D]); axL.set_ylim(*YL)
    axL.set_xlim(-1,1); axL.set_xticks([-1,-0.5,0,0.5,1]); axL.set_xticklabels(['−1','−0.5','0','0.5','1'])
    axL.spines[['top','right','left']].set_visible(False); axL.tick_params(axis='y',length=0,pad=2)
    axL.set_xlabel('Spearman ρ with mouse PS log2FC',fontsize=6,labelpad=1.5)
    from matplotlib.lines import Line2D as L2
    axL.legend(handles=[L2([],[],ls='',marker='o',ms=4,mfc='0.6',mec='0.2',mew=0.9,label='genes above bkg'),L2([],[],ls='',marker='D',ms=2.6,mfc='white',mec='0.35',mew=0.6,label='all 1:1 orthologs')],
               loc='lower left',bbox_to_anchor=(0.0,0.0),ncol=1,frameon=False,fontsize=5,handletextpad=0.3,borderaxespad=0.2)
    M=np.vstack([mrow]+[KM.loc[i,[f'{g}_log2FC' for g in KG]].values.astype(float) for i in range(n)])
    AB=np.vstack([[True]*len(KG)]+[KM.loc[i,[f'{g}_above_bkg' for g in KG]].values.astype(bool) for i in range(n)])
    yr=np.r_[-1.2,np.arange(n)]
    cm=mpl.colormaps['RdBu_r']; nm=mpl.colors.TwoSlopeNorm(0,-3,3)
    for i in range(M.shape[0]):
        for j in range(len(KG)):
            v=M[i,j]; fc=cm(nm(np.clip(v,-3,3))) if AB[i,j] else '0.93'
            axR.add_patch(mpl.patches.Rectangle((j-0.5,yr[i]-0.5),1,1,fc=fc,ec='white',lw=0.6))
            txtc='white' if (AB[i,j] and abs(v)>2.0) else ('0.55' if not AB[i,j] else '0.1')
            axR.text(j,yr[i],f'{v:.1f}'.replace('-','−'),ha='center',va='center',fontsize=5,color=txtc)
    axR.set_xlim(-0.5,len(KG)-0.5); axR.set_ylim(*YL)
    axR.set_xticks(range(len(KG))); axR.set_xticklabels(KG,fontstyle='italic',rotation=45,ha='left',rotation_mode='anchor'); axR.xaxis.tick_top()
    axR.set_yticks([]); axR.tick_params(length=0,pad=1.5)
    for s in axR.spines.values(): s.set_visible(False)
    cax=fig.add_axes([0.925,0.32,0.008,0.38]); cb=fig.colorbar(mpl.cm.ScalarMappable(nm,cm),cax=cax,ticks=[-3,0,3]); cb.ax.set_yticklabels(['≤−3','0','≥3']); cb.outline.set_linewidth(0.4)
    cb.set_label('PS log2FC',fontsize=5,labelpad=1); cb.ax.tick_params(length=1.5,labelsize=5)
    fig.text(0.555,0.06,'grey cell = gene not above platform background at either stage',fontsize=5,color='0.4',va='bottom')
    fig.text(0.01,0.02,'* fewer than 20 PS cells/spots at one stage (Stereo-seq CS9-2: 13 spots; monkey CS8: 10 and 16 cells)',fontsize=5,color='0.4',va='bottom')
    return fig
fig=build_4D(); print(bbox_check(fig)); fig.savefig(OUT+'Fig4D_crossdataset_PS_dynamics.png',dpi=400)


# ---- cell [frame 1c2d1a43, message 125] Moving 4D legend and saving formats
fig=build_4D()
lg=fig.axes[0].get_legend(); lg.set_bbox_to_anchor((0.0,0.28),transform=fig.axes[0].transAxes)
print(bbox_check(fig))
for ext in ['png','svg','pdf']: fig.savefig(OUT+f'Fig4D_crossdataset_PS_dynamics.{ext}',**({'dpi':400} if ext=='png' else {}))


# ---- cell [frame 1c2d1a43, message 127] Re-placing 4D legend
fig=build_4D(); axL=fig.axes[0]; h,l=axL.get_legend_handles_labels() 
old=axL.get_legend(); hs=old.legend_handles; ls_=[t.get_text() for t in old.get_texts()]; old.remove()
axL.legend(handles=hs,labels=ls_,loc='center left',bbox_to_anchor=(0.0,0.42),frameon=False,fontsize=5,handletextpad=0.3,borderaxespad=0.2)
print(bbox_check(fig))
for ext in ['png','svg','pdf']: fig.savefig(OUT+f'Fig4D_crossdataset_PS_dynamics.{ext}',**({'dpi':400} if ext=='png' else {}))
import shutil; shutil.copy(OUT+'Fig4D_crossdataset_PS_dynamics.png',W+'_view4D.png')


# ---- cell [frame 1c2d1a43, message 133] Moving 4D legend above rows
lg=axL.get_legend(); lg.remove()
axL.legend(handles=hs,labels=ls_,loc='lower left',bbox_to_anchor=(-0.02,1.02),ncol=2,frameon=False,fontsize=5,handletextpad=0.3,columnspacing=1.0,borderaxespad=0)
print(bbox_check(fig))
for ext in ['png','svg','pdf']: fig.savefig(OUT+f'Fig4D_crossdataset_PS_dynamics.{ext}',**({'dpi':400} if ext=='png' else {}))


# ---- cell [frame 1c2d1a43, message 139] Writing source-data workbook
readme=pd.DataFrame({'item':[
 'Mouse reference','Mouse PS-dynamic genes','Pseudocount','Human/monkey change','Background rule (primary)','Background rule (strict)','Concordance','Permutation','4C y-axis','4C human placement','4C HOX heatmap','4D left','4D right','Stereo-seq CS8 label','Small n'],
 'definition':[
 'Pijuan-Sala 2019 atlas (raw counts, mouse_atlas_mapped_rawcounts.h5ad), celltype "Primitive Streak" (APS separate), stages E6.5–E7.75 (E8.0 has 0 PS cells; mixed_gastrulation excluded). Spread = 10x sample (library; may pool embryos) with >=10 PS cells.',
 'E7.0→E7.75: |log2FC(mean CP10K+0.1)|>=1, detection >=10% at either stage, same sign in >=80% of the 18 E7.0×E7.75 sample pairs. 101 genes (51 up, 50 down); 88 with Ensembl 116 one-to-one human orthologs.',
 '0.1 CP10K added to mean CP10K in every dataset.',
 'log2((mean CP10K later+0.1)/(mean CP10K earlier+0.1)) in PS pseudobulk.',
 'gene detected in PS at >=2x and >=2 percentage points above the platform background at either stage. Background = max detection over VE1/VE2 (CosMx), AME/VE_YE (Stereo-seq), AME+Trophoblast (10x), AM+VE (monkey), same embryo/section set.',
 'as primary but >=5 pp (rescue.py presence rule).',
 'same-sign fraction and Spearman rho between mouse and dataset log2FC over the mouse PS-dynamic genes passing the gene filter.',
 '10,000 permutations of dataset log2FC across the tested genes; one-sided P in the observed direction ((1+#null>=obs)/(1+N) or lower tail).',
 'mouse: mean PS detection / max over E6.5–E7.75; band = min–max over samples on the same scale. human CosMx: (PS detection − VE background, clipped at 0) / max over CS7,CS8; hollow = not above background (primary rule) at that stage.',
 'CS7 at milestone window E7.125–7.375, CS8 at E7.5–7.75 (windows.csv).',
 'mouse PS detection %; CosMx PS detection minus max(VE1,VE2) detection, percentage points, clipped at 0.',
 'filled circle = genes above background; diamond = all mouse-dynamic genes with 1:1 ortholog present.',
 'log2FC for key genes; grey = not above platform background at either stage of that pair.',
 'kept as in plot.py ("Xiao CS8"); attribution not re-verified in this run.',
 'Stereo-seq CS9-2 PS = 13 spots; monkey CS8 PS = 10 (e1) and 16 (e2) cells; mouse E7.75 PS = 64 cells (3 samples: 22/15/26).']})
# (ExcelWriter block of this cell failed in the original run; the workbook is written in the last cell)


# ---- cell [frame 1c2d1a43, message 141] Writing source-data workbook
# (ExcelWriter block of this cell failed in the original run: openpyxl missing; repeated in the next cell)


# ---- cell [frame 1c2d1a43, message 146] Writing and reading back source data
with pd.ExcelWriter(xl) as w:
    readme.to_excel(w,sheet_name='README',index=False)
    C4df.to_excel(w,sheet_name='4C_trajectories',index=False); HXdf.to_excel(w,sheet_name='4C_HOX_heatmap',index=False)
    D4.to_excel(w,sheet_name='4D_concordance',index=False)
    KM.to_excel(w,sheet_name='4D_key_gene_log2FC',index=False)
    pd.DataFrame({'gene':KG,'mouse_PS_log2FC_E7.0_E7.75':mrow}).to_excel(w,sheet_name='4D_mouse_reference_row',index=False)
    S.to_excel(w,sheet_name='S_concordance_all_pairs',index=False)
    FT.to_excel(w,sheet_name='S_PS_dynamic_gene_table',index=False)
    DISC.to_excel(w,sheet_name='S_CosMx_discordant_genes',index=False)
    CL.to_excel(w,sheet_name='S_key_gene_claim_checks',index=False)
    CN.to_excel(w,sheet_name='S_cell_numbers',index=False)
x=pd.ExcelFile(xl); print(x.sheet_names)
# read back key numbers
d4=pd.read_excel(xl,'4D_concordance'); print(d4[['pair','n_same_primary','n_genes_primary','rho_primary','P_rho_upper_primary','P_rho_lower_primary','n_same_all','n_genes_all','rho_all','P_rho_upper_all','P_rho_lower_all']].round(4).to_string())
