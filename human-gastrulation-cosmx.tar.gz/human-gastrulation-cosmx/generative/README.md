# generative/ — generative model of intermediate states and analysis of the reconstructed CS7→CS8 transition

This module holds the code behind the STAR Methods sections **Generative model of intermediate states** [P408–P412] and
**Analysis of the reconstructed transition** [P414–P419]. It also covers **Supplementary Materials 3 and 4** (animations, [P580–P584]).
- Figures: **Figure 7E–I**, **Supplementary Figure 10B** and the halfway (t = 0.5) cells drawn in **Figure 7D / SF10A**.
- Tables: **Table S4** (training data and settings of the generator).

Naming used in the code. Comments in the original scripts use the names that were current when they were written:

| in code | in the paper |
|---|---|
| GG-OT | AIGG-OT |
| "Figure 6" | Figure 7 |
| "Supplementary Figure 11" | Supplementary Figure 10 |
| `final_v2` | the base generator |
| `V1a` (`lam_h = 3`) | the fine-tuned generator used for the human embryos |
| `t05` | the t = 0.5 (halfway) state |
| `ai_t05` | the 115-embryo working tree |
| `ai_t05_v153` | the 153-embryo working tree |

## Environment variables and working directory

| variable | default | meaning |
|---|---|---|
| `HGC_DATA` | `data` | input root (same layout as in `aiggot/README.md`, plus the folders below) |
| `HGC_GEN_ROOT` | `.` | generative working directory (layout of the original `ai_t05_v153` tree: `ai/`, `ai/step7/`, `ai/mz_bench/`, `ai/rot/`, `out_domain/`, `out_gencv/`) |
| `HGC_OUT` | `results` | output root for the AIGG-OT couplings read by `analysis/node_dv_fate.py` and for the animations |
| `HGC_FONT_DIR` | `.` | Liberation Sans `.ttf` files (figure scripts) |
| `PYTHON` | `python` | interpreter used by `latent/run_uce.sh` |

Almost all scripts in `latent/`, `ai/`, `out_domain/`, `out_gencv/` and `human/` use paths **relative to the working directory**, such as `ai/step7/rep.npz` or `out_gencv/...`. Run them with `cwd = $HGC_GEN_ROOT` and the script tree copied or linked into it, keeping the same sub-folders. In the original tree, `ai_t05_v153/ai` linked some files from the 115-embryo tree `ai_t05/ai`, and those files are read here as `$HGC_DATA/ai_t05/...`. Folders and files used from `$HGC_DATA`:

```
ai_t05/ai/{integrated_scvi.h5ad, scvi_model/, step7/final_v2/decoder.pt, step7/rep.npz}
ai_t05/out_domain/best_V1a_lamh3.0/      exported fine-tuned generator (s5_combo_export.py)
ai_t05/out_trajectory/                   human_traj_12fr_v153.npz (gen_fractions_v153.py)
UCE/{repo, inputs, out}                  UCE checkout (33-layer model files), per-dataset inputs, embeddings
cs7_cs8_matching/external/mouse_mittnenzweig2021/   GSE169210 files
GSE193007/                               cynomolgus monkey (Zhai et al. 2022)
bridge_bundle/{latent.npz, bridge.npz, t05_table.csv}   see "Gaps"
step12_t05_PS_dataset/t05_PS_generated_cells.h5ad       generated t = 0.5 streak cells (see "Gaps")
t05_AI_expression_matrix/                previous 15,819-cell t = 0.5 deliverable (read by human/fill_*.py)
```

## Run order

| # | script (cwd = `$HGC_GEN_ROOT`) | Methods | produces |
|---|---|---|---|
| 1 | `latent/assemble.py` | P409 (human, monkey and mouse reference cells; one-to-one orthologues) | `ai/integrated_input.h5ad` |
| 2 | `latent/train_scvi.py` | P409 (scVI, 3,000 HVGs, 30 latent dimensions) | `ai/scvi_model/`, `ai/integrated_scvi.h5ad` |
| 3 | `latent/uce_prepare.py`, then `latent/run_uce.sh` | P409 (Universal Cell Embeddings, 33-layer model, zero-shot; including the 153-embryo Mittnenzweig atlas) | `$HGC_DATA/UCE/out/*_uce_adata.h5ad` |
| 4 | `ai/mz_bench/prep.py`, `ai/mz_bench/query.py` | P409 (Mittnenzweig et al. 2021 cells mapped into the frozen scVI reference) | `ai/mz_bench/*` |
| 5 | `latent/step5_cache.py` | P409/P412 (human CS7/CS8 rows, matched-cell index of the t = 0.5 state) | `ai/step5_u7.npy`, `ai/step5_u8.npy`, `ai/step5_human_t05_index.csv`, caches |
| 6 | `latent/make_rotation_splits.py` | P411 (embryo-level splits; four rotations T,V,T,L) | `ai/mz_bench/embryo_split.csv`, `ai/mz_bench/rot/split_rot{0..3}.csv` |
| 7 | `ai/step7/rep.py` | P409–P410 (94-d latent: 30 scVI + 64 Harmony-corrected UCE PCs scaled by √(30/64); exact-OT endpoint pairings of triplets) | `ai/step7/rep.npz`, `ai/step7/pairs.pkl` |
| 8 | `ai/rot/build_rot.py <rot>` | P411 (triplets of each rotation) | `ai/rot/*` |
| 9 | `ai/step7/loop.py`, `ai/step7/loop2.py` → `ai/step7/final.py`, `ai/step7/final2.py` | P410–P411 (closed-loop Optuna search on validation embryos of rotation 0; final 5-seed generator) | `ai/step7/final_v2/` (weights, `generator_config.json`) |
| 10 | `out_domain/dom.py` (library), `out_domain/s0_lib.py`, `out_domain/s2_grid.py`, `out_domain/s5_combo_export.py V1a_lamh3.0` | P412 (fine-tuning with t as input, human end-point terms; pre-declared selection rule `out_domain/SELECTION_RULE.txt`) | `out_domain/best_V1a_lamh3.0/` |
| 11 | `ai/step5_lib.py` (library), `ai/step5_decoder.py`, `out_gencv/retrain_decoder.py` | P412 (negative-binomial decoder to 18,934 genes trained on the two human embryos; retrained on the 153-embryo latent) | `out_gencv/decoder/decoder.pt` |
| 12 | `out_gencv/run_gencv.py <rot>` (rot = 0..3; uses `gencv_lib.py`, `lib7dev/lib7.py`), then `out_gencv/analyse_v153.py` | P411 (nested CV; 77 locked mid embryos: −19.5 % [15.3–22.0], 76/77 vs linear + noise; −35.2 % [32.9–39.1], 77/77 vs linear) | `out_gencv/rot{r}_locked_triplets_long.csv`, `out_gencv/rot{r}_human_t05_latent.npz` (rotation 0 = human states), `out_gencv/nested_cv_results_v153.csv`, `out_gencv/nested_cv_per_mid_v153.csv` |
| 13 | `out_gencv/human_v153.py` | P412 (human t = 0.5 readouts of the rotation-0 V1a, five seeds, decoded with the retrained decoder) | `out_gencv/human_readouts_v153.csv`, `out_gencv/human_rot0_V1a/` |
| 14 | `human/gen_fractions_v153.py` | P412 (12 equally spaced t from 0 to 1) | `$HGC_DATA/ai_t05/out_trajectory/human_traj_12fr_v153.npz` |
| 15 | `human/fill_generate.py gate`, then `human/fill_generate.py generate`, `human/fill_merge_checks.py`, `human/make_seurat_t05_merged.R` | P412 (all 17,378 AIGG-OT-matched CS7 cells: 15,819 existing + 1,559 filled with the same weights) | `out_gencv/human_fill_1559/merged_t05_expression_matrix_17378/` |
| 16 | `ai/step5_milestones.py` | P419 (milestone staging; mouse-equivalent time 7.25 + 0.375 t) | milestone table |
| 17 | `analysis/train_scvi_cosmx_full.py` → `analysis/node_layers.py` → `analysis/node_layers_v2.py` → `analysis/node_dv_fate.py` → `analysis/figure_SF10B_node_couplings.py` | P415 | `ai/node_layers/cs7_node_cells_layers_v2.csv`, `node_DV_fate.xlsx`, SF10B |
| 18 | `analysis/streak_fate_t05.py` | P417 | `analysis_out/streak_*.csv` (Fig 7G–H statistics) |
| 19 | `analysis/half_change_timing.py` | P419 | `gene_timing_*.csv`, heatmap draft (Fig 7I) |
| 20 | `animations/build_supp_material_3_4.py [both\|disc\|groups]` | P580–P584 | Supplementary Materials 3 and 4 (`$HGC_OUT/animations/*.mp4, *.gif`) |

## JSON configuration files

JSON files are not distributed with the repository. The scripts read the following JSON files, and their full contents are given here.

`ai/step7/final_v2_orig/generator_config.json` (base generator, best of 120 Optuna trials; read by `out_gencv/gencv_lib.py`):

| field | value |
|---|---|
| `best_trial` | 111 |
| `val_score` | −0.2909867754370786 |
| `n_trials` | 120 |
| `human_D_days` | 0.375 |
| `human_t_CS7` | 7.25 |

`config` fields:

| field | value |
|---|---|
| `family` | `"net"` |
| `inv` | 0 |
| `pair` | `"emd_cen"` |
| `ds` | 0.8504200342350916 |
| `ns` | 0.9820207713992816 |
| `L` | 2 |
| `drop` | 0.03934532278807927 |
| `lr` | 0.0012875537625908582 |
| `wd` | 0.0023828295738891093 |
| `steps` | 3500 |
| `bs` | 256 |
| `lam` | 0.0369445112338345 |
| `use_pijuan` | 0 |
| `sig_init` | −1.5019207072414409 |
| `h` | 256 |
| `rep` | `"concat_harm_mz"` |

`out_gencv/V1a_config_ref.json` (fine-tuned generator):

| field | value |
|---|---|
| `config` | identical to the `config` above |
| `architecture` | `"NetF (lib7.Net + time-fraction input column; initialised from final_v2 seed s)"` |
| `envelope` | false |
| `finetune_kwargs` | `{"center_nominal": true, "w_end_m": 0.0, "lam_h": 3.0}` |
| `finetune_steps` | 1500 |
| `finetune_lr` | 0.00038626612877725743 |
| `generation_fraction` | 0.5 |
| `human_D_days` | 0.375 |
| `human_t_CS7` | 7.25 |
| `selection` | `"out_domain/SELECTION_RULE.txt"` |
| `loader` | `"out_domain/dom.py: NetF.from_net(load_v2(s)); load_state_dict(generator_seed{s}.pt)"` |

`ai/step5_final2/generator_config.json` (earlier flow-family generator used only by the step-5 utilities):

| field | value |
|---|---|
| `best_trial` | 205 |
| `tune_score` | −0.06493699913660377 |
| `n_complete` | 166 |
| `n_trials` | 270 |
| `human_D_days` | 0.375 |
| `human_t_CS7` | 7.25 |

`config` fields:

| field | value |
|---|---|
| `rep` | `"concat_harm"` |
| `family` | `"flow"` |
| `h` | 1024 |
| `L` | 4 |
| `drop` | 0.010886288529002325 |
| `lr` | 0.0024442124804433464 |
| `wd` | 0.0033765714546126783 |
| `steps` | 1000 |
| `bs` | 256 |
| `bmode` | `"cen"` |
| `sigma` | 0.020308352760348595 |
| `K` | 40 |
| `mode` | `"fwd"` |
| `alpha` | 0.6500333520966743 |
| `noise` | 0 |

To recreate a file, write the values above as JSON with `json.dump(..., indent=1)`.

## Gaps

- **Bridge bundle (`bridge_bundle/latent.npz`, `bridge.npz`, `t05_table.csv`).** These files gather in one place the 94-d latent states of the CosMx and Stereo-seq cells, the CS7 streak states, and the t = 0.5 positions, destinations and table:
  - CS7 streak states: t = 0; AI t = 0.5 for five seeds; linear; mouse-only; CS8 descendants.
  - From the t = 0.5 positions onward, they were assembled in an interactive session from objects that were already in memory.

  The writer depends on that kernel state and is not included. `analysis/streak_fate_t05.py`, `analysis/half_change_timing.py` and `analysis/node_dv_fate.py` read these files as inputs.
- **`t05_PS_generated_cells.h5ad`.** This file holds the generated streak cells with stored 94-d and scVI-30 latents. Its builder (step 12 of the bridge work) is not included. `half_change_timing.py` uses it only to fit the affine 94→30 latent map.
- **Earlier deliverable.** `human/fill_*.py` read the 15,819-cell t = 0.5 deliverable (`t05_AI_expression_matrix/`). Its build was superseded by the merged 17,378-cell output, and the original packaging step is not included.
- **`embryo_split_old68.csv`.** This is the 68-embryo split of the first Mittnenzweig release. `make_rotation_splits.py` reads it as an input.
- **Figure builders.** No final builder for Figure 7E–I or SF10A was found. `node_dv_fate.py` and `half_change_timing.py` contain the draft panel builders from the analysis session, and `figure_SF10B_node_couplings.py` is the SF10B draft.
