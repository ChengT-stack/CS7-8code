# cosmx/preprocessing

Metadata/QC exports from the final merged object, Supplementary Figure 1E-F, and the HuE#2 count export.

Inputs, run order, Methods-to-panel table and gaps: see [../README.md](../README.md). Origin and sha256 of every file: [../PROVENANCE.md](../PROVENANCE.md).
