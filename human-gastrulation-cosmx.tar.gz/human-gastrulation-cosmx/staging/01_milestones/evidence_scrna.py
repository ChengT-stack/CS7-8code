# staging/01_milestones/evidence_scrna.py
# Source: reconstructed from transcript 31f871e7
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Milestone evidence review, Tyser CS7 Smart-seq2 and in-house 10x CS7/CS8 (input to audit_calls.py).
# Reconstructed verbatim from session transcript 31f871e7 (code was run cell-by-cell in a
# persistent kernel and never saved as a file). Cells are concatenated in execution order;
# inspection-only and figure-polishing cells are omitted, and cells that stopped with an error are
# truncated at the failing line (marked). See PROVENANCE.md.


# ---- cell [frame 31f871e7, message 45] Loading both datasets into scanpy kernel
import scanpy as sc, anndata as ad, numpy as np, pandas as pd, scipy.io, scipy.sparse as sp, warnings, os
warnings.filterwarnings('ignore')
W=(str(HGC_DATA) + '/milestone_evidence/out_scrna/work/')
def load(p):
    M=scipy.io.mmread(W+p+'_counts.mtx').tocsr()
    g=[x for x in open(W+p+'_genes.txt').read().split('\n') if x!='']
    md=pd.read_csv(W+p+'_meta.csv')
    if M.shape[0]!=len(md): M=M.T.tocsr()
    A=ad.AnnData(M.astype(np.float32),obs=md.set_index('cell'),var=pd.DataFrame(index=g[:M.shape[1]]))
    A.var_names_make_unique(); return A
T=load('tyser'); X=load('tenx')
print(T.shape, X.shape)
print(T.obs.label.value_counts().to_dict())
print([g for g in T.var_names if g.startswith('NKX1') or g.startswith('NKX2.5') or g in('HBZ','HBE1','GATA1','ETV2','KDR','DPPA3')])


# ---- cell [frame 31f871e7, message 47] Recomputing panel tables vs workbook sheets
def gi(A,g):
    for c in (g, g.replace('-','.')):
        if c in A.var_names: return c
    return None
def det(A,g,mask=None):
    c=gi(A,g)
    if c is None: return None
    v=np.asarray((A[:,c].X>0).todense()).ravel() if sp.issparse(A.X) else (A[:,c].X>0).ravel()
    return v if mask is None else v[mask]
for A in (T,X): A.X=sp.csr_matrix(A.X)
lab10=X.obs.Type2
G10={'PS':['15 PS'],'NasMeso':['16 Nas.Meso/PSM'],'GasMes':['28 Gas.Mes'],'Node':['9   Node'],'Notochord':['10 Notochord'],'DE':['35 DE'],'Gut':['37 Gut'],
     'EPIa':['1   EPI/ECT(a)'],'EPIp':['2   EPI/ECT(p)'],'NMP':['5   NMP'],'NE':['3   NE','4   Brain'],'ParaMeso':['17 Para.Meso','19 Somite'],
     'Cardiac':['20 Cardiac progenitor','22 Cardiomyocyte'],'Allantois':['30 Allantois'],'EXM':['29 EXM'],'HEP':['32 Endothelial cell','33 Blood progenitor'],
     'Ery':['34 Erythrocyte'],'BG':['13 AME','39 Trophoblast']}
print(sorted(lab10.unique()))
GT={'PS':['Primitive Streak'],'NasMeso':['Nascent Mesoderm'],'Emergent':['Emergent Mesoderm'],'Advanced':['Advanced Mesoderm'],'Axial':['Axial Mesoderm'],'DE':['DE(P)','DE(NP)'],
    'Hypoblast':['Hypoblast'],'YSE':['YS Endoderm'],'EPI':['Epiblast'],'NNE':['NNE'],'Amnion':['Amnion'],'YSMeso':['YS Mesoderm'],
    'HEP':['Hemogenic Endothelium','Blood Progenitors','Erythro-Myeloid Progenitors','Myeloid Progenitors'],'Ery':['Erythroblasts'],'PGC':['PGC'],'BG':['Amnion','Hypoblast','YS Endoderm']}
def panel(A,lab,G,genes):
    out={}
    for k,v in G.items():
        m=lab.isin(v).values
        out[k]={g:(round(100*det(A,g,m).mean(),1) if gi(A,g) else np.nan) for g in genes}
        out[k]['_n']=m.sum()
    return pd.DataFrame(out)
# [not executed in the original run: the cell stopped with an error (openpyxl missing) at the next line; repeated in message 52]
# wb=pd.ExcelFile((str(HGC_DATA) + '/milestone_evidence/20261030-Fig_milestone_axis_human_monkey_data.xlsx'))
# for name,A,lab,G,sh in [('10x',X,lab10,G10,'inhouse10x_CS7_markers'),('Tyser',T,T.obs.label,GT,'tyser_CS7_markers')]:
#     ref=pd.read_excel(wb,sh).set_index('gene')
#     P=panel(A,lab,G,list(ref.index))
#     print(name,'n:',P.loc['_n'].to_dict())
#     d=(P.drop('_n').astype(float)-ref[P.columns].astype(float)).abs()
#     print(name,'max abs diff', d.max().max(), 'cells >0.15:', (d>0.15).sum().sum(), d.stack()[d.stack()>0.15].head(10).to_dict())
# 


# ---- cell [frame 31f871e7, message 52] Recomputing panel tables vs workbook sheets
wb=pd.ExcelFile((str(HGC_DATA) + '/milestone_evidence/20261030-Fig_milestone_axis_human_monkey_data.xlsx'))
for name,A,lab,G,sh in [('10x',X,lab10,G10,'inhouse10x_CS7_markers'),('Tyser',T,T.obs.label,GT,'tyser_CS7_markers')]:
    ref=pd.read_excel(wb,sh).set_index('gene')
    P=panel(A,lab,G,list(ref.index))
    print(name,'n:',P.loc['_n'].to_dict())
    d=(P.drop('_n').astype(float)-ref[P.columns].astype(float)).abs()
    s=d.stack(); print(name,'max abs diff', s.max(), 'n>0.15:', (s>0.15).sum(), s[s>0.15].head(10).to_dict())
    print('genes missing:', [g for g in ref.index if gi(A,g) is None])


# ---- cell [frame 31f871e7, message 54] Identifying Tyser PS pool definition
ref=pd.read_excel(wb,'tyser_CS7_markers').set_index('gene')
import itertools
labs=T.obs.label
others=[l for l in labs.unique() if l!='Primitive Streak']
best=[]
for k in range(0,3):
    for comb in itertools.combinations(others,k):
        m=labs.isin(['Primitive Streak',*comb]).values
        v={g:round(100*det(T,g,m).mean(),1) for g in ref.index}
        diff=np.nanmax(np.abs(pd.Series(v)-ref['PS']))
        best.append((diff,comb,m.sum()))
best.sort(key=lambda x:x[0]); print(best[:5])
d=(panel(T,labs,GT,list(ref.index)).drop('_n').astype(float)-ref[list(GT)].astype(float)).abs()
print(d.max().round(2).to_dict())


# ---- cell [frame 31f871e7, message 58] Loading mouse reference thresholds
MZ=(str(HGC_DATA) + '/milestone_evidence/mz/')
mg=pd.read_csv(MZ+'mouse_milestone_genes.csv'); pd.set_option('display.width',250)
print(mg[['type','stage','n','Gsc','Cer1','Hoxa1','Hoxb1','Hoxb8','Nkx1-2','Cdx2','Eomes','Mesp1','Noto','Foxj1','Chrd']].to_string())
cc=pd.read_csv(MZ+'mouse_celltype_counts_by_stage.csv',index_col=0)
fr=(cc/cc.sum(0)*100).round(3)
print(fr.loc[['Nascent mesoderm','Anterior Primitive Streak','Def. endoderm','Notochord','Caudal epiblast','Rostral neurectoderm','Paraxial mesoderm','Cardiomyocytes','PGC','Haematoendothelial progenitors','ExE mesoderm','Allantois','Erythroid1']].to_string())
spec=pd.read_csv((str(HGC_DATA) + '/staging/mouse_milestone_marker_specificity.csv')); print(spec.columns.tolist(), spec.shape)


# ---- cell [frame 31f871e7, message 60] Checking mouse epiblast Hesx1/Six3 by stage
p=(str(HGC_DATA) + '/MGA_full_atlas_116k.h5ad')
print(os.path.exists(p))
if os.path.exists(p):
    a=ad.read_h5ad(p,backed='r'); o=a.obs; vn=list(a.var_names)
    order=['E6.5','E6.75','E7.0','E7.25','E7.5','E7.75','E8.0']
    gl=['Hesx1','Six3','Tbx4','Hoxa10','Gsc','Foxa2','Cer1','Nanos3','Dppa3','Etv2','Kdr','Hand1','Gata1','Hba-x','Meox1','Tcf15','Nkx2-5','Tnnt2']
    gix=[vn.index(g) for g in gl]
    rows=[]
    for ct in ['Epiblast','Rostral neurectoderm','Anterior Primitive Streak','Allantois','PGC','Def. endoderm','ExE mesoderm','Haematoendothelial progenitors','Erythroid1']:
        for s in order:
            m=np.where((o.celltype==ct)&(o.stage==s))[0]
            if len(m)<10: continue
            Xm=a.X[m][:,gix]; Xm=(Xm.toarray() if sp.issparse(Xm) else Xm)>0
            r=dict(ct=ct,stage=s,n=len(m),**{g:round(100*Xm[:,i].mean(),1) for i,g in enumerate(gl)})
            if ct=='Rostral neurectoderm' or ct=='Epiblast': r['Hesx1+Six3+']=round(100*(Xm[:,0]&Xm[:,1]).mean(),1)
            if ct=='Anterior Primitive Streak': r['Gsc+Foxa2+']=round(100*(Xm[:,4]&Xm[:,5]).mean(),1)
            if ct=='Def. endoderm': r['Gsc+Cer1+']=round(100*(Xm[:,4]&Xm[:,6]).mean(),1)
            if ct=='Allantois': r['Tbx4+Hoxa10+']=round(100*(Xm[:,2]&Xm[:,3]).mean(),1)
            rows.append(r)
    MM=pd.DataFrame(rows); print(MM.to_string())
    MM.to_csv(W+'mouse_extra_reference.csv',index=False)


# ---- cell [frame 31f871e7, message 62] Reproducing Tyser layer re-clustering subclusters
OD=(str(HGC_DATA) + '/staging/layer_rescue/')
GS=pd.read_csv(OD+'mouse_milestone_genesets.csv')
DEF={'Notochord':('NOTO','SHH'),'Caudal epiblast':('NKX1-2','CDX2'),'Rostral neurectoderm':('HESX1','SIX3'),'Paraxial mesoderm':('MEOX1','TCF15'),
     'Cardiomyocytes':('NKX2-5','TNNT2'),'PGC':('NANOS3','DPPA3'),'Allantois':('TBX4','HOXA10')}
POOL={'Notochord':['X','M','N'],'Caudal epiblast':['E'],'Rostral neurectoderm':['E'],'Paraxial mesoderm':['M'],'Cardiomyocytes':['M','Mx'],'PGC':['E','M','Mx','X','N','VE','other'],'Allantois':['M','Mx']}
def recl(A,layer,dn):
    # gene names as in original export (tyser genes.txt same as mine -> dotted names!) 
    res={}; summ=[]
    for t,lays in POOL.items():
        P=A[np.isin(layer,lays)].copy()
        genes=[g for g in GS[GS.celltype==t].human if g in P.var_names]
        D=(P.X>0)
        P.obs['set_score']=np.asarray(D[:,[P.var_names.get_loc(g) for g in genes]].mean(1)).ravel()
        for g in DEF[t]: P.obs[g]=np.asarray(D[:,P.var_names.get_loc(g)].todense()).ravel() if g in P.var_names else np.nan
        P.obs['depth']=np.asarray(P.X.sum(1)).ravel()
        Q=P.copy(); sc.pp.normalize_total(Q,1e4); sc.pp.log1p(Q)
        sc.tl.score_genes(Q,genes,ctrl_size=50,n_bins=25,score_name='mod',random_state=0); P.obs['mod']=Q.obs['mod'].values
        sc.pp.highly_variable_genes(Q,n_top_genes=min(2000,Q.n_vars-1)); Q=Q[:,Q.var.highly_variable].copy()
        sc.pp.scale(Q,max_value=10); sc.tl.pca(Q,n_comps=min(30,Q.n_obs-2)); sc.pp.neighbors(Q,n_neighbors=15); sc.tl.leiden(Q,resolution=2.0,flavor='igraph',n_iterations=2,key_added='sub')
        P.obs['sub']=Q.obs['sub'].values
        g=P.obs.groupby('sub'); s=g.agg(n=('set_score','size'),m1=(DEF[t][0],'mean'),m2=(DEF[t][1],'mean'),mod=('mod','mean'))
        p1,p2=P.obs[DEF[t][0]].mean(),P.obs[DEF[t][1]].mean()
        s['marker_fe']=np.sqrt((s.m1/max(p1,1e-3))*(s.m2/max(p2,1e-3))); s['mod_z']=(s['mod']-P.obs['mod'].mean())/P.obs['mod'].std()
        s=s[s.n>=15].sort_values('marker_fe',ascending=False); b=s.index[0]
        res[t]=P.obs_names[P.obs['sub']==b]
        summ.append((t,P.n_obs,int(s.iloc[0].n),round(100*s.iloc[0].m1,1),round(100*s.iloc[0].m2,1),round(s.iloc[0].marker_fe,2),round(s.iloc[0].mod_z,2)))
    return res,summ
lt={'Epiblast':'E','Primitive Streak':'E','NNE':'E','Nascent Mesoderm':'M','Emergent Mesoderm':'M','Advanced Mesoderm':'M','YS Mesoderm':'Mx','Axial Mesoderm':'X','DE(P)':'N','DE(NP)':'N','Hypoblast':'VE','YS Endoderm':'VE','Amnion':'bg'}
# original used tyser genes.txt names: check whether dotted
print('NKX1-2' in T.var_names, 'NKX1.2' in T.var_names)
TL=T.obs.label.map(lt).fillna('other').values
Tsub,summ=recl(T,TL,'Tyser')
for r in summ: print(r)


# ---- cell [frame 31f871e7, message 66] Renaming Tyser genes and re-running reclustering
g0=[x for x in open(OD+'tyser_CS7_genes.txt').read().split('\n') if x!='']
assert len(g0)==T.n_vars
T.var_names=g0; T.var_names_make_unique()
Tsub,summ=recl(T,TL,'Tyser')
for r in summ: print(r)


# ---- cell [frame 31f871e7, message 68] Reproducing 10x layer re-clustering subclusters
n=X.obs.Type2.str.split().str[0].astype(int)
m={**{k:'E' for k in [1,2,3,4,5,8,12,15]},**{k:'M' for k in range(16,29)},**{k:'Mx' for k in [29,30,31]},9:'X',10:'X',35:'N',36:'N',37:'N',38:'VE'}
XL=n.map(m).fillna('other'); XL[X.obs.Type2.isin(['39 Trophoblast','13 AME'])]='bg'; XL=XL.values
Xsub,summX=recl(X,XL,'10x')
for r in summX: print(r)


# ---- cell [frame 31f871e7, message 70] Computing per-milestone evidence numbers
def D(A,g): return det(A,g)
def co(A,genes,mask):
    v=np.ones(A.n_obs,bool)
    for g in genes: v&=D(A,g)
    return int(v[mask].sum()), round(100*v[mask].mean(),1) if mask.sum() else np.nan
def pc(A,g,mask): 
    if isinstance(g,(list,tuple)): return co(A,g,mask)
    v=D(A,g); return int(v[mask].sum()), round(100*v[mask].mean(),1)
tl=T.obs.label; tc=T.obs.cluster; xl=X.obs.Type2
TM={'PS':(tc=='Primitive Streak').values,'PSsub':(tl=='Primitive Streak').values,'NasMeso':(tl=='Nascent Mesoderm').values,'Axial':(tl=='Axial Mesoderm').values,
    'DE':tl.isin(['DE(P)','DE(NP)']).values,'EPI':(tl=='Epiblast').values,'Emergent':(tl=='Emergent Mesoderm').values,'Advanced':(tl=='Advanced Mesoderm').values,
    'YSMeso':(tl=='YS Mesoderm').values,'HEP':tl.isin(GT['HEP']).values,'Ery':(tl=='Erythroblasts').values,'PGC':(tl=='PGC').values,
    'BG':tl.isin(['Amnion','Hypoblast','YS Endoderm']).values,'ALL':np.ones(T.n_obs,bool)}
TM['PSEPI']=TM['PS']|TM['EPI']
TM['EP']=~tl.isin(['Amnion','Hypoblast','YS Endoderm','YS Mesoderm','Erythroblasts']+GT['HEP']).values
TM['MESO']=tl.isin(['Nascent Mesoderm','Emergent Mesoderm','Advanced Mesoderm','YS Mesoderm']).values
for k,v in Tsub.items(): TM['sub_'+k]=T.obs_names.isin(v)
XM={k:xl.isin(v).values for k,v in G10.items()}
XM['ParaOnly']=(xl=='17 Para.Meso').values; XM['Somite']=(xl=='19 Somite').values; XM['CardProg']=(xl=='20 Cardiac progenitor').values; XM['CM3']=(xl=='22 Cardiomyocyte').values
XM['PSEPIpNMP']=xl.isin(['15 PS','2   EPI/ECT(p)','5   NMP']).values; XM['ALL']=np.ones(X.n_obs,bool)
XM['EP']=~xl.isin(['13 AME','39 Trophoblast','38 VE_YE','29 EXM','30 Allantois','31 YS.Meso','32 Endothelial cell','33 Blood progenitor','34 Erythrocyte','40 Doublet']).values
XM['NoDbl']=(xl!='40 Doublet').values
for k,v in Xsub.items(): XM['sub_'+k]=X.obs_names.isin(v)
print({k:int(v.sum()) for k,v in TM.items()}); print({k:int(v.sum()) for k,v in XM.items()})
Q=[('T','m01','MESP1','NasMeso'),('T','m01','MESP1','BG'),
   ('T','m02','FOXA2','Axial'),('T','m02','GSC','Axial'),('T','m02',['GSC','FOXA2'],'Axial'),('T','m02',['GSC','FOXA2'],'BG'),('T','m02',['GSC','FOXA2'],'PS'),('T','m02','GSC','BG'),
   ('T','m03',['FOXJ1','CHRD'],'Axial'),('T','m03',['FOXJ1','CHRD'],'BG'),('T','m03',['FOXJ1','CHRD'],'ALL'),
   ('T','m04',['FOXA2','SOX17'],'DE'),('T','m04',['FOXA2','SOX17'],'BG'),('T','m04','SOX17','DE'),
   ('T','m05',['GSC','CER1'],'DE'),('T','m05',['GSC','CER1'],'EP'),('T','m05',['GSC','CER1'],'BG'),('T','m05',['GSC','CER1'],'ALL'),
   ('T','m06','GSC','DE'),('T','m06','GSC','BG'),
   ('T','m07','NOTO','Axial'),('T','m07','NOTO','sub_Notochord'),('T','m07','NOTO','BG'),('T','m07','NOTO','ALL'),('T','m07',['NOTO','FOXA2'],'ALL'),('T','m07','SHH','sub_Notochord'),
   ('T','m08','HOXB1','PS'),('T','m08','HOXB1','BG'),('T','m08','HOXA1','PS'),('T','m08','HOXA1','BG'),('T','m08','HOXA1','PSsub'),('T','m08','HOXB1','PSsub'),('T','m08','HOXA1','EPI'),
   ('T','m09',['NKX1-2','CDX2'],'PSEPI'),('T','m09',['NKX1-2','CDX2'],'BG'),('T','m09',['NKX1-2','CDX2'],'sub_Caudal epiblast'),
   ('T','m10','HESX1','sub_Rostral neurectoderm'),('T','m10','SIX3','sub_Rostral neurectoderm'),('T','m10',['HESX1','SIX3'],'EPI'),('T','m10','HESX1','EPI'),('T','m10','SIX3','EPI'),('T','m10','HESX1','BG'),('T','m10','SIX3','BG'),('T','m10',['HESX1','SIX3'],'sub_Rostral neurectoderm'),
   ('T','m11','MEOX1','MESO'),('T','m11','TCF15','MESO'),('T','m11',['MEOX1','TCF15'],'MESO'),('T','m11','MEOX1','BG'),('T','m11','MEOX1','NasMeso'),('T','m11','MEOX1','Emergent'),('T','m11','MEOX1','Advanced'),
   ('T','m12','EOMES','PS'),('T','m12','EOMES','BG'),('T','m12','EOMES','PSsub'),
   ('T','m13','HOXB8',None),('T','m13','HOXB8','BG'),
   ('T','m14','NKX2-5','Advanced'),('T','m14','TNNT2','Advanced'),('T','m14',['NKX2-5','TNNT2'],'ALL'),('T','m14','NKX2-5','BG'),('T','m14','NKX2-5','sub_Cardiomyocytes'),
   ('T','m15','NANOS3','PGC'),('T','m15','DPPA3','PGC'),('T','m15','SOX17','PGC'),('T','m15','TFAP2C','PGC'),('T','m15','NANOS3','BG'),('T','m15','DPPA3','BG'),('T','m15',['NANOS3','SOX17'],'ALL'),
   ('T','m16','ETV2','HEP'),('T','m16','KDR','HEP'),('T','m16','CDH5','HEP'),('T','m16','RUNX1','HEP'),('T','m16','ETV2','BG'),('T','m16','KDR','BG'),('T','m16',['ETV2','KDR'],'HEP'),
   ('T','m17','HAND1','YSMeso'),('T','m17','HAND1','BG'),
   ('T','m18','TBX4','sub_Allantois'),('T','m18','HOXA10','sub_Allantois'),('T','m18',['TBX4','HOXA10'],'sub_Allantois'),('T','m18',['TBX4','HOXA10'],'ALL'),('T','m18','TBX4','BG'),('T','m18','HOXA10','BG'),('T','m18','TBX4','Advanced'),('T','m18','HOXA10','Advanced'),('T','m18','HOXA10','YSMeso'),
   ('T','m19','HBZ','Ery'),('T','m19','HBE1','Ery'),('T','m19','GATA1','Ery'),('T','m19','HBZ','BG'),('T','m19','GATA1','BG'),('T','m19',['HBZ','GATA1'],'Ery'),
]
# HOXB8 in NKX1-2+CDX2+ cells of PS/EPI
TM['CLEpos']=TM['PSEPI']&D(T,'NKX1-2')&D(T,'CDX2')
Q=[(a,b,c,('CLEpos' if d is None else d)) for a,b,c,d in Q]
QX=[('X','m01','MESP1','NasMeso'),('X','m01','MESP1','BG'),
   ('X','m02','FOXA2','Node'),('X','m02','GSC','Node'),('X','m02',['GSC','FOXA2'],'Node'),('X','m02',['GSC','FOXA2'],'PS'),('X','m02',['FOXA2','TBXT'],'PS'),('X','m02',['GSC','FOXA2'],'BG'),('X','m02',['GSC','FOXA2'],'NoDbl'),
   ('X','m03','FOXJ1','Node'),('X','m03','CHRD','Node'),('X','m03',['FOXJ1','CHRD'],'Node'),('X','m03',['FOXJ1','CHRD'],'BG'),
   ('X','m04','SOX17','DE'),('X','m04','FOXA2','DE'),('X','m04',['FOXA2','SOX17'],'DE'),('X','m04',['FOXA2','SOX17'],'BG'),
   ('X','m05',['GSC','CER1'],'DE'),('X','m05',['GSC','CER1'],'EP'),('X','m05',['GSC','CER1'],'BG'),
   ('X','m06','GSC','DE'),('X','m06','GSC','BG'),('X','m06','GSC','EPIa'),
   ('X','m07','NOTO','Node'),('X','m07','NOTO','Notochord'),('X','m07','NOTO','BG'),('X','m07','SHH','Node'),('X','m07',['NOTO','FOXA2'],'NoDbl'),
   ('X','m08','HOXB1','PS'),('X','m08','HOXB1','BG'),('X','m08','HOXB1','EPIa'),('X','m08','HOXA1','PS'),('X','m08','HOXA1','BG'),
   ('X','m09',['NKX1-2','CDX2'],'PSEPIpNMP'),('X','m09',['NKX1-2','CDX2'],'BG'),('X','m09','NKX1-2','EPIp'),('X','m09','CDX2','EPIp'),('X','m09','NKX1-2','PS'),('X','m09','CDX2','PS'),('X','m09','NKX1-2','BG'),
   ('X','m10','SIX3','EPIa'),('X','m10','HESX1','EPIa'),('X','m10',['HESX1','SIX3'],'EPIa'),('X','m10','SIX3','BG'),('X','m10','HESX1','BG'),('X','m10','HESX1','sub_Rostral neurectoderm'),('X','m10','SIX3','sub_Rostral neurectoderm'),('X','m10','SOX1','EPIa'),
   ('X','m11','MEOX1','ParaMeso'),('X','m11','TCF15','ParaMeso'),('X','m11','MEOX1','ParaOnly'),('X','m11','TCF15','ParaOnly'),('X','m11',['MEOX1','TCF15'],'ParaOnly'),('X','m11','MEOX1','BG'),('X','m11','TCF15','BG'),
   ('X','m12','EOMES','PS'),('X','m12','EOMES','BG'),('X','m12','EOMES','EPIa'),
   ('X','m13','HOXB8','CLEpos'),('X','m13','HOXB8','BG'),('X','m13','HOXB8','EPIp'),
   ('X','m14','NKX2-5','Cardiac'),('X','m14','TNNT2','Cardiac'),('X','m14',['NKX2-5','TNNT2'],'Cardiac'),('X','m14','NKX2-5','BG'),('X','m14','TNNT2','BG'),('X','m14','NKX2-5','CM3'),('X','m14','MYL7','Cardiac'),
   ('X','m15',['NANOS3','TFAP2C','PRDM1'],'NoDbl'),('X','m15','NANOS3','NoDbl'),('X','m15',['NANOS3','SOX17'],'NoDbl'),('X','m15','NANOS3','BG'),('X','m15','DPPA3','NoDbl'),('X','m15',['NANOS3','DPPA3'],'NoDbl'),
   ('X','m16','ETV2','HEP'),('X','m16','KDR','HEP'),('X','m16','CDH5','HEP'),('X','m16','RUNX1','HEP'),('X','m16','ETV2','BG'),('X','m16','KDR','BG'),('X','m16',['ETV2','KDR'],'HEP'),
   ('X','m17','HAND1','EXM'),('X','m17','HAND1','BG'),
   ('X','m18','TBX4','Allantois'),('X','m18','HOXA10','Allantois'),('X','m18',['TBX4','HOXA10'],'Allantois'),('X','m18','TBX4','BG'),('X','m18','HOXA10','BG'),('X','m18','HOXA10','EXM'),('X','m18','TBX4','sub_Allantois'),('X','m18','HOXA10','sub_Allantois'),
   ('X','m19','HBE1','Ery'),('X','m19','HBZ','Ery'),('X','m19','GATA1','Ery'),('X','m19','HBE1','BG'),('X','m19','HBZ','BG'),('X','m19','GATA1','BG'),('X','m19',['HBE1','GATA1'],'Ery')]
XM['CLEpos']=XM['PSEPIpNMP']&D(X,'NKX1-2')&D(X,'CDX2')
NUM={}
for ds,mid,g,pop in Q+QX:
    A,M=(T,TM) if ds=='T' else (X,XM)
    k,p=pc(A,g,M[pop]); gs='+'.join(g) if isinstance(g,list) else g
    NUM[(ds,mid,gs,pop)]=(k,int(M[pop].sum()),p)
with open(W+'numbers.txt','w') as f:
    for k,v in NUM.items(): f.write(f'{k[0]} {k[1]} {k[2]:22s} {k[3]:26s} {v[0]:5d}/{v[1]:5d} = {v[2]}%\n')
print(open(W+'numbers.txt').read())


# ---- cell [frame 31f871e7, message 72] Checking PGC count and TBXT+ pool metrics
print('10x NANOS3+TFAP2C+PRDM1 all cells', pc(X,['NANOS3','TFAP2C','PRDM1'],XM['ALL']), 'labels:', X.obs.Type2[D(X,'NANOS3')&D(X,'TFAP2C')&D(X,'PRDM1')].tolist())
print('Types PGC label-transfer:', (X.obs.Types.astype(str).str.contains('PGC')).sum())
for nm,A,L in [('T',T,TL),('X',X,XL)]:
    tp=np.isin(L,['E','M'])&D(A,'TBXT')
    print(nm,'TBXT+ E+M pool n=',tp.sum(),'EOMES',pc(A,'EOMES',tp),'HOXB1',pc(A,'HOXB1',tp),'HOXA1',pc(A,'HOXA1',tp))
    cle=np.isin(L,['E','M'])&D(A,'NKX1-2')&D(A,'CDX2'); print(nm,'NKX1-2+CDX2+ E+M',cle.sum(),'HOXB8',pc(A,'HOXB8',cle))
from scipy.stats import fisher_exact, binomtest
print('T HOXA1 PS vs BG', fisher_exact([[87,202-87],[2,96]]))
print('T HOXB1 PS vs BG', fisher_exact([[10,192],[3,95]]))
print('X HOXB8 binom CI', binomtest(122,520).proportion_ci())
print('T sub_Allantois labels', T.obs.label[TM['sub_Allantois']].value_counts().to_dict())
print('T sub_Rostral labels', T.obs.label[TM['sub_Rostral neurectoderm']].value_counts().to_dict())
print('T GSC+CER1+ labels', T.obs.label[D(T,'GSC')&D(T,'CER1')].value_counts().to_dict())
print('X GSC+CER1+ labels', X.obs.Type2[D(X,'GSC')&D(X,'CER1')].value_counts().to_dict())


# ---- cell [frame 31f871e7, message 74] Assembling evidence_scrna.csv table
mc=pd.read_excel(wb,'milestone_calls'); mdef=pd.read_excel(wb,'milestone_definitions')
MID=[f'm{i:02d}' for i in range(1,20)]
LAB=dict(zip(MID,mdef.label)); KEYM=dict(zip(MID,mc.milestone))
DSN={'T':'Tyser CS7 (Smart-seq2)','X':'In-house CS7 (10x)'}
FC={(d,m):mc.loc[i,DSN[d]] for d in 'TX' for i,m in enumerate(MID)}
FE={(d,m):mc.loc[i,DSN[d]+' | evidence'] for d in 'TX' for i,m in enumerate(MID)}
PN={'T':{'PS':'Primitive Streak cluster_id (195 PS + 7 PGC sub_cluster; = workbook PS)','PSsub':'Primitive Streak sub_cluster','NasMeso':'Nascent Mesoderm','Axial':'Axial Mesoderm',
     'DE':'DE(P)+DE(NP)','EPI':'Epiblast','Emergent':'Emergent Mesoderm','Advanced':'Advanced Mesoderm','YSMeso':'YS Mesoderm','HEP':'Hemogenic Endothelium+Blood/Erythro-Myeloid/Myeloid Progenitors',
     'Ery':'Erythroblasts','PGC':'PGC','BG':'Amnion+Hypoblast+YS Endoderm','ALL':'all cells','PSEPI':'PS cluster+Epiblast','EP':'embryo-proper (all minus amnion, hypoblast, YSE, YS mesoderm, haemato-endothelial, erythroid)',
     'MESO':'all mesoderm (Nascent+Emergent+Advanced+YS Mesoderm)','CLEpos':'NKX1-2+CDX2+ cells in PS/Epiblast','TBXTpool':'TBXT+ cells in epiblast/PS/NNE/mesoderm layers',
     **{f'sub_{k}':f're-clustered {v} subcluster (best for {k})' for k,v in [('Notochord','mesendoderm X+M+N'),('Caudal epiblast','epiblast-layer'),('Rostral neurectoderm','epiblast-layer'),('Paraxial mesoderm','mesoderm'),('Cardiomyocytes','mesoderm+ExE-mesoderm'),('PGC','all-layer'),('Allantois','mesoderm+ExE-mesoderm')]}},
    'X':{'PS':'15 PS','NasMeso':'16 Nas.Meso/PSM','Node':'9 Node','Notochord':'10 Notochord','DE':'35 DE','EPIa':'1 EPI/ECT(a)','EPIp':'2 EPI/ECT(p)','ParaMeso':'17 Para.Meso+19 Somite (= workbook ParaMeso)',
     'ParaOnly':'17 Para.Meso','Cardiac':'20 Cardiac progenitor+22 Cardiomyocyte','CM3':'22 Cardiomyocyte','Allantois':'30 Allantois','EXM':'29 EXM','HEP':'32 Endothelial cell+33 Blood progenitor',
     'Ery':'34 Erythrocyte','BG':'13 AME+39 Trophoblast','ALL':'all cells','NoDbl':'all non-doublet cells','EP':'embryo-proper (all minus AME, trophoblast, VE/YE, EXM, allantois, YS meso, endothelial, blood, erythroid, doublets)',
     'PSEPIpNMP':'15 PS+2 EPI/ECT(p)+5 NMP','CLEpos':'NKX1-2+CDX2+ cells in PS/EPI(p)/NMP','TBXTpool':'TBXT+ cells in epiblast/PS/NE/mesoderm layers',
     **{f'sub_{k}':f're-clustered layer subcluster (best for {k})' for k in ['Notochord','Caudal epiblast','Rostral neurectoderm','Paraxial mesoderm','Cardiomyocytes','PGC','Allantois']}}}
TM['TBXTpool']=np.isin(TL,['E','M'])&D(T,'TBXT'); XM['TBXTpool']=np.isin(XL,['E','M'])&D(X,'TBXT')
def val(d,g,pop):
    A,M=(T,TM) if d=='T' else (X,XM); k,p=pc(A,g.split('+') if '+' in g else g,M[pop]); return k,int(M[pop].sum()),p
ROWS=[]
def R(d,m,g,pop,bg,mouse,note='',metric=None,role='supporting'):
    k,n,p=val(d,g,pop)
    if bg: kb,nb,pb=val(d,g,bg)
    else: kb,nb,pb=(None,None,None)
    ROWS.append(dict(dataset=DSN[d],milestone_id=m,milestone=LAB[m],figure_call=FC[(d,m)],target_population=PN[d][pop],n_target=n,
        metric=metric or (f'{g} detection % (>=1 read/UMI)' if '+' not in g else f'{g} co-detection %'),value_target=p,
        background_population=PN[d][bg] if bg else '',n_background=nb if bg else '',value_background=pb if bg else '',
        mouse_reference=mouse,n_pos_target=k,n_pos_background=kb if bg else '',row_role=role,note=note))
def RC(d,m,popname,n,metric,value,mouse,note='',role='supporting',bgname='',nb='',vb=''):
    ROWS.append(dict(dataset=DSN[d],milestone_id=m,milestone=LAB[m],figure_call=FC[(d,m)],target_population=popname,n_target=n,metric=metric,value_target=value,
        background_population=bgname,n_background=nb,value_background=vb,mouse_reference=mouse,n_pos_target='',n_pos_background='',row_role=role,note=note))
print(len(MID), FC[('T','m08')], FC[('X','m05')])


# ---- cell [frame 31f871e7, message 76] Writing all evidence rows with verdicts
ROWS=[]
ON=dict(zip(MID,mc.mouse_onset))
MR={'m01':'Mouse nascent mesoderm Mesp1 98.6% vs 9.3% other',
'm02':'Mouse APS Gsc 91.7%, Foxa2 81.7% (vs 6.9/8.8%); Gsc+Foxa2+ 77.6% of APS at E7.0 [atlas recomputed]; APS 3.9% of cells E7.0 -> 0.007% E7.75',
'm03':'Mouse notochord Foxj1 90.9%, Chrd 64.2% (vs 2.3/1.9%)',
'm04':'Mouse DE Sox17 53.0%, Foxa2 70.8% (vs 12.9/8.9%)',
'm05':'Mouse Gsc+Cer1+ DE 0.26% of embryo-proper E7.0, 2.2% E7.25 (workbook); Gsc+Cer1+ % of DE 61.7 E7.25, 22.1 E7.5, 2.3 E7.75 [atlas recomputed]',
'm06':'Mouse DE Gsc peak 69.7% (E7.25); loss threshold 52.3% (75% of peak); 22.6% E7.5, 2.3% E7.75 (10x)',
'm07':'Mouse notochord Noto 91.2% vs 0.7%; node/notochord Noto 89.9% E7.5; notochord 0.074% of cells E7.25, 0.63% E7.5',
'm08':'Mouse PS Hoxb1 3.7/10.0/21.9% and Hoxa1 0.8/5.2/15.6% at E7.25/7.5/7.75 (onset thresholds 5.5% and 3.9%); TBXT+ pool Hoxa1 2.6/33.9%, Hoxb1 13.9/48.6% at E7.25/7.5 (monkey Hoxa1 threshold 19.4%)',
'm09':'Mouse caudal epiblast Nkx1-2 89.8%, Cdx2 97.2% (vs 8.9/31.9%); 0.06% of cells E7.25, 3.8% E7.5',
'm10':'Mouse rostral NE Six3 22.8%, Hesx1 38.9% (vs 2.5/5.9%); [atlas recomputed] Hesx1+Six3+ 6.6% of RNE E7.5, 20.2% E7.75; whole epiblast E7.0-7.25 Hesx1 3.1-3.2%, Six3 1.3-1.4%, co-detection <=0.1%',
'm11':'Mouse paraxial mesoderm Meox1 53.0%, Tcf15 72.1% (vs 5.1/10.3%)',
'm12':'Mouse PS Eomes peak 89.4% (E7.25), loss threshold 67.1%; 75.3% E7.5, 54.7% E7.75 (10x); TBXT+ pool 86.2/39.6/9.3% at E7.25/7.5/7.75 (monkey rule: reached <=9.3%, not reached >=39.6%)',
'm13':'Mouse caudal epiblast Hoxb8 5.3% E7.5, 52.1% E7.75; onset threshold 22.6% (calibration sheet, 25% of 90.2%); 23.6% if caudal epiblast+NMP table (max 94.3%) is used',
'm14':'Mouse cardiomyocytes Nkx2-5 93.5-97.1% (10x, E7.75-8.25); pharyngeal mesoderm Nkx2-5 26.1% E7.5',
'm15':'Mouse PGC Dppa3 56.9%, Nanos3 28.8% (vs 1.9/0.4%); PGC 0.40% of cells E7.25, 0.62% E7.5',
'm16':'Mouse haemato-endothelial progenitors Kdr 83.0%, Etv2 88.1% (vs 6.1/14.8%)',
'm17':'Mouse ExE mesoderm Hand1 80.6% vs 25.5%; 1.28% of cells E7.5',
'm18':'Mouse allantois Tbx4 31.6%, Hoxa10 79.3% (vs 0.4/2.3%); [atlas recomputed] E7.75 Tbx4 41.6%, Hoxa10 87.8%, Tbx4+Hoxa10+ 37.8%',
'm19':'Mouse Erythroid1 Hba-x 99.6%, Gata1 92.2% (vs 22.9/9.1%); 0.018% of cells E7.5, 4.0% E7.75'}
MR={k:v+f'; mouse onset E{ON[k]}' for k,v in MR.items()}
P='primary'
# ---------- Tyser ----------
R('T','m01','MESP1','NasMeso','BG',MR['m01'],role=P)
RC('T','m01','Nascent Mesoderm',98,'cells annotated',98,MR['m01'])
R('T','m02','GSC+FOXA2','Axial','BG',MR['m02'],role=P,note='APS-derived axial population present; FOXA2 alone uninformative vs rule background (hypoblast/YSE FOXA2+)')
R('T','m02','FOXA2','Axial','BG',MR['m02']); R('T','m02','GSC','Axial','BG',MR['m02'])
R('T','m02','GSC+FOXA2','PS',None,MR['m02'],note='no GSC+FOXA2+ cells in the PS cluster itself')
R('T','m03','FOXJ1+CHRD','Axial','BG',MR['m03'],role=P)
R('T','m04','FOXA2+SOX17','DE','BG',MR['m04'],role=P,note='rule background contains hypoblast/YS endoderm, which share FOXA2/SOX17; DE call rests on author annotation')
R('T','m04','SOX17','DE','BG',MR['m04']); R('T','m04','FOXA2','DE','BG',MR['m04'])
R('T','m05','GSC+CER1','DE','BG',MR['m05'],role=P)
RC('T','m05','DE(P)+DE(NP) GSC+CER1+ cells / embryo-proper cells',871,'GSC+CER1+ DE cells, % of embryo-proper',round(100*2/871,2),MR['m05'],
   note='2 of 871 embryo-proper cells (0.23%) ~ mouse E7.0 (0.26%); embryo-proper denominator = my choice (excl. amnion, hypoblast, YSE, YS mesoderm, haemato-endothelial, erythroid). 5 further GSC+CER1+ cells are Emergent Mesoderm, 1 Axial')
R('T','m06','GSC','DE','BG',MR['m06'],role=P,note='GSC in DE never reached an ADE-like level (7.5% vs mouse peak 69.7%), so loss cannot be scored')
R('T','m07','NOTO','sub_Notochord','BG',MR['m07'],role=P,note='reproduced re-clustering (22 cells; 21 Axial Mesoderm, 1 Nascent Mesoderm); module z 4.37 reproduced')
R('T','m07','NOTO','Axial','BG',MR['m07']); R('T','m07','SHH','sub_Notochord','BG',MR['m07'])
R('T','m07','NOTO+FOXA2','ALL',None,MR['m07'],note='NOTO+FOXA2+ = 1.0% of all cells, above mouse notochord fraction at E7.5 (0.63%) -> meets the human criterion; but NOTO 54.5% in axial subcluster < mouse notochord 91%')
R('T','m08','HOXB1','PS','BG',MR['m08'],role=P,note='HOXB1 not above rule background (Fisher P=0.56)')
R('T','m08','HOXA1','PS','BG',MR['m08'],role=P,note='HOXA1 43.1% vs 2.0% (Fisher P=6e-16); milestone defined as Hoxa1+ OR Hoxb1+ PS and Stereo-seq calls use HOXA1 -> reached')
R('T','m08','HOXA1','TBXTpool','BG',MR['m08'],note='TBXT+ pool HOXA1 64.4% > monkey-rule threshold 19.4%')
R('T','m08','HOXB1','TBXTpool','BG',MR['m08'],note='HOXB1 20.6% in TBXT+ pool vs 3.1% rule background; layer re-analysis called it ~background only because it used amnion alone (3/16 = 18.8%) as background')
R('T','m09','NKX1-2+CDX2','PSEPI','BG',MR['m09'],role=P,note='36 cells, no separate cluster -> partial')
R('T','m09','NKX1-2+CDX2','sub_Caudal epiblast','BG',MR['m09'],note='best epiblast-layer subcluster (26 cells, 24 PS): NKX1-2 53.8%, CDX2 57.7%, module z 0.64 (reproduced)')
R('T','m10','HESX1+SIX3','EPI','BG',MR['m10'],role=P,note='Epiblast HESX1+SIX3+ 4.5% lies between mouse whole epiblast (<=0.1%) and mouse RNE E7.5 (6.6%); cross-platform comparison only -> partial (provisional)')
R('T','m10','HESX1','sub_Rostral neurectoderm','BG',MR['m10'],note='reproduced subcluster (22 Epiblast cells); HESX1 is also 16.3% in the rule background (hypoblast/AVE)')
R('T','m10','SIX3','sub_Rostral neurectoderm','BG',MR['m10'])
R('T','m10','SIX3','EPI','BG',MR['m10'])
R('T','m11','MEOX1','MESO','BG',MR['m11'],role=P,note='MEOX1 3/530 mesoderm cells (all 3 in Nascent Mesoderm, 3.1%); 0% Emergent/Advanced')
R('T','m11','MEOX1+TCF15','MESO','BG',MR['m11']); R('T','m11','TCF15','MESO','BG',MR['m11'],note='TCF15 alone not paraxial-specific (40.5% Emergent Mesoderm)')
R('T','m12','EOMES','PS','BG',MR['m12'],role=P,note='Above background (7.5x) -> not reached under the "fallen to background" rule; but 14.9% is far below the mouse 10x PS loss threshold (67.1%) used for the 10x call')
R('T','m12','EOMES','TBXTpool','BG',MR['m12'],note='TBXT+ pool 13.4%: between mouse TBXT+ E7.5 (39.6%) and E7.75 (9.3%) -> partial under the monkey rule')
R('T','m13','HOXB8','CLEpos','BG',MR['m13'],role=P,note='0/36; at the 22.6% threshold ~8 positives would be expected (binomial P(0)=1e-4)')
R('T','m14','NKX2-5','Advanced','BG',MR['m14'],role=P)
R('T','m14','NKX2-5+TNNT2','ALL',None,MR['m14'],note='no NKX2-5+TNNT2+ cell in the dataset')
R('T','m14','NKX2-5','sub_Cardiomyocytes','BG',MR['m14'],note='best mesoderm subcluster for the cardiomyocyte module: 27 cells, NKX2-5 11.1%, module z -0.50 (reproduced)')
R('T','m15','NANOS3','PGC','BG',MR['m15'],role=P)
R('T','m15','DPPA3','PGC','BG',MR['m15'],note='DPPA3 also 28.6% in background (hypoblast/YSE)'); R('T','m15','SOX17','PGC','BG',MR['m15']); R('T','m15','TFAP2C','PGC','BG',MR['m15'])
RC('T','m16','Hemogenic Endothelium+Blood/Erythro-Myeloid/Myeloid Progenitors',111,'cells annotated',111,MR['m16'],role=P)
R('T','m16','KDR','HEP','BG',MR['m16']); R('T','m16','ETV2','HEP','BG',MR['m16'],note='ETV2 low (11.7%) vs mouse progenitors (88%), consistent with a population already past the Etv2+ progenitor stage (blood progenitors/EMPs present)')
R('T','m16','CDH5','HEP','BG',MR['m16']); R('T','m16','RUNX1','HEP','BG',MR['m16'])
R('T','m17','HAND1','YSMeso','BG',MR['m17'],role=P,note='83 cells = 6.9% of all cells')
R('T','m18','TBX4+HOXA10','sub_Allantois','BG',MR['m18'],role=P,note='0 TBX4+HOXA10+ cells in the whole dataset; subcluster TBX4 12.2%, HOXA10 12.2% vs mouse allantois 41.6/87.8% (Smart-seq2 should not under-detect relative to 10x) -> not reached / at most partial')
R('T','m18','TBX4','sub_Allantois','BG',MR['m18']); R('T','m18','HOXA10','sub_Allantois','BG',MR['m18'])
R('T','m18','HOXA10','YSMeso','BG',MR['m18'],note='HOXA10 also absent from YS mesoderm (2.4%)')
R('T','m19','HBZ+GATA1','Ery','BG',MR['m19'],role=P); R('T','m19','HBZ','Ery','BG',MR['m19']); R('T','m19','GATA1','Ery','BG',MR['m19'])
# ---------- 10x ----------
R('X','m01','MESP1','NasMeso','BG',MR['m01'],role=P)
R('X','m02','FOXA2','Node','BG',MR['m02'],role=P,note='reached via APS derivative (node); GSC+FOXA2+ streak cells absent, as expected after mouse APS regression (E7.75: 0.007% of cells)')
R('X','m02','GSC+FOXA2','Node','BG',MR['m02']); R('X','m02','GSC+FOXA2','PS',None,MR['m02']); R('X','m02','FOXA2+TBXT','PS',None,MR['m02'])
R('X','m03','FOXJ1+CHRD','Node','BG',MR['m03'],role=P); R('X','m03','FOXJ1','Node','BG',MR['m03']); R('X','m03','CHRD','Node','BG',MR['m03'])
R('X','m04','FOXA2+SOX17','DE','BG',MR['m04'],role=P); R('X','m04','SOX17','DE','BG',MR['m04']); R('X','m04','FOXA2','DE','BG',MR['m04'])
R('X','m05','GSC+CER1','DE','BG',MR['m05'],role=P,note='3/199 (1.5%) ~ mouse post-regression DE (E7.75 2.3%); appearance cannot be timed after regression -> not assessable is consistent')
R('X','m06','GSC','DE','BG',MR['m06'],role=P,note='6.5% << mouse 10x loss threshold 52.3%, between E7.5 (22.6%) and E7.75 (2.3%)')
R('X','m07','NOTO','Node','BG',MR['m07'],role=P); R('X','m07','SHH','Node','BG',MR['m07']); R('X','m07','NOTO','Notochord','BG',MR['m07'],note='only 6 cells labelled Notochord')
R('X','m08','HOXB1','PS','BG',MR['m08'],role=P,note='evidence string quotes bkg 3.3% = EPI/ECT(a); rule background (AME+trophoblast) is 19.8%; still 2x and 39.3% >> mouse 10x PS 21.9% at E7.75')
R('X','m08','HOXB1','PS','EPIa',MR['m08']); R('X','m08','HOXA1','PS','BG',MR['m08'])
R('X','m09','NKX1-2+CDX2','PSEPIpNMP','BG',MR['m09'],role=P,note='520 cells = 4.5% of all cells (mouse caudal epiblast 3.8% at E7.5); sit inside the PS cluster (Type label: B1 Caudal epiblast); layer re-analysis verdict "not supported by markers" (co-detection obs/exp 1.55)')
R('X','m09','NKX1-2','EPIp','BG',MR['m09']); R('X','m09','NKX1-2','PS','BG',MR['m09']); R('X','m09','CDX2','PS','BG',MR['m09'])
R('X','m10','HESX1+SIX3','EPIa','BG',MR['m10'],role=P,note='same-platform comparison: HESX1+SIX3+ 9.6% of EPI/ECT(a) > mouse RNE E7.5 (6.6%), >> mouse epiblast (<=0.1%); SOX1 0/821')
R('X','m10','SIX3','EPIa','BG',MR['m10']); R('X','m10','HESX1','EPIa','BG',MR['m10'])
R('X','m11','MEOX1+TCF15','ParaOnly','BG',MR['m11'],role=P,note='17 Para.Meso only (rules: Somite label not used)')
R('X','m11','MEOX1','ParaMeso','BG',MR['m11'],note='evidence string (MEOX1 43.6%, TCF15 72.4%) uses Para.Meso+Somite (163 cells), contrary to the rules note; Para.Meso alone: 58.8/86.8%')
R('X','m11','TCF15','ParaMeso','BG',MR['m11'])
R('X','m12','EOMES','PS','BG',MR['m12'],role=P,note='6.3% << mouse 10x loss threshold 67.1% (reached by same-platform calibration); still 12.6x above rule background, so the literal "fallen to background" criterion is not met')
R('X','m12','EOMES','TBXTpool','BG',MR['m12'],note='TBXT+ pool 4.8% <= 9.3% -> reached under the monkey rule')
R('X','m13','HOXB8','CLEpos','BG',MR['m13'],role=P,note='23.5% (95% CI 19.9-27.3%) straddles the onset threshold (22.6% or 23.6% depending on mouse table); layer-pool definition (E+M layers, 719 cells) gives 22.5%, below threshold -> borderline/partial')
R('X','m13','HOXB8','EPIp','BG',MR['m13'])
R('X','m14','NKX2-5','Cardiac','BG',MR['m14'],role=P,note='13.0% << mouse cardiomyocytes 93.5-97.1%, below mouse pharyngeal mesoderm E7.5 (26.1%); the 3 "Cardiomyocyte" cells are NKX2-5 0/3')
R('X','m14','NKX2-5+TNNT2','Cardiac','BG',MR['m14']); R('X','m14','TNNT2','Cardiac','BG',MR['m14'],note='TNNT2 21.4% in AME/trophoblast background')
R('X','m15','NANOS3+TFAP2C+PRDM1','ALL',None,MR['m15'],role=P,note='4 cells in all cells (3 excluding doublets: 1 EPI/ECT(p), 2 NNE); no PGC cluster; label transfer (Types) assigns 0 PGC; mouse fraction would predict ~45-70 PGCs in 11,487 cells')
R('X','m15','NANOS3+SOX17','NoDbl',None,MR['m15']); R('X','m15','NANOS3','NoDbl','BG',MR['m15'])
RC('X','m16','32 Endothelial cell+33 Blood progenitor',708,'cells annotated',708,MR['m16'],role=P)
R('X','m16','KDR','HEP','BG',MR['m16']); R('X','m16','ETV2','HEP','BG',MR['m16']); R('X','m16','CDH5','HEP','BG',MR['m16'])
R('X','m17','HAND1','EXM','BG',MR['m17'],role=P,note='511 cells = 4.4% of all; HAND1 also 54.3% in AME/trophoblast background (amnion expresses HAND1)')
R('X','m18','TBX4+HOXA10','Allantois','BG',MR['m18'],role=P,note='annotated (684 cells) and enriched over background, but TBX4 8.8%/HOXA10 17.1%/co 2.2% are far below same-platform mouse allantois (41.6/87.8/37.8% E7.75) -> partial')
R('X','m18','TBX4','Allantois','BG',MR['m18']); R('X','m18','HOXA10','Allantois','BG',MR['m18'])
R('X','m18','HOXA10','sub_Allantois','BG',MR['m18'],note='best re-clustered subcluster (108 cells; 98 Allantois) TBX4 21.3%, HOXA10 23.1% (reproduced)')
R('X','m19','HBE1+GATA1','Ery','BG',MR['m19'],role=P,note='HBZ uninformative (63.6% in background; ambient haemoglobin)')
R('X','m19','HBE1','Ery','BG',MR['m19']); R('X','m19','GATA1','Ery','BG',MR['m19'])
EV=pd.DataFrame(ROWS); print(EV.shape, EV.groupby('dataset').milestone_id.nunique().to_dict())


# ---- cell [frame 31f871e7, message 78] Assigning recomputed calls and verdicts
V={('T','m01'):('reached','yes'),('T','m02'):('reached','yes'),('T','m03'):('reached','yes'),('T','m04'):('reached','yes'),('T','m05'):('partial','yes'),
   ('T','m06'):('not assessable','yes'),('T','m07'):('reached','yes'),('T','m08'):('reached (HOXA1); HOXB1 alone not above background','no'),('T','m09'):('partial','yes'),
   ('T','m10'):('partial (provisional; HESX1+SIX3+ 4.5% of epiblast, cross-platform)','partly'),('T','m11'):('not reached','yes'),
   ('T','m12'):('not reached by background rule; partial by TBXT+ pool rule; reached by 10x-calibration rule','partly'),('T','m13'):('not reached','yes'),
   ('T','m14'):('not reached','yes'),('T','m15'):('reached','yes'),('T','m16'):('reached','yes'),('T','m17'):('reached','yes'),
   ('T','m18'):('not reached (at most partial)','no'),('T','m19'):('reached','yes'),
   ('X','m01'):('reached','yes'),('X','m02'):('reached','yes'),('X','m03'):('reached','yes'),('X','m04'):('reached','yes'),('X','m05'):('not assessable','yes'),
   ('X','m06'):('reached','yes'),('X','m07'):('reached','yes'),('X','m08'):('reached','yes'),('X','m09'):('reached','yes'),('X','m10'):('reached','yes'),
   ('X','m11'):('reached','yes'),('X','m12'):('reached (same-platform calibration; not at background)','yes'),('X','m13'):('borderline (partial)','partly'),
   ('X','m14'):('not reached','yes'),('X','m15'):('partial','yes'),('X','m16'):('reached','yes'),('X','m17'):('reached','yes'),
   ('X','m18'):('partial (annotated, markers far below mouse allantois)','partly'),('X','m19'):('reached','yes')}
inv={v:k for k,v in DSN.items()}
EV['recomputed_call']=[V[(inv[d],m)][0] for d,m in zip(EV.dataset,EV.milestone_id)]
EV['supports_figure_call']=[V[(inv[d],m)][1] for d,m in zip(EV.dataset,EV.milestone_id)]
EV['figure_evidence_string']=[FE[(inv[d],m)] for d,m in zip(EV.dataset,EV.milestone_id)]
cols=['dataset','milestone_id','milestone','figure_call','target_population','n_target','metric','value_target','background_population','n_background','value_background',
      'mouse_reference','recomputed_call','supports_figure_call','note','n_pos_target','n_pos_background','row_role','figure_evidence_string']
EV=EV[cols].sort_values(['dataset','milestone_id'],kind='stable',key=lambda s: s.map({'Tyser CS7 (Smart-seq2)':0,'In-house CS7 (10x)':1}) if s.name=='dataset' else s)
OUT=(str(HGC_DATA) + '/milestone_evidence/out_scrna/')
EV.to_csv(OUT+'evidence_scrna.csv',index=False); os.makedirs('out_scrna',exist_ok=True); EV.to_csv('out_scrna/evidence_scrna.csv',index=False)
# quick check: string numbers vs recomputed primary
print(EV[EV.row_role=='primary'][['dataset','milestone_id','figure_call','value_target','value_background','supports_figure_call']].to_string())
print(os.getcwd())


# ---- cell [frame 31f871e7, message 80] Fixing precision of rare-event values
mk=EV.n_pos_target.astype(str).str.len()>0
for i in EV.index[mk]:
    k=EV.at[i,'n_pos_target']; n=EV.at[i,'n_target']
    if k!='' and float(EV.at[i,'value_target'])<1: EV.at[i,'value_target']=round(100*int(k)/int(n),3)
    kb=EV.at[i,'n_pos_background']
    if kb not in ('',None) and EV.at[i,'value_background']!='' and float(EV.at[i,'value_background'])<1: EV.at[i,'value_background']=round(100*int(kb)/int(EV.at[i,'n_background']),3)
EV.to_csv(OUT+'evidence_scrna.csv',index=False); EV.to_csv('out_scrna/evidence_scrna.csv',index=False)
print(EV.loc[(EV.milestone_id=='m15')&(EV.row_role=='primary'),['dataset','value_target','n_pos_target']])


# ---- cell [frame 31f871e7, message 134] Recomputing Tyser window under corrected calls
dm=mc[['milestone','domain','mouse_onset']].copy(); dm['mid']=MID
def window(calls):
    r=[o for (m,dmn,o),c in zip(dm[['mid','domain','mouse_onset']].values,calls) if dmn=='disc' and c=='reached']
    n=[o for (m,dmn,o),c in zip(dm[['mid','domain','mouse_onset']].values,calls) if dmn=='disc' and c=='not reached']
    return max(r) if r else None, min(n) if n else None
print(dm[['mid','domain','mouse_onset']].T.to_string())
for d in 'TX':
    fc=[FC[(d,m)] for m in MID]; print(DSN[d],'figure calls window (lo,hi):',window(fc))
fc=[FC[('T',m)] for m in MID]; fc[MID.index('m08')]='reached'; print('Tyser with m08 reached:',window(fc))
fc2=list(fc); fc2[MID.index('m12')]='partial'; print('Tyser m08 reached + m12 partial:',window(fc2))
fx=[FC[('X',m)] for m in MID]; fx[MID.index('m13')]='partial'; print('10x with m13 partial:',window(fx))
