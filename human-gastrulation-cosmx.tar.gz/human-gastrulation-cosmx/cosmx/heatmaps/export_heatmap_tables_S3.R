# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: execution log, session 824ef1ce R kernel cell 1030 (producing cell of S2A_mean_cp10k_type_stage.csv
#     eed4e5e9, S2A_frac/S2A_n tables); load line as in cell 995 of the same kernel
# sha256 of original: bd69c6af5797235098fcef7806eeac4b24975dd76059f2f59b2962ebf26bede6
# Methods paragraphs: P343, P349
# Produces: hm/S2A_mean_cp10k_type_stage.csv, hm/S2A_frac_type_stage.csv, hm/S2A_n_type_stage.csv (Supplementary
#     Figure 3 gene panel)
# Edits/notes: reconstructed from kernel log; object path -> HGC_DATA.
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

suppressPackageStartupMessages(library(Seurat))
obj <- readRDS(file.path(DATA, "obj6_obj7_merged_curated_final.rds"))
SEG_A <- strsplit("POU5F1 NANOG DNMT3B LIN28A SOX2 CYP26A1 FST FGFR1 EOMES MIXL1 MESP1 TBXT FGFR4 WNT3A WNT8A CHRD LHX1 NODAL NOTO FOXA2 FOXF1 NOG NKX1-2 NANOS3 TFAP2C RPL38 PRDM14 ANXA2 TFAP2A CER1 WNT5A HAND1 COL2A1 HAND2 GATA6 NKX2-5 MESP2 ISL1 POSTN PITX1 COL1A1 ALDH1A2 TBXT HOXA1 LEFTY2 FOXC2 TCF15 FOXC1 SOX17 GATA4 HNF4A", " ")[[1]]
SEG_B <- strsplit("PITX2 AFP TTR APOA1 APOE IHH SHH GATA3 DKK1 OTX2 PTPN13 SIX3 RUNX1 PECAM1 FLI1 TAL1 KDR CDH5 SPP1 CD36 PPBP GP1BB GP9 HBZ HBG2 GCM1 KRT7", " ")[[1]]
NEW <- c("SALL3","USP44","THY1","DPPA3","DPPA5","TFCP2L1","DNMT3L","SUSD2")
print(setdiff(c(SEG_A,SEG_B,NEW), rownames(obj))); print(length(SEG_A)+length(SEG_B))
GG <- unique(c(SEG_A,SEG_B,NEW))
k <- which(obj$curated_kept %in% TRUE)
cnt <- LayerData(obj, assay="RNA", layer="counts")[GG, k]
cp <- t(t(as.matrix(cnt)) / obj$nCount_RNA[k] * 1e4)
key <- paste(as.character(obj$`39Type`[k]), as.character(obj$stage[k]), sep="||")
idx <- split(seq_along(key), key)
M <- sapply(idx, function(ii) rowMeans(cp[, ii, drop=FALSE]))
Fd <- sapply(idx, function(ii) rowMeans(cnt[, ii, drop=FALSE] > 0))
write.csv(M, "hm/S2A_mean_cp10k_type_stage.csv"); write.csv(Fd, "hm/S2A_frac_type_stage.csv")
write.csv(data.frame(key=names(idx), n=lengths(idx)), "hm/S2A_n_type_stage.csv", row.names=FALSE)
print(dim(M))