"""Embryo-level train/validation/test splits of the Mittnenzweig et al. (2021) mouse embryos used to train and evaluate
the generative model, and the four rotations used for nested cross-validation (pattern T,V,T,L over time-sorted embryos;
embryos with >= 100 cells). Rotation 0 reproduces the earlier 68-embryo split (embryo_split_old68.csv, required input)
for the embryos it contained; the additional embryos of the 153-embryo release are interleaved with the same pattern.
Reconstructed verbatim from session 5113e657 message [3360].
Outputs: ai/mz_bench/embryo_split.csv and ai/mz_bench/rot/split_rot{0..3}.csv (relative to HGC_GEN_ROOT).
"""
import os
import numpy as np, pandas as pd
DATA = os.environ.get('HGC_DATA', 'data')          # input data root (see README)
GEN_ROOT = os.environ.get('HGC_GEN_ROOT', '.')     # generative working directory
N=GEN_ROOT.rstrip('/')+'/'   # [glue] generative working directory (ai_t05_v153 layout)
import anndata as ad
qo=ad.read_h5ad(DATA+'/UCE/inputs/Mittnenzweig153.h5ad',backed='r').obs
E=qo.groupby('embryo',observed=True).agg(t=('time','first'),n=('time','size')); E=E[E.n>=100].sort_values('t',kind='stable')
old=pd.read_csv(N+'ai/mz_bench/embryo_split_old68.csv',index_col=0)
E['old']=E.index.isin(old.index); print(len(E),E.old.sum(), (old.index.isin(E.index)).all(), (E.loc[old.index,'n']==old.n).mean(), np.allclose(E.loc[old.index,'t'],old.t))
pat=np.array(['T','V','T','L'])
oldsorted=old.sort_values('t',kind='stable'); newE=E[~E.old].sort_values('t',kind='stable')
os.makedirs(N+'ai/mz_bench/rot',exist_ok=True)
for r in range(4):
    S=E[['t','n']].copy(); S['split']=''
    S.loc[oldsorted.index,'split']=pat[(np.arange(len(oldsorted))+r)%4]
    S.loc[newE.index,'split']=pat[(np.arange(len(newE))+r)%4]
    S['new_embryo']=~E.old
    if r==0: assert (S.loc[old.index,'split']==old.split).all(); S[['t','n','split']].to_csv(N+'ai/mz_bench/embryo_split.csv')
    S.to_csv(N+f'ai/mz_bench/rot/split_rot{r}.csv')
    print(r, S.split.value_counts().to_dict(), S[S.new_embryo].split.value_counts().to_dict())
