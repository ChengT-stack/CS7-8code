# gastruloid/04_denovo_annotation/apply.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/reannotation_denovo/code/apply.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

import sys, json, numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent)); import importlib, annotations as A; importlib.reload(A)
from annotations import *
UNITS = ['Hamazaki','Budjan','Yamanaka','Makwana','Gribaudo','Olmsted','Minn','Heemskerk','Chen_polyA','Chen_probe','Liu','Pedroza','Weatherbee','Rossi','Veenvliet']
DS = {'Hamazaki':'Hamazaki 2024 (gastruloid / RA-gastruloid)','Budjan':'Budjan 2022 (somitoid)','Yamanaka':'Yamanaka 2023 (axioloid)','Makwana':'Makwana 2025 (hTLS)','Gribaudo':'Gribaudo 2023 (spinoid)',
      'Olmsted':'Olmsted & Paluh 2021 (EMLOC)','Minn':'Minn 2020 (2D gastruloid)','Heemskerk':'Heemskerk 2024 (2D gastruloid)','Chen_polyA':'Chen 2025 (2D, poly-A library)','Chen_probe':'Chen 2025 (2D to day 10, probe library)',
      'Liu':'Liu 2023 (peri-gastruloid)','Pedroza':'Pedroza 2023 (hEE)','Weatherbee':'Weatherbee 2023 (embryo model)','Rossi':'Rossi 2021 (mouse gastruloid)','Veenvliet':'Veenvliet 2020 (mouse TLS)'}
V3H = {'1 EPI/ECT(a)':{PL,NE},'2 EPI/ECT(p)':{PL,PS},'11 PGC':{PGC},'12 NNE':{SE,AM},'13 AME':{AM},'14 SE':{SE,AM},'15 PS':{PS,NM},'16 Nas.Meso/PSM':{NM,PX},'17 Para.Meso':{PX},'18 Rostral.Meso':{PX,NM,LP},
       '19 Somite':{PX},'20 Cardiac progenitor':{LP,CA},'21 Splan.Meso':{LP},'22 Cardiomyocyte':{CA,LP},'23 Caudal.Meso':{PX,NM,NMP},'24 Inter.Meso':{LP},'26 LP.Meso':{LP},'27 Somatic.Meso':{LP},'28 Gas.Mes':{NM,LP},
       '29 EXM':{LP},'30 Allantois':{LP},'31 YS.Meso':{LP},'32 Endothelial cell':{EB},'34 Erythrocyte':{EB},'35 DE':{EN},'37 Gut':{EN},'38 VE_YE':{HY},'4 Brain':{NE},'5 NMP':{NMP},'6 SC':{NE},'7 Neuron':{NE},'8 NC':{NC},'9 Node':{AX}}
V3M = {'Anterior Primitive Streak':{PS,AX,EN},'Blood progenitors 1':{EB},'Erythroid1':{EB},'Erythroid3':{EB},'Cardiomyocytes':{CA,LP},'Caudal Mesoderm':{PX,NM,NMP},'Caudal epiblast':{NMP,PS,PL},'Def. endoderm':{EN},
       'Endothelium':{EB},'Epiblast':{PL},'ExE mesoderm':{LP},'Forebrain/Midbrain/Hindbrain':{NE},'Gut':{EN},'Haematoendothelial progenitors':{EB},'Intermediate mesoderm':{LP},'Mesenchyme':{LP,PX},
       'Mixed mesoderm':{NM,PX,LP},'NMP':{NMP},'Nascent mesoderm':{NM},'Neural crest':{NC},'PGC':{PGC,PL},'Paraxial mesoderm':{PX},'Pharyngeal mesoderm':{LP,PX},'Primitive Streak':{PS},'Rostral neurectoderm':{NE},
       'Somitic mesoderm':{PX},'Spinal cord':{NE},'Surface ectoderm':{SE,AM},'Visceral endoderm':{HY,EN},'Notochord':{AX}}
c3 = pd.read_csv('bm/out3/clusters_v3.csv', index_col=0); cm = pd.read_csv('bm/out2/clusters_strict.csv', index_col=0)
ALL = []; QC = []; CLT = []
for u in UNITS:
    d = f'reanno/out/{u}'; obs = pd.read_parquet(f'{d}/cells.parquet'); run = json.load(open(f'{d}/run.json'))
    ann = A.ANN[u]; ovr = A.OVR.get(u, {})
    lab = obs['cl'].astype(int).map(lambda c: ann[c]); fc = 'c' + obs['cl'].astype(str)
    obs['label'] = [x[0] for x in lab]; obs['cls'] = [x[1] for x in lab]; obs['conf'] = [x[2] for x in lab]; obs['evidence'] = [x[3] for x in lab]; obs['cluster_id'] = fc.values
    for r2, v in ovr.items():
        m = (obs['leiden_2.0'] == str(r2)).values
        obs.loc[m, ['label','cls','conf','evidence']] = list(v); obs.loc[m, 'cluster_id'] = [f'{x}.r{r2}' for x in obs.loc[m, 'cluster_id']]
    obs['unit'] = u; obs['dataset'] = DS[u]; obs['excluded'] = obs['cls'] == XX
    # v3 reference-based call of the same cells
    key = obs['group'].astype(str) + '|c' + obs['sub'].astype(str) if 'sub' in obs else pd.Series('', index=obs.index)
    if u in ('Rossi', 'Veenvliet'):
        obs['v3_type'] = key.map(cm['typeM']).values; obs['v3_cls2'] = key.map(cm['cls']).values; mp = V3M
    else:
        obs['v3_type'] = key.map(c3['a_type']).values; obs['v3_cls2'] = key.map(c3['cls2']).values; mp = V3H
    obs['v3_compatible'] = [np.nan if pd.isna(t) else (c in mp.get(t, set())) for t, c in zip(obs['v3_type'], obs['cls'])]
    obs.to_parquet(f'{d}/cells_annotated.parquet')
    # cluster table
    for cid, o in obs.groupby('cluster_id'):
        CLT.append(dict(dataset=DS[u], unit=u, cluster=cid, n_cells=len(o), label=o.label.iloc[0], lineage_class=o.cls.iloc[0], confidence=o.conf.iloc[0], evidence=o.evidence.iloc[0],
                        groups='; '.join(f'{g} {v:.0%}' for g, v in o.group.value_counts(normalize=True).items() if v >= .1), median_umi=float(o.n_umi2.median()), median_genes=float(o.n_genes2.median()),
                        median_pct_mt=float(o.pct_mt.median()), median_doublet_score=float(o.dbl_score.median()), phase='; '.join(f'{k} {v:.0%}' for k, v in o.phase.value_counts(normalize=True).items()),
                        v3_top_type=(o.v3_type.value_counts().index[0] if o.v3_type.notna().any() else ''), v3_top_frac=(float(o.v3_type.value_counts(normalize=True).iloc[0]) if o.v3_type.notna().any() else np.nan),
                        v3_compatible_frac=float(o.v3_compatible.astype(float).mean()) if o.v3_compatible.notna().any() else np.nan))
    for g, o in obs.groupby('group'):
        lq = o.label.str.startswith('Low-quality') | (o.label == 'Fibroblast-like (low depth)'); db = o.label == 'Doublet-like'; mx = o.label == 'Mixed epithelial (unresolved)'
        QC.append(dict(dataset=DS[u], unit=u, group=g, cells_after_basic_qc=int(run['cells_in'] if len(run['libs']) == 1 else sum(v['cells'] for k, v in run['libs'].items() if k.startswith(g + '|'))),
                       scrublet_doublets_removed=int(sum(v.get('n_doublet', 0) for k, v in run['doublets'].items() if k.startswith(g + '|'))), cells_clustered=len(o),
                       low_quality_cluster_cells=int(lq.sum()), doublet_cluster_cells=int(db.sum()), unresolved_cells=int(mx.sum()), cells_annotated=int((~o.excluded).sum()),
                       frac_excluded_after_clustering=float(o.excluded.mean()), median_umi=float(o.n_umi2[~o.excluded].median()), median_genes=float(o.n_genes2[~o.excluded].median())))
    ALL.append(obs[['unit','dataset','group','rep','cluster_id','label','cls','conf','excluded','n_umi2','n_genes2','pct_mt','dbl_score','phase','umap1','umap2','v3_type','v3_cls2','v3_compatible'] + [c for c in ['author_annotation','cell_assignment2','seurat_clusters'] if c in obs]])
ALL = pd.concat(ALL); ALL.to_parquet('reanno/out/all_cells_annotated.parquet')
CLT = pd.DataFrame(CLT); CLT.to_csv('reanno/out/cluster_annotation.csv', index=False); QC = pd.DataFrame(QC); QC.to_csv('reanno/out/qc_by_group.csv', index=False)
K = ALL[~ALL.excluded]
comp_cls = pd.crosstab(K.group, K.cls, normalize='index'); comp_lab = pd.crosstab(K.group, K.label, normalize='index')
order = [g for u in UNITS for g in pd.unique(ALL.group[ALL.unit == u])]; order = list(dict.fromkeys(order))
comp_cls.loc[order].to_csv('reanno/out/composition_class_by_group.csv'); comp_lab.loc[order].to_csv('reanno/out/composition_label_by_group.csv')
pd.crosstab(K.group, K.label).loc[order].to_csv('reanno/out/counts_label_by_group.csv')
print(QC.groupby('unit')[['cells_after_basic_qc','scrublet_doublets_removed','low_quality_cluster_cells','doublet_cluster_cells','unresolved_cells','cells_annotated']].sum().assign(frac_kept=lambda d: (d.cells_annotated / d.cells_after_basic_qc).round(3)).to_string())
print(QC[['cells_after_basic_qc','scrublet_doublets_removed','low_quality_cluster_cells','doublet_cluster_cells','unresolved_cells','cells_annotated']].sum().to_dict())
cc = K[K.v3_compatible.notna()].copy(); cc['v3_compatible'] = cc.v3_compatible.astype(float)
print(cc.groupby('unit').v3_compatible.agg(['mean','size']).round(3).to_string()); print('overall', round(cc.v3_compatible.mean(), 3), len(cc))
print(cc.groupby('v3_cls2').v3_compatible.agg(['mean','size']).round(3).to_string())
