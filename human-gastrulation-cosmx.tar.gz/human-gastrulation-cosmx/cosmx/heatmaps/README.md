# cosmx/heatmaps

Supplementary Figures 2A, 2B and 3A.

Inputs, run order, Methods-to-panel table and gaps: see [../README.md](../README.md). Origin and sha256 of every file: [../PROVENANCE.md](../PROVENANCE.md).
