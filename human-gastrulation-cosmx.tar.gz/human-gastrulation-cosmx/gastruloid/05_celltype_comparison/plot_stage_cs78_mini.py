# gastruloid/05_celltype_comparison/plot_stage_cs78_mini.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/plot_stage_cs78_mini.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Compact versions (landscape + portrait) of the CosMx-anchored staging figure: Hamazaki 0-96 h (no RA), Heemskerk 42 h, Liu d11; nothing to the right of the stage call
import numpy as np, pandas as pd, matplotlib as mpl, matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Patch
from matplotlib.lines import Line2D
OUT = 'gall/out_v2/'; apply_figure_style(sizes=(7, 6, 5))
src = open(Path(__file__).resolve().parent / 'plot_assess.py').read(); exec(src[src.index('SHORT = {'):src.index('assert all(g in SL')])
LGS = pd.read_csv(OUT + 'gastruloid_stage_vs_CS7_CS8_long.csv'); R = pd.read_csv(OUT + 'gastruloid_stage_vs_CS7_CS8.csv').fillna('').set_index('unit'); INFO = pd.read_csv(OUT + 'groups.csv', index_col=0)
UNITS = ['Ham_0h', 'Ham_24h', 'Ham_48h', 'Ham_72h', 'Ham_96h', 'Hee_42', 'Liu_PG_d11']; assert all(u in R.index and u in INFO.index for u in UNITS)
EMBS = ['Human embryo CS7 (CosMx)', 'Human embryo CS8 (CosMx)']; meta = LGS.drop_duplicates('milestone_id').set_index('milestone_id')
SO = ['A', 'B', 'C', 'unused']; MSO = [m for k in SO for m in sorted(meta.index[meta.milestone_set == k])]; SETL = {'A': 'CS7 and CS8', 'B': 'CS8 only', 'C': 'neither', 'unused': 'no clear call'}
COL = {'reached': '#1F5FA8', 'present below onset frequency': '#9CC3E6', 'expected, not reached': '#D55E00', 'not testable': '#BDBDBD'}
MUT = {'not used: reached': '#C7D8EC', 'not used: partial': '#E4ECF6', 'not used: not testable': '#EDEDED'}
SCOL = {'CS7-like': '#CBC9E2', 'CS7-to-CS8 transitional': '#9E9AC8', 'CS8-like': '#6A51A3', 'beyond CS8': '#3F007D', 'not stageable': '#FFFFFF'}; SLAB = {'CS7-to-CS8 transitional': 'CS7–CS8 transitional'}
GAPS = {'B': 0.6, 'C': 0.6, 'unused': 1.2}; mp = {}; cur = 0.0; sl, sr = {}, {}
for k in SO:
    cur += GAPS.get(k, 0); sl[k] = cur
    for m in MSO:
        if meta.milestone_set[m] == k: mp[m] = cur; cur += 1
    sr[k] = cur
MT = cur; rows = [(u, 'embryo') for u in EMBS] + [(g, INFO.dataset[g]) for g in UNITS]; sp_ = {}; cur = 0.0; prev = None
for u, d in rows:
    if prev is not None and d != prev: cur += 0.45 if prev != 'embryo' else 0.8
    sp_[u] = cur; cur += 1; prev = d
ST = cur; BAR = {'CS7 set': sr['A'] + 0.3, 'CS8-only set': sr['B'] + 0.3}; DS = list(dict.fromkeys(d for u, d in rows[2:]))
vc = R.loc[UNITS].stage.value_counts(); g_ = lambda k: int(vc.get(k, 0)); vb = lambda n: 'is' if n == 1 else 'are'
T1 = f"Against the CosMx embryos: {g_('CS7-like')} sample {vb(g_('CS7-like'))} CS7-like, {g_('CS7-to-CS8 transitional')} {vb(g_('CS7-to-CS8 transitional'))} in transition,"; T2 = f"{g_('CS8-like')} {vb(g_('CS8-like'))} CS8-like and {g_('beyond CS8')} of {len(UNITS)} {vb(g_('beyond CS8'))} beyond CS8"
HS = [Patch(fc=COL['reached'], label='reached'), Patch(fc=COL['present below onset frequency'], label='present, below the onset frequency'), Patch(fc=COL['expected, not reached'], label='expected, not reached'),
      Patch(fc='white', ec='#C8C8C8', lw=0.4, label='not reached, not yet expected'), Patch(fc=COL['not testable'], label='not testable'), Patch(fc=MUT['not used: reached'], label='pale: not used for staging'),
      Line2D([0], [0], color='black', lw=1.6, label='most advanced set reached')]
def draw(LAND, name):
    P = (lambda m, s: (m, s)) if LAND else (lambda m, s: (s, m))
    if LAND:
        cw, rh = 0.178, 0.162; x0 = 1.5; hdr = 2.12; RW = 2.0; W = x0 + MT * cw + RW; H = 0.4 + hdr + ST * rh + 0.2
        fig = plt.figure(figsize=(W, H)); ax = fig.add_axes([x0 / W, 0.2 / H, MT * cw / W, ST * rh / H]); ax.set_xlim(0, MT); ax.set_ylim(ST, 0)
    else:
        cw, rh = 0.19, 0.172; x0 = 2.45; hdr = 0.95; below = 1.72; W = x0 + ST * cw + 0.5; H = 0.55 + hdr + MT * rh + below
        fig = plt.figure(figsize=(W, H)); ax = fig.add_axes([x0 / W, below / H, ST * cw / W, MT * rh / H]); ax.set_xlim(0, ST); ax.set_ylim(MT, 0)
    for u, d in rows:
        st = LGS[LGS.unit == u].set_index('milestone_id').state
        for m in MSO:
            s = st[m]
            if s in COL or s in MUT: x_, y_ = P(mp[m] + 0.05, sp_[u] + 0.05); ax.add_patch(Rectangle((x_, y_), 0.9, 0.9, fc=COL.get(s, MUT.get(s)), ec='none'))
            else: x_, y_ = P(mp[m] + 0.09, sp_[u] + 0.09); ax.add_patch(Rectangle((x_, y_), 0.82, 0.82, fc='white', ec='#C8C8C8' if not s.startswith('not used') else '#E2E2E2', lw=0.4))
        if R.most_advanced_set[u] in BAR:
            a, b = P(BAR[R.most_advanced_set[u]], sp_[u] + 0.02), P(BAR[R.most_advanced_set[u]], sp_[u] + 0.98); ax.plot([a[0], b[0]], [a[1], b[1]], color='black', lw=1.6, solid_capstyle='butt', clip_on=False)
    for u, k in zip(EMBS, BAR):
        a, b = P(BAR[k], sp_[u] + 1.0), P(BAR[k], ST); ax.plot([a[0], b[0]], [a[1], b[1]], color='#555555', lw=0.6, ls=(0, (3, 2)), zorder=0)
    mlab = [f"{m[1:]}  {meta.milestone[m]}" for m in MSO]
    for spn in ax.spines.values(): spn.set_visible(False)
    if LAND:
        ax.set_xticks([mp[m] + 0.5 for m in MSO]); ax.set_xticklabels(mlab, rotation=90); ax.xaxis.tick_top(); ax.tick_params(length=0, pad=14); mt = ax.get_xticklabels()
        for k in SO:
            ax.plot([sl[k] + 0.1, sr[k] - 0.1], [-0.18, -0.18], color='#555555' if k != 'unused' else '#AAAAAA', lw=0.6, clip_on=False); ax.text((sl[k] + sr[k]) / 2, -0.3, SETL[k], ha='center', va='bottom', fontsize=5, color='#333333' if k != 'unused' else '#888888', clip_on=False)
        ax.text(-0.4, -0.3, 'Reached in CosMx embryo', ha='right', va='bottom', fontsize=5, color='#333333', clip_on=False)
        ax.set_yticks([sp_[u] + 0.5 for u, d in rows]); ax.set_yticklabels(['CS7 (CosMx)', 'CS8 (CosMx)'] + [SL[g] for g in UNITS]); xl = -(x0 - 0.08) / cw
        ax.text(xl, (sp_[EMBS[0]] + sp_[EMBS[1]] + 1) / 2, 'Human\nembryos', ha='left', va='center', fontsize=6, clip_on=False, linespacing=1.0)
        for d in DS:
            gs = [g for g in UNITS if INFO.dataset[g] == d]; ax.text(xl, (sp_[gs[0]] + sp_[gs[-1]] + 1) / 2, SHORT[d].split(' ')[0], ha='left', va='center', fontsize=6, clip_on=False)
        xs_ = MT + 0.6
        for u, d in rows:
            c = R.stage[u]; ax.add_patch(Rectangle((xs_, sp_[u] + 0.12), 0.76, 0.76, fc=SCOL[c], ec='none', clip_on=False)); ax.text(xs_ + 1.05, sp_[u] + 0.52, SLAB.get(c, c), ha='left', va='center', fontsize=6, clip_on=False)
        ax.text(xs_, -0.5, 'Stage', ha='left', va='bottom', fontsize=6, clip_on=False)
        fig.text(0.02, 1 - 0.14 / H, T1 + ' ' + T2, fontsize=7, ha='left', va='top')
        fig.legend(handles=HS, loc='upper left', bbox_to_anchor=((x0 + xs_ * cw - 0.03) / W, 1 - 0.62 / H), frameon=False, fontsize=6, ncol=1, handlelength=1.0, handleheight=1.0, labelspacing=0.45, borderaxespad=0.0, borderpad=0.0)
    else:
        ax.set_yticks([mp[m] + 0.5 for m in MSO]); ax.set_yticklabels(mlab); ax.tick_params(length=0, pad=5); mt = ax.get_yticklabels()
        ax.set_xticks([sp_[u] + 0.5 for u, d in rows]); ax.xaxis.tick_top(); ax.set_xticklabels(['CS7 (CosMx)', 'CS8 (CosMx)'] + [f"{SHORT[INFO.dataset[g]].split(' ')[0]} {SL[g]}" for g in UNITS], rotation=90)
        xb = ST + 0.25
        for k in SO:
            ax.plot([xb, xb], [sl[k] + 0.1, sr[k] - 0.1], color='#555555' if k != 'unused' else '#AAAAAA', lw=0.6, clip_on=False); ax.text(xb + 0.2, (sl[k] + sr[k]) / 2, SETL[k], ha='left', va='center', rotation=90, fontsize=5, color='#333333' if k != 'unused' else '#888888', clip_on=False)
        ax.text(xb + 0.2, -0.35, 'Reached in CosMx embryo', ha='left', va='bottom', rotation=90, fontsize=5, color='#333333', clip_on=False)
        ys_ = MT + 0.6
        for u, d in rows:
            c = R.stage[u]; ax.add_patch(Rectangle((sp_[u] + 0.12, ys_), 0.76, 0.76, fc=SCOL[c], ec='none', clip_on=False)); ax.text(sp_[u] + 0.5, ys_ + 1.1, SLAB.get(c, c), ha='center', va='top', rotation=90, fontsize=6, clip_on=False)
        ax.text(-0.45, ys_ + 0.38, 'Stage', ha='right', va='center', fontsize=6, clip_on=False)
        fig.text(0.03, 1 - 0.12 / H, T1 + '\n' + T2, fontsize=7, ha='left', va='top', linespacing=1.2)
        fig.legend(handles=HS, loc='lower left', bbox_to_anchor=(0.03, 0.1 / H), frameon=False, fontsize=6, ncol=2, handlelength=1.0, handleheight=1.0, columnspacing=1.0, labelspacing=0.4, borderaxespad=0.0, borderpad=0.0)
    for lab_, m in zip(mt, MSO):
        if meta.milestone_set[m] == 'unused': lab_.set_color('#888888')
    for ext in ('png', 'pdf', 'svg'): fig.savefig(OUT + name + '.' + ext, dpi=300)
    fig.canvas.draw(); r = fig.canvas.get_renderer(); texts = [(t, t.get_window_extent(r)) for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
    ov = [(a.get_text()[:25], b.get_text()[:25]) for i, (a, ba) in enumerate(texts) for b, bb in texts[i + 1:] if ba.overlaps(bb)]; outb = [t.get_text()[:30] for t, bb in texts if not (bb.x0 >= 0 and bb.y0 >= 0 and bb.x1 <= fig.bbox.x1 and bb.y1 <= fig.bbox.y1)]
    print(name, round(W, 2), round(H, 2), 'overlaps', len(ov), ov[:8], 'outside', outb[:8]); return fig
figL = draw(True, 'Fig_gastruloid_stage_vs_CS7_CS8_mini_landscape'); figP = draw(False, 'Fig_gastruloid_stage_vs_CS7_CS8_mini_portrait'); print(R.loc[UNITS].stage.to_dict())
