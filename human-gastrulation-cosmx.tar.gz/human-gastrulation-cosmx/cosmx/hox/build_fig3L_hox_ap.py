# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: artifact c1790332 build_fig3L_hox_ap.py (session 824ef1ce, 2026-11-11)
# sha256 of original: b79359c5f6c37440df9026e380a15ae04a78a8c40484422fe0eb12107822b65a
# Methods paragraphs: Figure 3L/3M legends
# Produces: hox/Fig3L_HOX_AP_CS7_CS8.{png,svg,pdf,ai} (combined L+M page, artifact 06cea1b6)
# Edits/notes: figure_style imported from common/; pickle read from and figures written to HGC_OUT/hox
#     (originally the script folder); font folder -> HGC_FONTS.
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

# HOX paralogue groups along the A-P axis of the CS7 and CS8 discs (CosMx), node-aligned um coordinates.
import sys, os, pickle, numpy as np, pandas as pd, matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.colors import LinearSegmentedColormap
from scipy.stats import spearmanr
from matplotlib import font_manager as _fm
for _f in ['arial.ttf','arialbd.ttf','ariali.ttf','arialbi.ttf']: _fm.fontManager.addfont(os.path.join(FONT_DIR, "") + _f)

sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))
from figure_style import apply_figure_style
HERE = str(OUT / 'hox')
D = pickle.load(open(os.path.join(HERE, 'hox_ap_figdata.pkl'), 'rb'))
MAPS, xc, yc, xg, RES, PK, GROUPS = (D[k] for k in ['MAPS', 'xc', 'yc', 'xg', 'RES', 'PK', 'GROUPS'])
apply_figure_style(sizes=(6, 5.5, 5))
mpl.rcParams.update({'pdf.fonttype': 42, 'ps.fonttype': 42}); mpl.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial'], 'svg.fonttype': 'none', 'mathtext.fontset': 'custom', 'mathtext.rm': 'Arial', 'mathtext.it': 'Arial:italic', 'mathtext.bf': 'Arial:bold'})
F0, F1, F2, FL = 6, 5.5, 5, 8
MM = 1 / 25.4; W, H = 180.0, 132.0
GCOL = {'HOX1–2': '#e3a21a', 'HOX3–5': '#d1495b', 'HOX6–8': '#8e3b8a', 'HOX9–13': '#2e4a8b'}
C7, C8 = '#2c5fa8', '#c0333d'
fig = plt.figure(figsize=(W * MM, H * MM))
def axmm(x0, y0, w, h): return fig.add_axes([x0 / W, y0 / H, w / W, h / H])
def letter(x, y, s): fig.text(x / W, y / H, s, fontsize=FL, fontweight='bold', va='top', ha='left')
def pkrow(st, u): return PK[(PK.stage == st) & (PK.unit == u)].iloc[0]
XL, YL = (-760, 820), (-340, 280)
# ---------------- A: maps ----------------
mw = 40.5; mh = mw * (YL[1] - YL[0]) / (XL[1] - XL[0]); gx = 3.5
rows_y = {'CS7': 104.0, 'CS8': 104.0 - mh - 3.0}
for j, k in enumerate(GROUPS):
    cm = LinearSegmentedColormap.from_list(k, ['#f4f4f4', GCOL[k]])
    vmax = np.nanpercentile(MAPS[('CS8', k + '_ex')], 99)
    for st in ['CS7', 'CS8']:
        a = axmm(8 + j * (mw + gx), rows_y[st], mw, mh)
        M = np.clip(MAPS[(st, k + '_ex')], 0, None)
        a.imshow(M.T, origin='lower', extent=[XL[0], XL[1], YL[0], YL[1]], cmap=cm, vmin=0, vmax=vmax, aspect='auto', interpolation='bilinear')
        a.contour(xc, yc, MAPS[(st, 'mask')].T.astype(float), levels=[0.5], colors='0.35', linewidths=0.5)
        nx, ny = MAPS[(st, 'node')]
        a.plot(nx, ny, marker='+', ms=4, mew=0.8, c='k')
        r = pkrow(st, k)
        if r.peak_sig:
            a.plot(min(r.peak_um, XL[1] - 15), YL[1] - 25, marker='v', ms=3.2, c='k')
        a.set_xlim(*XL); a.set_ylim(*YL); a.set_xticks([]); a.set_yticks([])
        for s in a.spines.values(): s.set_visible(False)
        if st == 'CS7': a.set_title(f'{k}', fontsize=F0, color=GCOL[k], pad=2, fontweight='bold')
        if j == 0: a.text(-0.04, 0.5, st, transform=a.transAxes, rotation=90, ha='right', va='center', fontsize=F0, color=C7 if st == 'CS7' else C8, fontweight='bold')
        if j == 0 and st == 'CS8':
            a.plot([XL[0] + 30, XL[0] + 230], [YL[0] + 25] * 2, c='k', lw=0.8); a.text(XL[0] + 130, YL[0] + 40, '200 µm', ha='center', va='bottom', fontsize=F2 - 0.5)
    cax = axmm(8 + j * (mw + gx) + mw * 0.55, rows_y['CS8'] - 4.2, mw * 0.42, 1.2)
    cb = fig.colorbar(mpl.cm.ScalarMappable(norm=mpl.colors.Normalize(0, vmax), cmap=cm), cax=cax, orientation='horizontal')
    cb.set_ticks([0, round(vmax, 1)]); cb.ax.tick_params(labelsize=F2 - 0.5, length=1, pad=0.5); cb.outline.set_linewidth(0.3)
fig.text(8 / W, (rows_y['CS8'] - 9.0) / H, 'anterior ← → posterior;  + node;  ▼ peak', fontsize=F2, va='bottom', color='0.3')
fig.text(8 / W, 125.5 / H, 'Dorsal view of both discs on one plane, aligned at the node (all germ layers except visceral endoderm; group score above matched-gene null)', fontsize=F1, va='bottom')
# ---------------- B: AP profiles ----------------
by0, bh, bw_ = 12.0, 40.0, 79.0
for i, st in enumerate(['CS7', 'CS8']):
    a = axmm(14 + i * (bw_ + 4), by0, bw_, bh)
    for k in GROUPS:
        r = RES[f'{st}|{k}']; v = r['valid']
        ex = np.where(v, r['p'] - r['med'], np.nan); band = np.where(v, r['hi'] - r['med'], np.nan)
        a.fill_between(xg, -band, band, color=GCOL[k], alpha=0.10, lw=0)
        a.plot(xg, ex, c=GCOL[k], lw=1.1)
        rr = pkrow(st, k)
        if rr.peak_sig: a.plot(rr.peak_um, rr.peak_excess + 0.07, marker='v', ms=3, c=GCOL[k], clip_on=False)
    nx = MAPS[(st, 'node')][0]
    a.plot([nx, nx], [1.25, 1.31], c='0.3', lw=0.6, solid_capstyle='butt'); a.text(nx, 1.33, 'node', ha='center', va='bottom', fontsize=F2 - 0.5, color='0.35')
    a.axhline(0, c='0.6', lw=0.4)
    if st == 'CS7':
        vx = xg[RES['CS7|HOX1–2']['valid']]; a.set_xlim(vx.min(), vx.max() + 20); a.set_xticks([-300, 0, 300, 600])
    else:
        a.set_xlim(*XL); a.set_xticks([-600, -300, 0, 300, 600])
    a.set_ylim(-0.25, 1.42)
    a.tick_params(labelsize=F2, length=1.5, pad=1); a.spines[['top', 'right']].set_visible(False)
    if i: a.set_yticklabels([])
    else: a.set_ylabel('HOX group score\nabove null (log1p CP10K)', fontsize=F1, labelpad=1)
    a.text(0.02, 0.97, st, transform=a.transAxes, fontsize=F0, fontweight='bold', color=C7 if st == 'CS7' else C8, va='top')
fig.text((14 + bw_ + 2) / W, 3.0 / H, 'A–P position relative to node (µm; arc length along the disc)', ha='center', va='bottom', fontsize=F1)
H1 = [Line2D([], [], c=GCOL[k], lw=1.2, label=k + ': ' + ', '.join(g.replace('HOX', '') for g in v)) for k, v in GROUPS.items()]
fig.legend(handles=H1, loc='upper left', bbox_to_anchor=(14 / W, 61.0 / H), ncol=4, frameon=False, fontsize=F2 - 0.5, handlelength=1.4, columnspacing=1.0, labelspacing=0.25, borderaxespad=0)
fig.text(14 / W, 61.5 / H, 'Profiles along the A–P axis (shaded, 95% range of matched-gene null; ▼ peak above null)', fontsize=F1, va='bottom')
fig.canvas.draw(); rr = fig.canvas.get_renderer()
tx = [t for t in fig.findobj(mpl.text.Text) if t.get_text().strip() and t.get_visible()]
bb = [(t, t.get_window_extent(rr)) for t in tx]
ov = [(x.get_text()[:18], y.get_text()[:18]) for i, (x, bx) in enumerate(bb) for y, by in bb[i + 1:] if bx.overlaps(by)]
out = [t.get_text()[:18] for t, b in bb if not (fig.bbox.x0 - 1 <= b.x0 and b.x1 <= fig.bbox.x1 + 1 and fig.bbox.y0 - 1 <= b.y0 and b.y1 <= fig.bbox.y1 + 1)]
print('overlaps', ov, 'outside', out)
for ext in ('png', 'svg', 'pdf'): fig.savefig(os.path.join(HERE, f'Fig3L_HOX_AP_CS7_CS8.{ext}'), dpi=600 if ext == 'png' else None)
fig.savefig(os.path.join(HERE, 'Fig3L_HOX_AP_CS7_CS8.ai'), format='pdf')
