"""Fate and progression of CS7 streak cells (PS and APS; n = 1,557) at t = 0.5 (Figure 7G-H; Methods 'Analysis of the
reconstructed transition', 'Fate and progression of streak cells at t = 0.5').
kNN classifier (k = 15) trained on the latent states of annotated CS8 cells -> CS8 type call of each generated t = 0.5
state (five seeds; majority call for display); Kruskal-Wallis and one-sided Mann-Whitney tests of the t = 0.5 A-P
positions among fates; attainment of the CS8 fate class (anterior / posterior / CLE; cells whose dominant CS8 type is PS
excluded) in five CS7 A-P bins, with Fisher's exact test (most anterior vs most posterior bin), logistic trend test on the
bin index and a 2,000-resample percentile bootstrap of the difference.
Reconstructed verbatim from session 5113e657 messages [4311], [4319], [4323], [4339], [4345], [4363], [4413], [4433],
[4435], [4441], [4443], [4459], [4475], [4506] (subsets as marked). The latent positional-register analysis that shared
these cells was not used in the paper and was removed. Inputs (bridge bundle; see README): latent.npz (CosMx / Stereo-seq
94-d latent states and labels), bridge.npz (CS7 streak t0 / t0.5 AI (5 seeds) / linear / mouse-only / CS8-descendant
states, dominant destination, ps_mask), t05_table.csv (t = 0.5 positions), dataprep frames.
"""
import os
import numpy as np, pandas as pd
from scipy.stats import spearmanr
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)

# ---- [4311] (subset: generated-latent bundle; Stereo-seq frame checks removed)
z=np.load(DATA+'/bridge_bundle/latent.npz',allow_pickle=True)
Z=z['Z']; dsZ=z['ds']; labZ=z['label']; i7z=z['i7']; i8z=z['i8']

# ---- [4319] (subset)
base=DATA+'/cs7_cs8_matching/dataprep/'
C7=pd.read_csv(base+'export/CS7_cells.csv'); C8=pd.read_csv(base+'export/CS8_cells.csv')
F7=pd.read_csv(base+'frames/CS7_frames.csv'); F8=pd.read_csv(base+'frames/CS8_frames.csv')
l7=labZ[i7z]; l8=labZ[i8z]

# ---- [4323] (subset)
Z7=Z[i7z]; Z8=Z[i8z]

# ---- [4339] (subset)
rng=np.random.default_rng(0)   # NOTE: in the session this generator had been used by earlier cells before the bootstraps below, so the bootstrap CIs are not bit-identical

# ---- [4345] (subset)
t05=pd.read_csv(DATA+'/bridge_bundle/t05_table.csv')

# ---- [4363] (subset)
t2c={'Notochord':'Axial','Node':'Axial','PrP':'PrP','DE':'DE','Rostral.Meso':'Rostral','Heart.Meso':'Heart','Nas.Meso':'Nascent','Para.Meso':'Paraxial','LP.Meso':'LP','PS':'PS','CLE':'CLE'}

# ---- [4413] (subset)
bins4=[-1,0.4,0.6,0.8,9]; bl4=['<0.4','0.4–0.6','0.6–0.8','>0.8']

# ---- [4433] (subset)
bz=np.load(DATA+'/bridge_bundle/bridge.npz',allow_pickle=True)

# ---- [4435] (subset; register analysis not used)
pm=bz['ps_mask'].astype(bool); ci7=bz['cs7_idx']
apb=F7.AP_arc_frac.values[ci7][pm]
Ab,Bb,Lb=bz['A'][pm],bz['B'][pm],bz['LIN'][pm]; AIb=bz['AI'][:,pm]; F2b=bz['F2'][:,pm]
print(pm.sum(), np.abs(Ab-Z7[ci7][pm]).max())

# ---- [4441]
from sklearn.neighbors import KNeighborsClassifier
def cls3(c):
    if c in ['Rostral.Meso','Heart.Meso','Node','Notochord','PrP','DE']: return 'ant'
    if c in ['Nas.Meso','Para.Meso','LP.Meso']: return 'post'
    if c in ['CLE','PS']: return c
    return 'other'
knn=KNeighborsClassifier(15,n_jobs=16).fit(Z8,l8)
destb=bz['dest'][pm].astype(str); dcls=np.array([cls3(c) for c in destb]); keep=dcls!='PS'
apF=F7.AP_frac.values[ci7][pm]  # earlier analysis used AP_frac bins
bins5=[-9,0.45,0.6,0.7,0.8,9]; lb5=['<0.45','0.45–0.6','0.6–0.7','0.7–0.8','>0.8']
bb=pd.cut(apF,bins5,labels=lb5)
att={}
for nm,Xs in [('AI t0.5',[AIb[s] for s in range(5)]),('linear t0.5',[Lb]),('mouse-only t0.5',[F2b[s] for s in range(5)]),('CS7 (t0)',[Ab])]:
    R=np.mean([np.array([cls3(c) for c in knn.predict(X)])==dcls for X in Xs],axis=0)
    rows=[]
    for b in lb5:
        v=R[keep&(bb==b)]; bs=[v[rng.integers(0,len(v),len(v))].mean() for _ in range(1000)]
        rows.append((b,len(v),v.mean(),*np.percentile(bs,[2.5,97.5])))
    att[nm]=pd.DataFrame(rows,columns=['bin','n','reached','lo','hi']); print(nm,att[nm].reached.round(3).tolist(), 'rho',round(spearmanr(apF[keep],R[keep])[0],3))

# ---- [4443]
RA=np.mean([np.array([cls3(c) for c in knn.predict(AIb[s])])==dcls for s in range(5)],axis=0)
RL=(np.array([cls3(c) for c in knn.predict(Lb)])==dcls).astype(float)
d=(RA-RL)[keep]; a=apF[keep]
r0=spearmanr(a,d)[0]; bs=[]
for _ in range(1000):
    j=rng.integers(0,len(d),len(d)); bs.append(spearmanr(a[j],d[j])[0])
print('AI-LIN attainment vs AP rho',round(r0,3),np.round(np.percentile(bs,[2.5,97.5]),3))
for b in lb5:
    m=(bb[keep]==b); v=d[m]; bsv=[v[rng.integers(0,len(v),len(v))].mean() for _ in range(1000)]; print(b,round(v.mean(),3),np.round(np.percentile(bsv,[2.5,97.5]),3))

# ---- [4459] (subset; register-per-seed lines not used)
calls_ai=np.array([knn.predict(AIb[s]) for s in range(5)])  # 5 x n
from collections import Counter
maj=np.array([Counter(calls_ai[:,i]).most_common(1)[0][0] for i in range(calls_ai.shape[1])])
majc=np.array([t2c.get(c,'other') for c in maj])
print(pd.Series(majc).value_counts().to_dict())
tAPb=t05.set_index('cs7_idx').reindex(ci7[pm])[['AP','LR']].values
dfH=pd.DataFrame({'AP':tAPb[:,0],'LR':tAPb[:,1],'cls':majc,'apF':apF})
dfH['bin']=pd.cut(dfH.AP,[-1,0.4,0.6,0.8,9],labels=bl4)
t=pd.crosstab(dfH.bin,dfH.cls); print((t.div(t.sum(1),axis=0)*100).round(0))

# ---- [4475]
from scipy.stats import kruskal, mannwhitneyu, chi2_contingency
APs=dfH.AP.values
oc6=['DE','PrP','Rostral','Nascent','Paraxial','LP']
seed_stats=[]
for s in range(5):
    cc=np.array([t2c.get(c,'other') for c in calls_ai[s]])
    m=np.isin(cc,oc6)
    grp=[APs[m&(cc==c)] for c in oc6]
    kw=kruskal(*[g for g in grp if len(g)>2])
    b=pd.cut(APs[m],[-1,0.4,0.6,0.8,9],labels=bl4); tab=pd.crosstab(b,cc[m]); chi=chi2_contingency(tab)
    n=tab.values.sum(); V=np.sqrt(chi[0]/(n*(min(tab.shape)-1)))
    pr={}
    for a_,b_ in [('PrP','Rostral'),('Rostral','Paraxial'),('Paraxial','LP'),('Rostral','LP')]:
        ga,gb=APs[m&(cc==a_)],APs[m&(cc==b_)]
        pr[f'{a_}<{b_}']=(ga.mean(),gb.mean(),mannwhitneyu(ga,gb,alternative='less').pvalue,len(ga),len(gb))
    seed_stats.append((s,kw.pvalue,chi[1],V,{c:(round(APs[m&(cc==c)].mean(),3),int((m&(cc==c)).sum())) for c in oc6},pr))
    print(s,'KW p',f'{kw.pvalue:.1e}','chi2 p',f'{chi[1]:.1e}','V',round(V,3))
    print('  means',seed_stats[-1][4]); print('  pairs',{k:(round(v[0],2),round(v[1],2),f'{v[2]:.1e}') for k,v in pr.items()})

# ---- [4506]
import statsmodels.api as smapi
from scipy.stats import fisher_exact
seed_att=[]
for s in range(5):
    Rs=(np.array([cls3(c) for c in calls_ai[s]])==dcls)[keep].astype(int); a=apF[keep]; bk=np.asarray(bb)[keep]
    X=smapi.add_constant(a); lr=smapi.Logit(Rs,X).fit(disp=0)
    OR=np.exp(lr.params[1]*0.1); p_lr=lr.pvalues[1]
    # Cochran-Armitage via logistic on bin index
    bi=pd.Categorical(bk,categories=lb5).codes; lr2=smapi.Logit(Rs,smapi.add_constant(bi.astype(float))).fit(disp=0)
    f=Rs[bi==0]; l=Rs[bi==4]; tab=[[f.sum(),len(f)-f.sum()],[l.sum(),len(l)-l.sum()]]
    seed_att.append(dict(seed=s,frac_ant=f.mean(),frac_post=l.mean(),diff=f.mean()-l.mean(),fisher_p=fisher_exact(tab)[1],OR_per_0p1AP=OR,logit_p=p_lr,trend_p=lr2.pvalues[1],spearman=spearmanr(a,Rs)[0]))
SA=pd.DataFrame(seed_att); print(SA.round(4).to_string())
# pooled over seeds per source cell: mean reached; bootstrap diff
d_ant=RA[keep][np.asarray(bb)[keep]=='<0.45']; d_post=RA[keep][np.asarray(bb)[keep]=='>0.8']
bs=[d_ant[rng.integers(0,len(d_ant),len(d_ant))].mean()-d_post[rng.integers(0,len(d_post),len(d_post))].mean() for _ in range(2000)]
print('diff',round(d_ant.mean()-d_post.mean(),3),np.round(np.percentile(bs,[2.5,97.5]),3), len(d_ant),len(d_post))
r_=spearmanr(apF[keep],RA[keep]); print('spearman pooled',r_)

# ---- output tables
# [glue] save the per-seed statistics and attainment tables printed above
os.makedirs('analysis_out', exist_ok=True)
SA.to_csv('analysis_out/streak_attainment_per_seed.csv', index=False)
pd.concat({k: v for k, v in att.items()}, names=['state']).to_csv('analysis_out/streak_attainment_by_AP_bin.csv')
pd.DataFrame([dict(seed=s, KW_p=kw, chi2_p=c, cramers_V=V, **{f'MW_p_{k}': v[2] for k, v in pr.items()}) for s, kw, c, V, _, pr in seed_stats]).to_csv('analysis_out/streak_fate_AP_order_per_seed.csv', index=False)
dfH.to_csv('analysis_out/streak_t05_majority_calls.csv', index=False)
