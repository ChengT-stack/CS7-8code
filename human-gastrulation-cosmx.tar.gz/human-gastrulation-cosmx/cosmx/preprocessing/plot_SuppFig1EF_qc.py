# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: execution log, session 824ef1ce python kernel cells 116 (load/style lines only) + 118 (producing cell
#     of SuppFig1EF_QC.pdf, artifact 600de10e)
# sha256 of original: 94d8267d6a12d05adcbfcd50720ead5fefb6a63bda76af1232f64f41db2be6df
# Methods paragraphs: P343
# Produces: Supplementary Figure 1E-F (SuppFig1EF_QC.pdf/svg/png; 1x4 histogram layout)
# Edits/notes: reconstructed from kernel log; apply_figure_style() try-block of cell 116 replaced by its own
#     fallback rcParams line. A later page-composite (SuppFig1E_QC_CS7.pdf, session 5113e657) is raster
#     compositing and not included.
import os, sys
from pathlib import Path
# Paths: raw inputs under HGC_DATA, all outputs/intermediates under HGC_OUT (see cosmx/README.md).
SCRIPT_DIR = Path(__file__).resolve().parent if '__file__' in globals() else Path(os.environ.get('HGC_SCRIPT_DIR', '.')).resolve()
DATA = Path(os.environ.get('HGC_DATA', 'data')).resolve(); os.environ['HGC_DATA'] = str(DATA)
OUT = Path(os.environ.get('HGC_OUT', 'results')).resolve(); os.environ['HGC_OUT'] = str(OUT)
if os.environ.get('HGC_IN_OUT') != '1':          # first entry: work inside OUT (relative paths below are inside OUT)
    OUT.mkdir(parents=True, exist_ok=True); os.chdir(OUT); os.environ['HGC_IN_OUT'] = '1'
sys.path.insert(0, str(SCRIPT_DIR.parent / 'common'))   # figure_style.py, pathway_gene_sets.py
FONT_DIR = os.environ.get('HGC_FONTS', '')              # optional folder with arial*.ttf
try:  # tolerate missing font files (original runs used a local Arial folder)
    import matplotlib.font_manager as _fmgr
    _addfont0 = _fmgr.fontManager.addfont
    _fmgr.fontManager.addfont = lambda p, _o=_addfont0: _o(p) if os.path.exists(p) else None
except Exception:
    pass

import pandas as pd, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size":8, "pdf.fonttype":42, "svg.fonttype":"none"})
plt.rcParams["pdf.fonttype"]=42
qc = pd.read_csv("qc_per_cell.csv", index_col=0)

import matplotlib.ticker as mt
fig2, axs = plt.subplots(1, 4, figsize=(9.2, 2.3))
spec = [("CS7","nCount_RNA","Transcripts per cell","#3D7DD8","#D62728",4000),
        ("CS7","nFeature_RNA","Genes detected per cell","#F4876B","#1F3A93",4000),
        ("CS8","nCount_RNA","Transcripts per cell","#3D7DD8","#D62728",4000),
        ("CS8","nFeature_RNA","Genes detected per cell","#F4876B","#1F3A93",2500)]
for ax,(st,var,title,fc,lc,xmax) in zip(axs, spec):
    v = qc.loc[qc.stage==st, var].values; med = np.median(v)
    ax.hist(v[v<=xmax], bins=np.arange(0, xmax+40, 40), color=fc, linewidth=0)
    ax.axvline(med, color=lc, lw=1.2, ls=(0,(4,3)))
    ax.set_title(title, fontsize=7.5, pad=12)
    ax.text(0.5, 1.01, f"Median = {med:,.0f}", transform=ax.transAxes, ha="center", va="bottom", color=lc, fontsize=7)
    ax.set_xlabel(var, fontsize=7); ax.set_xlim(0, xmax)
    ax.yaxis.set_major_formatter(mt.FuncFormatter(lambda x,_: f"{x:,.0f}")); ax.xaxis.set_major_formatter(mt.FuncFormatter(lambda x,_: f"{x:,.0f}"))
    ax.grid(axis="y", color="#DDDDDD", lw=0.6); ax.set_axisbelow(True)
    for s in ["top","right"]: ax.spines[s].set_visible(False)
    ax.tick_params(labelsize=6.5)
axs[0].set_ylabel("Number of cells", fontsize=7); axs[2].set_ylabel("Number of cells", fontsize=7)
fig2.text(0.005, 0.95, "E", fontweight="bold", fontsize=11); fig2.text(0.5, 0.95, "F", fontweight="bold", fontsize=11)
fig2.text(0.26, 0.005, "CS7 embryo (n = 84,310 cells)", ha="center", fontsize=7); fig2.text(0.76, 0.005, "CS8 embryo (n = 86,704 cells)", ha="center", fontsize=7)
fig2.tight_layout(rect=(0.01,0.04,1,0.95), w_pad=1.2)
n_clip = {(st,var): int((qc.loc[qc.stage==st,var]>xm).sum()) for st,var,_,_,_,xm in spec}
for ext in ["pdf","svg","png"]: fig2.savefig(f"SuppFig1EF_QC.{ext}", dpi=300)
print(n_clip)