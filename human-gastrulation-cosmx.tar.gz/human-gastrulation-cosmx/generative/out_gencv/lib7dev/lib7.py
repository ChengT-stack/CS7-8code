import numpy as np, torch, torch.nn as nn, pickle, sys
sys.path.insert(0,'ai'); import step5_lib as L
import os; dev=os.environ.get('DEV','cuda')
R=np.load('ai/step7/rep.npz',allow_pickle=True); Z=R['Z']; grp=R['grp'].astype(str); mt=R['mt']; emb=R['emb'].astype(str); etime=R['etime']; valid=R['valid']
PK=pickle.load(open('ai/step7/pairs.pkl','rb')); C=PK['C']; TR=PK['TR']; HUM=PK['hum']; GB=list(PK['GB'])
Zt=torch.tensor(Z,device=dev)
PAIRS=['emd_cen','emd_top','emd_sample','ent_cen','ent_sample']
def tt(x): return torch.as_tensor(x,device=dev,dtype=torch.float32)
# ---------------- Pijuan stage triplets usable as extra supervision (D = 0.5 d)
PJ=[]
for (a,m,b) in L.triplets((),(0.5,)):
    k=f'm_{a}_{b}'
    PJ.append(dict(ta=a,tm=m,tb=b,ia=C[k+'_a'],im=np.where((mt==m)&valid)[0],dom=C[k+'_dom'],emd_cen=C[k+'_cen'],ent_cen=C[k+'_ent_cen'],emd_top=C[k+'_topZ'],emd_sample=C[k+'_emd_sample'],ent_sample=C[k+'_ent_sample']))
def lin_of(t,pair): return 0.5*(Zt[torch.as_tensor(t['ia'],device=dev)]+tt(t[pair]))
# ---------------- families
class Net(nn.Module):
    def __init__(s,d,h,Ly,drop,sig_init):
        super().__init__(); s.f=L.mlp(2*d+2,2*d,h,Ly,drop); nn.init.zeros_(s.f[-1].weight); nn.init.zeros_(s.f[-1].bias)
        with torch.no_grad(): s.f[-1].bias[d:]=sig_init
        s.d=d
    def forward(s,lin,dlt,D,ta):
        o=s.f(torch.cat([lin,dlt,D[:,None],ta[:,None]-7.5],1)); return o[:,:s.d], o[:,s.d:].clamp(-6,2)
def fit(cfg,seed=0):
    torch.manual_seed(seed); rng=np.random.default_rng(seed); fam=cfg['family']; pair=cfg['pair']; d=Z.shape[1]
    train=TR['train']+(PJ if cfg.get('use_pijuan',0) else [])
    if fam=='calib':
        dr={g:[] for g in GB}; vr={g:[] for g in GB}; allr=[]; allv=[]
        for t in train:
            lin=lin_of(t,pair).cpu().numpy(); dom=t['dom']; Ym=Z[t['im']]; gm=grp[t['im']]
            for g in GB:
                s1=dom==g; s2=gm==g
                if s1.sum()<10 or s2.sum()<10: continue
                dlt=Ym[s2].mean(0)-lin[s1].mean(0); dv=Ym[s2].var(0)-lin[s1].var(0)
                if cfg['dscale']: dlt=dlt/((t['tb']-t['ta'])/0.375)
                dr[g].append(dlt); vr[g].append(dv); allr.append(dlt); allv.append(dv)
        gd=np.mean(allr,0); gv=np.clip(np.mean(allv,0),cfg['vfloor'],None)
        M={}
        for g in GB:
            n=len(dr[g])
            if cfg['group_specific'] and n>0:
                w=n/(n+cfg['shrink']); M[g]=(w*np.mean(dr[g],0)+(1-w)*gd, np.clip(w*np.mean(vr[g],0)+(1-w)*gv,cfg['vfloor'],None))
            else: M[g]=(gd,gv)
        if cfg['iso']: M={g:(m,np.full_like(v,v.mean())) for g,(m,v) in M.items()}
        return ('calib',{g:(tt(m),tt(np.sqrt(v))) for g,(m,v) in M.items()})
    if fam=='net':
        net=Net(d,cfg['h'],cfg['L'],cfg['drop'],cfg['sig_init']).to(dev); opt=torch.optim.AdamW(net.parameters(),lr=cfg['lr'],weight_decay=cfg['wd'])
        sch=torch.optim.lr_scheduler.OneCycleLR(opt,max_lr=cfg['lr'],total_steps=cfg['steps'],pct_start=0.1)
        P=[(torch.as_tensor(t['ia'],device=dev),tt(t[pair if pair in t else 'emd_cen']),torch.as_tensor(t['im'],device=dev),t['tb']-t['ta'],t['ta'],lin_of(t,pair if pair in t else 'emd_cen').mean(0)) for t in train]
        inv=cfg.get('inv',0)
        for it in range(cfg['steps']):
            ia,bp,im,D,ta,cen=P[rng.integers(len(P))]; j=torch.randint(len(ia),(cfg['bs'],),device=dev)
            A=Zt[ia[j]]; Bp=bp[j]; lin=0.5*(A+Bp); n=len(A)
            mu,ls=net(lin-cen if inv>=1 else lin,Bp-A,torch.full((n,),D,device=dev),torch.full((n,),ta,device=dev))
            if inv==2: mu=mu-mu.mean(0,keepdim=True)
            gen=lin+mu+torch.exp(ls)*torch.randn_like(lin); Y=Zt[im[torch.randint(len(im),(cfg['bs'],),device=dev)]]
            loss=L.energy(gen,Y)+cfg['lam']*(mu**2).mean()
            opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(net.parameters(),1.0); opt.step(); sch.step()
        net.eval(); return ('net',net)
    if fam=='flow':
        fc=dict(family='flow',h=cfg['h'],L=cfg['L'],drop=0.01,lr=cfg['lr'],wd=cfg['wd'],steps=cfg['steps'],bs=256,bmode='cen',sigma=cfg['sigma'],K=cfg['K'],mode='fwd')
        model=_train_flow(fc,seed)
        return ('flow',(model,fc))
def _train_flow(fc,seed):
    torch.manual_seed(seed); rng=np.random.default_rng(seed); m=L.Flow(Z.shape[1],fc['h'],fc['L'],fc['drop']).to(dev)
    opt=torch.optim.AdamW(m.parameters(),lr=fc['lr'],weight_decay=fc['wd']); sch=torch.optim.lr_scheduler.OneCycleLR(opt,max_lr=fc['lr'],total_steps=fc['steps'],pct_start=0.1)
    P=[]
    for a,b in zip(L.STG[:-1],L.STG[1:]):
        k=f'm_{a}_{b}'; P.append((torch.as_tensor(C[k+'_a'],device=dev),tt(C[k+'_topZ']),a,b))
    for it in range(fc['steps']):
        ia,bz,ta,tb=P[rng.integers(len(P))]; j=torch.randint(len(ia),(fc['bs'],),device=dev); x0=Zt[ia[j]]; x1=bz[j]; u=torch.rand(fc['bs'],device=dev)
        xt=(1-u)[:,None]*x0+u[:,None]*x1+fc['sigma']*torch.sqrt(u*(1-u))[:,None]*torch.randn_like(x0)
        loss=((m(xt,ta+u*(tb-ta))-(x1-x0)/(tb-ta))**2).mean(); opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(m.parameters(),1.0); opt.step(); sch.step()
    m.eval(); return m
@torch.no_grad()
def generate(M,cfg,t,seed=0,ia=None,bp=None,dom=None):
    """t: triplet dict (or human dict + D/ta keys)."""
    torch.manual_seed(seed); pair=cfg['pair']
    A=Zt[torch.as_tensor(t['ia'],device=dev)]; Bp=tt(t[pair]); lin=0.5*(A+Bp); D=t['tb']-t['ta']; ta=t['ta']; n=len(A); kind,obj=M
    if kind=='linear': return lin
    if kind=='linear_noise': return lin+cfg['sigma0']*torch.randn_like(lin)
    if kind=='calib':
        dom=t['dom']; mu=torch.zeros_like(lin); sd=torch.zeros_like(lin)
        for g,(m,s) in obj.items():
            sel=torch.as_tensor(dom==g,device=dev)
            if sel.any(): mu[sel]=m*(D/0.375 if cfg['dscale'] else 1.0); sd[sel]=s
        return lin+cfg['ds']*mu+cfg['ns']*sd*torch.randn_like(lin)
    if kind=='net':
        inv=cfg.get('inv',0); mu,ls=obj(lin-lin.mean(0,keepdim=True) if inv>=1 else lin,Bp-A,torch.full((n,),D,device=dev),torch.full((n,),ta,device=dev))
        if inv==2: mu=mu-mu.mean(0,keepdim=True)
        return lin+cfg['ds']*mu+cfg['ns']*torch.exp(ls)*torch.randn_like(lin)
    if kind=='flow':
        m,fc=obj; K=fc['K']; f=m.integrate(A.clone(),torch.full((n,),ta,device=dev),torch.full((n,),ta+D/2,device=dev),K)
        return lin+cfg['ds']*(f-lin)+cfg['ns']*0.3*torch.randn_like(lin)
