import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import numpy as np, pandas as pd, scipy.io
B=DATA + '/cs7_cs8_matching/'
lib=[np.asarray(scipy.io.mmread(B+f'dataprep/export/{s}_counts.mtx').tocsr().sum(0)).ravel() for s in ['CS7','CS8']]  # genes x cells -> sum over genes
lib7,lib8=lib; print(len(lib7),len(lib8))
t05=pd.read_csv('ai/step5_human_t05_index.csv')
anc=pd.read_csv(B+'figure/final_ggot/ggot_table_cs8_ancestor.csv'); anc=anc[anc.cls!='unmatched']; desc=anc.groupby('ancestor_idx').cs8_idx.apply(np.array).reindex(t05.cs7_idx.values)
lib05=np.array([np.sqrt(lib7[i]*lib8[d].mean()) for i,d in zip(t05.cs7_idx.values,desc.values)]); np.save('out_domain/cache_lib05.npy',lib05)
import anndata as ad; T=ad.read_h5ad('ai/step7/final_v2/t05_AI_generated_counts.h5ad',backed='r'); print('max abs diff vs stored library',np.abs(T.obs.library.values-lib05).max())
