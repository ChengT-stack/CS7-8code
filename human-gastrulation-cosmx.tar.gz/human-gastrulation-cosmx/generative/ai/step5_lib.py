# Generator families for t=0.5 states between two developmental endpoints, and the evaluation protocol.
import numpy as np, torch, torch.nn as nn
dev='cuda'
STG=[6.5,6.75,7.0,7.25,7.5,7.75,8.0,8.25,8.5]
_C={}
def cache(rep):
    if rep not in _C: _C[rep]=dict(np.load(f'ai/step5_cache_{rep}.npz',allow_pickle=True))
    return _C[rep]
def stage_idx(C,mt,s): return np.where((mt==s)&C['valid'])[0]
def triplets(held=(),spacing=(0.5,1.0)):
    T=[]
    for i,a in enumerate(STG):
        for b in STG[i+1:]:
            d=round(b-a,2)
            if d not in spacing: continue
            m=round((a+b)/2,3)
            if m not in STG: continue
            if any(x in held for x in (a,m,b)): continue
            T.append((a,m,b))
    return T
def energy(X,Y,cap=1500,gen=None):
    if len(X)>cap: X=X[torch.randperm(len(X),device=X.device,generator=gen)[:cap]]
    if len(Y)>cap: Y=Y[torch.randperm(len(Y),device=Y.device,generator=gen)[:cap]]
    return 2*torch.cdist(X,Y).mean()-torch.cdist(X,X).mean()-torch.cdist(Y,Y).mean()
def mlp(i,o,h,L,drop,act=nn.SiLU):
    layers=[]; d=i
    for _ in range(L): layers+=[nn.Linear(d,h),act(),nn.Dropout(drop)]; d=h
    layers+=[nn.Linear(d,o)]; return nn.Sequential(*layers)
class Corrector(nn.Module):
    """mid = (a+b)/2 + s * delta([a,b,b-a,Δ,(t_a)], eps)"""
    def __init__(s,d,h,L,drop,noise,abs_t):
        super().__init__(); s.noise=noise; s.abs_t=abs_t; s.net=mlp(3*d+1+abs_t+noise,d,h,L,drop)
        nn.init.zeros_(s.net[-1].weight); nn.init.zeros_(s.net[-1].bias)
    def forward(s,a,b,D,ta):
        f=[a,b,b-a,D[:,None]]+([ta[:,None]-7.5] if s.abs_t else [])+([torch.randn(len(a),s.noise,device=a.device)] if s.noise else [])
        d=s.net(torch.cat(f,1)); return 0.5*(a+b)+d, d
class Flow(nn.Module):
    def __init__(s,d,h,L,drop):
        super().__init__(); s.net=mlp(d+16,d,h,L,drop); s.register_buffer('fr',torch.arange(8,dtype=torch.float32)+1)
    def forward(s,x,t):
        tt=(t[:,None]-7.5)*s.fr[None]; return s.net(torch.cat([x,torch.sin(tt),torch.cos(tt)],1))
    def integrate(s,x,t0,t1,K):
        h=(t1-t0)/K
        for k in range(K): x=x+h[:,None]*s(x,t0+k*h)
        return x
def build_pairs(C,mt,held,spacing,shuffle=False,rng=None,bmode='cen'):
    """training triplets: endpoints a (cells), b-centroid, real mid cells"""
    out=[]
    T=triplets(held,spacing)
    mids=[stage_idx(C,mt,m) for (_,m,_) in T]
    if shuffle:  # time-shuffled control: each triplet gets the mid set of a random other stage (not its own)
        allm=[s for s in STG if s not in held]
        mids=[stage_idx(C,mt,rng.choice([s for s in allm if s!=m])) for (_,m,_) in T]
    for (a,m,b),mi in zip(T,mids):
        k=f'm_{a}_{b}'; out.append(dict(a=C[k+'_a'],cen=C[k+'_cen'] if bmode=='cen' else C['Z'][C[k+'_top']],mid=mi,D=b-a,ta=a))
    return out
def train(cfg,C,mt,held,seed=0,shuffle=False,log=None):
    torch.manual_seed(seed); rng=np.random.default_rng(seed)
    Z=torch.tensor(C['Z'],device=dev); d=Z.shape[1]
    fam=cfg['family']; wd=cfg['wd']; steps=cfg['steps']; bs=cfg['bs']
    if fam=='flow':
        model=Flow(d,cfg['h'],cfg['L'],cfg['drop']).to(dev)
        # consecutive available stages (gap allowed where a stage is held out)
        avail=[s for s in STG if s not in held]
        if shuffle: perm=list(rng.permutation(avail)); tmap=dict(zip(avail,perm))
        P=[]
        for a,b in zip(avail[:-1],avail[1:]):
            k=f'm_{a}_{b}'
            if k+'_a' not in C: continue
            ta,tb=(tmap[a],tmap[b]) if shuffle else (a,b)
            if ta==tb: continue
            P.append((torch.tensor(C[k+'_a'],device=dev),torch.tensor(C[k+'_top'],device=dev),ta,tb))
    else:
        model=Corrector(d,cfg['h'],cfg['L'],cfg['drop'],cfg.get('noise',0),cfg.get('abs_t',0)).to(dev)
        P=build_pairs(C,mt,held,cfg['spacing'],shuffle,rng,cfg.get('bmode','cen'))
        P=[dict(a=torch.tensor(p['a'],device=dev),cen=torch.tensor(p['cen'],device=dev),mid=torch.tensor(p['mid'],device=dev),D=p['D'],ta=p['ta']) for p in P]
    opt=torch.optim.AdamW(model.parameters(),lr=cfg['lr'],weight_decay=wd)
    sch=torch.optim.lr_scheduler.OneCycleLR(opt,max_lr=cfg['lr'],total_steps=steps,pct_start=0.1)
    model.train()
    for it in range(steps):
        if fam=='flow':
            ia,ib,ta,tb=P[rng.integers(len(P))]; j=torch.randint(len(ia),(bs,),device=dev)
            x0,x1=Z[ia[j]],Z[ib[j]]; u=torch.rand(bs,device=dev)
            xt=(1-u)[:,None]*x0+u[:,None]*x1+cfg['sigma']*torch.sqrt(u*(1-u))[:,None]*torch.randn_like(x0)
            t=ta+u*(tb-ta); loss=((model(xt,t)-(x1-x0)/(tb-ta))**2).mean()
        else:
            p=P[rng.integers(len(P))]; j=torch.randint(len(p['a']),(bs,),device=dev)
            a=Z[p['a'][j]]; b=p['cen'][j]; n=len(a)
            gen,dl=model(a,b,torch.full((n,),p['D'],device=dev),torch.full((n,),p['ta'],device=dev))
            mid=Z[p['mid'][torch.randint(len(p['mid']),(bs,),device=dev)]]
            loss=energy(gen,mid)+cfg['lam']*(dl**2).mean()
        opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step(); sch.step()
    model.eval(); return model
@torch.no_grad()
def generate(model,cfg,a,b,D,ta,K=None):
    g=_generate(model,cfg,a,b,D,ta,K)
    if model is not None and 'alpha' in cfg: lin=0.5*(a+b); g=lin+cfg['alpha']*(g-lin)
    return g
@torch.no_grad()
def _generate(model,cfg,a,b,D,ta,K=None):
    if model is None: return 0.5*(a+b)
    n=len(a)
    if cfg['family']=='flow':
        K=K or cfg['K']; t0=torch.full((n,),ta,device=a.device); tm=t0+D/2; t1=t0+D
        f=model.integrate(a.clone(),t0,tm,K)
        if cfg['mode']=='fwd': return f
        bk=model.integrate(b.clone(),t1,tm,K); w=cfg.get('wf',0.5); return w*f+(1-w)*bk
    return model(a,b,torch.full((n,),D,device=a.device),torch.full((n,),ta,device=a.device))[0]
@torch.no_grad()
def evaluate(model,cfg,C,mt,grp,trips,seed=123,min_n=50):
    """returns list of (triplet, group, ED_model, ED_linear); group 'ALL' = whole stage"""
    g=torch.Generator(device=dev); g.manual_seed(seed)
    Z=torch.tensor(C['Z'],device=dev); res=[]
    for (a,m,b) in trips:
        k=f'm_{a}_{b}'; ia=torch.tensor(C[k+'_a'],device=dev); cen=torch.tensor(C[k+'_cen'] if cfg.get('bmode','cen')=='cen' else C['Z'][C[k+'_top']],device=dev); dom=C[k+'_dom']
        mi=stage_idx(C,mt,m); A=Z[ia]
        gm=generate(model,cfg,A,cen,b-a,a); gl=0.5*(A+cen)
        for G in ['ALL']+sorted(set(dom)):
            sel=np.ones(len(dom),bool) if G=='ALL' else (dom==G); ms=mi if G=='ALL' else mi[grp[mi]==G]
            if sel.sum()<min_n or len(ms)<min_n: continue
            Y=Z[torch.tensor(ms,device=dev)]; s=torch.tensor(np.where(sel)[0],device=dev)
            torch.manual_seed(seed); em=float(energy(gm[s],Y,gen=g)); g.manual_seed(seed); el=float(energy(gl[s],Y,gen=g))
            res.append(((a,m,b),G,em,el))
    return res
def score(res): return float(np.mean([np.log(max(em,1e-6)/max(el,1e-6)) for _,_,em,el in res]))

@torch.no_grad()
def eval_noise(C,cfg,mt,grp,trips,sig,seed=123,min_n=50):
    """linear midpoint + isotropic Gaussian noise (non-learned, variance-restoring baseline); same item order as evaluate()"""
    Z=torch.tensor(C['Z'],device=dev); res=[]; g=torch.Generator(device=dev)
    for (a,m,b) in trips:
        k=f'm_{a}_{b}'; A=Z[torch.tensor(C[k+'_a'],device=dev)]; Bc=torch.tensor(C[k+'_cen'] if cfg.get('bmode','cen')=='cen' else C['Z'][C[k+'_top']],device=dev)
        gl=0.5*(A+Bc); torch.manual_seed(0); gm=gl+sig*torch.randn_like(gl); dom=C[k+'_dom']; mi=stage_idx(C,mt,m)
        for G in ['ALL']+sorted(set(dom)):
            sel=np.ones(len(dom),bool) if G=='ALL' else dom==G; ms=mi if G=='ALL' else mi[grp[mi]==G]
            if sel.sum()<min_n or len(ms)<min_n: continue
            Y=Z[torch.tensor(ms,device=dev)]; s=torch.tensor(np.where(sel)[0],device=dev)
            g.manual_seed(seed); em=float(energy(gm[s],Y,gen=g)); g.manual_seed(seed); el=float(energy(gl[s],Y,gen=g)); res.append(((a,m,b),G,em,el))
    return res
SIGS=[0.0,0.05,0.1,0.2,0.3,0.5,0.75,1.0]
_BL={}
def baseline(C,rep,cfg,mt,grp,folds):
    """per (rep, endpoint mode): noise level minimising the tuning score; returns {(trip,G): ED_baseline} for each fold"""
    key=(rep,cfg.get('bmode','cen'))
    if key not in _BL:
        best=None
        for sg in SIGS:
            R=[eval_noise(C,cfg,mt,grp,tr,sg) for _,tr in folds]; sc=np.mean([score(r) for r in R])
            if best is None or sc<best[0]: best=(sc,sg,[{(t,G):em for t,G,em,el in r} for r in R])
        _BL[key]=best
    return _BL[key]
def score_vs(res,bl): return float(np.mean([np.log(max(em,1e-6)/max(bl[(t,G)],1e-6)) for t,G,em,el in res]))

@torch.no_grad()
def eval_monkey(model,cfg,C,ds,grp,which,noise=None,seed=123,min_n=40):
    """mouse-trained generator applied to monkey CS8 cells + their CS11 OT partners; target = real CS9 cells of embryo(s) `which`"""
    Z=torch.tensor(C['Z'],device=dev); A=Z[torch.tensor(C['k_a'],device=dev)]
    Bm=torch.tensor(C['k_cen'] if cfg.get('bmode','cen')=='cen' else C['Z'][C['k_top']],device=dev)
    gl=0.5*(A+Bm)
    if noise is None: torch.manual_seed(0); gm=generate(model,cfg,A,Bm,0.5,7.375)
    else: torch.manual_seed(0); gm=gl+noise*torch.randn_like(gl)
    mi=C['k_mid']; mi=mi[np.isin(ds[mi],which)]; dom=C['k_dom']; res=[]; g=torch.Generator(device=dev)
    for G in ['ALL']+sorted(set(dom)):
        sel=np.ones(len(dom),bool) if G=='ALL' else dom==G; ms=mi if G=='ALL' else mi[grp[mi]==G]
        if sel.sum()<min_n or len(ms)<min_n: continue
        Y=Z[torch.tensor(ms,device=dev)]; s=torch.tensor(np.where(sel)[0],device=dev)
        g.manual_seed(seed); em=float(energy(gm[s],Y,gen=g)); g.manual_seed(seed); el=float(energy(gl[s],Y,gen=g)); res.append((('mk',),G,em,el))
    return res
_BLM={}
def baseline_monkey(C,rep,cfg,ds,grp,which):
    key=(rep,cfg.get('bmode','cen'),tuple(which))
    if key not in _BLM:
        best=None
        for sg in SIGS:
            r=eval_monkey(None,cfg,C,ds,grp,which,noise=sg); sc=score(r)
            if best is None or sc<best[0]: best=(sc,sg,{(t,G):em for t,G,em,el in r})
        _BLM[key]=best
    return _BLM[key]
