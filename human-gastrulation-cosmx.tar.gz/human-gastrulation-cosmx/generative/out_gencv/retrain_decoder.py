# Retrain the NB-MLP decoder (ai/step5_decoder.py, unchanged architecture/loss/training loop) on the NEW 153-embryo Z.
# Hyper-parameters = the ones selected for the final_v2 decoder (decoder.log, study dec_concat_harm_mz_final, trial 15); no re-search.
# Training: fit(p, seed=0), MAXEP=200 (script default), patience 15, 10% val split rng(0). Human rows of Z changed (max |dZ| 0.40) -> retrain required.
import os
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
import sys, os, numpy as np, pandas as pd, scipy.sparse as sp, torch
OG = 'out_gencv/decoder/'; os.makedirs(OG, exist_ok=True)
R = np.load('ai/step7/rep.npz', allow_pickle=True); np.savez(OG + 'step5_cache_concat_harm_mz.npz', Z=R['Z'])
src = open('ai/step5_decoder.py').read().split("if __name__=='__main__':")[0]
src = src.replace("cfgG=json.load(open(f'{OUT}/generator_config.json')); rep=cfgG['config']['rep']", "rep='concat_harm_mz'")
src = src.replace("C=dict(np.load(f'ai/step5_cache_{rep}.npz',allow_pickle=True))", "C=dict(np.load('out_gencv/decoder/step5_cache_concat_harm_mz.npz',allow_pickle=True))")
assert "out_gencv/decoder/step5_cache" in src and "rep='concat_harm_mz'" in src
exec(src)
p = {'h': 1024, 'L': 2, 'drop': 0.2686570360825852, 'lr': 0.0008755598553633595, 'wd': 4.4359857410204014e-05, 'bs': 256, 'zin': 0.2951983274588786}
m, b, ne = fit(p, seed=0); torch.save(dict(state=m.state_dict(), params=p, rep=rep, genes=list(g), note='retrained on 153-embryo Z'), OG + 'decoder.pt')
print('final decoder val NLL', round(b, 3), 'epochs', ne, flush=True)
@torch.no_grad()
def dec(z, ll, seed):
    torch.manual_seed(seed); out = []
    for k in range(0, len(z), 2048):
        mu, th = m(torch.tensor(z[k:k+2048], device=dev, dtype=torch.float32), torch.tensor(np.log(ll[k:k+2048]), device=dev, dtype=torch.float32))
        r = torch.distributions.Gamma(th.expand_as(mu), th.expand_as(mu) / mu.clamp_min(1e-8)).sample(); out.append(sp.csr_matrix(torch.poisson(r).cpu().numpy()))
    return sp.vstack(out).tocsr()
sp.save_npz(OG + 'C7_decoded.npz', dec(Zc[:n7], lib[:n7], 1)); sp.save_npz(OG + 'C8_decoded.npz', dec(Zc[n7:], lib[n7:], 2)); print('decoded C7/C8', flush=True)
# old-Z decoder val NLL on the same val split for reference: evaluate old decoder with OLD Z human rows
Do = torch.load(DATA + '/ai_t05/ai/step7/final_v2/decoder.pt', map_location=dev, weights_only=False)
mo = Dec(Zg.shape[1], Xg.shape[1], Do['params']['h'], Do['params']['L'], Do['params']['drop']).to(dev); mo.load_state_dict(Do['state']); mo.eval()
Zold = np.load(DATA + '/ai_t05/ai/step7/rep.npz', allow_pickle=True)['Z']; Zo = torch.tensor(np.vstack([Zold[u7], Zold[u8]]).astype(np.float32), device=dev)
with torch.no_grad():
    for nm, mm, ZZ in [('old decoder on old Z', mo, Zo), ('old decoder on NEW Z', mo, Zg), ('new decoder on NEW Z', m, Zg)]:
        v = float(np.mean([nb_nll(Xg[vai[k:k+2048]].float(), *mm(ZZ[vai[k:k+2048]], Lg[vai[k:k+2048]])).item() for k in range(0, len(vai), 2048)]))
        print('val NLL', nm, round(v, 3), flush=True)
