# gastruloid/03_staging_vs_cosmx/stage_cs78.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/assessability_all_models/stage_cs78.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Stage every gastruloid sample against the two CosMx human embryos only (CS7 and CS8); mouse onset times are not used.
#  A  = disc milestones reached in both CosMx embryos (CS7 set)
#  B  = reached in the CS8 embryo but not in the CS7 embryo (CS8-only set)
#  C  = not reached in the CS8 embryo (later than CS8)
#  not used = no clear reached / not-reached pair of calls in the CosMx embryos (partial or not assessable)
#  level of a sample = most advanced set with at least one reached milestone; milestones of earlier sets are expected
#  stage: CS7-like (level A) | CS7-to-CS8 transitional (level B, not all testable B reached) | CS8-like (all testable B reached) | beyond CS8 (any C reached)
import sys, numpy as np, pandas as pd; sys.path.insert(0, str(Path(__file__).resolve().parents[1] / '02_milestone_scoring')); import stage_lib as L
OUT = 'gall/out_v2/'; T2 = pd.read_excel(os.environ.get('HGC_TABLE_S2', str(HGC_DATA / 'Table_S2_milestones.xlsx')), sheet_name='milestones').query("`Row type` == 'milestone'").set_index('Milestone ID'); ON = pd.Series(L.ONSET); DOMN = pd.Series(L.DOM)
MS = sorted(m for m in ON.index if DOMN[m] == 'embryonic disc')
CA = pd.read_csv(OUT + 'calls_all_samples.csv', index_col=0); M = pd.read_csv(OUT + 'milestone_assessability_by_model.csv', index_col=0); INFO = pd.read_csv(OUT + 'groups.csv', index_col=0)
def norm(s):
    s = str(s); return 'reached' if s.startswith('reached') else 'partial' if s.startswith('partial') else 'not testable' if (s.startswith('not testable') or s == 'not assessable') else 'not reached'
E7 = T2['HuE#1 CS7 (CosMx)'].map(norm)[MS]; E8 = T2['HuE#2 CS8 (CosMx)'].map(norm)[MS]
A = [m for m in MS if E7[m] == 'reached' and E8[m] == 'reached']; B = [m for m in MS if E7[m] == 'not reached' and E8[m] == 'reached']; C = [m for m in MS if E7[m] == 'not reached' and E8[m] == 'not reached']; U = [m for m in MS if m not in A + B + C]
SETS = {'A': A, 'B': B, 'C': C, 'unused': U}; SET_OF = {m: k for k, v in SETS.items() for m in v}; LEV = {'A': 1, 'B': 2, 'C': 3}
print('A', A, '| B', B, '| C', C, '| not used', {m: (E7[m], E8[m]) for m in U})
def classify(st):
    st = st[MS]; lev = max([LEV[SET_OF[m]] for m in MS if st[m] == 'reached' and SET_OF[m] in LEV], default=0); tb = [m for m in B if st[m] != 'not testable']; nb = sum(st[m] == 'reached' for m in B)
    stage = 'beyond CS8' if lev == 3 else ('CS8-like' if (lev == 2 and nb == len(tb)) else 'CS7-to-CS8 transitional' if lev == 2 else 'CS7-like' if lev == 1 else 'not stageable')
    state = {}
    for m in MS:
        k = SET_OF[m]
        if k == 'unused': state[m] = 'not used: ' + st[m]
        elif st[m] == 'reached': state[m] = 'reached'
        elif st[m] == 'partial': state[m] = 'present below onset frequency'
        elif st[m] == 'not testable': state[m] = 'not testable'            # shown grey whether or not the milestone is expected
        else: state[m] = 'expected, not reached' if LEV[k] < lev else 'not yet expected'
    return lev, stage, pd.Series(state)
def cnt(st, S): return int(sum(st[m] == 'reached' for m in S)), ';'.join(m for m in S if st[m] in ('not reached', 'partial')), ';'.join(m for m in S if st[m] == 'not testable')
W = pd.read_csv('tb/out/sample_window.csv'); comp = W.groupby('group').status.apply(lambda s: ' / '.join(sorted(set(s)))).to_dict(); rows, long = [], []
def add(u, st, extra):
    st = st[MS]; lev, stage, state = classify(st); a, b = cnt(st, A), cnt(st, B)
    rows.append(dict(unit=u, **extra, stage=stage, most_advanced_set={0: '', 1: 'CS7 set', 2: 'CS8-only set', 3: 'later than CS8'}[lev], later_than_CS8_reached=';'.join(m for m in C if st[m] == 'reached'),
                     CS7_set_reached=a[0], CS7_set_not_reached=a[1], CS7_set_not_testable=a[2], CS8_only_set_reached=b[0], CS8_only_set_not_reached=b[1], CS8_only_set_not_testable=b[2],
                     expected_not_reached=';'.join(state.index[state == 'expected, not reached']), expected_not_testable=';'.join(m for m in MS if SET_OF[m] in LEV and LEV[SET_OF[m]] < lev and st[m] == 'not testable')))
    for m in MS: long.append(dict(unit=u, kind=extra['kind'], milestone_id=m, milestone=L.MNAME[m], milestone_set=SET_OF[m], mouse_onset=ON[m], call=st[m], state=state[m]))
add('Human embryo CS7 (CosMx)', T2['HuE#1 CS7 (CosMx)'].map(norm), dict(kind='embryo', dataset='', label='', hours=np.nan, composition_window=''))
add('Human embryo CS8 (CosMx)', T2['HuE#2 CS8 (CosMx)'].map(norm), dict(kind='embryo', dataset='', label='', hours=np.nan, composition_window=''))
for g in CA.columns: add(g, CA[g].map(norm), dict(kind='sample', dataset=INFO.dataset[g], label=INFO.label[g], hours=INFO.hours[g], composition_window=comp.get(g, '')))
for d in [c for c in M.columns if c not in ('milestone', 'domain', 'mouse_onset')]: add(d, M[d].map(norm), dict(kind='model (any sample)', dataset=d, label='', hours=np.nan, composition_window=''))
R = pd.DataFrame(rows); R.to_csv(OUT + 'gastruloid_stage_vs_CS7_CS8.csv', index=False); pd.DataFrame(long).to_csv(OUT + 'gastruloid_stage_vs_CS7_CS8_long.csv', index=False)
K = ['Hamazaki 2024', 'Budjan 2022', 'Minn 2020', 'Heemskerk 2024', 'Chen 2025', 'Liu 2023', 'Rossi 2021', 'Veenvliet 2020']; s = R[(R.kind == 'sample') & R.dataset.isin(K)]
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 100); pd.set_option('display.max_colwidth', 30)
print(R[(R.kind != 'sample') | R.dataset.isin(K)][['unit', 'stage', 'later_than_CS8_reached', 'CS7_set_reached', 'CS7_set_not_reached', 'CS7_set_not_testable', 'CS8_only_set_reached', 'CS8_only_set_not_reached', 'CS8_only_set_not_testable', 'expected_not_reached']].to_string(index=False))
print(s.stage.value_counts().to_dict(), '| samples with >=1 expected-not-reached:', int((s.expected_not_reached != '').sum()), 'of', len(s))
