"""Supplementary Figure 10B: composition of the CS8 descendants of the ventral / middle / dorsal CS7 node terciles under
four matchings (AIGG-OT; no transition prior; expression only with prior; expression only without prior).
Built in session 5113e657 when the panel was numbered 'Supplementary Figure 11' (messages [5270] definitions, [5273]
final redraw with Liberation Sans); the figure title string and labels 'GG-OT (Figure 6E, F)' are those of that draft
(renamed AIGG-OT / Figure 7E-F in the published figure). Input: node_DV_fate.xlsx from node_dv_fate.py (cwd).
"""
import os
import numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
T=pd.read_excel('node_DV_fate.xlsx',sheet_name='fate_by_layer')
FC={'PrP':'#33bbee','Notochord':'#0077bb','Node':'#cc3311','other':'#cfcfcf'}
LC={'ventral':'#542788','middle':'#35978F','dorsal':'#E08214'}
lab={'GG-OT (reference)':'GG-OT (Figure 6E, F)','no transition prior':'GG-OT, no transition prior','expression only':'expression only\n(spatial term = 0)','expression only, no prior':'expression only,\nno transition prior'}
def sci(p):
    m,e=f'{p:.0e}'.split('e'); return rf'${m}\times10^{{{int(e)}}}$'
W,H=558/72,767.52/72
from matplotlib.patches import Patch

# ---- [5273]
import warnings, logging; logging.getLogger('matplotlib.font_manager').setLevel(logging.ERROR)
from matplotlib import font_manager as fm
import glob
for f in glob.glob(os.path.join(os.environ.get('HGC_FONT_DIR', '.'), 'LiberationSans*.ttf')): fm.fontManager.addfont(f)   # Liberation Sans font files
plt.rcParams['font.family']='Liberation Sans'; plt.rcParams['pdf.fonttype']=42
fig=plt.figure(figsize=(W,H))
fig.text(36/558,1-40/767.52,'Supplementary Figure 11',fontsize=10.1,fontweight='bold',va='baseline')
x0,x1=205,425
ax=fig.add_axes([x0/558,1-330/767.52,(x1-x0)/558,250/767.52])
y=0
for k in lab:
    q=T[T.coupling==k].set_index('layer')
    ax.text(-(x0-40)/(x1-x0)*100,y-1,lab[k],fontsize=6.2,ha='left',va='center',linespacing=1.15)
    for L in ['ventral','middle','dorsal']:
        r=q.loc[L]; left=0
        for f in ['PrP','Notochord','Node']:
            v=r[f]; ax.barh(y,v,left=left,color=FC[f],height=0.8,lw=0)
            if v>=8: ax.text(left+v/2,y,f'{v:.0f}',fontsize=5,color='w',ha='center',va='center')
            left+=v
        ax.barh(y,max(0,100-left),left=left,color=FC['other'],height=0.8,lw=0)
        ax.text(-2,y,f"{L} (n = {int(r.n_cells)})",fontsize=5.4,ha='right',va='center',color=LC[L]); y-=1
    ax.text(104,y+2,'Node: P = '+sci(q.Fisher_P_Node_ventral_vs_dorsal.iloc[0])+'\nPrP:   P = '+sci(q.Fisher_P_PrP_ventral_vs_dorsal.iloc[0]),fontsize=5.4,va='center',linespacing=1.5)
    y-=0.7
ax.set_ylim(y+0.3,0.7); ax.set_xlim(0,100); ax.set_yticks([])
for s in ['left','top','right']: ax.spines[s].set_visible(False)
ax.tick_params(labelsize=5.5,width=0.5,length=2); ax.spines['bottom'].set_linewidth(0.5)
ax.set_xlabel('% of CS8 descendants of each CS7 node layer',fontsize=6)
ax.text(104,0.9,'ventral vs dorsal\n(Fisher exact test)',fontsize=5.4,va='bottom',color='0.35')
ax.text(-(x0-40)/(x1-x0)*100,0.9,'coupling',fontsize=5.4,va='bottom',color='0.35')
ax.legend(handles=[Patch(color=FC[f],label=f) for f in ['PrP','Notochord','Node','other']],fontsize=5.6,frameon=False,ncol=4,loc='lower left',bbox_to_anchor=(0,1.0),handlelength=0.9,handletextpad=0.35,columnspacing=0.9)
fig.savefig('FigureS11_node_couplings.pdf'); fig.savefig('FigureS11_node_couplings.png',dpi=200); plt.close(fig)
