# gastruloid/01_preprocess/loaders.py
# Source: drive F: CS6-CS7/cs7_cs8_matching/cross_species_SEU3D/gastruloid_comparison/scRNA_all_datasets/milestone_staging/code/loaders.py
# Part of human-gastrulation-cosmx (MIT licence); see README.md and PROVENANCE.md of this directory.
# Inputs are read under $HGC_DATA and outputs written under $HGC_OUT (relative sub-paths as in the original analysis).
import os
from pathlib import Path
HGC_DATA = Path(os.environ.get('HGC_DATA', 'data'))
HGC_OUT = Path(os.environ.get('HGC_OUT', 'results'))

# Group registry and loaders for the gastruloid scRNA-seq datasets (raw GEO supplementary files in $HGC_DATA/gastruloid_sc/).
import os, io, gzip, tarfile, glob, numpy as np, pandas as pd, scipy.io, scipy.sparse as sp, anndata as ad, scanpy as sc
ROOT = (str(HGC_DATA) + '/gastruloid_sc/')
def _read_mtx(mtx, feat, bc, gene_col=1):
    M = scipy.io.mmread(mtx).tocsr().T.tocsr().astype(np.float32)
    f = pd.read_csv(feat, sep='\t', header=None); b = pd.read_csv(bc, sep='\t', header=None)
    a = ad.AnnData(M, obs=pd.DataFrame(index=b[0].astype(str).values), var=pd.DataFrame(index=f[min(gene_col, f.shape[1] - 1)].astype(str).values))
    if f.shape[1] > 2: a = a[:, (f[2] == 'Gene Expression').values].copy()
    a.var_names_make_unique(); return a
def mtx_prefix(g, prefix, sep='_', feat='features'):
    d = ROOT + g + '/'; return _read_mtx(d + prefix + sep + 'matrix.mtx.gz', d + prefix + sep + feat + '.tsv.gz', d + prefix + sep + 'barcodes.tsv.gz')
def mtx_tar(g, fn):
    d = ROOT + g + '/'; out = '/tmp/gas_' + fn.split('_')[0] + '/'
    if not os.path.isdir(out): os.makedirs(out); tarfile.open(d + fn).extractall(out)
    p = glob.glob(out + '**/filtered_feature_bc_matrix/', recursive=True)[0]
    return _read_mtx(p + 'matrix.mtx.gz', p + 'features.tsv.gz', p + 'barcodes.tsv.gz')
def h5(g, fn):
    a = sc.read_10x_h5(ROOT + g + '/' + fn, gex_only=True); a.var_names_make_unique(); return a
def dense_csv(g, fn, genes_in_rows=True):
    df = pd.read_csv(ROOT + g + '/' + fn, index_col=0, compression='gzip')
    if genes_in_rows: df = df.T
    a = ad.AnnData(sp.csr_matrix(df.values.astype(np.float32)), obs=pd.DataFrame(index=df.index.astype(str)), var=pd.DataFrame(index=df.columns.astype(str))); a.var_names_make_unique(); return a
def merge(parts, names):
    for p, n in zip(parts, names): p.obs['replicate'] = n; p.obs_names = [f'{n}:{x}' for x in p.obs_names]
    return ad.concat(parts, join='outer', fill_value=0) if len(parts) > 1 else parts[0]

# id: (dataset, species, label, hours, series, order, loader)
# series: groups sharing a series id are one time course (earlier = lower order); loader: callable returning AnnData with raw counts
G = {}
def reg(gid, ds, sp_, label, h, series, order, fn): G[gid] = dict(dataset=ds, species=sp_, label=label, hours=h, series=series, order=order, load=fn)
# --- Veenvliet et al. 2020 (mouse, GSE141175)
V = 'GSE141175'
reg('Vee_TLS96', 'Veenvliet 2020', 'mouse', 'TLS precursor 96 h', 96, 'Vee_TLS', 1, lambda: mtx_tar(V, 'GSM4196547_TLS_96h.tar.gz'))
reg('Vee_TLSMG108', 'Veenvliet 2020', 'mouse', 'TLS (Matrigel) 108 h', 108, 'Vee_TLS', 2, lambda: mtx_tar(V, 'GSM4196548_TLS_108h.tar.gz'))
reg('Vee_TLSMG120', 'Veenvliet 2020', 'mouse', 'TLS (Matrigel) 120 h', 120, 'Vee_TLS', 3, lambda: mtx_tar(V, 'GSM4196549_TLS_120h.tar.gz'))
reg('Vee_G120', 'Veenvliet 2020', 'mouse', 'Gastruloid 120 h (no Matrigel)', 120, 'Vee_G', 1, lambda: mtx_tar(V, 'GSM4478171_Gastruloid_120h.tar.gz'))
reg('Vee_TLSMGCL120', 'Veenvliet 2020', 'mouse', 'TLS + CHIR + LDN 120 h', 120, 'Vee_CL', 1, lambda: mtx_tar(V, 'GSM4478172_TLSMGCL_120h.tar.gz'))
# --- Rossi et al. 2021 (mouse, GSE158999): one merged matrix with metadata
_ros = {}
def _rossi(day):
    if 'a' not in _ros:
        d = ROOT + 'GSE158999/'; M = scipy.io.mmread(d + 'GSE158999_matrix.mtx.gz').tocsr(); f = pd.read_csv(d + 'GSE158999_features.tsv.gz', sep='\t', header=None); b = pd.read_csv(d + 'GSE158999_barcodes.tsv.gz', sep='\t', header=None)
        md = pd.read_csv(d + 'GSE158999_metadata.tsv.gz', sep='\t', index_col=0); _ros['md'] = md
        if M.shape[0] == len(f): M = M.T.tocsr()
        a = ad.AnnData(M.astype(np.float32), obs=pd.DataFrame(index=b[0].astype(str).values), var=pd.DataFrame(index=f[1 if f.shape[1] > 1 else 0].astype(str).values)); a.var_names_make_unique(); _ros['a'] = a
    a = _ros['a']; md = _ros['md']; idx = md.index[md['stage'].astype(str) == f'Day{day}']; b = a[a.obs_names.isin(idx)].copy(); b.obs['batch'] = md.loc[b.obs_names, 'Dataset'].values; return b
for dy in [4, 5, 6, 7]: reg(f'Ros_d{dy}', 'Rossi 2021', 'mouse', f'Cardiogenic gastruloid day {dy}', dy * 24, 'Ros', dy, (lambda dy=dy: _rossi(dy)))
# --- EMLOC (human, GSE194356)
reg('Emloc_D7', 'Olmsted & Paluh 2021', 'human', 'EMLOC day 7', 168, 'Emloc', 1, lambda: h5('GSE194356', 'GSM5834049_scRNA_D07.h5'))
reg('Emloc_D16', 'Olmsted & Paluh 2021', 'human', 'EMLOC day 16', 384, 'Emloc', 2, lambda: h5('GSE194356', 'GSM5834050_scRNA_D16.h5'))
# --- Hamazaki et al. 2024 (human, GSE208369) from the R export of the GEO Seurat objects
EXP = (str(HGC_DATA) + '/GSE208369/export/')
def _ham(t):
    M = scipy.io.mmread(EXP + t + '_counts.mtx').tocsr().T.tocsr().astype(np.float32)
    a = ad.AnnData(M, obs=pd.read_csv(EXP + t + '_meta.csv').set_index('cell'), var=pd.DataFrame(index=pd.read_csv(EXP + t + '_genes.csv').gene.values)); a.var_names_make_unique(); return a
for t, h in [('hGas_0h', 0), ('hGas_24h', 24), ('hGas_48h', 48), ('hGas_72h', 72), ('hGas_96h', 96)]: reg('Ham_' + t[5:], 'Hamazaki 2024', 'human', f'Gastruloid {h} h', h, 'Ham', h, (lambda t=t: _ham(t)))
reg('Ham_RA96', 'Hamazaki 2024', 'human', 'RA-gastruloid 96 h', 96, 'Ham_RA', 1, lambda: _ham('RA_hGas_96h'))
reg('Ham_RA120', 'Hamazaki 2024', 'human', 'RA-gastruloid 120 h', 120, 'Ham_RA', 2, lambda: _ham('RA_hGas_120h'))
reg('Ham_RALDN', 'Hamazaki 2024', 'human', 'LDN-treated RA-gastruloid 120 h', 120, 'Ham_LDN', 1, lambda: _ham('RA_LDN'))
# --- Miao et al. 2023 somitoid (human, GSE194214)
for k, dy in [('d1', 1), ('d2', 2), ('d3', 3), ('d5', 5)]: reg(f'Som_{k}', 'Miao 2023', 'human', f'Somitoid day {dy}', dy * 24, 'Som', dy, (lambda k=k, dy=dy: mtx_prefix('GSE194214', {'d1': 'GSM5830919', 'd2': 'GSM5830920', 'd3': 'GSM5830921', 'd5': 'GSM5830922'}[k] + f'_somitoid_{k}')))
# --- Yamanaka et al. 2023 axioloid (human, GSE199571)
AX = {'48h': ('GSM5975287', ['48h']), '72h': ('GSM5975288', ['72h']), '96h': (None, [('GSM5975289', '96h_exp1'), ('GSM5975290', '96h_exp2')]), '96h_MG': (None, [('GSM5975291', '96h_MG_exp1'), ('GSM5975292', '96h_MG_exp2')]),
      '96h_MG_RA': ('GSM5975293', ['96h_MG_RA']), '96h_MG_RAL': ('GSM5975294', ['96h_MG_RAL']), '120h': ('GSM5975295', ['120h']), '120h_MG': ('GSM5975296', ['120h_MG']), '120h_MG_RA': ('GSM5975297', ['120h_MG_RA']), '120h_MG_RAL': ('GSM5975298', ['120h_MG_RAL'])}
def _ax(k):
    g, parts = AX[k]
    if g: return mtx_prefix('GSE199571', f'{g}_{parts[0]}')
    return merge([mtx_prefix('GSE199571', f'{gg}_{nm}') for gg, nm in parts], [nm for _, nm in parts])
_AXL = {'48h': ('hAxioloid 48 h', 48, 'Ax', 1), '72h': ('hAxioloid 72 h', 72, 'Ax', 2), '96h': ('hAxioloid 96 h', 96, 'Ax', 3), '120h': ('hAxioloid 120 h', 120, 'Ax', 4),
        '96h_MG': ('hAxioloid + Matrigel 96 h', 96, 'Ax_MG', 1), '120h_MG': ('hAxioloid + Matrigel 120 h', 120, 'Ax_MG', 2), '96h_MG_RA': ('hAxioloid + Matrigel + RA 96 h', 96, 'Ax_RA', 1), '120h_MG_RA': ('hAxioloid + Matrigel + RA 120 h', 120, 'Ax_RA', 2),
        '96h_MG_RAL': ('hAxioloid + Matrigel + retinal 96 h', 96, 'Ax_RAL', 1), '120h_MG_RAL': ('hAxioloid + Matrigel + retinal 120 h', 120, 'Ax_RAL', 2)}
for k, (lab, h, se, o) in _AXL.items(): reg('Ax_' + k, 'Yamanaka 2023', 'human', lab, h, se, o, (lambda k=k: _ax(k)))
# --- Gribaudo et al. 2023 spinoid (human, GSE215983): dense csv
reg('Gri_spinoid7', 'Gribaudo 2023', 'human', 'Spinoid (hTLS) day 7', 168, 'Gri', 1, lambda: dense_csv('GSE215983', 'GSM6652420_matrix_spinoids10x.csv.gz', genes_in_rows=True))
# --- Makwana et al. 2025 hTLS (human, GSE268451)
for k, g, h in [('72', 'GSM8291523_TIL1', 72), ('96', 'GSM8291524_TIL2', 96), ('120', 'GSM8291525_TIL3', 120)]:
    reg('Mak_' + k, 'Makwana 2025', 'human', f'hTLS {h} h', h, 'Mak', h, (lambda g=g: mtx_prefix('GSE268451', g, '.')))
# --- Minn et al. 2020 (human 2D, GSE144897)
reg('Min_44', 'Minn 2020', 'human', '2D gastruloid 44 h', 44, 'Min', 1, lambda: merge([mtx_prefix('GSE144897', 'GSM4300502_gastruloid1', '.', 'genes'), mtx_prefix('GSE144897', 'GSM4300503_gastruloid2', '.', 'genes')], ['g1', 'g2']))
reg('Min_48re', 'Minn 2020', 'human', '2D gastruloid 48 h (reseeded)', 48, 'Min_re', 1, lambda: mtx_prefix('GSE144897', 'GSM4300504_reseed', '.', 'genes'))
# --- Chen et al. 2025 (human 2D, GSE262081)
C = 'GSE262081'
def _chen(files, names): return merge([h5(C, f) for f in files], names)
CH = {'48': ['GSM8157259_4830-KJ-1_filtered_feature_bc_matrix.h5', 'GSM8157262_9704-BC-2_48hr_filtered_feature_bc_matrix.h5'], '72': ['GSM8157260_4830-KJ-2_filtered_feature_bc_matrix.h5', 'GSM8157262_9704-BC-3_72hr_filtered_feature_bc_matrix.h5'],
      '96': ['GSM8157261_4830-KJ-3_filtered_feature_bc_matrix.h5', 'GSM8157262_9704-BC-4_96hr_filtered_feature_bc_matrix.h5'], 'D6': ['GSM8633801_11288-BC-2_D6_filtered_feature_bc_matrix.h5'], 'D8': ['GSM8633801_11288-BC-3_D8_filtered_feature_bc_matrix.h5'], 'D10': ['GSM8633801_11288-BC-4_D10_filtered_feature_bc_matrix.h5']}
for i, (k, fl) in enumerate(CH.items()):
    h = {'48': 48, '72': 72, '96': 96, 'D6': 144, 'D8': 192, 'D10': 240}[k]; reg('Chen_' + k, 'Chen 2025', 'human', f'2D gastruloid {h} h' if k[0] != 'D' else f'2D gastruloid day {k[1:]}', h, 'Chen', i + 1, (lambda fl=fl: _chen(fl, [f'rep{j + 1}' for j in range(len(fl))])))
# --- Heemskerk lab 2D (human, GSE271604): rep1 dense counts csv + rep2 h5
reg('Hee_42', 'Heemskerk 2024', 'human', 'Micropattern 2D gastruloid 42 h', 42, 'Hee', 1, lambda: merge([dense_csv('GSE271604', 'GSE271604_42h_rep1_filtered_Counts.csv.gz', genes_in_rows=True), h5('GSE271604', 'GSM8373031_42h_rep2_filtered_feature_bc_matrix.h5')], ['rep1', 'rep2']))
