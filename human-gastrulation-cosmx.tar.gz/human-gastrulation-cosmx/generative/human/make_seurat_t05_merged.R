# Seurat object for the merged 17,378-cell t = 0.5 matrix; same construction as make_seurat_t05.R of the existing deliverable (paths and description changed; check plots omitted).
suppressMessages({library(Seurat); library(Matrix)})
d <- file.path(Sys.getenv("HGC_GEN_ROOT", "."), "out_gencv/human_fill_1559/merged_t05_expression_matrix_17378/")
out <- paste0(d,"t05_AI_V1a_seurat.rds"); stopifnot(!file.exists(out) || Sys.getenv("FILL_REWRITE")=="1")   # FILL_REWRITE: replace this workflow's own earlier output only
m <- as(readMM(paste0(d,"t05_counts.mtx")), "CsparseMatrix")
g <- read.csv(paste0(d,"genes.csv"))$gene
cl <- read.csv(paste0(d,"t05_cells.csv"), check.names=FALSE)
pr <- read.csv(paste0(d,"t05_CS8type_probabilities.csv"), check.names=FALSE)
stopifnot(identical(pr$cell, cl$cell))
rownames(m) <- g; colnames(m) <- cl$cell; rownames(cl) <- cl$cell
meta <- cbind(cl, pr[, -1])
names(meta)[names(meta)=="label_short"] <- "ggot_CS8_destination"
names(meta)[names(meta)=="t05_pred_CS8type"] <- "annotation"
meta$annotation <- factor(meta$annotation, levels=c("EPI","aECT","pECT","NNE","CLE","PS","Nas.Meso","Para.Meso","Rostral.Meso","LP.Meso","Heart.Meso","Node","Notochord","PrP","DE","VE1","VE2"))
o <- CreateSeuratObject(counts=m, project="t05_AI", assay="RNA", meta.data=meta, min.cells=0, min.features=0)
o <- NormalizeData(o, normalization.method="LogNormalize", scale.factor=1e4, verbose=FALSE)
cen <- data.frame(x=cl$AP_um, y=cl$LR_um, cell=cl$cell)
o[["t05"]] <- CreateFOV(CreateCentroids(cen), type="centroids", assay="RNA")
sp2 <- as.matrix(cl[, c("AP_um","LR_um")]); colnames(sp2) <- c("spatial_1","spatial_2")
o[["spatial"]] <- CreateDimReducObject(embeddings=sp2, key="spatial_", assay="RNA")
sp3 <- as.matrix(cl[, c("AP_frac","LR_frac","DV_gap_units")]); colnames(sp3) <- c("frame_1","frame_2","frame_3")
o[["embryo_frame"]] <- CreateDimReducObject(embeddings=sp3, key="frame_", assay="RNA")
Idents(o) <- "annotation"
o@misc$description <- paste(
 "AI-generated t = 0.5 state between CS7 (HuE#1) and CS8 (HuE#2): one cell per GG-OT-matched CS7 cell (17,378 = 15,819 cells of the earlier object, unchanged and first, plus 1,559 fill-in cells; meta column fill_1559).",
 "Expression: same generator, latent and decoder for all cells; counts = generator seed-0 sample; data = LogNormalize (1e4).",
 "Space: AP_um/LR_um = straight midpoint of the CS7 cell and its CS8 partner(s) in the normalised embryo frame, x 1138.3 / 497.5 um; DV in gap units.",
 "annotation = CS8-trained logistic classifier (17 types), averaged over 5 seeds; prob_* = class probabilities; ggot_CS8_destination = dominant GG-OT CS8 destination of the source CS7 cell.")
saveRDS(o, out)
print(o); print(Images(o)); print(Reductions(o)); print(table(o$fill_1559)); cat(as.character(packageVersion("Seurat")), R.version.string, "\n")
