# Repository: human-gastrulation-cosmx (MIT licence) — module cosmx/
# Source: [F:]/CS6-CS7/cs7_five_pop_curves/export_five.R (2026-10-03; artifact 12b37487)
# sha256 of original: ef4bfc1775590f5e4cff318dcc7362732448a1cf93f1c38c6bc1b4b6e4067434
# Methods paragraphs: P358, P361
# Produces: handoff/five_counts.mtx, five_genes.csv, five_cells.csv (HuE#1 EPI, ECT, Node, APS, PS;
#     curated_kept)
# Edits/notes: object path -> HGC_DATA; handoff folder created.
DATA <- normalizePath(Sys.getenv('HGC_DATA', 'data'), mustWork = FALSE)   # raw inputs (see cosmx/README.md)
OUT <- Sys.getenv('HGC_OUT', 'results'); dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
setwd(OUT)                                                                       # relative paths below are inside OUT

dir.create('handoff', showWarnings = FALSE)   # added: intermediate folder inside HGC_OUT
suppressPackageStartupMessages({library(Seurat); library(Matrix)})
o <- readRDS(file.path(DATA, "obj6_obj7_merged_curated_final.rds"))
md <- o@meta.data
TG7 <- c("Epiblast (EPI)","Ectoderm (ECT)",
         "Node","Anterior primitive streak (APS)","Primitive streak (PS)")
lab <- as.character(md$`39Type`)
cat("labels found:", paste(intersect(TG7, unique(lab)), collapse=" | "), "\n")
sel <- md$source_object=="obj6" & lab %in% TG7 & as.logical(md$curated_kept)
cn <- LayerData(o[["RNA"]], "counts")[, sel, drop=FALSE]
det <- Matrix::rowSums(cn > 0); keep <- det >= 10
cat("cells:", ncol(cn), "| genes detected in >=10 cells:", sum(keep), "\n")
print(table(lab[sel]))
writeMM(cn[keep, , drop=FALSE], "handoff/five_counts.mtx")
write.csv(data.frame(gene=rownames(cn)[keep], n_det=as.integer(det[keep])), "handoff/five_genes.csv", row.names=FALSE)
write.csv(data.frame(cell=md$cell[sel], label=lab[sel], x=md$x_um[sel], y=md$y_um[sel], z=md$z_um[sel], nCount=md$nCount[sel]),
          "handoff/five_cells.csv", row.names=FALSE)
cat("written", round(file.size("handoff/five_counts.mtx")/1e6,1), "MB\n")
