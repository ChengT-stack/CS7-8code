"""Normalised anatomical frames (A-P arc-length fraction, L-R fraction, D-V depth in epithelium-endoderm gap units)
and section-sampling weights for the CS7 and CS8 disc cells.
Reconstructed verbatim from transcript frame 0f4081de (data-prep sub-agent of session 824ef1ce), messages [30], [32], [34]
(EPI/AXIAL/ENDO definitions), [38], [40] (CSV part only; QC figure code removed) and [46]. Only paths changed; the working
directory is $HGC_DATA/cs7_cs8_matching/dataprep (outputs frames/{CS7,CS8}_frames.csv, *_z_weights.csv, frame_spans.json,
frame_landmark_checks.json). [glue] lines are marked.
"""
import os
os.environ["KMP_AFFINITY"]="disabled"; os.environ["OMP_PROC_BIND"]="false"; os.environ["OMP_NUM_THREADS"]="8"
import numpy as np, pandas as pd, json
DATA = os.environ.get('HGC_DATA', 'data')   # input data root (see README)
os.chdir(os.path.join(DATA, "cs7_cs8_matching", "dataprep"))   # [glue] original cwd = sub-agent workspace holding export/ and frames/

# ---- [32] frames: origins, axes, landmark checks
os.makedirs("frames", exist_ok=True)
ctx = pd.read_csv("export/all_kept_cells_coords.csv")
cells = {e: pd.read_csv(f"export/{e}_cells.csv") for e in ["CS7","CS8"]}
EXE = ['Trophoblast','Distal yolk sac endoderm (Dist.ys.Endo)','Proximal yolk sac endoderm (Prox.ys.Endo)','Parietal yolk sac endoderm (Pari.Endo)','Yolk sac mesoderm (ys.Meso)','Chorion-allantois mesenchyme (ChA.Mes)']
def frame(e, df_all):
    a = df_all[df_all.embryo==e]
    if e=="CS7":
        ctr = a[["x_um","y_um","z_um"]].median().values
        B = {"AP":(-1,0,0),"LR":(0,0,1),"DV":(0,1,0)}
        post = a[a.label=='Primitive streak (PS)']; ant = a[a.label=='Anterior visceral endoderm (AVE)']
        origin_desc = "median of all curated_kept CS7 (obj6) cells (Signalling notes, 'figure frame')"
    else:
        ctr = a.loc[a.disc_main_body, ["x_um","y_um","z_um"]].median().values
        B = {"AP":(0,1,0),"LR":(0,0,1),"DV":(1,0,0)}
        post = a[a.label=='Primitive streak (PS)']; ant = a[a.label=='Prechordal plate']
        origin_desc = "median of disc_main_body curated_kept CS8 (obj7) cells (Transport notes entries 13-14)"
    M = np.array([B["AP"],B["LR"],B["DV"]],float)
    det = np.linalg.det(M.T)
    def tf(d): return (d[["x_um","y_um","z_um"]].values-ctr)@M.T
    epi = a[a.label.str.contains(r'\(EPI\)|ectoderm|\(ECT\)|\(CLE\)')]
    chk = {"origin_xyz_um":ctr.tolist(),"origin_desc":origin_desc,"det_[AP,LR,DV]":float(det),
           "AP_median_PS":float(np.median(tf(post)[:,0])),
           "anterior_landmark": "AVE" if e=="CS7" else "Prechordal plate",
           "AP_median_anterior_landmark":float(np.median(tf(ant)[:,0])),
           "DV_median_extraembryonic":float(np.median(tf(a[a.label.isin(EXE)])[:,2])),
           "DV_median_disc_epithelium":float(np.median(tf(epi)[:,2]))}
    return M, ctr, chk
F = {}; CHK={}
for e in ["CS7","CS8"]:
    M, ctr, chk = frame(e, ctx); F[e]=(M,ctr); CHK[e]=chk; print(e, json.dumps(chk))
    assert chk["AP_median_PS"] > chk["AP_median_anterior_landmark"]
json.dump(CHK, open("frames/frame_landmark_checks.json","w"), indent=1)

# ---- [34] layer definitions (only the three dictionaries of this exploratory cell are used later)
EPI_TYPES = {"CS7":["EPI","ECT"], "CS8":["EPI","aECT","pECT","CLE","NNE"]}
AXIAL = {"CS7":["Node","APS","PS"], "CS8":["Node","Notochord","PrP","PS"]}
ENDO = {"CS7":["DE","VE1","VE2","AVE"], "CS8":["DE","VE1","VE2"]}
for e in ["CS7","CS8"]:   # [34] frame coordinates of the exported cells
    M,ctr = F[e]; d = cells[e]
    xyz = (d[["x_um","y_um","z_um"]].values-ctr)@M.T
    d["AP_um"],d["LR_um"],d["DV_um"] = xyz.T

# ---- [38] LOWESS epithelium/endoderm surfaces, normalised coordinates, z-weights
from scipy.spatial import cKDTree
def lowess2d(P_fit, v_fit, Q, r=75.0, kmin=20, iters=2):
    """robust local-linear regression of v on 2D P, evaluated at Q. returns S, gx, gy, n_local, dist_nearest"""
    tree = cKDTree(P_fit); S=np.full(len(Q),np.nan); G=np.zeros((len(Q),2)); N=np.zeros(len(Q),int)
    dn,_ = tree.query(Q)
    nb = tree.query_ball_point(Q, r)
    dk,ik = tree.query(Q, kmin)
    for i,q in enumerate(Q):
        idx = np.array(nb[i]) if len(nb[i])>=kmin else ik[i]
        X = P_fit[idx]-q; y=v_fit[idx]; dd=np.sqrt((X**2).sum(1)); h=max(r, dd.max()*1.001)
        w=(1-(dd/h)**3)**3
        A=np.c_[np.ones(len(idx)),X]
        for it in range(iters+1):
            sw=np.sqrt(w); beta,*_=np.linalg.lstsq(A*sw[:,None], y*sw, rcond=None)
            res=y-A@beta; s=np.median(np.abs(res))*1.4826+1e-6
            w=w*(np.clip(1-(res/(6*s))**2,0,None)**2) if it<iters else w
        S[i]=beta[0]; G[i]=beta[1:]; N[i]=len(idx)
    return S,G[:,0],G[:,1],N,dn
OUT={}; SPAN={}
for e in ["CS7","CS8"]:
    d=cells[e].copy(); ep=d[d.label_short.isin(EPI_TYPES[e])]; en=d[d.label_short.isin(ENDO[e])]
    Q=d[["AP_um","LR_um"]].values
    Se,gxe,gye,Ne,dne = lowess2d(ep[["AP_um","LR_um"]].values, ep.DV_um.values, Q)
    Sn,gxn,gyn,Nn,dnn = lowess2d(en[["AP_um","LR_um"]].values, en.DV_um.values, Q)
    off = d.DV_um.values-Se
    s = -1.0 if np.median(off[d.label_short.isin(ENDO[e])])>0 else 1.0   # dorsal (+) = epithelium side away from endoderm
    d["DV_dorsal_sign"]=s
    d["DV_um_to_surface"] = s*off/np.sqrt(1+gxe**2+gye**2)
    gap = s*(Se-Sn)            # local epithelium-endoderm separation along DV (positive = endoderm ventral)
    d["epi_surface_DV_um"]=Se; d["endo_surface_DV_um"]=Sn; d["local_gap_um"]=gap
    d["DV_gap_units"] = d.DV_um_to_surface/np.clip(gap,10,None)
    d["dist_to_nearest_epi_um"]=dne; d["dist_to_nearest_endo_um"]=dnn
    d["outside_epi_footprint"]=dne>100; d["outside_endo_footprint"]=dnn>100
    # AP / LR normalisation
    p1,p99=np.percentile(ep.AP_um,[1,99]); l1,l99=np.percentile(ep.LR_um,[1,99]); mid=np.median(d.loc[d.label_short.isin(AXIAL[e]),"LR_um"])
    d["AP_frac"]=(d.AP_um-p1)/(p99-p1); d["LR_frac"]=(d.LR_um-mid)/(l99-l1)
    q1,q99=np.percentile(d.AP_um,[1,99]); d["AP_frac_disc20"]=(d.AP_um-q1)/(q99-q1)
    # z weights from all curated_kept sections of the embryo
    zall=np.sort(ctx.loc[ctx.embryo==e,"z_um"].unique()); dz=np.diff(zall)
    w=np.empty(len(zall)); w[1:-1]=(dz[:-1]+dz[1:])/2; w[0]=dz[0]; w[-1]=dz[-1]
    zw=dict(zip(zall,w)); d["z_rep_um"]=d.z_um.map(zw); d["z_weight"]=d.z_rep_um/d.z_rep_um.mean()
    SPAN[e]=dict(AP_p1=p1,AP_p99=p99,AP_span_epi=p99-p1,LR_p1=l1,LR_p99=l99,LR_span_epi=l99-l1,LR_midline_axial=mid,AP_span_disc20=q99-q1,dorsal_sign=s,
                 n_sections=len(zall),z_spacings=dict(zip(*[x.tolist() for x in np.unique(dz,return_counts=True)])))
    OUT[e]=d
    g=d.groupby("label_short")
    print(e, "sign",s, "| gap median (epi cells)", round(np.median(gap[d.label_short.isin(EPI_TYPES[e])]),1), "| outside epi footprint", d.outside_epi_footprint.mean().round(3), "outside endo", d.outside_endo_footprint.mean().round(3))
    print(g[["DV_um_to_surface","DV_gap_units","AP_frac","LR_frac","z_weight"]].median().round(2).to_string())
json.dump(SPAN, open("frames/frame_spans.json","w"), indent=1, default=float)

# ---- [40] dorsal-positive DV in gap units; write frames (QC figure removed)
for e in ["CS7","CS8"]:
    d=OUT[e]; s=d.DV_dorsal_sign.values
    d["DV_gap_units"]=(s*(d.DV_um-d.epi_surface_DV_um))/np.clip(d.local_gap_um,10,None)
    d["local_gap_um_normal"]=d.local_gap_um/np.sqrt(1+np.gradient(d.epi_surface_DV_um)**2) if False else d.local_gap_um
    cols=["cell","label","label_short","batch","section","z_um","AP_um","LR_um","DV_um","AP_frac","LR_frac","AP_frac_disc20","DV_um_to_surface","DV_gap_units",
          "epi_surface_DV_um","endo_surface_DV_um","local_gap_um","DV_dorsal_sign","dist_to_nearest_epi_um","dist_to_nearest_endo_um","outside_epi_footprint","outside_endo_footprint","z_rep_um","z_weight"]
    d[cols].to_csv(f"frames/{e}_frames.csv", index=False)
    d[["cell","section","z_um","z_rep_um","z_weight"]].to_csv(f"frames/{e}_z_weights.csv", index=False)
    print(e, d.groupby("label_short").DV_gap_units.median().round(2).to_dict())


# ---- [46] arc-length A-P fraction along the epithelium surface
for e in ["CS7","CS8"]:
    d=OUT[e]; ep=d[d.label_short.isin(EPI_TYPES[e])]; mid=SPAN[e]["LR_midline_axial"]
    apg=np.linspace(d.AP_um.min()-1,d.AP_um.max()+1,400); Qg=np.c_[apg,np.full_like(apg,mid)]
    Se_g=lowess2d(ep[["AP_um","LR_um"]].values,ep.DV_um.values,Qg)[0]
    # restrict slope to epithelium footprint; outside, continue with the edge slope (linear extrapolation of arc)
    inside=(apg>=np.percentile(ep.AP_um,0.5))&(apg<=np.percentile(ep.AP_um,99.5))
    slope=np.gradient(Se_g,apg); slope[~inside]=np.nan; slope=pd.Series(slope).ffill().bfill().values
    arc=np.concatenate([[0],np.cumsum(np.sqrt(1+slope[:-1]**2)*np.diff(apg))])
    s_of=lambda a: np.interp(a,apg,arc)
    s1,s99=s_of(SPAN[e]["AP_p1"]),s_of(SPAN[e]["AP_p99"])
    d["AP_arc_um"]=s_of(d.AP_um.values)-s1; d["AP_arc_frac"]=d.AP_arc_um/(s99-s1)
    SPAN[e]["AP_arc_span_epi"]=s99-s1; SPAN[e]["disc_tilt_deg_median"]=float(np.degrees(np.arctan(np.nanmedian(np.abs(slope[inside])))))
    print(e, "arc span", round(s99-s1), "projected span", round(SPAN[e]["AP_span_epi"]), "median tilt deg", round(SPAN[e]["disc_tilt_deg_median"],1))
    cols=["cell","label","label_short","batch","section","z_um","AP_um","LR_um","DV_um","AP_frac","AP_arc_um","AP_arc_frac","LR_frac","AP_frac_disc20","DV_um_to_surface","DV_gap_units",
          "epi_surface_DV_um","endo_surface_DV_um","local_gap_um","DV_dorsal_sign","dist_to_nearest_epi_um","dist_to_nearest_endo_um","outside_epi_footprint","outside_endo_footprint","z_rep_um","z_weight"]
    d[cols].to_csv(f"frames/{e}_frames.csv", index=False)
json.dump(SPAN, open("frames/frame_spans.json","w"), indent=1, default=float)
print(OUT["CS8"].groupby("label_short")[["AP_frac","AP_arc_frac"]].median().round(2).T.to_string())
