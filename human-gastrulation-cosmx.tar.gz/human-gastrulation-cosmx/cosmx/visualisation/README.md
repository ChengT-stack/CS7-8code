# cosmx/visualisation

Figure 2C, 2H/2I values, Supplementary Figure 5F, SF4B-style panels, Supplementary Materials 1-2 and 2D section pages.

Inputs, run order, Methods-to-panel table and gaps: see [../README.md](../README.md). Origin and sha256 of every file: [../PROVENANCE.md](../PROVENANCE.md).
